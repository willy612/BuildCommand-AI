from db.models import ProjectSetupProgress, Document, ScheduleActivity, ProjectSubcontractor, ProjectRoleAssignment

def ensure_progress(db,project_id):
    row=db.query(ProjectSetupProgress).filter(ProjectSetupProgress.project_id==project_id).first()
    if not row:
        row=ProjectSetupProgress(project_id=project_id)
        db.add(row); db.commit(); db.refresh(row)
    return row

def refresh_progress(db,project):
    row=ensure_progress(db,project.id)
    row.company_info_complete=bool(project.name and project.project_number)
    row.team_complete=db.query(ProjectRoleAssignment).filter(
        ProjectRoleAssignment.project_id==project.id,
        ProjectRoleAssignment.active==True
    ).count()>0
    row.jurisdiction_complete=bool(project.jurisdiction)
    row.documents_complete=db.query(Document).filter(Document.project_id==project.id).count()>0
    row.schedule_complete=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project.id).count()>0
    row.subcontractors_complete=db.query(ProjectSubcontractor).filter(ProjectSubcontractor.project_id==project.id).count()>0
    row.requirements_complete=row.jurisdiction_complete and row.documents_complete
    row.completed=all([
        row.company_info_complete,row.team_complete,row.jurisdiction_complete,
        row.documents_complete,row.schedule_complete,row.subcontractors_complete,row.requirements_complete
    ])
    db.commit(); db.refresh(row)
    return row

def percent_complete(row):
    vals=[
        row.company_info_complete,row.team_complete,row.jurisdiction_complete,
        row.documents_complete,row.schedule_complete,row.subcontractors_complete,row.requirements_complete
    ]
    return round(sum(1 for x in vals if x)/len(vals)*100)
