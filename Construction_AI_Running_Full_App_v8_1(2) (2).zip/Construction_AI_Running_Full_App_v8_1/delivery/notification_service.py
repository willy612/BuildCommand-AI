from db.models import OutboundNotification,SubcontractorContact,User

def queue_user_notification(db,project_id,user_id,subject,body,channel="IN_APP"):
    user=db.query(User).filter(User.id==user_id).first()
    recipient=user.email if user else ""
    row=OutboundNotification(
        project_id=project_id,user_id=user_id,channel=channel,
        recipient=recipient,subject=subject,body=body,status="DRAFT"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def queue_sub_notification(db,project_id,subcontractor_id,subject,body,channel="EMAIL"):
    contact=db.query(SubcontractorContact).filter(
        SubcontractorContact.subcontractor_id==subcontractor_id,
        SubcontractorContact.active==True
    ).order_by(SubcontractorContact.primary_contact.desc()).first()
    recipient=contact.email if contact else ""
    row=OutboundNotification(
        project_id=project_id,subcontractor_id=subcontractor_id,channel=channel,
        recipient=recipient,subject=subject,body=body,status="DRAFT"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def approve_notification(db,notification_id):
    row=db.query(OutboundNotification).filter(OutboundNotification.id==notification_id).first()
    if not row: return False
    row.status="APPROVED_TO_SEND"
    db.commit()
    return True
