import base64, json, os
from pathlib import Path
from datetime import datetime

try:
    from openai import OpenAI
except ImportError:
    OpenAI=None

SYSTEM="""
You are a construction field-photo analysis assistant.

Analyze only what is visibly supported by the image. Do not declare code compliance,
inspection approval, structural adequacy, safety compliance, or completion from appearance alone.

Return valid JSON:
{
 "summary":"",
 "observations":[{"category":"progress|quality|safety|coordination|material|other",
                  "statement":"","confidence":"high|medium|low"}],
 "possible_issues":[{"type":"quality|safety|coordination|damage|missing_work",
                     "statement":"","confidence":"high|medium|low",
                     "requires_human_verification":true}],
 "possible_task_ids":[],
 "recommended_followups":[],
 "proposed_changes":[]
}

Every proposed project-state change must contain "requires_human_approval": true.
"""

def analyze_photo(image_bytes, filename, task_catalog=None):
    if OpenAI is None or not os.getenv("OPENAI_API_KEY"):
        return {
            "summary":f"Photo uploaded: {filename}",
            "observations":[{"category":"other","statement":"Photo stored for human review; AI vision unavailable.","confidence":"low"}],
            "possible_issues":[],
            "possible_task_ids":[],
            "recommended_followups":["Review the photo and assign it to the correct activity/area."],
            "proposed_changes":[]
        }

    mime="image/jpeg"
    if filename.lower().endswith(".png"): mime="image/png"
    data=base64.b64encode(image_bytes).decode("ascii")
    url=f"data:{mime};base64,{data}"

    client=OpenAI()
    response=client.responses.create(
        model=os.getenv("OPENAI_VISION_MODEL","gpt-5"),
        instructions=SYSTEM,
        input=[{
            "role":"user",
            "content":[
                {"type":"input_text","text":f"TASK CATALOG:\n{json.dumps(task_catalog or [])}\nAnalyze this field photo."},
                {"type":"input_image","image_url":url,"detail":"high"}
            ]
        }]
    )
    raw=response.output_text.strip()
    if raw.startswith("```"):
        raw=raw.strip("`")
        if raw.lower().startswith("json"): raw=raw[4:].strip()
    try:
        result=json.loads(raw)
    except Exception:
        result={"summary":raw,"observations":[],"possible_issues":[],"possible_task_ids":[],"recommended_followups":[],"proposed_changes":[]}
    for c in result.get("proposed_changes",[]):
        c["requires_human_approval"]=True
    return result

def new_photo_record(filename, analysis, area="", task_id=""):
    return {
        "id":f"photo-{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
        "created_at":datetime.now().isoformat(timespec="seconds"),
        "filename":filename,
        "area":area,
        "task_id":task_id,
        "analysis":analysis,
        "status":"PENDING_APPROVAL"
    }
