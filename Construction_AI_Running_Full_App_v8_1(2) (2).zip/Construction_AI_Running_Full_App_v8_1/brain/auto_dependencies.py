import json
from pathlib import Path

BASE=Path(__file__).resolve().parent.parent
TEMPLATES=BASE/"knowledge"/"master"/"dependency_templates.json"

def load_templates():
    return json.loads(TEMPLATES.read_text(encoding="utf-8"))

def generate_dependencies(state, tasks):
    templates=load_templates()
    docs=state.get("documents",[])
    current_docs=[d for d in docs if d.get("status") in ("CURRENT","APPROVED")]
    by_type={}
    for d in current_docs:
        by_type.setdefault(d.get("document_type") or d.get("discipline"),[]).append(d)

    generated={
        "task_document_links":[],
        "task_prerequisites":dict(state.get("task_prerequisites",{})),
        "suggested_procurement_items":[],
        "suggested_requirements":[]
    }

    for task in tasks:
        tid=task["id"]
        template=templates.get(tid,{})
        if not template:
            continue

        for dtype in template.get("required_documents",[]):
            matches=by_type.get(dtype,[])
            for d in matches:
                generated["task_document_links"].append({
                    "task_id":tid,
                    "document_id":d["document_id"],
                    "reason":f"{dtype} project document linked automatically."
                })

        prereqs=generated["task_prerequisites"].setdefault(tid,{})
        for p in template.get("typical_prerequisites",[]):
            prereqs.setdefault(p,False)

        for name in template.get("typical_submittals",[]):
            generated["suggested_procurement_items"].append({
                "name":name,
                "task_ids":[tid],
                "required":True,
                "source":"dependency_template"
            })

        generated["suggested_requirements"].append({
            "task_id":tid,
            "permit_expected":bool(template.get("required_permit")),
            "inspection_expected":bool(template.get("required_inspection")),
            "testing_expected":bool(template.get("required_testing")),
            "safety_expected":bool(template.get("required_safety"))
        })

    return generated

def apply_generated_dependencies(state, generated):
    existing_links={(x.get("task_id"),x.get("document_id")) for x in state.get("task_document_links",[])}
    for link in generated.get("task_document_links",[]):
        key=(link.get("task_id"),link.get("document_id"))
        if key not in existing_links:
            state.setdefault("task_document_links",[]).append(link)
            existing_links.add(key)

    state["task_prerequisites"]=generated.get("task_prerequisites",state.get("task_prerequisites",{}))
    state["suggested_procurement_items"]=generated.get("suggested_procurement_items",[])
    state["suggested_requirements"]=generated.get("suggested_requirements",[])
    return state
