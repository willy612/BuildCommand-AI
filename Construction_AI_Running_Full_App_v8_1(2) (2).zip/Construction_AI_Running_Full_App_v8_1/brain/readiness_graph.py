from datetime import date, datetime
from collections import defaultdict, deque

READY = "READY"
HOLD = "HOLD"
AT_RISK = "AT RISK"
NOT_VERIFIED = "NOT VERIFIED"

BLOCKING_RELATIONS = {
    "REQUIRES", "PRECEDES", "REQUIRES_PERMIT", "REQUIRES_INSPECTION",
    "REQUIRES_TEST", "REQUIRES_SUBMITTAL", "REQUIRES_MATERIAL",
    "REQUIRES_SAFETY", "REQUIRES_DOCUMENT", "BLOCKED_BY"
}

def _node_id(kind, value):
    return f"{kind}:{value}"

def _add_node(nodes, node_id, kind, label, status=NOT_VERIFIED, **extra):
    if node_id not in nodes:
        nodes[node_id] = {
            "id": node_id,
            "type": kind,
            "label": label,
            "status": status,
            **extra
        }
    else:
        nodes[node_id].update({k:v for k,v in extra.items() if v not in (None,"")})
        if status and status != NOT_VERIFIED:
            nodes[node_id]["status"] = status

def _add_edge(edges, source, target, relation, blocking=False, reason=""):
    edges.append({
        "from": source,
        "to": target,
        "relation": relation,
        "blocking": bool(blocking),
        "reason": reason
    })

def build_readiness_graph(state, tasks):
    nodes = {}
    edges = []
    task_index = {t["id"]: t for t in tasks}

    # Construction activities are the center of the graph.
    for task in tasks:
        tid = _node_id("task", task["id"])
        complete = task["id"] in set(state.get("completed_tasks", []))
        _add_node(
            nodes, tid, "construction_activity", task.get("name", task["id"]),
            READY if complete else NOT_VERIFIED,
            phase=task.get("phase",""),
            task_id=task["id"]
        )

    # Project documents / plan sheets.
    for d in state.get("documents", []):
        did = _node_id("document", d.get("document_id", d.get("filename","unknown")))
        ds = READY if d.get("status") in ("CURRENT","APPROVED") else (
            HOLD if d.get("status") == "SUPERSEDED" else NOT_VERIFIED
        )
        _add_node(nodes, did, "document", d.get("filename","Document"), ds,
                  discipline=d.get("discipline",""), revision=d.get("revision",""))

    # Explicit task-document links, when available.
    for link in state.get("task_document_links", []):
        task_id = link.get("task_id")
        doc_id = link.get("document_id")
        if task_id and doc_id:
            _add_edge(
                edges, _node_id("document", doc_id), _node_id("task", task_id),
                "REQUIRES_DOCUMENT", blocking=True,
                reason=link.get("reason","Current governing project document required.")
            )

    # Permits.
    for task_id, status in state.get("permits", {}).items():
        pid = _node_id("permit", task_id)
        ps = READY if status in ("VERIFIED","APPROVED","NOT_REQUIRED") else HOLD
        _add_node(nodes, pid, "permit", f"Permit / authorization — {task_id}", ps, raw_status=status)
        _add_edge(edges, pid, _node_id("task", task_id), "REQUIRES_PERMIT", blocking=True)

    # Inspections.
    for i, rec in enumerate(state.get("inspections", [])):
        task_id = rec.get("task_id","")
        iid = _node_id("inspection", rec.get("id", f"{task_id}:{i}"))
        result = str(rec.get("result","PENDING")).upper()
        status = READY if result in ("PASSED","APPROVED","ACCEPTED","NOT_REQUIRED") else (
            HOLD if result in ("FAILED","REJECTED") else NOT_VERIFIED
        )
        _add_node(nodes, iid, "inspection", rec.get("inspection_type","Inspection"), status,
                  task_id=task_id, result=result)
        if task_id:
            _add_edge(edges, iid, _node_id("task", task_id), "REQUIRES_INSPECTION",
                      blocking=bool(rec.get("required",True)))

    # Tests.
    for i, rec in enumerate(state.get("tests", [])):
        task_id = rec.get("task_id","")
        xid = _node_id("test", rec.get("id", f"{task_id}:{i}"))
        result = str(rec.get("result","PENDING")).upper()
        status = READY if result in ("PASSED","APPROVED","ACCEPTED","NOT_REQUIRED") else (
            HOLD if result in ("FAILED","REJECTED") else NOT_VERIFIED
        )
        _add_node(nodes, xid, "test", rec.get("test_type","Test"), status,
                  task_id=task_id, result=result)
        if task_id:
            _add_edge(edges, xid, _node_id("task", task_id), "REQUIRES_TEST",
                      blocking=bool(rec.get("required",True)))

    # Safety readiness.
    for task_id, ready in state.get("safety_readiness", {}).items():
        sid = _node_id("safety", task_id)
        _add_node(nodes, sid, "safety", f"Safety / JHA — {task_id}",
                  READY if ready else HOLD, task_id=task_id)
        _add_edge(edges, sid, _node_id("task", task_id), "REQUIRES_SAFETY", blocking=True)

    # RFIs and constraints.
    for i, r in enumerate(state.get("rfis", [])):
        rid = _node_id("rfi", r.get("id", i))
        open_rfi = r.get("status","OPEN") not in ("CLOSED","ANSWERED")
        blocking = bool(r.get("blocking")) and open_rfi
        _add_node(nodes, rid, "rfi", r.get("subject") or r.get("id") or "RFI",
                  HOLD if blocking else (AT_RISK if open_rfi else READY),
                  raw_status=r.get("status","OPEN"))
        for task_id in r.get("task_ids", []):
            _add_edge(edges, rid, _node_id("task", task_id), "BLOCKED_BY",
                      blocking=blocking, reason="Open RFI / design coordination.")

    for i, c in enumerate(state.get("constraints", [])):
        cid = _node_id("constraint", c.get("id", i))
        open_c = c.get("status","OPEN") != "CLOSED"
        blocking = bool(c.get("blocking", True)) and open_c
        _add_node(nodes, cid, "constraint",
                  c.get("description") or c.get("title") or "Field constraint",
                  HOLD if blocking else (AT_RISK if open_c else READY))
        task_id = c.get("task_id")
        if task_id:
            _add_edge(edges, cid, _node_id("task", task_id), "BLOCKED_BY",
                      blocking=blocking, reason="Open field constraint.")

    # Procurement / submittals.
    try:
        from brain.submittal_procurement import assess_item
    except Exception:
        assess_item = None

    for i, item in enumerate(state.get("procurement_items", [])):
        pid = _node_id("procurement", item.get("id", i))
        risk = assess_item(item).get("risk") if assess_item else item.get("risk","NOT_VERIFIED")
        status = HOLD if risk == "CRITICAL" else (
            AT_RISK if risk in ("AT_RISK","WATCH","NOT_VERIFIED") else READY
        )
        _add_node(nodes, pid, "procurement", item.get("name","Procurement item"), status,
                  risk=risk, required_on_site_date=item.get("required_on_site_date",""))
        for task_id in item.get("task_ids", []):
            _add_edge(edges, pid, _node_id("task", task_id), "REQUIRES_MATERIAL",
                      blocking=bool(item.get("required",True) and risk == "CRITICAL"),
                      reason="Linked submittal / procurement requirement.")

    # Explicit predecessor dependencies.
    for task_id, prereqs in state.get("task_prerequisites", {}).items():
        for name, complete in prereqs.items():
            prid = _node_id("prerequisite", f"{task_id}:{name}")
            _add_node(nodes, prid, "prerequisite", name, READY if complete else HOLD, task_id=task_id)
            _add_edge(edges, prid, _node_id("task", task_id), "REQUIRES",
                      blocking=True, reason="Project-specific prerequisite.")

    # Schedule links and activity status.
    for a in state.get("schedule_activities", []):
        aid = _node_id("schedule", a.get("activity_id", a.get("name","activity")))
        raw = a.get("status","NOT_STARTED")
        status = HOLD if raw == "BLOCKED" else (
            AT_RISK if raw in ("AT_RISK","DELAYED") or a.get("critical_risk") else
            READY if raw in ("COMPLETE","IN_PROGRESS","READY") else NOT_VERIFIED
        )
        _add_node(nodes, aid, "schedule_activity", a.get("name","Schedule activity"), status,
                  planned_start=a.get("planned_start",""), planned_finish=a.get("planned_finish",""))
        if a.get("task_id"):
            _add_edge(edges, aid, _node_id("task", a["task_id"]), "SCHEDULES", blocking=False)

    return {"nodes": list(nodes.values()), "edges": edges}

def evaluate_task_from_graph(graph, task_id):
    target = _node_id("task", task_id)
    nodes = {n["id"]: n for n in graph.get("nodes", [])}
    incoming = [e for e in graph.get("edges", []) if e.get("to") == target]

    blockers = []
    risks = []
    verified = []

    for edge in incoming:
        source = nodes.get(edge.get("from"), {})
        status = source.get("status", NOT_VERIFIED)
        item = {
            "source_id": source.get("id"),
            "type": source.get("type"),
            "label": source.get("label"),
            "status": status,
            "relation": edge.get("relation"),
            "reason": edge.get("reason","")
        }
        if edge.get("blocking") and status in (HOLD, NOT_VERIFIED):
            blockers.append(item)
        elif status in (AT_RISK, NOT_VERIFIED):
            risks.append(item)
        else:
            verified.append(item)

    if blockers:
        status = HOLD
    elif risks:
        status = AT_RISK
    elif incoming:
        status = READY
    else:
        status = NOT_VERIFIED

    return {
        "task_id": task_id,
        "status": status,
        "blockers": blockers,
        "risks": risks,
        "verified": verified,
        "dependency_count": len(incoming)
    }

def downstream_impact(graph, source_node_id, max_depth=4):
    adjacency = defaultdict(list)
    for e in graph.get("edges", []):
        adjacency[e["from"]].append(e)

    visited = {source_node_id}
    queue = deque([(source_node_id, 0)])
    impacts = []
    while queue:
        current, depth = queue.popleft()
        if depth >= max_depth:
            continue
        for edge in adjacency.get(current, []):
            nxt = edge["to"]
            if nxt in visited:
                continue
            visited.add(nxt)
            impacts.append({
                "node_id": nxt,
                "depth": depth + 1,
                "relation": edge.get("relation"),
                "blocking": edge.get("blocking", False)
            })
            queue.append((nxt, depth + 1))
    return impacts

def graph_metrics(graph):
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    return {
        "nodes": len(nodes),
        "edges": len(edges),
        "holds": sum(1 for n in nodes if n.get("status") == HOLD),
        "at_risk": sum(1 for n in nodes if n.get("status") == AT_RISK),
        "not_verified": sum(1 for n in nodes if n.get("status") == NOT_VERIFIED),
    }
