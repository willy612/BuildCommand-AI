from pathlib import Path
import hashlib
import re

try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

SHEET_RE = re.compile(r"\b([A-Z]{1,3}[-.]?\d{1,3}(?:\.\d+)?)\b")
TITLE_HINTS = [
    "GENERAL NOTES","SITE PLAN","GRADING PLAN","UTILITY PLAN","FOUNDATION PLAN",
    "FLOOR PLAN","ROOF PLAN","REFLECTED CEILING PLAN","DETAILS","SECTIONS",
    "ELEVATIONS","SCHEDULE","PLUMBING","MECHANICAL","ELECTRICAL","STRUCTURAL"
]

def _chunk_id(document_id, page_number, text):
    h = hashlib.sha256()
    h.update(f"{document_id}:{page_number}:{text[:500]}".encode("utf-8", errors="ignore"))
    return h.hexdigest()[:16]

def guess_sheet_number(text):
    top = "\n".join((text or "").splitlines()[:40]).upper()
    matches = SHEET_RE.findall(top)
    return matches[0] if matches else ""

def guess_sheet_title(text):
    lines = [x.strip() for x in (text or "").splitlines() if x.strip()]
    upper = [x.upper() for x in lines[:60]]
    for hint in TITLE_HINTS:
        for original, up in zip(lines[:60], upper):
            if hint in up and len(original) < 120:
                return original[:120]
    return lines[0][:120] if lines else ""

def infer_discipline(sheet_number, title, fallback=""):
    s = f"{sheet_number} {title}".upper()
    if sheet_number:
        prefix = re.sub(r"[^A-Z]", "", sheet_number.upper())
        if prefix.startswith("C"): return "civil"
        if prefix.startswith("A"): return "architectural"
        if prefix.startswith("S"): return "structural"
        if prefix.startswith("P"): return "plumbing"
        if prefix.startswith("M"): return "mechanical"
        if prefix.startswith("E"): return "electrical"
        if prefix.startswith("FP") or prefix.startswith("F"): return "fire_protection"
    for key, words in {
        "civil":["GRADING","UTILITY","SITE PLAN","STORM"],
        "architectural":["FLOOR PLAN","ELEVATION","REFLECTED CEILING"],
        "structural":["FOUNDATION","STRUCTURAL","FRAMING"],
        "plumbing":["PLUMBING","SANITARY","DOMESTIC WATER"],
        "mechanical":["MECHANICAL","HVAC"],
        "electrical":["ELECTRICAL","LIGHTING","POWER"],
        "fire_protection":["FIRE PROTECTION","SPRINKLER"]
    }.items():
        if any(w in s for w in words):
            return key
    return fallback or "unknown"

def split_into_chunks(text, max_chars=2400, overlap=250):
    text = re.sub(r"\n{3,}", "\n\n", text or "").strip()
    if not text:
        return []
    chunks=[]
    start=0
    while start < len(text):
        end=min(len(text), start+max_chars)
        chunk=text[start:end]
        if end < len(text):
            cut=max(chunk.rfind("\n\n"), chunk.rfind(". "))
            if cut > max_chars//2:
                end=start+cut+1
                chunk=text[start:end]
        chunks.append(chunk.strip())
        if end >= len(text): break
        start=max(0,end-overlap)
    return chunks

def parse_pdf(path, document_meta):
    if PdfReader is None:
        raise RuntimeError("pypdf is not installed. Run pip install -r requirements.txt")
    reader = PdfReader(str(path))
    pages=[]
    chunks=[]
    for idx,page in enumerate(reader.pages, start=1):
        try:
            text=page.extract_text() or ""
        except Exception:
            text=""
        sheet=guess_sheet_number(text)
        title=guess_sheet_title(text)
        discipline=infer_discipline(sheet,title,document_meta.get("discipline",""))
        page_rec={
            "document_id":document_meta["document_id"],
            "filename":document_meta["filename"],
            "page_number":idx,
            "sheet_number":sheet,
            "sheet_title":title,
            "discipline":discipline,
            "revision":document_meta.get("revision",""),
            "text_excerpt":text[:1200],
            "keywords":[],
            "source_ref":f"{document_meta['filename']} | page {idx}" + (f" | sheet {sheet}" if sheet else "")
        }
        pages.append(page_rec)
        for chunk in split_into_chunks(text):
            chunks.append({
                "chunk_id":_chunk_id(document_meta["document_id"],idx,chunk),
                "document_id":document_meta["document_id"],
                "page_number":idx,
                "sheet_number":sheet,
                "section":"",
                "discipline":discipline,
                "content":chunk,
                "source_ref":page_rec["source_ref"],
                "revision":document_meta.get("revision",""),
                "status":document_meta.get("status","UPLOADED")
            })
    return pages,chunks

def search_chunks(chunks, query, top_k=6):
    terms=[t.lower() for t in re.findall(r"[A-Za-z0-9._/-]+", query) if len(t)>2]
    scored=[]
    for c in chunks:
        hay=f"{c.get('sheet_number','')} {c.get('discipline','')} {c.get('content','')}".lower()
        score=sum(hay.count(t) for t in terms)
        if c.get("status") in ("CURRENT","APPROVED"):
            score += 2
        if c.get("status") == "SUPERSEDED":
            score -= 5
        if score>0:
            scored.append((score,c))
    scored.sort(key=lambda x:x[0], reverse=True)
    return [c for _,c in scored[:top_k]]

def format_sources(chunks):
    out=[]
    seen=set()
    for c in chunks:
        ref=c.get("source_ref")
        if ref and ref not in seen:
            seen.add(ref)
            out.append(ref)
    return out
