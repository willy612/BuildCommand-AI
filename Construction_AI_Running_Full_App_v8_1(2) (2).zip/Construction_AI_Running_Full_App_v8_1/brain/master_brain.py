import json
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
TASKS=BASE/'knowledge'/'master'/'master_tasks.json'
SAFETY=BASE/'knowledge'/'master'/'safety_rules.json'
ALIASES={'permit':'civil.planning_permitting','swppp':'civil.erosion_swppp','erosion':'civil.erosion_swppp','survey':'civil.survey_control','clearing':'civil.clearing','proctor':'civil.soils_proctor','soil':'civil.soils_proctor','over excav':'civil.excavation_overex','excavat':'civil.excavation_overex','compaction':'civil.compaction','road':'civil.roads_pads','pad':'civil.roads_pads','utility survey':'civil.utility_survey','storm':'civil.storm','drainage':'civil.storm','underground mep':'civil.underground_mep','underground':'civil.underground_mep','mat footing':'foundation.mat','mat foundation':'foundation.mat','footing':'foundation.footings','stem wall':'foundation.stemwall_or_cmu','cmu':'foundation.stemwall_or_cmu','concrete sample':'foundation.concrete','concrete':'foundation.concrete','pour grade':'foundation.pour_grade','structural':'structural.system_selection'}
def load_tasks(): return json.loads(TASKS.read_text())
def get_task(i): return {t['id']:t for t in load_tasks()}.get(i)
def find_task(q):
    q=q.lower()
    for k in sorted(ALIASES,key=len,reverse=True):
        if k in q: return get_task(ALIASES[k])
    return None
def safety_for(task):
    if not task:return []
    rules=json.loads(SAFETY.read_text())['rules']; hay=(task['name']+' '+task['system']+' '+task['purpose']).lower()
    return [r for r in rules if not r['keywords'] or any(k in hay for k in r['keywords'])]
def evaluate(state,task):
    if not task:return {'status':'HOLD','reasons':['No task matched']}
    reasons=[]
    if task['id']!='civil.planning_permitting' and state.get('permits',{}).get(task['id'],'NOT_CHECKED') not in ('VERIFIED','APPROVED','NOT_REQUIRED'):
        reasons.append('Permit/approval status not verified')
    records=[x for x in state.get('inspections',[])+state.get('tests',[]) if x.get('task_id')==task['id'] and x.get('required')]
    if any(str(x.get('result','')).upper() in ('FAILED','FAIL','REJECTED') for x in records): reasons.append('A required inspection/test failed or was rejected')
    elif any(str(x.get('result','')).upper() not in ('PASSED','PASS','ACCEPTED','APPROVED') for x in records): reasons.append('Required inspection/testing is pending')
    if task['id']=='civil.erosion_swppp' and state.get('swppp_status')=='FAILED': reasons.append('SWPPP/environmental corrective action is open')
    return {'status':'HOLD' if reasons else 'READY','reasons':reasons}
def format_task(task,state):
    if not task:return 'No task matched.'
    g=evaluate(state,task); out=[f"## {task['name']}",f"**Phase:** {task['phase']}  ",f"**Purpose:** {task['purpose']}",'',f"### BuildWise Status: **{g['status']}**"]+[f'- {x}' for x in g['reasons']]
    out += ['', '### Prerequisites']+[f'- {x}' for x in task.get('prerequisites',[])]
    out += ['', '### Hard gates']+[f'- {x}' for x in task.get('hard_gates',[])]
    out += ['', '### Inspection / testing']+[f'- {x}' for x in task.get('inspection_types',[])]
    out += ['', '### Safety']
    for r in safety_for(task): out += [f"**{r['id']}**"]+[f'- Hazard: {x}' for x in r['hazards']]+[f'- Control: {x}' for x in r['controls']]
    out += ['', '### Documentation']+[f'- {x}' for x in task.get('documentation',[])]
    n=get_task(task.get('next_task')) if task.get('next_task') else None
    if n: out += ['',f"### What comes next: **{n['name']}**"]
    return '\n'.join(out)
