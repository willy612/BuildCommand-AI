from pathlib import Path
import hashlib
import re

DISCIPLINE_MAP = {
    "civil": ["civil", "grading", "utility", "storm", "site"],
    "architectural": ["architectural", "floor plan", "elevation", "finish"],
    "structural": ["structural", "foundation", "framing", "steel", "concrete"],
    "plumbing": ["plumbing", "sanitary", "domestic water"],
    "mechanical": ["mechanical", "hvac", "duct"],
    "electrical": ["electrical", "power", "lighting"],
    "fire_protection": ["fire protection", "sprinkler"],
    "geotechnical": ["geotechnical", "soil", "geotech", "proctor"],
    "permit": ["permit"],
    "swppp": ["swppp", "stormwater pollution prevention"],
    "special_inspection": ["special inspection", "statement of special inspections"],
    "schedule": ["schedule", "lookahead", "critical path"],
    "specifications": ["spec", "specification"],
}

def _id_for(filename):
    return hashlib.sha256(filename.encode("utf-8")).hexdigest()[:16]

def classify_filename(filename):
    name = filename.lower()
    for discipline, keywords in DISCIPLINE_MAP.items():
        if any(k in name for k in keywords):
            return discipline
    if name.endswith(".pdf"):
        return "unknown_pdf"
    return "other"

def detect_revision(filename):
    name = Path(filename).stem
    for p in [r"(?:rev|revision)[\s_-]*([a-z0-9]+)", r"[_-]r([0-9]+)$"]:
        m = re.search(p, name, flags=re.I)
        if m:
            return m.group(1).upper()
    return ""

def intake_metadata(filename, size_bytes=0):
    dtype = classify_filename(filename)
    return {
        "document_id": _id_for(filename),
        "filename": filename,
        "document_type": dtype,
        "discipline": dtype,
        "sheet_or_section": "",
        "title": Path(filename).stem,
        "revision": detect_revision(filename),
        "document_date": "",
        "status": "UPLOADED",
        "supersedes": "",
        "source_notes": "",
        "size_bytes": size_bytes,
    }

def mark_current(documents, document_id):
    target = next((d for d in documents if d["document_id"] == document_id), None)
    if not target:
        return documents
    for d in documents:
        same_slot = (
            d.get("discipline") == target.get("discipline")
            and d.get("sheet_or_section")
            and d.get("sheet_or_section") == target.get("sheet_or_section")
        )
        if same_slot and d["document_id"] != document_id:
            d["status"] = "SUPERSEDED"
    target["status"] = "CURRENT"
    return documents

def find_revision_conflicts(documents):
    conflicts = []
    by_key = {}
    for d in documents:
        key = (d.get("discipline"), d.get("sheet_or_section"))
        if not key[1]:
            continue
        by_key.setdefault(key, []).append(d)
    for key, docs in by_key.items():
        revisions = {d.get("revision","") for d in docs}
        if len(docs) > 1 and len(revisions) > 1:
            conflicts.append({
                "discipline": key[0],
                "sheet_or_section": key[1],
                "documents": [d["filename"] for d in docs],
                "revisions": sorted(revisions)
            })
    return conflicts
