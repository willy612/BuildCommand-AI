import re

CALL_OUT_PATTERNS = [
    re.compile(r"\b(\d{1,2})\s*/\s*([A-Z]{1,3}[-.]?\d{1,3}(?:\.\d+)?)\b", re.I),
    re.compile(r"\b([A-Z]{1,3}[-.]?\d{1,3}(?:\.\d+)?)\b", re.I),
]

def build_sheet_index(plan_pages, visual_pages):
    idx = {}
    for p in (plan_pages or []) + (visual_pages or []):
        sheet = (p.get("sheet_number") or "").upper()
        if sheet:
            idx.setdefault(sheet, []).append(p)
    return idx

def extract_sheet_refs(text):
    refs = set()
    text = text or ""
    for pat in CALL_OUT_PATTERNS:
        for match in pat.findall(text):
            if isinstance(match, tuple):
                refs.add(match[-1].upper())
            else:
                refs.add(match.upper())
    return sorted(refs)

def build_callout_links(visual_pages, plan_pages):
    index = build_sheet_index(plan_pages, visual_pages)
    edges = []
    for p in visual_pages or []:
        source = f"page:{p['document_id']}:{p['page_number']}"
        content = " ".join(map(str, p.get("callouts",[]))) + " " + " ".join(map(str, p.get("notes",[])))
        for ref in extract_sheet_refs(content):
            if ref in index:
                for target_page in index[ref]:
                    target = f"page:{target_page['document_id']}:{target_page['page_number']}"
                    if source != target:
                        edges.append({"from":source,"to":target,"relation":"REFERENCES_SHEET","label":ref})
    return edges
