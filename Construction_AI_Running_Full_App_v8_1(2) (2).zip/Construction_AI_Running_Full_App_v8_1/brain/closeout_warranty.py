from datetime import date, datetime

CLOSEOUT_CATEGORIES=[
    "as_builts","record_drawings","o_and_m_manuals","warranties","training",
    "testing_reports","inspection_approvals","commissioning","tab_report",
    "attic_stock","keys_access","final_clean","punch_complete","occupancy_documents"
]

def closeout_status(state):
    records=state.get("closeout_items",[])
    required=[x for x in records if x.get("required",True)]
    complete=[x for x in required if x.get("status")=="COMPLETE"]
    pct=round((len(complete)/len(required))*100) if required else 0
    missing=[x for x in required if x.get("status")!="COMPLETE"]
    return {"percent_complete":pct,"required":len(required),"complete":len(complete),"missing":missing}

def warranty_status(state, today=None):
    if today is None:
        today=date.today()
    elif not isinstance(today,date):
        today=datetime.fromisoformat(str(today)).date()
    rows=[]
    for item in state.get("warranty_items",[]):
        end=item.get("warranty_end")
        expired=False
        if end:
            try: expired=datetime.fromisoformat(str(end)).date()<today
            except Exception: pass
        rows.append({**item,"expired":expired})
    return rows
