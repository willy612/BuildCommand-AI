from datetime import date, datetime

READY="READY"
HOLD="HOLD"
AT_RISK="AT RISK"
UNKNOWN="NOT VERIFIED"

def _records(state, key, task_id):
    return [r for r in state.get(key,[]) if r.get("task_id")==task_id]

def _passed(result):
    return str(result or "").upper() in {"PASSED","PASS","APPROVED","ACCEPTED","NOT_REQUIRED"}

def _failed(result):
    return str(result or "").upper() in {"FAILED","FAIL","REJECTED"}

def _document_gate(state, task):
    docs=[d for d in state.get("documents",[]) if d.get("status") in ("CURRENT","APPROVED")]
    if not docs:
        return {"name":"Current project documents","status":UNKNOWN,
                "reason":"No CURRENT or APPROVED project document is registered."}
    return {"name":"Current project documents","status":READY,
            "reason":f"{len(docs)} current/approved document(s) registered."}

def _permit_gate(state, task):
    status=state.get("permits",{}).get(task["id"],"NOT_CHECKED")
    if status in ("VERIFIED","APPROVED","NOT_REQUIRED"):
        return {"name":"Permit / authorization","status":READY,"reason":status}
    return {"name":"Permit / authorization","status":HOLD,
            "reason":"Applicable permit/authorization has not been verified for this activity."}

def _inspection_gate(state, task):
    recs=[r for r in _records(state,"inspections",task["id"]) if r.get("required")]
    if any(_failed(r.get("result")) for r in recs):
        return {"name":"Required inspections","status":HOLD,"reason":"A required inspection failed/rejected."}
    pending=[r for r in recs if not _passed(r.get("result"))]
    if pending:
        return {"name":"Required inspections","status":HOLD,"reason":f"{len(pending)} required inspection(s) pending."}
    if recs:
        return {"name":"Required inspections","status":READY,"reason":"Recorded required inspections passed/accepted."}
    return {"name":"Required inspections","status":UNKNOWN,
            "reason":"No task-specific required inspection records are registered."}

def _test_gate(state, task):
    recs=[r for r in _records(state,"tests",task["id"]) if r.get("required")]
    if any(_failed(r.get("result")) for r in recs):
        return {"name":"Required testing","status":HOLD,"reason":"A required test failed."}
    pending=[r for r in recs if not _passed(r.get("result"))]
    if pending:
        return {"name":"Required testing","status":HOLD,"reason":f"{len(pending)} required test(s) pending."}
    if recs:
        return {"name":"Required testing","status":READY,"reason":"Recorded required testing passed/accepted."}
    return {"name":"Required testing","status":UNKNOWN,
            "reason":"No task-specific required testing records are registered."}

def _prerequisite_gate(state, task):
    completed=set(state.get("completed_tasks",[]))
    explicit=state.get("task_prerequisites",{}).get(task["id"],{})
    missing=[name for name,value in explicit.items() if not value]
    if missing:
        return {"name":"Prerequisites","status":HOLD,"reason":"Missing: "+", ".join(missing)}
    if explicit:
        return {"name":"Prerequisites","status":READY,"reason":"Recorded prerequisites are complete."}
    return {"name":"Prerequisites","status":UNKNOWN,
            "reason":"Project-specific prerequisites have not yet been fully verified."}

def _safety_gate(state, task):
    safety=state.get("safety_readiness",{}).get(task["id"])
    if safety is True:
        return {"name":"Safety planning","status":READY,"reason":"Task safety readiness recorded complete."}
    if safety is False:
        return {"name":"Safety planning","status":HOLD,"reason":"Task safety readiness is not complete."}
    return {"name":"Safety planning","status":UNKNOWN,
            "reason":"Task-specific safety/JHA/pre-task readiness has not been verified."}

def _rfi_gate(state, task):
    open_rfis=[r for r in state.get("rfis",[]) if r.get("status","OPEN") not in ("CLOSED","ANSWERED")
               and task["id"] in r.get("task_ids",[])]
    blocking=[r for r in open_rfis if r.get("blocking",False)]
    if blocking:
        return {"name":"RFIs / design conflicts","status":HOLD,
                "reason":f"{len(blocking)} blocking RFI/conflict(s) remain open."}
    if open_rfis:
        return {"name":"RFIs / design conflicts","status":AT_RISK,
                "reason":f"{len(open_rfis)} related open RFI(s) require monitoring."}
    return {"name":"RFIs / design conflicts","status":READY,"reason":"No blocking related RFI is recorded."}

def _procurement_gate(state, task):
    from brain.submittal_procurement import assess_item
    items=[x for x in state.get("procurement_items",[]) if task["id"] in x.get("task_ids",[])]
    if not items:
        return {"name":"Submittals / procurement","status":UNKNOWN,
                "reason":"No task-linked submittal/procurement records are registered."}

    assessments=[(x, assess_item(x)) for x in items]
    critical=[x for x,a in assessments if x.get("required",True) and a.get("risk")=="CRITICAL"]
    risk=[x for x,a in assessments if a.get("risk") in ("AT_RISK","WATCH","NOT_VERIFIED")]

    if critical:
        return {"name":"Submittals / procurement","status":HOLD,
                "reason":f"{len(critical)} required item(s) have a critical missed procurement milestone."}
    if risk:
        return {"name":"Submittals / procurement","status":AT_RISK,
                "reason":f"{len(risk)} linked item(s) require procurement attention."}
    return {"name":"Submittals / procurement","status":READY,
            "reason":"Linked procurement milestones are currently on track."}

def _schedule_gate(state, task):
    acts=[a for a in state.get("schedule_activities",[]) if a.get("task_id")==task["id"]]
    if not acts:
        return {"name":"Schedule","status":UNKNOWN,"reason":"No schedule activity is linked to this task."}
    risks=[a for a in acts if a.get("status") in ("DELAYED","AT_RISK","BLOCKED") or a.get("critical_risk")]
    if risks:
        return {"name":"Schedule","status":AT_RISK,
                "reason":f"{len(risks)} linked schedule activity/activities show risk."}
    return {"name":"Schedule","status":READY,"reason":"Linked schedule activities show no recorded risk."}

def evaluate_readiness(state, task):
    gates=[
        _document_gate(state,task),
        _permit_gate(state,task),
        _prerequisite_gate(state,task),
        _inspection_gate(state,task),
        _test_gate(state,task),
        _safety_gate(state,task),
        _rfi_gate(state,task),
        _procurement_gate(state,task),
        _schedule_gate(state,task),
    ]
    if any(g["status"]==HOLD for g in gates):
        overall=HOLD
    elif any(g["status"] in (AT_RISK,UNKNOWN) for g in gates):
        overall=AT_RISK
    else:
        overall=READY

    blockers=[g for g in gates if g["status"]==HOLD]
    risks=[g for g in gates if g["status"] in (AT_RISK,UNKNOWN)]
    return {"task_id":task["id"],"task_name":task["name"],"status":overall,
            "gates":gates,"blockers":blockers,"risks":risks}

def format_readiness(result):
    lines=[f"## {result['task_name']} — {result['status']}",""]
    icon={"READY":"✓","HOLD":"✕","AT RISK":"!","NOT VERIFIED":"?"}
    for g in result["gates"]:
        lines.append(f"{icon.get(g['status'],'•')} **{g['name']}** — {g['status']}: {g['reason']}")
    if result["blockers"]:
        lines+=["","### Blocking items"]+[f"- {g['name']}: {g['reason']}" for g in result["blockers"]]
    if result["risks"]:
        lines+=["","### Risks / verification needed"]+[f"- {g['name']}: {g['reason']}" for g in result["risks"]]
    lines+=["","**Decision rule:** READY means all tracked gates are clear. NOT VERIFIED items prevent the system from claiming full readiness."]
    return "\n".join(lines)
