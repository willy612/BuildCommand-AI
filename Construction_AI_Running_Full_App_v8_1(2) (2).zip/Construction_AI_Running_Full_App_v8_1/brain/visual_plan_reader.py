from pathlib import Path
import base64
import io
import json
import os

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    from PIL import Image
except ImportError:
    Image = None

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

VISUAL_SYSTEM = """
You are analyzing a construction drawing page.

Extract only what is actually visible. Do not invent text, dimensions, elevations,
callouts, symbols, or relationships that are unreadable.

Return concise JSON with:
- visual_summary: short description of the page
- likely_sheet_number
- likely_sheet_title
- discipline
- callouts: list of visible detail/section callouts
- dimensions: list of clearly readable important dimensions/elevations
- notes: list of clearly readable important notes
- elements: list of objects with type, label, and description
- potential_conflicts_or_questions: items that should be checked by a human

If something is uncertain, include "uncertain": true on that item.
"""

def render_pdf_page(pdf_path, page_number, output_dir, zoom=2.0):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed. Run pip install -r requirements.txt")
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    doc = fitz.open(str(pdf_path))
    if page_number < 1 or page_number > len(doc):
        raise ValueError("page_number is 1-based and outside the PDF range")

    page = doc.load_page(page_number - 1)
    matrix = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    out = output_dir / f"{Path(pdf_path).stem}_page_{page_number}.png"
    pix.save(str(out))
    doc.close()
    return out

def image_to_data_url(image_path):
    image_path = Path(image_path)
    mime = "image/png" if image_path.suffix.lower() == ".png" else "image/jpeg"
    data = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{data}"

def analyze_page_image(image_path, source_ref="", model=None):
    if OpenAI is None:
        raise RuntimeError("openai package is not installed.")
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is not configured.")

    client = OpenAI()
    model = model or os.getenv("OPENAI_VISION_MODEL", "gpt-5")
    data_url = image_to_data_url(image_path)

    prompt = f"""
Source reference: {source_ref}

Analyze this construction drawing page carefully. Focus on:
1. sheet identity/title/discipline
2. visible detail and section callouts
3. clearly readable dimensions/elevations
4. clearly readable construction notes
5. major assemblies/equipment/utilities shown
6. anything that should be linked to another sheet/detail
7. apparent coordination issues that require human verification

Return valid JSON only.
"""

    response = client.responses.create(
        model=model,
        instructions=VISUAL_SYSTEM,
        input=[
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    {"type": "input_image", "image_url": data_url, "detail": "high"}
                ]
            }
        ]
    )

    raw = response.output_text.strip()
    # Be resilient if the model wraps JSON in markdown.
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:].strip()
    try:
        return json.loads(raw)
    except Exception:
        return {
            "visual_summary": raw,
            "likely_sheet_number": "",
            "likely_sheet_title": "",
            "discipline": "",
            "callouts": [],
            "dimensions": [],
            "notes": [],
            "elements": [],
            "potential_conflicts_or_questions": [],
            "parse_warning": "Model output was not valid JSON."
        }

def build_visual_record(document_meta, page_number, render_path, analysis):
    source_ref = f"{document_meta['filename']} | page {page_number}"
    sheet = analysis.get("likely_sheet_number") or document_meta.get("sheet_or_section","")
    if sheet:
        source_ref += f" | sheet {sheet}"

    return {
        "document_id": document_meta["document_id"],
        "filename": document_meta["filename"],
        "page_number": page_number,
        "sheet_number": sheet,
        "sheet_title": analysis.get("likely_sheet_title",""),
        "discipline": analysis.get("discipline") or document_meta.get("discipline",""),
        "revision": document_meta.get("revision",""),
        "render_path": str(render_path),
        "visual_summary": analysis.get("visual_summary",""),
        "visual_elements": analysis.get("elements",[]),
        "callouts": analysis.get("callouts",[]),
        "dimensions": analysis.get("dimensions",[]),
        "notes": analysis.get("notes",[]),
        "potential_conflicts_or_questions": analysis.get("potential_conflicts_or_questions",[]),
        "source_ref": source_ref,
        "status": document_meta.get("status","UPLOADED")
    }

def visual_record_to_chunks(record):
    chunks = []

    def add(kind, items):
        for idx, item in enumerate(items or []):
            if isinstance(item, dict):
                content = json.dumps(item, ensure_ascii=False)
            else:
                content = str(item)
            chunks.append({
                "chunk_id": f"visual:{record['document_id']}:{record['page_number']}:{kind}:{idx}",
                "document_id": record["document_id"],
                "page_number": record["page_number"],
                "sheet_number": record.get("sheet_number",""),
                "section": kind,
                "discipline": record.get("discipline",""),
                "content": content,
                "source_ref": record.get("source_ref",""),
                "revision": record.get("revision",""),
                "status": record.get("status","UPLOADED"),
                "source_type": "visual"
            })

    if record.get("visual_summary"):
        add("visual_summary", [record["visual_summary"]])
    add("callout", record.get("callouts"))
    add("dimension", record.get("dimensions"))
    add("note", record.get("notes"))
    add("element", record.get("visual_elements"))
    add("coordination_question", record.get("potential_conflicts_or_questions"))
    return chunks
