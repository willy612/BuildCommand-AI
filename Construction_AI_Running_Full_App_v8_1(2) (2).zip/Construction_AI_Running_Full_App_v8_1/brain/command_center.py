from datetime import date, datetime, timedelta
from brain.readiness_engine import evaluate_readiness
from brain.submittal_procurement import assess_item

def _as_date(value):
    if not value:
        return None
    if isinstance(value, date):
        return value
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None

def _task_index(tasks):
    return {t["id"]: t for t in tasks}

def activity_health(state, tasks):
    idx = _task_index(tasks)
    rows = []
    for activity in state.get("schedule_activities", []):
        task_id = activity.get("task_id")
        if task_id and task_id in idx:
            readiness = evaluate_readiness(state, idx[task_id])
            status = readiness["status"]
            reasons = [x["reason"] for x in readiness.get("blockers", []) + readiness.get("risks", [])]
        else:
            status = activity.get("status", "NOT_STARTED")
            reasons = []
        rows.append({
            "activity_id": activity.get("activity_id"),
            "name": activity.get("name"),
            "task_id": task_id,
            "status": status,
            "planned_start": activity.get("planned_start", ""),
            "planned_finish": activity.get("planned_finish", ""),
            "percent_complete": activity.get("percent_complete", 0),
            "reasons": reasons
        })
    return rows

def inspection_board(state, today=None, horizon_days=7):
    today = _as_date(today) or date.today()
    end = today + timedelta(days=horizon_days)
    rows = []
    for r in state.get("inspections", []):
        d = _as_date(r.get("scheduled_date"))
        if not d or (today <= d <= end):
            rows.append(r)
    return rows

def testing_board(state, today=None, horizon_days=7):
    today = _as_date(today) or date.today()
    end = today + timedelta(days=horizon_days)
    rows = []
    for r in state.get("tests", []):
        d = _as_date(r.get("scheduled_date") or r.get("date"))
        if not d or (today <= d <= end):
            rows.append(r)
    return rows

def procurement_board(state, today=None):
    results = []
    for item in state.get("procurement_items", []):
        a = assess_item(item, today=today)
        results.append({
            "name": item.get("name"),
            "trade": item.get("trade"),
            "responsible_company": item.get("responsible_company"),
            "risk": a.get("risk"),
            "reason": a.get("reason"),
            "required_on_site_date": item.get("required_on_site_date"),
            "task_ids": item.get("task_ids", [])
        })
    order = {"CRITICAL":0, "AT_RISK":1, "WATCH":2, "NOT_VERIFIED":3, "ON_TRACK":4}
    return sorted(results, key=lambda x: order.get(x["risk"], 99))

def rfi_board(state):
    rows = []
    for r in state.get("rfis", []):
        if r.get("status", "OPEN") not in ("CLOSED", "ANSWERED"):
            rows.append(r)
    return rows

def safety_board(state, tasks):
    idx = _task_index(tasks)
    rows = []
    for task_id, ready in state.get("safety_readiness", {}).items():
        task = idx.get(task_id)
        rows.append({
            "task_id": task_id,
            "name": task.get("name") if task else task_id,
            "status": "READY" if ready else "HOLD"
        })
    return rows

def swppp_board(state):
    status = state.get("swppp_status", "NOT_CHECKED")
    return {
        "status": status,
        "attention": status in ("FAILED", "NOT_CHECKED")
    }

def priority_actions(state, tasks, today=None):
    actions = []

    # Readiness / schedule activity blockers
    for row in activity_health(state, tasks):
        if row["status"] == "HOLD":
            actions.append({
                "priority": 1,
                "category": "Readiness",
                "title": row["name"],
                "reason": row["reasons"][0] if row["reasons"] else "Activity is on HOLD."
            })
        elif row["status"] == "AT RISK":
            actions.append({
                "priority": 2,
                "category": "Readiness",
                "title": row["name"],
                "reason": row["reasons"][0] if row["reasons"] else "Activity is AT RISK."
            })

    # Procurement
    for p in procurement_board(state, today=today):
        if p["risk"] == "CRITICAL":
            actions.append({
                "priority": 1,
                "category": "Procurement",
                "title": p["name"],
                "reason": p["reason"]
            })
        elif p["risk"] in ("AT_RISK", "WATCH", "NOT_VERIFIED"):
            actions.append({
                "priority": 2 if p["risk"] == "AT_RISK" else 3,
                "category": "Procurement",
                "title": p["name"],
                "reason": p["reason"]
            })

    # Blocking RFIs
    for r in rfi_board(state):
        actions.append({
            "priority": 1 if r.get("blocking") else 3,
            "category": "RFI",
            "title": r.get("subject") or r.get("id") or "Open RFI",
            "reason": "Blocking design/coordination issue." if r.get("blocking") else "Open RFI requires follow-up."
        })

    # Safety holds
    for s in safety_board(state, tasks):
        if s["status"] == "HOLD":
            actions.append({
                "priority": 1,
                "category": "Safety",
                "title": s["name"],
                "reason": "Task safety/JHA readiness is not verified."
            })

    # SWPPP
    sw = swppp_board(state)
    if sw["attention"]:
        actions.append({
            "priority": 1 if sw["status"] == "FAILED" else 3,
            "category": "SWPPP",
            "title": "Erosion / SWPPP",
            "reason": f"Current status: {sw['status']}"
        })

    return sorted(actions, key=lambda x: (x["priority"], x["category"], x["title"]))

def command_summary(state, tasks, today=None):
    activities = activity_health(state, tasks)
    counts = {
        "READY": sum(1 for x in activities if x["status"] == "READY"),
        "HOLD": sum(1 for x in activities if x["status"] == "HOLD"),
        "AT_RISK": sum(1 for x in activities if x["status"] == "AT RISK"),
        "IN_PROGRESS": sum(1 for x in activities if x["status"] == "IN_PROGRESS"),
        "COMPLETE": sum(1 for x in activities if x["status"] == "COMPLETE"),
    }
    procurement = procurement_board(state, today=today)
    counts["PROCUREMENT_CRITICAL"] = sum(1 for x in procurement if x["risk"] == "CRITICAL")
    counts["OPEN_RFIS"] = len(rfi_board(state))
    counts["INSPECTIONS"] = len(inspection_board(state, today=today))
    counts["TESTS"] = len(testing_board(state, today=today))
    return counts


def closeout_board(state):
    items=state.get("closeout_items",[])
    return {
        "total":len(items),
        "complete":sum(1 for x in items if x.get("status")=="COMPLETE"),
        "open":sum(1 for x in items if x.get("status")!="COMPLETE")
    }

def punch_board(state):
    open_items=[x for x in state.get("punch_items",[]) if x.get("status","OPEN")!="CLOSED"]
    return open_items


def subcontractor_commitment_board(state):
    rows=[]
    for c in state.get("subcontractor_commitments",[]):
        status=c.get("status","PENDING")
        health="READY" if status=="CONFIRMED" else (
            "HOLD" if status in ("CANNOT_MEET_DATE","DECLINED") else
            "AT_RISK" if status in ("DELAY_REPORTED","MATERIAL_ISSUE","MANPOWER_ISSUE","ACCESS_ISSUE","NEED_INFORMATION") else
            "NOT_VERIFIED"
        )
        rows.append({**c,"health":health})
    return rows
