from datetime import date, datetime

def _is_resolved(value):
    return value in (True, "VERIFIED", "APPROVED", "PASSED", "ACCEPTED", "COMPLETE", "NOT_REQUIRED")

def evaluate_activity(activity, project_state):
    reasons = []

    # Predecessors
    completed = set(project_state.get("completed_tasks", []))
    for pred in activity.get("predecessors", []):
        if pred not in completed:
            reasons.append(f"Predecessor not complete: {pred}")

    # Permit gates
    permits = project_state.get("permits", {})
    for permit_key in activity.get("required_permits", []):
        if not _is_resolved(permits.get(permit_key, "NOT_CHECKED")):
            reasons.append(f"Permit/approval not verified: {permit_key}")

    # Inspection gates
    inspections = project_state.get("inspections", [])
    for req in activity.get("required_inspections", []):
        matches = [x for x in inspections if x.get("task_id") == req and x.get("required", True)]
        if not matches or not any(_is_resolved(x.get("result")) for x in matches):
            reasons.append(f"Inspection not accepted: {req}")

    # Testing gates
    tests = project_state.get("tests", [])
    for req in activity.get("required_tests", []):
        matches = [x for x in tests if x.get("task_id") == req and x.get("required", True)]
        if not matches or not any(_is_resolved(x.get("result")) for x in matches):
            reasons.append(f"Test not accepted: {req}")

    # Open constraints
    unresolved_constraints = [
        c for c in activity.get("constraints", [])
        if not c.get("resolved", False)
    ]
    for c in unresolved_constraints:
        reasons.append(f"Open constraint: {c.get('description', c.get('type', 'unknown'))}")

    if activity.get("percent_complete", 0) >= 100:
        status = "COMPLETE"
    elif reasons:
        status = "HOLD"
    elif activity.get("actual_start"):
        status = "IN_PROGRESS"
    else:
        status = "READY"

    return {
        "activity_id": activity.get("activity_id"),
        "name": activity.get("name"),
        "status": status,
        "reasons": reasons
    }

def build_lookahead(activities, project_state):
    evaluated = [evaluate_activity(a, project_state) for a in activities]
    return sorted(evaluated, key=lambda x: (x["status"] != "HOLD", x["name"] or ""))

def critical_actions(activities, project_state):
    results = []
    for a in activities:
        ev = evaluate_activity(a, project_state)
        if ev["status"] == "HOLD":
            results.append({
                "activity": ev["name"],
                "reasons": ev["reasons"]
            })
    return results
