from datetime import date, datetime, timedelta

SUBMITTAL_STATUSES = [
    "NOT_STARTED", "PREPARING", "GC_REVIEW", "DESIGN_REVIEW",
    "REVISION_REQUIRED", "APPROVED", "APPROVED_AS_NOTED", "REJECTED"
]

PROCUREMENT_STATUSES = [
    "NOT_RELEASED", "RELEASED", "FABRICATION", "SHIPPED",
    "DELIVERED", "INSTALLED", "ON_HOLD"
]

def _as_date(value):
    if not value:
        return None
    if isinstance(value, date):
        return value
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None

def calculate_required_dates(item):
    """
    Work backward from required_on_site_date.
    Durations are calendar days in v0.10.
    """
    on_site = _as_date(item.get("required_on_site_date"))
    if not on_site:
        return {}

    shipping = int(item.get("shipping_days") or 0)
    fabrication = int(item.get("fabrication_days") or 0)
    release_buffer = int(item.get("release_buffer_days") or 0)
    design_review = int(item.get("design_review_days") or 0)
    gc_review = int(item.get("gc_review_days") or 0)
    resubmit_buffer = int(item.get("resubmit_buffer_days") or 0)

    ship_by = on_site - timedelta(days=shipping)
    release_by = ship_by - timedelta(days=fabrication + release_buffer)
    approved_by = release_by
    submit_by = approved_by - timedelta(days=design_review + gc_review + resubmit_buffer)

    return {
        "required_on_site_date": on_site.isoformat(),
        "ship_by_date": ship_by.isoformat(),
        "release_by_date": release_by.isoformat(),
        "approved_by_date": approved_by.isoformat(),
        "submit_by_date": submit_by.isoformat(),
    }

def assess_item(item, today=None):
    today = _as_date(today) or date.today()
    dates = calculate_required_dates(item)
    if not dates:
        return {
            "risk": "NOT_VERIFIED",
            "reason": "Required-on-site date is missing.",
            "dates": {}
        }

    submit_by = _as_date(dates["submit_by_date"])
    approved_by = _as_date(dates["approved_by_date"])
    release_by = _as_date(dates["release_by_date"])
    ship_by = _as_date(dates["ship_by_date"])
    on_site = _as_date(dates["required_on_site_date"])

    sub = item.get("submittal_status", "NOT_STARTED")
    proc = item.get("procurement_status", "NOT_RELEASED")
    approved = sub in ("APPROVED", "APPROVED_AS_NOTED")
    released = proc in ("RELEASED", "FABRICATION", "SHIPPED", "DELIVERED", "INSTALLED")
    shipped = proc in ("SHIPPED", "DELIVERED", "INSTALLED")
    delivered = proc in ("DELIVERED", "INSTALLED")

    if today > on_site and not delivered:
        return {"risk":"CRITICAL", "reason":"Required-on-site date has passed and item is not delivered.", "dates":dates}
    if today > ship_by and not shipped:
        return {"risk":"CRITICAL", "reason":"Ship-by date has passed and item is not shipped.", "dates":dates}
    if today > release_by and not released:
        return {"risk":"CRITICAL", "reason":"Release-by date has passed and item is not released.", "dates":dates}
    if today > approved_by and not approved:
        return {"risk":"CRITICAL", "reason":"Approval-required date has passed and submittal is not approved.", "dates":dates}
    if today > submit_by and sub in ("NOT_STARTED", "PREPARING"):
        return {"risk":"AT_RISK", "reason":"Submit-by date has passed and the submittal has not entered review.", "dates":dates}

    milestones = [
        ("submit", submit_by, sub not in ("NOT_STARTED", "PREPARING")),
        ("approval", approved_by, approved),
        ("release", release_by, released),
        ("shipping", ship_by, shipped),
        ("delivery", on_site, delivered),
    ]
    open_dates = [(name, d) for name, d, complete in milestones if not complete]
    if open_dates:
        name, next_date = min(open_dates, key=lambda x: x[1])
        days = (next_date - today).days
        if days <= 3:
            return {"risk":"AT_RISK", "reason":f"Next {name} milestone is due in {days} day(s).", "dates":dates}
        if days <= 10:
            return {"risk":"WATCH", "reason":f"Next {name} milestone is due in {days} day(s).", "dates":dates}

    return {"risk":"ON_TRACK", "reason":"No current procurement deadline is breached.", "dates":dates}

def readiness_status(item, today=None):
    result = assess_item(item, today)
    risk = result["risk"]
    if risk == "CRITICAL":
        return "HOLD"
    if risk in ("AT_RISK", "WATCH", "NOT_VERIFIED"):
        return "AT_RISK"
    return "READY"

def sync_to_readiness_record(item, today=None):
    result = assess_item(item, today)
    return {
        "id": item.get("id"),
        "name": item.get("name"),
        "task_ids": item.get("task_ids", []),
        "required": item.get("required", True),
        "status": item.get("submittal_status", "NOT_STARTED"),
        "procurement_status": item.get("procurement_status", "NOT_RELEASED"),
        "risk": result["risk"],
        "required_on_site_date": item.get("required_on_site_date", ""),
        "spec_section": item.get("spec_section", ""),
        "responsible_company": item.get("responsible_company", ""),
        "reason": result["reason"],
    }

def portfolio_risks(items, today=None):
    ranked = {"CRITICAL":0, "AT_RISK":1, "WATCH":2, "NOT_VERIFIED":3, "ON_TRACK":4}
    results = []
    for item in items:
        assessment = assess_item(item, today)
        results.append({"item":item, "assessment":assessment})
    return sorted(results, key=lambda x: ranked.get(x["assessment"]["risk"], 99))
