import json
import os
import re
from datetime import datetime

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

SYSTEM = """
You are a construction field-intelligence parser.

Convert a superintendent's field update into PROPOSED project-state changes.
Never claim that an inspection passed, a test passed, work is complete, a safety condition
is acceptable, or a permit is approved unless the speaker explicitly states that fact.

Return valid JSON only with:
{
  "summary": "...",
  "observations": [{"category":"progress|inspection|testing|safety|delivery|constraint|rfi|weather|quality|other",
                    "statement":"...", "confidence":"high|medium|low"}],
  "proposed_changes": [{
      "change_type":"inspection|test|constraint|task_progress|delivery|safety|rfi|note",
      "task_id":"",
      "payload":{},
      "reason":"",
      "requires_human_approval":true
  }],
  "daily_report_notes":["..."],
  "questions_for_superintendent":["..."]
}

All proposed changes require human approval.
Do not invent task IDs if they are not supplied in context.
"""

def _client():
    if OpenAI is None:
        return None
    if not os.getenv("OPENAI_API_KEY"):
        return None
    return OpenAI()

def fallback_parse(text):
    lower=text.lower()
    observations=[]
    changes=[]

    categories=[
        ("inspection", ["inspection","inspector","passed inspection","failed inspection"]),
        ("testing", ["test","compaction","density","concrete sample","cylinder","pressure test"]),
        ("delivery", ["delivered","delivery","material arrived","equipment arrived"]),
        ("safety", ["jha","safety","hazard","fall protection","trench","ppe"]),
        ("constraint", ["blocked","delay","delayed","missing","waiting","cannot","can't"]),
        ("progress", ["complete","completed","finished","started","working on","installed"]),
    ]
    for cat,words in categories:
        if any(w in lower for w in words):
            observations.append({"category":cat,"statement":text.strip(),"confidence":"medium"})

    if "passed inspection" in lower:
        changes.append({
            "change_type":"inspection","task_id":"",
            "payload":{"result":"PASSED","inspection_type":"Field-reported inspection"},
            "reason":"Speaker explicitly reported a passed inspection.",
            "requires_human_approval":True
        })
    if "failed inspection" in lower:
        changes.append({
            "change_type":"inspection","task_id":"",
            "payload":{"result":"FAILED","inspection_type":"Field-reported inspection"},
            "reason":"Speaker explicitly reported a failed inspection.",
            "requires_human_approval":True
        })
    if any(w in lower for w in ["blocked","delay","delayed","missing","waiting"]):
        changes.append({
            "change_type":"constraint","task_id":"",
            "payload":{"description":text.strip(),"status":"OPEN"},
            "reason":"Field update indicates a possible constraint.",
            "requires_human_approval":True
        })

    return {
        "summary": text.strip(),
        "observations": observations or [{"category":"other","statement":text.strip(),"confidence":"low"}],
        "proposed_changes": changes,
        "daily_report_notes":[text.strip()],
        "questions_for_superintendent":[]
    }

def parse_field_update(text, task_catalog=None):
    client=_client()
    if client is None:
        return fallback_parse(text)

    catalog = task_catalog or []
    response=client.responses.create(
        model=os.getenv("OPENAI_MODEL","gpt-5.4-mini"),
        instructions=SYSTEM,
        input=f"""TASK CATALOG:
{json.dumps(catalog, ensure_ascii=False)}

FIELD UPDATE:
{text}

Extract only what was actually reported. Return JSON only."""
    )
    raw=response.output_text.strip()
    if raw.startswith("```"):
        raw=raw.strip("`")
        if raw.lower().startswith("json"):
            raw=raw[4:].strip()
    try:
        result=json.loads(raw)
    except Exception:
        result=fallback_parse(text)

    for change in result.get("proposed_changes",[]):
        change["requires_human_approval"]=True
    return result

def new_pending_update(raw_text, parsed, source_type="voice_or_text"):
    return {
        "id":f"field-{datetime.now().strftime('%Y%m%d%H%M%S%f')}",
        "created_at":datetime.now().isoformat(timespec="seconds"),
        "source_type":source_type,
        "raw_text":raw_text,
        "parsed":parsed,
        "status":"PENDING_APPROVAL"
    }

def apply_change(state, change):
    kind=change.get("change_type")
    task_id=change.get("task_id","")
    payload=dict(change.get("payload") or {})

    if kind=="inspection":
        payload["task_id"]=task_id or payload.get("task_id","")
        state.setdefault("inspections",[]).append(payload)
    elif kind=="test":
        payload["task_id"]=task_id or payload.get("task_id","")
        state.setdefault("tests",[]).append(payload)
    elif kind=="constraint":
        payload.setdefault("task_id",task_id)
        state.setdefault("constraints",[]).append(payload)
    elif kind=="delivery":
        state.setdefault("field_deliveries",[]).append(payload)
    elif kind=="safety":
        if task_id and "ready" in payload:
            state.setdefault("safety_readiness",{})[task_id]=bool(payload["ready"])
        state.setdefault("safety_observations",[]).append(payload)
    elif kind=="rfi":
        payload.setdefault("task_ids",[task_id] if task_id else [])
        state.setdefault("rfis",[]).append(payload)
    elif kind=="task_progress":
        state.setdefault("field_progress_updates",[]).append({"task_id":task_id, **payload})
    else:
        state.setdefault("field_notes",[]).append(payload)

def approve_pending_update(state, update_id, selected_indices=None):
    updates=state.setdefault("pending_field_updates",[])
    target=next((u for u in updates if u.get("id")==update_id),None)
    if not target:
        return False
    changes=target.get("parsed",{}).get("proposed_changes",[])
    selected=set(selected_indices if selected_indices is not None else range(len(changes)))
    for i,change in enumerate(changes):
        if i in selected:
            apply_change(state,change)
    target["status"]="APPROVED"
    target["approved_change_indices"]=sorted(selected)
    return True

def reject_pending_update(state, update_id):
    target=next((u for u in state.setdefault("pending_field_updates",[]) if u.get("id")==update_id),None)
    if not target:
        return False
    target["status"]="REJECTED"
    return True

def daily_report(state, project_name=""):
    approved=[u for u in state.get("pending_field_updates",[]) if u.get("status")=="APPROVED"]
    notes=[]
    for u in approved:
        notes.extend(u.get("parsed",{}).get("daily_report_notes",[]))
    lines=[
        f"# Daily Field Report — {project_name or 'Project'}",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "## Field Notes"
    ]
    if notes:
        lines.extend(f"- {n}" for n in notes[-30:])
    else:
        lines.append("- No approved field notes recorded.")
    lines += ["", "## Open Constraints"]
    constraints=[c for c in state.get("constraints",[]) if c.get("status","OPEN")!="CLOSED"]
    if constraints:
        lines.extend(f"- {c.get('description') or c.get('title') or 'Constraint'}" for c in constraints)
    else:
        lines.append("- No open constraints recorded.")
    return "\n".join(lines)
