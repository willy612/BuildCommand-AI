from brain.sheet_linker import build_callout_links

def build_graph(project_state):
    nodes=[]
    edges=[]

    for d in project_state.get("documents",[]):
        nodes.append({
            "id":f"doc:{d['document_id']}",
            "type":"document",
            "label":d.get("filename"),
            "status":d.get("status"),
            "discipline":d.get("discipline")
        })

    seen_pages=set()
    for p in project_state.get("plan_pages",[]):
        pid=f"page:{p['document_id']}:{p['page_number']}"
        if pid not in seen_pages:
            nodes.append({
                "id":pid,
                "type":"plan_page",
                "label":p.get("sheet_number") or f"Page {p['page_number']}",
                "discipline":p.get("discipline"),
                "title":p.get("sheet_title")
            })
            seen_pages.add(pid)
        edges.append({"from":f"doc:{p['document_id']}","to":pid,"relation":"CONTAINS"})

    for p in project_state.get("visual_pages",[]):
        pid=f"page:{p['document_id']}:{p['page_number']}"
        if pid not in seen_pages:
            nodes.append({
                "id":pid,
                "type":"plan_page",
                "label":p.get("sheet_number") or f"Page {p['page_number']}",
                "discipline":p.get("discipline"),
                "title":p.get("sheet_title")
            })
            seen_pages.add(pid)

        for idx, element in enumerate(p.get("visual_elements",[])):
            eid=f"element:{p['document_id']}:{p['page_number']}:{idx}"
            label=element.get("label") if isinstance(element,dict) else str(element)
            nodes.append({"id":eid,"type":"visual_element","label":label})
            edges.append({"from":pid,"to":eid,"relation":"SHOWS"})

    for a in project_state.get("schedule_activities",[]):
        nodes.append({
            "id":f"activity:{a['activity_id']}",
            "type":"schedule_activity",
            "label":a.get("name"),
            "phase":a.get("phase")
        })

    edges.extend(build_callout_links(
        project_state.get("visual_pages",[]),
        project_state.get("plan_pages",[])
    ))

    return {"nodes":nodes,"edges":edges}
