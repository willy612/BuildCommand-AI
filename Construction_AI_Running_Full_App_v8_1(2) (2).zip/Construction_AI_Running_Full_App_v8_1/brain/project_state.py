import json
from pathlib import Path
T=Path(__file__).resolve().parent.parent/'knowledge'/'master'/'project_state_template.json'
def new_project_state(): return json.loads(T.read_text())
def set_permit(s,tid,status): s.setdefault('permits',{})[tid]=status; return s
def add_inspection(s,r): s.setdefault('inspections',[]).append(r); return s
def add_test(s,r): s.setdefault('tests',[]).append(r); return s
def mark_complete(s,tid):
    if tid not in s.setdefault('completed_tasks',[]): s['completed_tasks'].append(tid)
    return s
