def startup_readiness(project_state):
    missing = []

    if not project_state.get("jurisdiction"):
        missing.append("Jurisdiction / city not identified")

    documents = project_state.get("documents", [])
    types = {d.get("document_type") for d in documents if d.get("status") != "SUPERSEDED"}

    if not any(t in types for t in {"civil","architectural","structural","unknown_pdf"}):
        missing.append("Current plan set not uploaded")

    if "specifications" not in types:
        missing.append("Specifications not uploaded")

    if project_state.get("requires_geotechnical", True) and "geotechnical" not in types:
        missing.append("Geotechnical / soils document not uploaded")

    if project_state.get("requires_swppp", False) and "swppp" not in types:
        missing.append("SWPPP document not uploaded")

    if project_state.get("requires_special_inspections", False) and "special_inspection" not in types:
        missing.append("Special inspection document not uploaded")

    if project_state.get("schedule_expected", True) and "schedule" not in types:
        missing.append("Project schedule not uploaded")

    return {"status": "READY" if not missing else "INCOMPLETE", "missing": missing, "document_count": len(documents)}
