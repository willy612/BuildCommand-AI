def build_project_notifications(command_actions, procurement_rows=None, ingestion_jobs=None):
    notifications=[]

    for action in command_actions or []:
        severity="critical" if action.get("priority")==1 else "warning" if action.get("priority")==2 else "info"
        notifications.append({
            "severity":severity,
            "category":action.get("category","Project"),
            "title":action.get("title","Project action"),
            "message":action.get("reason","")
        })

    for row in procurement_rows or []:
        if row.get("risk") in ("CRITICAL","AT_RISK"):
            notifications.append({
                "severity":"critical" if row["risk"]=="CRITICAL" else "warning",
                "category":"Procurement",
                "title":row.get("name","Procurement item"),
                "message":row.get("reason","")
            })

    for job in ingestion_jobs or []:
        if getattr(job,"status",None)=="FAILED":
            notifications.append({
                "severity":"warning",
                "category":"Document ingestion",
                "title":f"Document #{getattr(job,'document_id','')}",
                "message":getattr(job,"error_message","Ingestion failed.")
            })

    return notifications
