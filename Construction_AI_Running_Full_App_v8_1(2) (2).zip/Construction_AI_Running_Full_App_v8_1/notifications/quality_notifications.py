from db.models import InboxItem,ProjectUserRole

def notify_project_team(db,project_id,title,message,severity="warning"):
    assignments=db.query(ProjectUserRole).filter(ProjectUserRole.project_id==project_id).all()
    created=[]
    for a in assignments:
        row=InboxItem(
            company_id=a.company_id,project_id=project_id,user_id=a.user_id,
            category="QUALITY",severity=severity,title=title,message=message,status="UNREAD"
        )
        db.add(row); created.append(row)
    db.commit()
    return created
