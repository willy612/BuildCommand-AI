from db.models import RiskOutcomeCalibration,PredictiveRiskSnapshot

def record_risk_outcome(db,snapshot_id,actual_delay_occurred,actual_delay_days=0,notes=""):
    snap=db.query(PredictiveRiskSnapshot).filter(PredictiveRiskSnapshot.id==snapshot_id).first()
    if not snap:return None
    row=RiskOutcomeCalibration(
        project_id=snap.project_id,predictive_risk_snapshot_id=snap.id,
        actual_delay_occurred=bool(actual_delay_occurred),
        actual_delay_days=float(actual_delay_days or 0),outcome_notes=notes
    )
    db.add(row);db.commit();db.refresh(row);return row

def calibration_summary(db,project_id):
    rows=db.query(RiskOutcomeCalibration).filter(RiskOutcomeCalibration.project_id==project_id).all()
    if not rows:return {"count":0,"hit_rate":0.0}
    hits=0
    for r in rows:
        s=db.query(PredictiveRiskSnapshot).filter(PredictiveRiskSnapshot.id==r.predictive_risk_snapshot_id).first()
        predicted=bool(s and s.risk_score>=55)
        if predicted==bool(r.actual_delay_occurred):hits+=1
    return {"count":len(rows),"hit_rate":hits/len(rows)}
