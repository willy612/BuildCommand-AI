from db.models import (
    ScheduleActivity,ScheduleDriftAlert,MakeReadyAction,
    PredictiveRiskSnapshot,CompanyKnowledgePattern,ProductionIntelligenceSnapshot
)
from interventions.impact import downstream_impact

def _band(score):
    if score>=75:return "CRITICAL"
    if score>=55:return "HIGH"
    if score>=30:return "WATCH"
    return "LOW"

def calculate_activity_risk(db,project_id,company_id,activity):
    drift=0;constraint=0;commitment=0;production=0;downstream=0;history=0
    reasons=[]

    alert=db.query(ScheduleDriftAlert).filter(
        ScheduleDriftAlert.project_id==project_id,
        ScheduleDriftAlert.schedule_activity_id==activity.id,
        ScheduleDriftAlert.status=="OPEN"
    ).order_by(ScheduleDriftAlert.created_at.desc()).first()
    if alert:
        drift=min(25,abs(float(alert.variance_days or 0))*3)
        reasons.append(f"Field/CPM variance is {alert.variance_days:+d} days.")

    mr=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.schedule_activity_id==activity.id,
        MakeReadyAction.status=="OPEN"
    ).all()
    if mr:
        constraint=min(25,8*len(mr)+sum((x.escalation_level or 0)*2 for x in mr))
        reasons.append(f"{len(mr)} open make-ready constraint(s) remain.")

    prod=db.query(ProductionIntelligenceSnapshot).filter(
        ProductionIntelligenceSnapshot.project_id==project_id,
        ProductionIntelligenceSnapshot.schedule_activity_id==activity.id
    ).order_by(ProductionIntelligenceSnapshot.created_at.desc()).first()
    if prod and prod.planned_quantity_per_day>0:
        pace=prod.pace_ratio or 0
        if pace<1:
            production=min(15,(1-pace)*20)
            reasons.append(f"Recorded production pace is {pace:.0%} of the daily plan; trend {prod.trend}.")
    elif getattr(activity,"percent_complete",0) and getattr(activity,"status","") not in ("COMPLETE","COMPLETED"):
        pct=float(activity.percent_complete or 0)
        if 0<pct<100:
            production=min(8,max(0,(50-pct)/12))
            if production>0:
                reasons.append("Activity is in progress with limited completion; verify production pace.")

    impacts=downstream_impact(db,project_id,activity.id,4)
    downstream=min(15,len(impacts)*2)
    if impacts:
        reasons.append(f"{len(impacts)} downstream activity(ies) are exposed within four logic hops.")

    patterns=db.query(CompanyKnowledgePattern).filter(
        CompanyKnowledgePattern.company_id==company_id
    ).order_by(CompanyKnowledgePattern.confidence.desc()).all()
    relevant=[p for p in patterns if p.pattern_type in ("FIELD_CPM_VARIANCE","RECOVERY_OUTCOME")]
    if relevant:
        strongest=relevant[0]
        history=min(10,strongest.confidence*10)
        reasons.append(f"Company history contributes {history:.1f} risk-context points from {strongest.sample_count} prior observation(s).")

    score=min(100,drift+constraint+commitment+production+downstream+history)
    explanation=" ".join(reasons) if reasons else "No significant modeled warning signals detected."
    return {
        "risk_score":round(score,1),"probability_band":_band(score),
        "schedule_drift_points":round(drift,1),"constraint_points":round(constraint,1),
        "commitment_points":round(commitment,1),"production_points":round(production,1),
        "downstream_points":round(downstream,1),"company_history_points":round(history,1),
        "explanation":explanation
    }

def run_project_risk(db,project_id,company_id):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    rows=[]
    for a in acts:
        r=calculate_activity_risk(db,project_id,company_id,a)
        snap=PredictiveRiskSnapshot(project_id=project_id,schedule_activity_id=a.id,**r)
        db.add(snap);rows.append(snap)
    db.commit()
    return sorted(rows,key=lambda x:x.risk_score,reverse=True)
