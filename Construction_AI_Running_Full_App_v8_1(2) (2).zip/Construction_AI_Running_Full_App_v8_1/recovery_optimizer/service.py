from db.models import RecoveryOptionEvaluation
from recovery_sandbox.engine import run_sandbox

DEFAULT_SCENARIOS=[
    ("ADD_CREW",20.0),
    ("OVERTIME",15.0),
    ("WORK_SATURDAY",0.0),
    ("CLEAR_CONSTRAINT",2.0),
    ("RESEQUENCE",20.0),
]

COST_FACTORS={
    "ADD_CREW":12000.0,
    "OVERTIME":8000.0,
    "WORK_SATURDAY":6000.0,
    "CLEAR_CONSTRAINT":2500.0,
    "RESEQUENCE":4000.0,
}

RISK={
    "ADD_CREW":"MEDIUM",
    "OVERTIME":"HIGH",
    "WORK_SATURDAY":"MEDIUM",
    "CLEAR_CONSTRAINT":"LOW",
    "RESEQUENCE":"MEDIUM",
}

def _risk_penalty(level):
    return {"LOW":0,"MEDIUM":10,"HIGH":20}.get(level,10)

def evaluate_options(db,project_id,activity_id,scenarios=None):
    scenarios=scenarios or DEFAULT_SCENARIOS
    results=[]
    for scenario_type,value in scenarios:
        run,_=run_sandbox(db,project_id,activity_id,scenario_type,value)
        if not run:
            continue
        est_cost=COST_FACTORS.get(scenario_type,5000.0)
        risk=RISK.get(scenario_type,"MEDIUM")
        milestone_score=min(100.0,(run.project_days_recovered or 0)*20.0)
        confidence=run.confidence or 0.0

        # Explainable ranking:
        # prioritize project days recovered and confidence;
        # penalize cost and constructability risk.
        score=(
            (run.project_days_recovered or 0)*25
            + (run.activity_days_recovered or 0)*8
            + confidence*20
            + milestone_score*0.2
            - min(est_cost/1000.0,25)
            - _risk_penalty(risk)
        )
        row=RecoveryOptionEvaluation(
            project_id=project_id,schedule_activity_id=activity_id,
            scenario_type=scenario_type,scenario_value=value,
            modeled_project_days_recovered=run.project_days_recovered or 0,
            modeled_activity_days_recovered=run.activity_days_recovered or 0,
            estimated_cost=est_cost,constructability_risk=risk,
            safety_review_required=True,milestone_protection_score=milestone_score,
            confidence=confidence,optimizer_score=round(score,1),
            assumptions=run.assumptions,status="PROPOSED"
        )
        db.add(row);results.append(row)
    db.commit()
    return sorted(results,key=lambda x:x.optimizer_score,reverse=True)
