ROLE_PERMISSIONS = {
    "owner_admin": {"read","write","approve","manage_users","manage_billing"},
    "project_manager": {"read","write","approve","manage_project"},
    "superintendent": {"read","write","approve"},
    "project_engineer": {"read","write"},
    "foreman": {"read","write_field"},
    "viewer": {"read"}
}

def can(role, permission):
    return permission in ROLE_PERMISSIONS.get(role, set())
