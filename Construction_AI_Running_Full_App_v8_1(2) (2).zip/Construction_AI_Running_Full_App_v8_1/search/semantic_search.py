import json
import math
import os
from db.models import KnowledgeChunk

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

DEFAULT_EMBEDDING_MODEL = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")

def _client():
    if OpenAI is None or not os.getenv("OPENAI_API_KEY"):
        return None
    return OpenAI()

def embed_text(text):
    client = _client()
    if client is None:
        return None
    response = client.embeddings.create(
        model=DEFAULT_EMBEDDING_MODEL,
        input=text
    )
    return response.data[0].embedding

def cosine(a, b):
    if not a or not b or len(a) != len(b):
        return -1.0
    dot = sum(x*y for x,y in zip(a,b))
    na = math.sqrt(sum(x*x for x in a))
    nb = math.sqrt(sum(y*y for y in b))
    if not na or not nb:
        return -1.0
    return dot/(na*nb)

def backfill_embeddings(db, project_id, limit=None):
    q = db.query(KnowledgeChunk).filter(KnowledgeChunk.project_id == project_id)
    rows = q.all()
    updated = 0
    for row in rows:
        if limit and updated >= limit:
            break
        if row.embedding_json:
            continue
        vec = embed_text(row.content)
        if vec is None:
            break
        row.embedding_json = json.dumps(vec)
        updated += 1
    db.commit()
    return updated

def hybrid_search(db, project_id, query, top_k=8):
    from search.project_search import _terms

    rows = db.query(KnowledgeChunk).filter(KnowledgeChunk.project_id == project_id).all()
    terms = _terms(query)
    qvec = embed_text(query)

    scored = []
    for row in rows:
        hay = f"{row.sheet_number} {row.discipline} {row.section} {row.content}".lower()
        keyword = sum(hay.count(t) for t in terms)
        semantic = 0.0
        if qvec and row.embedding_json:
            try:
                semantic = max(0.0, cosine(qvec, json.loads(row.embedding_json)))
            except Exception:
                semantic = 0.0

        revision_bonus = 0.5 if row.status in ("CURRENT","APPROVED") else 0.0
        total = keyword + semantic * 5.0 + revision_bonus
        if total > 0:
            scored.append((total, row))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [r for _,r in scored[:top_k]]
