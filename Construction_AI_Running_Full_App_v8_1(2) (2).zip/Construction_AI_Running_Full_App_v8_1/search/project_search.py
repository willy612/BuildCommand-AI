import re
from db.models import KnowledgeChunk

def _terms(query):
    return [t.lower() for t in re.findall(r"[A-Za-z0-9._/-]+", query or "") if len(t)>2]

def search_project_chunks(db, project_id, query, top_k=8):
    terms=_terms(query)
    rows=db.query(KnowledgeChunk).filter(KnowledgeChunk.project_id==project_id).all()
    scored=[]
    for row in rows:
        hay=f"{row.sheet_number} {row.discipline} {row.section} {row.content}".lower()
        score=sum(hay.count(t) for t in terms)
        if row.status in ("CURRENT","APPROVED"): score+=2
        if score>0: scored.append((score,row))
    scored.sort(key=lambda x:x[0], reverse=True)
    return [r for _,r in scored[:top_k]]

def format_search_results(rows):
    return [{
        "document_id":r.document_id,
        "page_number":r.page_number,
        "sheet_number":r.sheet_number,
        "discipline":r.discipline,
        "source_ref":r.source_ref,
        "content":r.content,
        "status":r.status
    } for r in rows]
