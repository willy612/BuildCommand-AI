import importlib
import os
from pathlib import Path

CHECKS=[]

def check(name,fn):
    try:
        detail=fn()
        CHECKS.append((name,True,detail))
    except Exception as e:
        CHECKS.append((name,False,str(e)))

def run():
    check("database import",lambda: importlib.import_module("db.session") and "ok")
    check("api import",lambda: importlib.import_module("api.main") and "ok")
    check("storage backend",lambda: importlib.import_module("storage.backend").get_storage_backend().__class__.__name__)
    check("openai configured",lambda: "configured" if os.getenv("OPENAI_API_KEY") else "not configured")
    check("database url",lambda: os.getenv("DATABASE_URL","default sqlite"))
    check("storage mode",lambda: os.getenv("STORAGE_BACKEND","local"))
    check("auth provider",lambda: os.getenv("AUTH_PROVIDER","development"))

    failed=[x for x in CHECKS if not x[1]]
    for name,ok,detail in CHECKS:
        print(("PASS" if ok else "FAIL"),"-",name,"-",detail)
    if failed:
        raise SystemExit(1)

if __name__=="__main__":
    run()
