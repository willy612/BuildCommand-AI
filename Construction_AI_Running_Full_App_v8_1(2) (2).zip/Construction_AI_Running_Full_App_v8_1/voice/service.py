def normalize_spoken_update(text):
    """
    v3.1 voice-ready abstraction.
    The UI can accept dictated/transcribed text now.
    A real speech-to-text provider can plug in later without changing field workflows.
    """
    return " ".join((text or "").strip().split())

def split_quick_update(text):
    t=normalize_spoken_update(text)
    return {
        "raw":t,
        "field_update":t,
        "suggested_type":"BLOCKER" if any(x in t.lower() for x in ["blocked","delay","waiting","can't","cannot"]) else "PROGRESS"
    }
