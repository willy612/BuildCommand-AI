from db.models import (
    PredictiveRiskSnapshot,ScheduleActivity,ProductionIntelligenceSnapshot,
    CompanyKnowledgePattern,ApprovedRecoveryPlan,FieldAssistantQuery
)

def project_brief(db,company_id,project_id,user_id=None,question="What needs my attention today?"):
    risks=db.query(PredictiveRiskSnapshot).filter(
        PredictiveRiskSnapshot.project_id==project_id
    ).order_by(PredictiveRiskSnapshot.created_at.desc()).all()
    latest={}
    for r in risks:latest.setdefault(r.schedule_activity_id,r)
    top=sorted(latest.values(),key=lambda x:x.risk_score,reverse=True)[:5]

    lines=[];evidence=[]
    for r in top:
        if r.risk_score<30:continue
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==r.schedule_activity_id).first()
        lines.append(f"{r.probability_band}: {a.name if a else r.schedule_activity_id} ({r.risk_score:.0f}/100). {r.explanation}")
        evidence.append(f"risk_snapshot={r.id}")

    plans=db.query(ApprovedRecoveryPlan).filter(
        ApprovedRecoveryPlan.project_id==project_id,
        ApprovedRecoveryPlan.status=="ACTIVE"
    ).all()
    if plans:
        lines.append(f"{len(plans)} approved recovery plan(s) are active and should be checked against actual field progress.")
        evidence.extend(f"recovery_plan={p.id}" for p in plans)

    patterns=db.query(CompanyKnowledgePattern).filter(
        CompanyKnowledgePattern.company_id==company_id
    ).order_by(CompanyKnowledgePattern.confidence.desc()).limit(3).all()
    if patterns:
        lines.append("Company history: "+" | ".join(p.recommendation for p in patterns))

    answer="\n\n".join(lines) if lines else "No significant modeled warning signals are currently available. Verify today's field conditions and refresh project intelligence."
    q=FieldAssistantQuery(
        company_id=company_id,project_id=project_id,user_id=user_id,
        question=question,answer=answer,evidence="; ".join(evidence)
    )
    db.add(q);db.commit();db.refresh(q)
    return q
