from pathlib import Path
from db.models import Document, DocumentPage, KnowledgeChunk, IngestionJob
from brain.plan_reader import parse_pdf

def create_ingestion_job(db, project_id, document_id):
    job = IngestionJob(project_id=project_id, document_id=document_id, status="QUEUED", stage="created", progress=0)
    db.add(job); db.commit(); db.refresh(job)
    return job

def _doc_meta(doc):
    return {
        "document_id": str(doc.id),
        "filename": doc.filename,
        "document_type": doc.document_type,
        "discipline": doc.discipline,
        "sheet_or_section": doc.sheet_or_section,
        "title": doc.title,
        "revision": doc.revision,
        "status": doc.status,
    }

def ingest_document(db, job_id):
    job=db.query(IngestionJob).filter(IngestionJob.id==job_id).first()
    if not job: raise ValueError("Ingestion job not found")
    doc=db.query(Document).filter(Document.id==job.document_id).first()
    if not doc: raise ValueError("Document not found")
    path=Path(doc.storage_path)
    if not path.exists(): raise FileNotFoundError(path)

    try:
        job.status="RUNNING"; job.stage="parse_pdf"; job.progress=10; db.commit()
        db.query(DocumentPage).filter(DocumentPage.document_id==doc.id).delete()
        db.query(KnowledgeChunk).filter(KnowledgeChunk.document_id==doc.id).delete()
        db.commit()

        pages,chunks=parse_pdf(path,_doc_meta(doc))
        job.stage="store_pages"; job.progress=45; db.commit()

        for p in pages:
            db.add(DocumentPage(
                document_id=doc.id,
                page_number=p.get("page_number",0),
                sheet_number=p.get("sheet_number",""),
                sheet_title=p.get("sheet_title",""),
                discipline=p.get("discipline",""),
                source_ref=p.get("source_ref",""),
                text_excerpt=p.get("text_excerpt",""),
                status="PARSED"
            ))
        for c in chunks:
            db.add(KnowledgeChunk(
                project_id=job.project_id,
                document_id=doc.id,
                page_number=c.get("page_number",0),
                sheet_number=c.get("sheet_number",""),
                discipline=c.get("discipline",""),
                section=c.get("section",""),
                source_type=c.get("source_type","text"),
                source_ref=c.get("source_ref",""),
                content=c.get("content",""),
                status=c.get("status","CURRENT")
            ))
        db.commit()
        job.stage="complete"; job.progress=100; job.status="COMPLETE"; db.commit(); db.refresh(job)
        return job
    except Exception as e:
        job.status="FAILED"; job.stage="failed"; job.error_message=str(e); db.commit()
        raise

def list_jobs(db, project_id):
    return db.query(IngestionJob).filter(IngestionJob.project_id==project_id).order_by(IngestionJob.created_at.desc()).all()
