from db.models import (
    ScheduleActivity,ScheduleRelationship,ScheduleActivityAdvanced,
    ScheduleRelationshipAdvanced,ScheduleQualitySnapshot
)

def evaluate_schedule_quality(db,project_id,long_duration_threshold=20,high_float_threshold=44,high_lag_threshold=10):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    pred={a.external_id:0 for a in acts}; succ={a.external_id:0 for a in acts}
    for r in rels:
        if r.predecessor_external_id in succ:succ[r.predecessor_external_id]+=1
        if r.successor_external_id in pred:pred[r.successor_external_id]+=1

    open_ends=sum(1 for a in acts if pred[a.external_id]==0 or succ[a.external_id]==0)
    long_durations=0
    high_float=0
    negative_float=0
    for a in acts:
        adv=db.query(ScheduleActivityAdvanced).filter(ScheduleActivityAdvanced.schedule_activity_id==a.id).first()
        if adv:
            if (adv.remaining_duration_days or 0)>long_duration_threshold:long_durations+=1
            tf=float(adv.total_float_days or 0)
            if tf>high_float_threshold:high_float+=1
            if tf<0:negative_float+=1

    high_lag=0
    for r in rels:
        adv=db.query(ScheduleRelationshipAdvanced).filter(
            ScheduleRelationshipAdvanced.relationship_id==r.id
        ).first()
        lag=float(adv.lag_days if adv else getattr(r,"lag_days",0) or 0)
        if abs(lag)>high_lag_threshold:high_lag+=1

    density=(len(rels)/len(acts)) if acts else 0.0
    deductions=(
        min(open_ends*2,25)+
        min(long_durations*2,15)+
        min(high_float*2,15)+
        min(negative_float*3,20)+
        min(high_lag*2,10)
    )
    if density<1.2 and acts:
        deductions+=10
    score=max(0,100-deductions)
    snap=ScheduleQualitySnapshot(
        project_id=project_id,
        data_date="",
        open_ends=open_ends,long_durations=long_durations,
        high_float=high_float,negative_float=negative_float,
        high_lag=high_lag,relationship_density=round(density,2),
        quality_score=round(score,1)
    )
    db.add(snap);db.commit();db.refresh(snap)
    return snap

def schedule_quality_findings(snapshot):
    findings=[]
    if snapshot.open_ends:findings.append(f"{snapshot.open_ends} open-ended activity condition(s).")
    if snapshot.long_durations:findings.append(f"{snapshot.long_durations} activity(ies) with long remaining durations.")
    if snapshot.high_float:findings.append(f"{snapshot.high_float} activity(ies) with unusually high float.")
    if snapshot.negative_float:findings.append(f"{snapshot.negative_float} activity(ies) with negative float.")
    if snapshot.high_lag:findings.append(f"{snapshot.high_lag} relationship(s) with high lag.")
    if snapshot.relationship_density<1.2:findings.append("Relationship density is low; logic may be incomplete.")
    return findings
