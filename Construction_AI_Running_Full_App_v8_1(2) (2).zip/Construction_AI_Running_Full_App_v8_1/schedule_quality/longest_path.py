from collections import defaultdict,deque
from db.models import ScheduleActivity,ScheduleRelationship

def longest_path_candidates(db,project_id):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    by={a.external_id:a for a in acts}
    succ=defaultdict(list); indeg={k:0 for k in by}
    for r in rels:
        if r.predecessor_external_id in by and r.successor_external_id in by:
            succ[r.predecessor_external_id].append(r.successor_external_id)
            indeg[r.successor_external_id]+=1
    q=deque([k for k,v in indeg.items() if v==0])
    dist={k:1 for k in by}; parent={}
    order=[]
    while q:
        n=q.popleft();order.append(n)
        for s in succ[n]:
            if dist.get(n,1)+1>dist.get(s,1):
                dist[s]=dist[n]+1;parent[s]=n
            indeg[s]-=1
            if indeg[s]==0:q.append(s)
    if not dist:return []
    end=max(dist,key=dist.get)
    path=[end]
    while end in parent:
        end=parent[end];path.append(end)
    path.reverse()
    return [{"external_id":x,"name":by[x].name,"depth":i+1} for i,x in enumerate(path)]
