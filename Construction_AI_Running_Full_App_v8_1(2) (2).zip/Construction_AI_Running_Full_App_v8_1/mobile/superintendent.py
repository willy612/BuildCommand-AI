def superintendent_digest(state, tasks, command_summary_fn, priority_actions_fn):
    summary=command_summary_fn(state,tasks)
    actions=priority_actions_fn(state,tasks)
    return {
        "ready":summary.get("READY",0),
        "hold":summary.get("HOLD",0),
        "at_risk":summary.get("AT_RISK",0),
        "top_actions":actions[:5],
        "field_prompt":"What changed in the field since the last update?",
        "quick_actions":[
            "Record field update","Add photo observation","Report blocker",
            "Record inspection/test result","Check tomorrow readiness"
        ]
    }
