from db.models import ActionRoutingRecord,ProjectUser,Subcontractor,ScheduleActivity

def suggest_routes(db,action):
    routes=[]
    activity=db.query(ScheduleActivity).filter(ScheduleActivity.id==action.schedule_activity_id).first() if action.schedule_activity_id else None
    users=db.query(ProjectUser).filter(ProjectUser.project_id==action.project_id,ProjectUser.active==True).all()
    role_priority=["superintendent","project_manager","project engineer"]
    for role in role_priority:
        for u in users:
            if (u.role or "").lower()==role:
                routes.append({"type":"PROJECT_USER","id":u.id,"name":u.display_name,"email":u.email,
                               "reason":f"Project role: {u.role}"})
    if activity and getattr(activity,"trade",""):
        subs=db.query(Subcontractor).filter(Subcontractor.project_id==action.project_id).all()
        for s in subs:
            if (s.trade or "").lower()==activity.trade.lower():
                routes.append({"type":"SUBCONTRACTOR","id":s.id,"name":s.name,
                               "email":getattr(s,"email","") or "",
                               "reason":f"Trade match: {activity.trade}"})
    return routes[:8]

def save_route(db,action,route):
    row=ActionRoutingRecord(
        superintendent_action_id=action.id,recipient_type=route["type"],recipient_id=route["id"],
        recipient_name=route["name"],recipient_email=route["email"],
        routing_reason=route["reason"],status="DRAFT"
    )
    db.add(row);db.commit();db.refresh(row);return row
