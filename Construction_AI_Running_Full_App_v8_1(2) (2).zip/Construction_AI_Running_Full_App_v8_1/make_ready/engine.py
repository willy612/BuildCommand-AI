from datetime import datetime,date,timedelta
from db.models import MakeReadyAction,MakeReadySnapshot,ScheduleActivity,ActivityAssignment,Subcontractor
from activity_release.engine import evaluate_activity_release
from lookahead.engine import lookahead_activities
from operations.settings import lead_times
from operations.routing import route_project_user
from forecasting.engine import record_clearance

LEAD_DAYS={
    "Predecessors":3,
    "Inspection / Quality":2,
    "Permit / authorization":10,
    "Subcontractor commitment":14,
    "Submittals / procurement":21,
    "Site conditions":2,
}

def _parse_date(value):
    if not value: return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try: return datetime.strptime(str(value),fmt).date()
        except Exception: pass
    return None

def _responsible_party(db,project_id,activity,gate):
    if gate=="Subcontractor commitment":
        aa=db.query(ActivityAssignment).filter(
            ActivityAssignment.project_id==project_id,
            ActivityAssignment.schedule_activity_id==activity.id
        ).first()
        if aa:
            s=db.query(Subcontractor).filter(Subcontractor.id==aa.subcontractor_id).first()
            if s: return "SUBCONTRACTOR",s.id,s.name
    if gate=="Submittals / procurement":
        return "PROJECT_TEAM",None,"Project engineer / procurement"
    if gate=="Permit / authorization":
        return "PROJECT_TEAM",None,"Project manager / permit coordinator"
    if gate=="Inspection / Quality":
        return "PROJECT_TEAM",None,"Superintendent / quality"
    if gate=="Site conditions":
        return "PROJECT_TEAM",None,"Superintendent"
    return "PROJECT_TEAM",None,"Project team"

def sync_make_ready_actions(db,project_id,weeks=6):
    activities=lookahead_activities(db,project_id,weeks=weeks)
    from db.models import Project
    project=db.query(Project).filter(Project.id==project_id).first()
    company_id=project.company_id if project else None
    lead_config=lead_times(db,company_id) if company_id else LEAD_DAYS
    created=[]
    statuses={"READY":0,"AT RISK":0,"HOLD":0}
    for activity in activities:
        result=evaluate_activity_release(db,project_id,activity.id)
        statuses[result["status"]]=statuses.get(result["status"],0)+1
        start=_parse_date(activity.planned_start) or date.today()
        for gate in result["blocking_reasons"]+result["risk_reasons"]:
            lead=lead_config.get(gate["gate"],7)
            required_by=start-timedelta(days=lead)
            rtype,rid,rlabel=_responsible_party(db,project_id,activity,gate["gate"])
            existing=db.query(MakeReadyAction).filter(
                MakeReadyAction.project_id==project_id,
                MakeReadyAction.schedule_activity_id==activity.id,
                MakeReadyAction.gate_name==gate["gate"],
                MakeReadyAction.status!="CLOSED"
            ).first()
            priority="CRITICAL" if required_by < date.today() or result["status"]=="HOLD" else "HIGH"
            if existing:
                existing.reason=gate["reason"]
                existing.required_by=required_by.isoformat()
                existing.priority=priority
                existing.responsible_type=rtype
                existing.responsible_id=rid
            else:
                existing=MakeReadyAction(
                    project_id=project_id,schedule_activity_id=activity.id,
                    gate_name=gate["gate"],
                    title=f"Clear {gate['gate']} for {activity.name}",
                    reason=gate["reason"],responsible_type=rtype,responsible_id=rid,
                    required_by=required_by.isoformat(),status="OPEN",priority=priority
                )
                db.add(existing); created.append(existing)
    db.commit()
    end=date.today()+timedelta(weeks=weeks)
    snap=MakeReadySnapshot(
        project_id=project_id,window_start=date.today().isoformat(),window_end=end.isoformat(),
        ready_count=statuses.get("READY",0),at_risk_count=statuses.get("AT RISK",0),
        hold_count=statuses.get("HOLD",0)
    )
    db.add(snap); db.commit()
    return created,snap

def close_resolved_actions(db,project_id):
    rows=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.status!="CLOSED"
    ).all()
    closed=0
    for row in rows:
        result=evaluate_activity_release(db,project_id,row.schedule_activity_id)
        unresolved={g["gate"] for g in result["blocking_reasons"]+result["risk_reasons"]}
        if row.gate_name not in unresolved:
            row.status="CLOSED"
            record_clearance(db,row)
            closed+=1
    db.commit()
    return closed
