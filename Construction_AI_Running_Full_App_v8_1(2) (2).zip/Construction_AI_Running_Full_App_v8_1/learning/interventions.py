from db.models import InterventionOutcome

def record_outcome(db,project_id,action,intervention_type,predicted_days_saved,actual_days_saved,resolved_on_time,notes=""):
    delta=abs(float(predicted_days_saved or 0)-float(actual_days_saved or 0))
    rating="STRONG" if resolved_on_time and delta<=1 else "MIXED" if resolved_on_time else "WEAK"
    row=InterventionOutcome(
        project_id=project_id,superintendent_action_id=action.id,
        schedule_activity_id=action.schedule_activity_id,
        intervention_type=intervention_type,predicted_days_saved=predicted_days_saved or 0,
        actual_days_saved=actual_days_saved or 0,resolved_on_time=bool(resolved_on_time),
        outcome_rating=rating,notes=notes
    )
    db.add(row);db.commit();db.refresh(row);return row

def intervention_scorecard(db,project_id):
    rows=db.query(InterventionOutcome).filter(InterventionOutcome.project_id==project_id).all()
    grouped={}
    for r in rows:
        g=grouped.setdefault(r.intervention_type,{"count":0,"predicted":0.0,"actual":0.0,"on_time":0})
        g["count"]+=1;g["predicted"]+=r.predicted_days_saved or 0;g["actual"]+=r.actual_days_saved or 0
        g["on_time"]+=1 if r.resolved_on_time else 0
    for g in grouped.values():
        g["on_time_rate"]=g["on_time"]/g["count"] if g["count"] else 0
    return grouped
