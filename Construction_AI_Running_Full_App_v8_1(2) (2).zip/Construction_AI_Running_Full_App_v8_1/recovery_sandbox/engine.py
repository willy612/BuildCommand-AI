from datetime import datetime,date,timedelta
from collections import defaultdict,deque
from db.models import (
    ScheduleActivity,ScheduleRelationship,ScheduleActivityAdvanced,
    ScheduleRelationshipAdvanced,CPMCalculationSnapshot,
    RecoverySandboxRun,RecoverySandboxActivityResult
)

def _parse(v):
    if not v:return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try:return datetime.strptime(str(v)[:10],fmt).date()
        except:pass
    return None

def _add_workdays(start,days,include_saturday=False):
    if days==0:return start
    step=1 if days>0 else -1
    remaining=abs(int(round(days)));d=start
    while remaining:
        d+=timedelta(days=step)
        work=d.weekday()<5 or (include_saturday and d.weekday()==5)
        if work:remaining-=1
    return d

def _wdiff(a,b,include_saturday=False):
    if not a or not b:return 0
    if a==b:return 0
    step=1 if b>a else -1;d=a;n=0
    while d!=b:
        d+=timedelta(days=step)
        if d.weekday()<5 or (include_saturday and d.weekday()==5):n+=step
    return n

def _duration(a,adv):
    if adv and (adv.remaining_duration_days or 0)>0:
        return max(1,int(round(adv.remaining_duration_days)))
    s=_parse(a.planned_start);f=_parse(a.planned_finish)
    return max(1,_wdiff(s,f)+1) if s and f else 1

def _network(db,project_id):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    by={a.external_id:a for a in acts};adv={}
    for a in acts:
        adv[a.external_id]=db.query(ScheduleActivityAdvanced).filter(
            ScheduleActivityAdvanced.schedule_activity_id==a.id).first()
    pred=defaultdict(list);succ=defaultdict(list);indeg={k:0 for k in by}
    for r in db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all():
        if r.predecessor_external_id not in by or r.successor_external_id not in by:continue
        ar=db.query(ScheduleRelationshipAdvanced).filter(ScheduleRelationshipAdvanced.relationship_id==r.id).first()
        typ=(ar.relationship_type if ar else getattr(r,"relationship_type","FS") or "FS").upper()
        lag=float(ar.lag_days if ar else getattr(r,"lag_days",0) or 0)
        e=(r.predecessor_external_id,r.successor_external_id,typ,lag)
        pred[r.successor_external_id].append(e);succ[r.predecessor_external_id].append(e);indeg[r.successor_external_id]+=1
    q=deque([k for k,v in indeg.items() if v==0]);order=[]
    while q:
        n=q.popleft();order.append(n)
        for _,s,_,_ in succ[n]:
            indeg[s]-=1
            if indeg[s]==0:q.append(s)
    for k in by:
        if k not in order:order.append(k)
    return by,adv,pred,succ,order

def _forward(by,adv,pred,order,durations,include_saturday=False,data_date=None):
    data_date=data_date or date.today()
    ES={};EF={}
    for k in order:
        base=max(data_date,_parse(by[k].planned_start) or data_date)
        es=base
        for p,s,typ,lag in pred[k]:
            lag=int(round(lag))
            if typ=="FS": cand=_add_workdays(EF[p],lag+1,include_saturday)
            elif typ=="SS": cand=_add_workdays(ES[p],lag,include_saturday)
            elif typ=="FF":
                rf=_add_workdays(EF[p],lag,include_saturday)
                cand=_add_workdays(rf,-(durations[k]-1),include_saturday)
            elif typ=="SF":
                rf=_add_workdays(ES[p],lag,include_saturday)
                cand=_add_workdays(rf,-(durations[k]-1),include_saturday)
            else: cand=_add_workdays(EF[p],lag+1,include_saturday)
            es=max(es,cand)
        ES[k]=es;EF[k]=_add_workdays(es,durations[k]-1,include_saturday)
    return ES,EF

def run_sandbox(db,project_id,activity_id,scenario_type,scenario_value=0):
    by,adv,pred,succ,order=_network(db,project_id)
    target=next((a for a in by.values() if a.id==activity_id),None)
    if not target:return None,[]
    data_dates=[_parse(x.data_date) for x in adv.values() if x and x.data_date]
    data_date=max([x for x in data_dates if x] or [date.today()])
    original_d={k:_duration(by[k],adv[k]) for k in by}
    original_es,original_ef=_forward(by,adv,pred,order,original_d,False,data_date)
    sim_d=dict(original_d);include_sat=False
    assumptions=[]
    ext=target.external_id
    if scenario_type=="ADD_CREW":
        pct=max(0,min(float(scenario_value or 20),60))/100
        # conservative: duration gain is half the crew increase to reflect diminishing returns
        sim_d[ext]=max(1,int(round(original_d[ext]*(1-pct*0.5))))
        assumptions.append("Crew increase uses a diminishing-return duration factor; field feasibility is not guaranteed.")
    elif scenario_type=="OVERTIME":
        pct=max(0,min(float(scenario_value or 10),40))/100
        # overtime benefit discounted for productivity loss
        sim_d[ext]=max(1,int(round(original_d[ext]*(1-pct*0.45))))
        assumptions.append("Overtime benefit is discounted for productivity loss.")
    elif scenario_type=="WORK_SATURDAY":
        include_sat=True
        assumptions.append("Saturday is treated as a workday across the simulated network.")
    elif scenario_type=="CLEAR_CONSTRAINT":
        days=max(0,int(round(scenario_value or 1)))
        sim_d[ext]=max(1,original_d[ext]-days)
        assumptions.append("Constraint clearance is modeled as direct remaining-duration relief on the selected activity.")
    elif scenario_type=="RESEQUENCE":
        pct=max(0,min(float(scenario_value or 20),50))/100
        sim_d[ext]=max(1,int(round(original_d[ext]*(1-pct))))
        assumptions.append("Resequencing is approximated as overlap on the selected activity; logic must be validated before execution.")

    sim_es,sim_ef=_forward(by,adv,pred,order,sim_d,include_sat,data_date)
    original_finish=max(original_ef.values());sim_finish=max(sim_ef.values())
    project_recovered=max(0,_wdiff(sim_finish,original_finish,include_sat))
    activity_recovered=max(0,_wdiff(sim_ef[ext],original_ef[ext],include_sat))
    changed=[]
    for k in order:
        ss=_wdiff(original_es[k],sim_es[k],include_sat)
        fs=_wdiff(original_ef[k],sim_ef[k],include_sat)
        if ss or fs:
            changed.append((k,ss,fs))
    confidence=0.55 if scenario_type in ("CLEAR_CONSTRAINT","RESEQUENCE") else 0.45
    run=RecoverySandboxRun(
        project_id=project_id,schedule_activity_id=activity_id,scenario_type=scenario_type,
        scenario_value=float(scenario_value or 0),original_completion=original_finish.isoformat(),
        simulated_completion=sim_finish.isoformat(),project_days_recovered=project_recovered,
        activity_days_recovered=activity_recovered,downstream_changed_count=len(changed),
        confidence=confidence,
        assumptions=" ".join(assumptions)+" Screening sandbox only; validate safety, cost, contracts, resources, workspace, and authoritative CPM."
    )
    db.add(run);db.commit();db.refresh(run)
    results=[]
    for k,ss,fs in changed:
        row=RecoverySandboxActivityResult(
            recovery_sandbox_run_id=run.id,schedule_activity_id=by[k].id,
            original_start=original_es[k].isoformat(),original_finish=original_ef[k].isoformat(),
            simulated_start=sim_es[k].isoformat(),simulated_finish=sim_ef[k].isoformat(),
            start_shift_days=ss,finish_shift_days=fs
        )
        db.add(row);results.append(row)
    db.commit()
    return run,results
