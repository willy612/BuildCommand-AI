from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, DateTime, Boolean, Text, ForeignKey, Float
)
from sqlalchemy.orm import relationship
from db.session import Base

class Company(Base):
    __tablename__ = "companies"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    display_name = Column(String(255), default="")
    role = Column(String(50), default="superintendent")
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True)
    name = Column(String(255), nullable=False)
    project_number = Column(String(100), default="")
    project_type = Column(String(100), default="")
    address_or_site = Column(String(500), default="")
    jurisdiction = Column(String(255), default="")
    owner = Column(String(255), default="")
    architect = Column(String(255), default="")
    general_contractor = Column(String(255), default="")
    status = Column(String(50), default="ACTIVE")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

class ProjectMember(Base):
    __tablename__ = "project_members"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    role = Column(String(50), default="viewer")

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    filename = Column(String(500), nullable=False)
    storage_path = Column(String(1000), nullable=False)
    document_type = Column(String(100), default="other")
    discipline = Column(String(100), default="")
    sheet_or_section = Column(String(100), default="")
    title = Column(String(500), default="")
    revision = Column(String(100), default="")
    status = Column(String(50), default="UPLOADED")
    source_hash = Column(String(128), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class TaskState(Base):
    __tablename__ = "task_states"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    task_id = Column(String(255), nullable=False, index=True)
    status = Column(String(50), default="NOT_VERIFIED")
    percent_complete = Column(Float, default=0.0)
    notes = Column(Text, default="")
    updated_at = Column(DateTime, default=datetime.utcnow)

class PermitRecord(Base):
    __tablename__ = "permit_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    task_id = Column(String(255), nullable=False)
    authority = Column(String(255), default="")
    permit_type = Column(String(255), default="")
    status = Column(String(50), default="NOT_CHECKED")
    permit_number = Column(String(255), default="")
    notes = Column(Text, default="")

class InspectionRecord(Base):
    __tablename__ = "inspection_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    task_id = Column(String(255), nullable=False)
    inspection_type = Column(String(255), default="")
    authority_or_agency = Column(String(255), default="")
    required = Column(Boolean, default=True)
    scheduled_date = Column(String(50), default="")
    result = Column(String(50), default="PENDING")
    report_number = Column(String(255), default="")
    notes = Column(Text, default="")

class TestRecord(Base):
    __tablename__ = "test_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    task_id = Column(String(255), nullable=False)
    test_type = Column(String(255), default="")
    testing_agency = Column(String(255), default="")
    required = Column(Boolean, default=True)
    scheduled_date = Column(String(50), default="")
    result = Column(String(50), default="PENDING")
    report_number = Column(String(255), default="")
    notes = Column(Text, default="")

class ProcurementItem(Base):
    __tablename__ = "procurement_items"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    task_id = Column(String(255), default="")
    name = Column(String(500), nullable=False)
    spec_section = Column(String(100), default="")
    trade = Column(String(100), default="")
    responsible_company = Column(String(255), default="")
    submittal_status = Column(String(50), default="NOT_STARTED")
    procurement_status = Column(String(50), default="NOT_RELEASED")
    required_on_site_date = Column(String(50), default="")
    fabrication_days = Column(Integer, default=0)
    shipping_days = Column(Integer, default=0)
    gc_review_days = Column(Integer, default=0)
    design_review_days = Column(Integer, default=0)
    resubmit_buffer_days = Column(Integer, default=0)
    notes = Column(Text, default="")

class RFIRecord(Base):
    __tablename__ = "rfi_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    rfi_number = Column(String(100), default="")
    subject = Column(String(500), default="")
    status = Column(String(50), default="OPEN")
    blocking = Column(Boolean, default=False)
    task_id = Column(String(255), default="")
    notes = Column(Text, default="")

class ConstraintRecord(Base):
    __tablename__ = "constraint_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    task_id = Column(String(255), default="")
    category = Column(String(100), default="other")
    description = Column(Text, nullable=False)
    blocking = Column(Boolean, default=True)
    status = Column(String(50), default="OPEN")
    responsible_party = Column(String(255), default="")
    due_date = Column(String(50), default="")

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(255), nullable=False)
    entity_type = Column(String(100), default="")
    entity_id = Column(String(100), default="")
    payload_json = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class DocumentPage(Base):
    __tablename__ = "document_pages"
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
    page_number = Column(Integer, nullable=False)
    sheet_number = Column(String(100), default="")
    sheet_title = Column(String(500), default="")
    discipline = Column(String(100), default="")
    source_ref = Column(String(1000), default="")
    text_excerpt = Column(Text, default="")
    visual_summary = Column(Text, default="")
    status = Column(String(50), default="PARSED")
    created_at = Column(DateTime, default=datetime.utcnow)

class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
    page_number = Column(Integer, default=0)
    sheet_number = Column(String(100), default="")
    discipline = Column(String(100), default="")
    section = Column(String(255), default="")
    source_type = Column(String(50), default="text")
    source_ref = Column(String(1000), default="")
    content = Column(Text, nullable=False)
    status = Column(String(50), default="CURRENT")
    embedding_json = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class IngestionJob(Base):
    __tablename__ = "ingestion_jobs"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False, index=True)
    status = Column(String(50), default="QUEUED")
    stage = Column(String(100), default="")
    progress = Column(Integer, default=0)
    error_message = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class JurisdictionSource(Base):
    __tablename__ = "jurisdiction_sources"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    jurisdiction = Column(String(255), nullable=False)
    source_type = Column(String(100), default="")
    title = Column(String(500), nullable=False)
    source_url = Column(String(1000), default="")
    code_cycle = Column(String(100), default="")
    effective_date = Column(String(50), default="")
    verified_date = Column(String(50), default="")
    notes = Column(Text, default="")
    status = Column(String(50), default="SOURCE_NEEDED")

class SafetySource(Base):
    __tablename__ = "safety_sources"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    authority = Column(String(255), default="")
    standard = Column(String(255), default="")
    topic = Column(String(255), default="")
    source_url = Column(String(1000), default="")
    verified_date = Column(String(50), default="")
    applies_to_json = Column(Text, default="[]")
    notes = Column(Text, default="")
    status = Column(String(50), default="SOURCE_NEEDED")

class NotificationRecord(Base):
    __tablename__ = "notification_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    severity = Column(String(50), default="info")
    category = Column(String(100), default="")
    title = Column(String(500), nullable=False)
    message = Column(Text, default="")
    status = Column(String(50), default="OPEN")
    created_at = Column(DateTime, default=datetime.utcnow)


class ScheduleActivity(Base):
    __tablename__ = "schedule_activities"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    external_id = Column(String(255), nullable=False, index=True)
    name = Column(String(500), nullable=False)
    planned_start = Column(String(50), default="")
    planned_finish = Column(String(50), default="")
    percent_complete = Column(Float, default=0.0)
    phase = Column(String(255), default="")
    trade = Column(String(255), default="")
    mapped_task_id = Column(String(255), default="")
    status = Column(String(50), default="NOT_STARTED")

class ScheduleRelationship(Base):
    __tablename__ = "schedule_relationships"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    predecessor_external_id = Column(String(255), nullable=False)
    successor_external_id = Column(String(255), nullable=False)
    relationship_type = Column(String(20), default="FS")
    lag_days = Column(Float, default=0.0)

class DocumentRevisionEvent(Base):
    __tablename__ = "document_revision_events"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=False)
    superseded_document_id = Column(Integer, nullable=True)
    reason = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class Subcontractor(Base):
    __tablename__ = "subcontractors"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True, index=True)
    name = Column(String(255), nullable=False)
    trade = Column(String(255), default="")
    scope = Column(Text, default="")
    status = Column(String(50), default="ACTIVE")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class SubcontractorContact(Base):
    __tablename__ = "subcontractor_contacts"
    id = Column(Integer, primary_key=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    role = Column(String(100), default="")
    email = Column(String(255), default="")
    phone = Column(String(100), default="")
    primary_contact = Column(Boolean, default=False)
    active = Column(Boolean, default=True)

class ProjectSubcontractor(Base):
    __tablename__ = "project_subcontractors"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    project_scope = Column(Text, default="")
    project_trade = Column(String(255), default="")
    status = Column(String(50), default="ACTIVE")

class ActivityAssignment(Base):
    __tablename__ = "activity_assignments"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    responsibility = Column(String(100), default="PRIMARY")

class LookaheadCommitment(Base):
    __tablename__ = "lookahead_commitments"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    requested_start = Column(String(50), default="")
    requested_finish = Column(String(50), default="")
    response_due = Column(String(50), default="")
    status = Column(String(50), default="PENDING")
    manpower_commitment = Column(String(100), default="")
    material_status = Column(String(100), default="")
    equipment_status = Column(String(100), default="")
    delay_reason = Column(Text, default="")
    response_text = Column(Text, default="")
    superintendent_review_status = Column(String(50), default="PENDING")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)

class CommunicationDraft(Base):
    __tablename__ = "communication_drafts"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    recipient_email = Column(String(255), default="")
    subject = Column(String(500), default="")
    body = Column(Text, default="")
    communication_type = Column(String(100), default="LOOKAHEAD_CONFIRMATION")
    status = Column(String(50), default="DRAFT")
    created_at = Column(DateTime, default=datetime.utcnow)

class SubcontractorResponse(Base):
    __tablename__ = "subcontractor_responses"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    response_type = Column(String(100), default="OTHER")
    response_text = Column(Text, default="")
    proposed_delay_days = Column(Float, default=0.0)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)


class CompanySettings(Base):
    __tablename__ = "company_settings"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, unique=True, index=True)
    timezone = Column(String(100), default="America/Los_Angeles")
    default_lookahead_weeks = Column(Integer, default=6)
    require_send_approval = Column(Boolean, default=True)
    require_ai_change_approval = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ProjectRoleAssignment(Base):
    __tablename__ = "project_role_assignments"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    role = Column(String(100), nullable=False)
    primary_assignment = Column(Boolean, default=False)
    active = Column(Boolean, default=True)

class CompanySubcontractorAccess(Base):
    __tablename__ = "company_subcontractor_access"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    approved = Column(Boolean, default=True)
    notes = Column(Text, default="")


class ApprovalQueueItem(Base):
    __tablename__ = "approval_queue_items"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    requested_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    approval_type = Column(String(100), nullable=False)
    entity_type = Column(String(100), default="")
    entity_id = Column(String(100), default="")
    title = Column(String(500), nullable=False)
    summary = Column(Text, default="")
    payload_json = Column(Text, default="")
    status = Column(String(50), default="PENDING")
    decided_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    decision_notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    decided_at = Column(DateTime, nullable=True)

class InboxItem(Base):
    __tablename__ = "inbox_items"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, index=True)
    category = Column(String(100), default="PROJECT")
    severity = Column(String(50), default="info")
    title = Column(String(500), nullable=False)
    message = Column(Text, default="")
    status = Column(String(50), default="UNREAD")
    created_at = Column(DateTime, default=datetime.utcnow)

class ProjectSetupProgress(Base):
    __tablename__ = "project_setup_progress"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, unique=True, index=True)
    company_info_complete = Column(Boolean, default=False)
    team_complete = Column(Boolean, default=False)
    jurisdiction_complete = Column(Boolean, default=False)
    documents_complete = Column(Boolean, default=False)
    schedule_complete = Column(Boolean, default=False)
    subcontractors_complete = Column(Boolean, default=False)
    requirements_complete = Column(Boolean, default=False)
    completed = Column(Boolean, default=False)
    updated_at = Column(DateTime, default=datetime.utcnow)

class SubcontractorPortalUser(Base):
    __tablename__ = "subcontractor_portal_users"
    id = Column(Integer, primary_key=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    email = Column(String(255), nullable=False, index=True)
    display_name = Column(String(255), default="")
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class DailyFieldReport(Base):
    __tablename__ = "daily_field_reports"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    report_date = Column(String(50), nullable=False, index=True)
    superintendent_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    weather = Column(String(255), default="")
    site_conditions = Column(Text, default="")
    work_completed = Column(Text, default="")
    delays = Column(Text, default="")
    safety_notes = Column(Text, default="")
    inspection_notes = Column(Text, default="")
    tomorrow_plan = Column(Text, default="")
    status = Column(String(50), default="DRAFT")
    created_at = Column(DateTime, default=datetime.utcnow)

class FieldUpdate(Base):
    __tablename__ = "field_updates"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    update_type = Column(String(100), default="PROGRESS")
    text = Column(Text, nullable=False)
    percent_complete_proposal = Column(Float, nullable=True)
    status = Column(String(50), default="RECORDED")
    created_at = Column(DateTime, default=datetime.utcnow)

class FieldPhotoRecord(Base):
    __tablename__ = "field_photo_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True)
    storage_path = Column(String(1000), default="")
    caption = Column(Text, default="")
    observation = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ConstraintProposal(Base):
    __tablename__ = "constraint_proposals"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True)
    source_type = Column(String(100), default="FIELD_UPDATE")
    source_id = Column(String(100), default="")
    category = Column(String(100), default="OTHER")
    description = Column(Text, nullable=False)
    responsible_party = Column(String(255), default="")
    required_by = Column(String(50), default="")
    schedule_exposure = Column(Text, default="")
    recommended_action = Column(Text, default="")
    confidence = Column(Float, default=0.0)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)


class ChangeEvent(Base):
    __tablename__ = "change_events"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    source_document_id = Column(Integer, ForeignKey("documents.id"), nullable=True)
    prior_document_id = Column(Integer, ForeignKey("documents.id"), nullable=True)
    change_type = Column(String(100), default="DOCUMENT_REVISION")
    title = Column(String(500), nullable=False)
    summary = Column(Text, default="")
    affected_tasks_json = Column(Text, default="[]")
    affected_subcontractors_json = Column(Text, default="[]")
    affected_schedule_json = Column(Text, default="[]")
    possible_rfi = Column(Boolean, default=False)
    possible_cost_change = Column(Boolean, default=False)
    possible_schedule_change = Column(Boolean, default=False)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)

class ChangeImpactItem(Base):
    __tablename__ = "change_impact_items"
    id = Column(Integer, primary_key=True)
    change_event_id = Column(Integer, ForeignKey("change_events.id"), nullable=False, index=True)
    impact_type = Column(String(100), nullable=False)
    entity_type = Column(String(100), default="")
    entity_id = Column(String(100), default="")
    label = Column(String(500), default="")
    severity = Column(String(50), default="INFO")
    reason = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class CostChangeEvent(Base):
    __tablename__ = "cost_change_events"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    change_event_id = Column(Integer, ForeignKey("change_events.id"), nullable=True, index=True)
    title = Column(String(500), nullable=False)
    description = Column(Text, default="")
    responsible_party = Column(String(255), default="")
    estimated_cost = Column(Float, default=0.0)
    approved_cost = Column(Float, default=0.0)
    status = Column(String(50), default="POTENTIAL")
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleImpactEvent(Base):
    __tablename__ = "schedule_impact_events"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    change_event_id = Column(Integer, ForeignKey("change_events.id"), nullable=True, index=True)
    source_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    exposure_days = Column(Float, default=0.0)
    downstream_activity_ids_json = Column(Text, default="[]")
    milestone_exposure_json = Column(Text, default="[]")
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)

class OutboundNotification(Base):
    __tablename__ = "outbound_notifications"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True)
    channel = Column(String(50), default="IN_APP")
    recipient = Column(String(255), default="")
    subject = Column(String(500), default="")
    body = Column(Text, default="")
    status = Column(String(50), default="DRAFT")
    created_at = Column(DateTime, default=datetime.utcnow)


class FieldVisionProposal(Base):
    __tablename__ = "field_vision_proposals"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    photo_record_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    observation_type = Column(String(100), default="GENERAL")
    title = Column(String(500), default="")
    observation = Column(Text, default="")
    suggested_action = Column(Text, default="")
    suggested_percent_complete = Column(Float, nullable=True)
    confidence = Column(Float, default=0.0)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)


class FieldVerificationProposal(Base):
    __tablename__ = "field_verification_proposals"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    photo_record_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    verification_type = Column(String(100), default="DOCUMENT_CHECK")
    title = Column(String(500), default="")
    field_observation = Column(Text, default="")
    requirement_text = Column(Text, default="")
    source_document_id = Column(Integer, ForeignKey("documents.id"), nullable=True)
    source_page = Column(Integer, nullable=True)
    source_ref = Column(String(500), default="")
    result = Column(String(50), default="NOT_VERIFIED")
    suggested_action = Column(Text, default="")
    confidence = Column(Float, default=0.0)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)

class PunchQualityItem(Base):
    __tablename__ = "punch_quality_items"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    source_photo_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=True)
    title = Column(String(500), nullable=False)
    description = Column(Text, default="")
    category = Column(String(100), default="QUALITY")
    responsible_party = Column(String(255), default="")
    status = Column(String(50), default="OPEN")
    created_at = Column(DateTime, default=datetime.utcnow)


class ProjectLocation(Base):
    __tablename__ = "project_locations"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    parent_id = Column(Integer, ForeignKey("project_locations.id"), nullable=True)
    location_type = Column(String(50), default="AREA")
    code = Column(String(100), default="")
    name = Column(String(255), nullable=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class PhotoLocationLink(Base):
    __tablename__ = "photo_location_links"
    id = Column(Integer, primary_key=True)
    photo_record_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=False, index=True)
    location_id = Column(Integer, ForeignKey("project_locations.id"), nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class QualityIssue(Base):
    __tablename__ = "quality_issues"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    location_id = Column(Integer, ForeignKey("project_locations.id"), nullable=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True)
    source_photo_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=True)
    title = Column(String(500), nullable=False)
    description = Column(Text, default="")
    category = Column(String(100), default="PUNCH")
    priority = Column(String(50), default="NORMAL")
    status = Column(String(50), default="OPEN")
    due_date = Column(String(50), default="")
    verification_photo_id = Column(Integer, ForeignKey("field_photo_records.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class InspectionTestRecord(Base):
    __tablename__ = "inspection_test_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    location_id = Column(Integer, ForeignKey("project_locations.id"), nullable=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True)
    inspection_type = Column(String(255), nullable=False)
    authority = Column(String(255), default="")
    planned_date = Column(String(50), default="")
    actual_date = Column(String(50), default="")
    result = Column(String(50), default="PENDING")
    notes = Column(Text, default="")
    source_ref = Column(String(500), default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class ReadinessGate(Base):
    __tablename__ = "readiness_gates"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    gate_type = Column(String(100), nullable=False)
    source_entity_type = Column(String(100), default="")
    source_entity_id = Column(Integer, nullable=True)
    title = Column(String(500), nullable=False)
    status = Column(String(50), default="OPEN")
    blocking = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class SiteConditionRecord(Base):
    __tablename__ = "site_condition_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    condition_type = Column(String(100), default="GENERAL")
    status = Column(String(50), default="CLEAR")
    description = Column(Text, default="")
    blocking = Column(Boolean, default=False)
    recorded_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ActivityReleaseDecision(Base):
    __tablename__ = "activity_release_decisions"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    status = Column(String(50), default="HOLD")
    reasons_json = Column(Text, default="[]")
    evaluated_at = Column(DateTime, default=datetime.utcnow)


class MakeReadyAction(Base):
    __tablename__ = "make_ready_actions"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    gate_name = Column(String(150), nullable=False)
    title = Column(String(500), nullable=False)
    reason = Column(Text, default="")
    responsible_type = Column(String(100), default="PROJECT_TEAM")
    responsible_id = Column(Integer, nullable=True)
    required_by = Column(String(50), default="")
    status = Column(String(50), default="OPEN")
    priority = Column(String(50), default="NORMAL")
    last_followup_at = Column(DateTime, nullable=True)
    escalation_level = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

class MakeReadySnapshot(Base):
    __tablename__ = "make_ready_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    window_start = Column(String(50), default="")
    window_end = Column(String(50), default="")
    ready_count = Column(Integer, default=0)
    at_risk_count = Column(Integer, default=0)
    hold_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class MakeReadyLeadTimeSetting(Base):
    __tablename__ = "make_ready_lead_time_settings"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    gate_name = Column(String(150), nullable=False)
    lead_days = Column(Integer, default=7)
    created_at = Column(DateTime, default=datetime.utcnow)

class CoordinationMeetingRecord(Base):
    __tablename__ = "coordination_meeting_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    meeting_date = Column(String(50), nullable=False)
    lookahead_weeks = Column(Integer, default=6)
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class SubcontractorReliabilitySnapshot(Base):
    __tablename__ = "subcontractor_reliability_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    total_commitments = Column(Integer, default=0)
    confirmed = Column(Integer, default=0)
    delay_reports = Column(Integer, default=0)
    no_response = Column(Integer, default=0)
    closed_quality_items = Column(Integer, default=0)
    open_quality_items = Column(Integer, default=0)
    score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class ProductionRecord(Base):
    __tablename__ = "production_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True)
    work_date = Column(String(50), nullable=False)
    crew_size = Column(Integer, default=0)
    regular_hours = Column(Float, default=0.0)
    overtime_hours = Column(Float, default=0.0)
    quantity_installed = Column(Float, default=0.0)
    quantity_unit = Column(String(50), default="")
    planned_quantity = Column(Float, default=0.0)
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ConstraintClearanceHistory(Base):
    __tablename__ = "constraint_clearance_history"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    make_ready_action_id = Column(Integer, ForeignKey("make_ready_actions.id"), nullable=False, index=True)
    planned_clear_date = Column(String(50), default="")
    actual_clear_date = Column(String(50), default="")
    variance_days = Column(Integer, default=0)
    gate_name = Column(String(150), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleExposureRecord(Base):
    __tablename__ = "schedule_exposure_records"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    source_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    exposed_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    make_ready_action_id = Column(Integer, ForeignKey("make_ready_actions.id"), nullable=True)
    relationship_depth = Column(Integer, default=1)
    exposure_type = Column(String(100), default="DOWNSTREAM")
    risk_days = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class ActivityForecastSnapshot(Base):
    __tablename__ = "activity_forecast_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    planned_finish = Column(String(50), default="")
    forecast_finish = Column(String(50), default="")
    remaining_duration_days = Column(Float, default=0.0)
    forecast_variance_days = Column(Integer, default=0)
    confidence = Column(Float, default=0.0)
    critical_candidate = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class ProjectForecastSnapshot(Base):
    __tablename__ = "project_forecast_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    planned_completion = Column(String(50), default="")
    forecast_completion = Column(String(50), default="")
    variance_days = Column(Integer, default=0)
    milestone_confidence = Column(Float, default=0.0)
    critical_activity_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class ScheduleActivityAdvanced(Base):
    __tablename__ = "schedule_activity_advanced"
    id = Column(Integer, primary_key=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, unique=True, index=True)
    baseline_start = Column(String(50), default="")
    baseline_finish = Column(String(50), default="")
    data_date = Column(String(50), default="")
    calendar_name = Column(String(255), default="")
    total_float_days = Column(Float, default=0.0)
    free_float_days = Column(Float, default=0.0)
    actual_start = Column(String(50), default="")
    actual_finish = Column(String(50), default="")
    remaining_duration_days = Column(Float, default=0.0)
    constraint_type = Column(String(100), default="")
    constraint_date = Column(String(50), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleRelationshipAdvanced(Base):
    __tablename__ = "schedule_relationship_advanced"
    id = Column(Integer, primary_key=True)
    relationship_id = Column(Integer, ForeignKey("schedule_relationships.id"), nullable=False, unique=True, index=True)
    relationship_type = Column(String(20), default="FS")
    lag_days = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)

class PortfolioForecastSnapshot(Base):
    __tablename__ = "portfolio_forecast_snapshots"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    planned_completion = Column(String(50), default="")
    forecast_completion = Column(String(50), default="")
    variance_days = Column(Integer, default=0)
    confidence = Column(Float, default=0.0)
    hold_count = Column(Integer, default=0)
    at_risk_count = Column(Integer, default=0)
    intervention_score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class CPMCalculationSnapshot(Base):
    __tablename__ = "cpm_calculation_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    early_start = Column(String(50), default="")
    early_finish = Column(String(50), default="")
    late_start = Column(String(50), default="")
    late_finish = Column(String(50), default="")
    total_float_days = Column(Float, default=0.0)
    critical = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleUpdateSnapshot(Base):
    __tablename__ = "schedule_update_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    planned_completion = Column(String(50), default="")
    calculated_completion = Column(String(50), default="")
    critical_count = Column(Integer, default=0)
    negative_float_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class ProjectCalendar(Base):
    __tablename__ = "project_calendars"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    workweek_json = Column(Text, default='{"0":true,"1":true,"2":true,"3":true,"4":true,"5":false,"6":false}')
    hours_per_day = Column(Float, default=8.0)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class ProjectCalendarHoliday(Base):
    __tablename__ = "project_calendar_holidays"
    id = Column(Integer, primary_key=True)
    calendar_id = Column(Integer, ForeignKey("project_calendars.id"), nullable=False, index=True)
    holiday_date = Column(String(50), nullable=False)
    name = Column(String(255), default="Holiday")

class WBSNode(Base):
    __tablename__ = "wbs_nodes"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    external_id = Column(String(255), nullable=False, index=True)
    parent_external_id = Column(String(255), default="")
    code = Column(String(255), default="")
    name = Column(String(500), nullable=False)

class ActivityCodeAssignment(Base):
    __tablename__ = "activity_code_assignments"
    id = Column(Integer, primary_key=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    code_type = Column(String(255), nullable=False)
    code_value = Column(String(255), nullable=False)

class ScheduleQualitySnapshot(Base):
    __tablename__ = "schedule_quality_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    data_date = Column(String(50), default="")
    open_ends = Column(Integer, default=0)
    long_durations = Column(Integer, default=0)
    high_float = Column(Integer, default=0)
    negative_float = Column(Integer, default=0)
    high_lag = Column(Integer, default=0)
    relationship_density = Column(Float, default=0.0)
    quality_score = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class LookaheadScheduleAlignment(Base):
    __tablename__ = "lookahead_schedule_alignment"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    lookahead_start = Column(String(50), default="")
    cpm_start = Column(String(50), default="")
    variance_days = Column(Integer, default=0)
    alignment_status = Column(String(50), default="ALIGNED")
    reason = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class ScheduleVersion(Base):
    __tablename__ = "schedule_versions"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    version_name = Column(String(255), nullable=False)
    data_date = Column(String(50), default="")
    source_type = Column(String(50), default="XER")
    source_filename = Column(String(500), default="")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleVersionActivity(Base):
    __tablename__ = "schedule_version_activities"
    id = Column(Integer, primary_key=True)
    schedule_version_id = Column(Integer, ForeignKey("schedule_versions.id"), nullable=False, index=True)
    external_id = Column(String(255), nullable=False, index=True)
    name = Column(String(500), nullable=False)
    planned_start = Column(String(50), default="")
    planned_finish = Column(String(50), default="")
    percent_complete = Column(Float, default=0.0)
    total_float_days = Column(Float, default=0.0)
    remaining_duration_days = Column(Float, default=0.0)

class FieldScheduleMatch(Base):
    __tablename__ = "field_schedule_matches"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    field_label = Column(String(500), nullable=False)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    match_method = Column(String(50), default="FUZZY")
    match_score = Column(Float, default=0.0)
    status = Column(String(50), default="PENDING_REVIEW")
    created_at = Column(DateTime, default=datetime.utcnow)

class ScheduleDriftAlert(Base):
    __tablename__ = "schedule_drift_alerts"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    alert_type = Column(String(100), default="FIELD_CPM_VARIANCE")
    severity = Column(String(50), default="WARNING")
    variance_days = Column(Integer, default=0)
    message = Column(Text, default="")
    status = Column(String(50), default="OPEN")
    created_at = Column(DateTime, default=datetime.utcnow)


class SuperintendentAction(Base):
    __tablename__ = "superintendent_actions"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    action_type = Column(String(100), nullable=False)
    title = Column(String(500), nullable=False)
    why = Column(Text, default="")
    recommended_action = Column(Text, default="")
    owner_role = Column(String(100), default="superintendent")
    due_date = Column(String(50), default="")
    severity = Column(String(50), default="NORMAL")
    score = Column(Float, default=0.0)
    status = Column(String(50), default="OPEN")
    created_at = Column(DateTime, default=datetime.utcnow)

class RecoveryScenario(Base):
    __tablename__ = "recovery_scenarios"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    scenario_type = Column(String(100), nullable=False)
    description = Column(Text, default="")
    modeled_days_recovered = Column(Float, default=0.0)
    assumptions = Column(Text, default="")
    status = Column(String(50), default="PROPOSED")
    created_at = Column(DateTime, default=datetime.utcnow)


class ActionRoutingRecord(Base):
    __tablename__ = "action_routing_records"
    id = Column(Integer, primary_key=True)
    superintendent_action_id = Column(Integer, ForeignKey("superintendent_actions.id"), nullable=False, index=True)
    recipient_type = Column(String(50), default="PROJECT_USER")
    recipient_id = Column(Integer, nullable=True)
    recipient_name = Column(String(255), default="")
    recipient_email = Column(String(255), default="")
    routing_reason = Column(Text, default="")
    status = Column(String(50), default="DRAFT")
    created_at = Column(DateTime, default=datetime.utcnow)

class ActionResponse(Base):
    __tablename__ = "action_responses"
    id = Column(Integer, primary_key=True)
    superintendent_action_id = Column(Integer, ForeignKey("superintendent_actions.id"), nullable=False, index=True)
    responder_name = Column(String(255), default="")
    responder_email = Column(String(255), default="")
    response_status = Column(String(50), default="RECEIVED")
    committed_date = Column(String(50), default="")
    delay_expected = Column(Boolean, default=False)
    delay_days = Column(Integer, default=0)
    response_text = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class RecoverySimulation(Base):
    __tablename__ = "recovery_simulations"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    scenario_type = Column(String(100), nullable=False)
    original_remaining_days = Column(Float, default=0.0)
    simulated_remaining_days = Column(Float, default=0.0)
    original_project_finish = Column(String(50), default="")
    simulated_project_finish = Column(String(50), default="")
    modeled_days_recovered = Column(Float, default=0.0)
    confidence = Column(Float, default=0.0)
    assumptions = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class InterventionOutcome(Base):
    __tablename__ = "intervention_outcomes"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    superintendent_action_id = Column(Integer, ForeignKey("superintendent_actions.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    intervention_type = Column(String(100), default="")
    predicted_days_saved = Column(Float, default=0.0)
    actual_days_saved = Column(Float, default=0.0)
    resolved_on_time = Column(Boolean, default=False)
    outcome_rating = Column(String(50), default="UNKNOWN")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class RecoverySandboxRun(Base):
    __tablename__ = "recovery_sandbox_runs"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    scenario_type = Column(String(100), nullable=False)
    scenario_value = Column(Float, default=0.0)
    original_completion = Column(String(50), default="")
    simulated_completion = Column(String(50), default="")
    project_days_recovered = Column(Float, default=0.0)
    activity_days_recovered = Column(Float, default=0.0)
    downstream_changed_count = Column(Integer, default=0)
    confidence = Column(Float, default=0.0)
    assumptions = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class RecoverySandboxActivityResult(Base):
    __tablename__ = "recovery_sandbox_activity_results"
    id = Column(Integer, primary_key=True)
    recovery_sandbox_run_id = Column(Integer, ForeignKey("recovery_sandbox_runs.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    original_start = Column(String(50), default="")
    original_finish = Column(String(50), default="")
    simulated_start = Column(String(50), default="")
    simulated_finish = Column(String(50), default="")
    start_shift_days = Column(Integer, default=0)
    finish_shift_days = Column(Integer, default=0)


class RecoveryOptionEvaluation(Base):
    __tablename__ = "recovery_option_evaluations"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    scenario_type = Column(String(100), nullable=False)
    scenario_value = Column(Float, default=0.0)
    modeled_project_days_recovered = Column(Float, default=0.0)
    modeled_activity_days_recovered = Column(Float, default=0.0)
    estimated_cost = Column(Float, default=0.0)
    constructability_risk = Column(String(50), default="MEDIUM")
    safety_review_required = Column(Boolean, default=True)
    milestone_protection_score = Column(Float, default=0.0)
    confidence = Column(Float, default=0.0)
    optimizer_score = Column(Float, default=0.0)
    assumptions = Column(Text, default="")
    status = Column(String(50), default="PROPOSED")
    created_at = Column(DateTime, default=datetime.utcnow)

class ApprovedRecoveryPlan(Base):
    __tablename__ = "approved_recovery_plans"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    recovery_option_evaluation_id = Column(Integer, ForeignKey("recovery_option_evaluations.id"), nullable=False, index=True)
    approved_by_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_date = Column(String(50), default="")
    target_completion = Column(String(50), default="")
    predicted_days_recovered = Column(Float, default=0.0)
    predicted_cost = Column(Float, default=0.0)
    status = Column(String(50), default="ACTIVE")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class RecoveryOutcomeReview(Base):
    __tablename__ = "recovery_outcome_reviews"
    id = Column(Integer, primary_key=True)
    approved_recovery_plan_id = Column(Integer, ForeignKey("approved_recovery_plans.id"), nullable=False, index=True)
    actual_completion = Column(String(50), default="")
    actual_days_recovered = Column(Float, default=0.0)
    actual_cost = Column(Float, default=0.0)
    met_target = Column(Boolean, default=False)
    outcome_rating = Column(String(50), default="UNKNOWN")
    lessons = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class CompanyLearningSignal(Base):
    __tablename__ = "company_learning_signals"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    signal_type = Column(String(100), nullable=False, index=True)
    category = Column(String(255), default="")
    context_key = Column(String(500), default="")
    numeric_value = Column(Float, default=0.0)
    unit = Column(String(50), default="")
    outcome = Column(String(100), default="")
    evidence = Column(Text, default="")
    confidence = Column(Float, default=0.5)
    created_at = Column(DateTime, default=datetime.utcnow)

class CompanyKnowledgePattern(Base):
    __tablename__ = "company_knowledge_patterns"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    pattern_type = Column(String(100), nullable=False, index=True)
    category = Column(String(255), default="")
    context_key = Column(String(500), default="")
    sample_count = Column(Integer, default=0)
    average_value = Column(Float, default=0.0)
    success_rate = Column(Float, default=0.0)
    confidence = Column(Float, default=0.0)
    recommendation = Column(Text, default="")
    last_refreshed_at = Column(DateTime, default=datetime.utcnow)

class CompanyPlaybookRule(Base):
    __tablename__ = "company_playbook_rules"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    rule_name = Column(String(255), nullable=False)
    trigger_type = Column(String(100), nullable=False)
    trigger_category = Column(String(255), default="")
    recommended_action = Column(Text, nullable=False)
    evidence_summary = Column(Text, default="")
    confidence = Column(Float, default=0.0)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class PredictiveRiskSnapshot(Base):
    __tablename__ = "predictive_risk_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=False, index=True)
    risk_score = Column(Float, default=0.0)
    probability_band = Column(String(50), default="LOW")
    schedule_drift_points = Column(Float, default=0.0)
    constraint_points = Column(Float, default=0.0)
    commitment_points = Column(Float, default=0.0)
    production_points = Column(Float, default=0.0)
    downstream_points = Column(Float, default=0.0)
    company_history_points = Column(Float, default=0.0)
    explanation = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class RiskOutcomeCalibration(Base):
    __tablename__ = "risk_outcome_calibration"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    predictive_risk_snapshot_id = Column(Integer, ForeignKey("predictive_risk_snapshots.id"), nullable=False, index=True)
    actual_delay_occurred = Column(Boolean, default=False)
    actual_delay_days = Column(Float, default=0.0)
    outcome_notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class SubcontractorPerformanceSnapshot(Base):
    __tablename__ = "subcontractor_performance_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    trade = Column(String(255), default="")
    commitments_total = Column(Integer, default=0)
    commitments_confirmed = Column(Integer, default=0)
    commitments_delayed = Column(Integer, default=0)
    commitments_pending = Column(Integer, default=0)
    response_reliability = Column(Float, default=0.0)
    start_reliability = Column(Float, default=0.0)
    manpower_reliability = Column(Float, default=0.0)
    production_reliability = Column(Float, default=0.0)
    early_warning_rate = Column(Float, default=0.0)
    quality_open_count = Column(Integer, default=0)
    quality_closed_count = Column(Integer, default=0)
    context_score = Column(Float, default=0.0)
    explanation = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class SubcontractorInteractionEvent(Base):
    __tablename__ = "subcontractor_interaction_events"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    event_type = Column(String(100), nullable=False)
    event_date = Column(String(50), default="")
    numeric_value = Column(Float, default=0.0)
    unit = Column(String(50), default="")
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class ProductionIntelligenceSnapshot(Base):
    __tablename__ = "production_intelligence_snapshots"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    subcontractor_id = Column(Integer, ForeignKey("subcontractors.id"), nullable=True, index=True)
    trade = Column(String(255), default="")
    activity_type = Column(String(255), default="")
    quantity_unit = Column(String(50), default="")
    observation_days = Column(Integer, default=0)
    total_quantity = Column(Float, default=0.0)
    total_labor_hours = Column(Float, default=0.0)
    average_crew = Column(Float, default=0.0)
    quantity_per_day = Column(Float, default=0.0)
    quantity_per_labor_hour = Column(Float, default=0.0)
    planned_quantity_per_day = Column(Float, default=0.0)
    pace_ratio = Column(Float, default=0.0)
    projected_remaining_days = Column(Float, default=0.0)
    trend = Column(String(50), default="UNKNOWN")
    explanation = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class CompanyProductionBenchmark(Base):
    __tablename__ = "company_production_benchmarks"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    trade = Column(String(255), default="", index=True)
    activity_type = Column(String(255), default="", index=True)
    quantity_unit = Column(String(50), default="")
    sample_count = Column(Integer, default=0)
    average_quantity_per_day = Column(Float, default=0.0)
    average_quantity_per_labor_hour = Column(Float, default=0.0)
    average_crew = Column(Float, default=0.0)
    confidence = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)


class PlaybookExecution(Base):
    __tablename__ = "playbook_executions"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    company_playbook_rule_id = Column(Integer, ForeignKey("company_playbook_rules.id"), nullable=False, index=True)
    schedule_activity_id = Column(Integer, ForeignKey("schedule_activities.id"), nullable=True, index=True)
    owner_user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    status = Column(String(50), default="OPEN")
    triggered_reason = Column(Text, default="")
    due_date = Column(String(50), default="")
    escalation_date = Column(String(50), default="")
    completed_date = Column(String(50), default="")
    helped = Column(Boolean, nullable=True)
    feedback = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class PlaybookChecklistItem(Base):
    __tablename__ = "playbook_checklist_items"
    id = Column(Integer, primary_key=True)
    playbook_execution_id = Column(Integer, ForeignKey("playbook_executions.id"), nullable=False, index=True)
    item_order = Column(Integer, default=0)
    item_text = Column(Text, nullable=False)
    status = Column(String(50), default="OPEN")
    completed_at = Column(DateTime, nullable=True)

class FieldAssistantQuery(Base):
    __tablename__ = "field_assistant_queries"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    question = Column(Text, nullable=False)
    answer = Column(Text, default="")
    evidence = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class ExecutiveRiskSnapshot(Base):
    __tablename__ = "executive_risk_snapshots"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    critical_risk_count = Column(Integer, default=0)
    high_risk_count = Column(Integer, default=0)
    open_recovery_plan_count = Column(Integer, default=0)
    production_at_risk_count = Column(Integer, default=0)
    open_make_ready_count = Column(Integer, default=0)
    executive_score = Column(Float, default=0.0)
    explanation = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class IntelligenceAuditEvent(Base):
    __tablename__ = "intelligence_audit_events"
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    event_type = Column(String(100), nullable=False)
    entity_type = Column(String(100), default="")
    entity_id = Column(Integer, nullable=True)
    decision = Column(String(100), default="")
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
