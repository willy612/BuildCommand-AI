from db.models import InboxItem

def push_inbox(db, company_id, title, message="", severity="info",
               category="PROJECT", project_id=None, user_id=None):
    row=InboxItem(
        company_id=company_id,project_id=project_id,user_id=user_id,
        category=category,severity=severity,title=title,message=message,status="UNREAD"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def user_inbox(db, company_id, user_id, include_read=False):
    q=db.query(InboxItem).filter(
        InboxItem.company_id==company_id,
        (InboxItem.user_id==user_id) | (InboxItem.user_id==None)
    )
    if not include_read:
        q=q.filter(InboxItem.status=="UNREAD")
    return q.order_by(InboxItem.created_at.desc()).all()

def mark_read(db,item_id):
    row=db.query(InboxItem).filter(InboxItem.id==item_id).first()
    if not row: return False
    row.status="READ"; db.commit(); return True
