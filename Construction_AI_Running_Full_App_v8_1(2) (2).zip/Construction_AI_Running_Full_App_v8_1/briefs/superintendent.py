from datetime import date
from make_ready.engine import sync_make_ready_actions,close_resolved_actions
from analytics.operations import constraint_aging
from lookahead.engine import lookahead_activities
from activity_release.engine import evaluate_activity_release

def morning_brief(db,project_id):
    close_resolved_actions(db,project_id)
    _,snap=sync_make_ready_actions(db,project_id,6)
    aging=constraint_aging(db,project_id)
    lookahead=lookahead_activities(db,project_id,weeks=2)
    decisions=[evaluate_activity_release(db,project_id,a.id) for a in lookahead]
    today_items=[x for x in aging if x["age_days"]>0][:10]
    holds=[d for d in decisions if d["status"]=="HOLD"][:10]
    risks=[d for d in decisions if d["status"]=="AT RISK"][:10]
    return {
        "date":date.today().isoformat(),
        "snapshot":{
            "ready":snap.ready_count,"at_risk":snap.at_risk_count,"hold":snap.hold_count
        },
        "overdue_actions":today_items,
        "near_term_holds":holds,
        "near_term_risks":risks
    }
