def new_safety_source(
    authority,
    standard,
    topic,
    source_url="",
    verified_date="",
    applies_to=None,
    notes=""
):
    return {
        "authority":authority,
        "standard":standard,
        "topic":topic,
        "source_url":source_url,
        "verified_date":verified_date,
        "applies_to":applies_to or [],
        "notes":notes,
        "status":"VERIFIED_SOURCE" if source_url else "SOURCE_NEEDED"
    }

def safety_sources_for_task(sources, task_id):
    return [s for s in sources if not s.get("applies_to") or task_id in s.get("applies_to",[])]
