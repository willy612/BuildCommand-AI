from datetime import date

def new_jurisdiction_source(
    jurisdiction,
    source_type,
    title,
    source_url="",
    code_cycle="",
    effective_date="",
    verified_date=None,
    notes=""
):
    return {
        "jurisdiction":jurisdiction,
        "source_type":source_type,
        "title":title,
        "source_url":source_url,
        "code_cycle":code_cycle,
        "effective_date":effective_date,
        "verified_date":verified_date or date.today().isoformat(),
        "notes":notes,
        "status":"VERIFIED_SOURCE" if source_url else "SOURCE_NEEDED"
    }

def source_is_stale(source, max_age_days=180):
    from datetime import datetime
    value=source.get("verified_date")
    if not value:
        return True
    try:
        verified=datetime.fromisoformat(value).date()
    except Exception:
        return True
    return (date.today()-verified).days > max_age_days
