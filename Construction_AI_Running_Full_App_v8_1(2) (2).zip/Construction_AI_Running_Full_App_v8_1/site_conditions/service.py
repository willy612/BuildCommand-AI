from db.models import SiteConditionRecord

def record_site_condition(db,project_id,condition_type,description="",status="CLEAR",
                          blocking=False,schedule_activity_id=None,user_id=None):
    row=SiteConditionRecord(
        project_id=project_id,schedule_activity_id=schedule_activity_id,
        condition_type=condition_type,status=status,description=description,
        blocking=blocking,recorded_by_user_id=user_id
    )
    db.add(row); db.commit(); db.refresh(row); return row

def blocking_site_conditions(db,project_id,activity_id):
    return db.query(SiteConditionRecord).filter(
        SiteConditionRecord.project_id==project_id,
        SiteConditionRecord.schedule_activity_id==activity_id,
        SiteConditionRecord.blocking==True,
        SiteConditionRecord.status!="CLEAR"
    ).all()
