import os

class Settings:
    ENV=os.getenv("CONSTRUCTION_AI_ENV","development")
    DATABASE_URL=os.getenv("DATABASE_URL","sqlite:///construction_ai.db")
    SECRET_KEY=os.getenv("SECRET_KEY","")
    EMAIL_PROVIDER=os.getenv("EMAIL_PROVIDER","disabled")
    SMS_PROVIDER=os.getenv("SMS_PROVIDER","disabled")
    REQUIRE_HUMAN_APPROVAL=os.getenv("REQUIRE_HUMAN_APPROVAL","true").lower()=="true"
    TENANT_GUARD_ENABLED=os.getenv("TENANT_GUARD_ENABLED","true").lower()=="true"

    @classmethod
    def validate(cls):
        errors=[]
        if cls.ENV=="production" and not cls.SECRET_KEY:
            errors.append("SECRET_KEY is required in production.")
        if cls.ENV=="production" and cls.DATABASE_URL.startswith("sqlite"):
            errors.append("Production DATABASE_URL must not use SQLite.")
        if not cls.REQUIRE_HUMAN_APPROVAL:
            errors.append("Human approval must remain enabled for production construction actions.")
        return errors
