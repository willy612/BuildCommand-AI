from db.models import Project, ProjectMember, ProjectRoleAssignment, User

COMPANY_ROLES={"owner_admin","operations_manager","project_executive"}
PROJECT_ROLES={"project_manager","superintendent","assistant_superintendent","project_engineer","foreman","viewer"}

def user_company_id(user):
    return getattr(user,"company_id",None)

def project_belongs_to_company(db, project_id, company_id):
    return db.query(Project).filter(Project.id==project_id,Project.company_id==company_id).first() is not None

def user_can_access_project(db, user, project_id):
    if not user or not getattr(user,"active",False):
        return False
    project=db.query(Project).filter(Project.id==project_id).first()
    if not project or project.company_id != user.company_id:
        return False
    if user.role in COMPANY_ROLES:
        return True
    member=db.query(ProjectMember).filter(
        ProjectMember.project_id==project_id,
        ProjectMember.user_id==user.id
    ).first()
    assignment=db.query(ProjectRoleAssignment).filter(
        ProjectRoleAssignment.project_id==project_id,
        ProjectRoleAssignment.user_id==user.id,
        ProjectRoleAssignment.active==True
    ).first()
    return bool(member or assignment)

def accessible_projects(db,user):
    if not user: return []
    if user.role in COMPANY_ROLES:
        return db.query(Project).filter(Project.company_id==user.company_id).all()
    project_ids={r.project_id for r in db.query(ProjectMember).filter(ProjectMember.user_id==user.id).all()}
    project_ids |= {r.project_id for r in db.query(ProjectRoleAssignment).filter(
        ProjectRoleAssignment.user_id==user.id,ProjectRoleAssignment.active==True
    ).all()}
    if not project_ids: return []
    return db.query(Project).filter(Project.id.in_(project_ids),Project.company_id==user.company_id).all()
