from db.models import User, ProjectMember, ProjectRoleAssignment

def create_user(db,company_id,email,display_name="",role="superintendent"):
    row=User(company_id=company_id,email=email,display_name=display_name,role=role,active=True)
    db.add(row); db.commit(); db.refresh(row)
    return row

def assign_project_role(db,project_id,user_id,role,primary=False):
    row=db.query(ProjectRoleAssignment).filter(
        ProjectRoleAssignment.project_id==project_id,
        ProjectRoleAssignment.user_id==user_id,
        ProjectRoleAssignment.role==role
    ).first()
    if not row:
        row=ProjectRoleAssignment(project_id=project_id,user_id=user_id,role=role,primary_assignment=primary,active=True)
        db.add(row)
    else:
        row.active=True; row.primary_assignment=primary
    if not db.query(ProjectMember).filter(ProjectMember.project_id==project_id,ProjectMember.user_id==user_id).first():
        db.add(ProjectMember(project_id=project_id,user_id=user_id,role=role))
    db.commit(); db.refresh(row)
    return row

def project_team(db,project_id):
    return db.query(User,ProjectRoleAssignment).join(
        ProjectRoleAssignment,ProjectRoleAssignment.user_id==User.id
    ).filter(ProjectRoleAssignment.project_id==project_id,ProjectRoleAssignment.active==True).all()
