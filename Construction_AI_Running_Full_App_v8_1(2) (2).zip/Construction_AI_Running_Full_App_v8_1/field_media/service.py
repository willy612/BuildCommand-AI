from pathlib import Path
from datetime import datetime
from config.settings import FILE_STORAGE_DIR
from db.models import FieldPhotoRecord

def save_field_photo(db,project_id,image_bytes,filename,caption="",schedule_activity_id=None,
                     subcontractor_id=None,observation=""):
    root=Path(FILE_STORAGE_DIR)/str(project_id)/"field_photos"
    root.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime("%Y%m%d%H%M%S%f")
    safe=Path(filename).name
    path=root/f"{stamp}_{safe}"
    path.write_bytes(image_bytes)
    row=FieldPhotoRecord(
        project_id=project_id,schedule_activity_id=schedule_activity_id,
        subcontractor_id=subcontractor_id,storage_path=str(path),
        caption=caption,observation=observation
    )
    db.add(row); db.commit(); db.refresh(row)
    return row
