import csv
from pathlib import Path

ALIASES = {
    "activity id":["activity id","activity_id","id","task id"],
    "name":["activity name","activity","name","task name"],
    "planned start":["planned start","start","start date"],
    "planned finish":["planned finish","finish","finish date","end date"],
    "percent complete":["percent complete","% complete","progress"],
    "predecessors":["predecessors","predecessor"],
    "trade":["trade","responsible trade"],
    "phase":["phase","wbs","category"]
}

def _norm(s):
    return str(s or "").strip().lower()

def _map_headers(headers):
    mapped={}
    for canonical, aliases in ALIASES.items():
        for h in headers:
            if _norm(h) in aliases:
                mapped[canonical]=h
                break
    return mapped

def parse_schedule_csv(path):
    path=Path(path)
    rows=[]
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        reader=csv.DictReader(f)
        mapping=_map_headers(reader.fieldnames or [])
        for raw in reader:
            activity_id=str(raw.get(mapping.get("activity id",""),"")).strip()
            name=str(raw.get(mapping.get("name",""),"")).strip()
            if not name:
                continue
            predecessors=[
                x.strip() for x in str(raw.get(mapping.get("predecessors",""),"")).replace(";",",").split(",")
                if x.strip()
            ]
            try:
                pct=float(str(raw.get(mapping.get("percent complete",""),"0")).replace("%","") or 0)
            except Exception:
                pct=0
            rows.append({
                "activity_id":activity_id or f"ACT-{len(rows)+1}",
                "name":name,
                "planned_start":str(raw.get(mapping.get("planned start",""),"")).strip(),
                "planned_finish":str(raw.get(mapping.get("planned finish",""),"")).strip(),
                "percent_complete":pct,
                "predecessors":predecessors,
                "successors":[],
                "trade":str(raw.get(mapping.get("trade",""),"")).strip(),
                "phase":str(raw.get(mapping.get("phase",""),"")).strip(),
                "constraints":[],
                "required_permits":[],
                "required_inspections":[],
                "required_tests":[],
                "required_documents":[],
                "required_materials":[],
                "required_manpower":[],
                "status":"NOT_STARTED"
            })
    # build successors
    index={r["activity_id"]:r for r in rows}
    for r in rows:
        for p in r["predecessors"]:
            if p in index:
                index[p]["successors"].append(r["activity_id"])
    return rows
