from db.models import (
    Subcontractor, SubcontractorContact, ProjectSubcontractor,
    ActivityAssignment, ScheduleActivity
)

def create_subcontractor(db, name, trade="", scope="", company_id=None):
    row=Subcontractor(name=name,trade=trade,scope=scope,company_id=company_id)
    db.add(row); db.commit(); db.refresh(row)
    return row

def add_contact(db, subcontractor_id, name, email="", phone="", role="", primary_contact=False):
    if primary_contact:
        db.query(SubcontractorContact).filter(
            SubcontractorContact.subcontractor_id==subcontractor_id
        ).update({"primary_contact":False})
    row=SubcontractorContact(
        subcontractor_id=subcontractor_id,name=name,email=email,phone=phone,
        role=role,primary_contact=primary_contact
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def add_to_project(db, project_id, subcontractor_id, project_trade="", project_scope=""):
    row=ProjectSubcontractor(
        project_id=project_id,subcontractor_id=subcontractor_id,
        project_trade=project_trade,project_scope=project_scope
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def assign_activity(db, project_id, schedule_activity_id, subcontractor_id, responsibility="PRIMARY"):
    existing=db.query(ActivityAssignment).filter(
        ActivityAssignment.project_id==project_id,
        ActivityAssignment.schedule_activity_id==schedule_activity_id,
        ActivityAssignment.subcontractor_id==subcontractor_id
    ).first()
    if existing:
        return existing
    row=ActivityAssignment(
        project_id=project_id,schedule_activity_id=schedule_activity_id,
        subcontractor_id=subcontractor_id,responsibility=responsibility
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def project_subcontractors(db, project_id):
    return db.query(Subcontractor).join(
        ProjectSubcontractor, ProjectSubcontractor.subcontractor_id==Subcontractor.id
    ).filter(ProjectSubcontractor.project_id==project_id).all()

def primary_email(db, subcontractor_id):
    c=db.query(SubcontractorContact).filter(
        SubcontractorContact.subcontractor_id==subcontractor_id,
        SubcontractorContact.active==True
    ).order_by(SubcontractorContact.primary_contact.desc()).first()
    return c.email if c else ""
