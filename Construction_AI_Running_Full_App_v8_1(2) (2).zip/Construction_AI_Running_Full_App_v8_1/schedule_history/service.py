from db.models import ScheduleUpdateSnapshot,CPMCalculationSnapshot,ScheduleActivity

def update_history(db,project_id,limit=12):
    rows=db.query(ScheduleUpdateSnapshot).filter(
        ScheduleUpdateSnapshot.project_id==project_id
    ).order_by(ScheduleUpdateSnapshot.created_at.desc()).limit(limit).all()
    return list(reversed([{
        "data_date":r.data_date,"planned_completion":r.planned_completion,
        "calculated_completion":r.calculated_completion,
        "critical_count":r.critical_count,"negative_float_count":r.negative_float_count
    } for r in rows]))

def critical_path_rows(db,project_id,data_date=None):
    q=db.query(CPMCalculationSnapshot).filter(
        CPMCalculationSnapshot.project_id==project_id,
        CPMCalculationSnapshot.critical==True
    )
    if data_date:q=q.filter(CPMCalculationSnapshot.data_date==data_date)
    rows=q.order_by(CPMCalculationSnapshot.early_start.asc()).all()
    result=[]
    for r in rows:
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==r.schedule_activity_id).first()
        result.append({
            "external_id":a.external_id if a else "",
            "activity":a.name if a else str(r.schedule_activity_id),
            "early_start":r.early_start,"early_finish":r.early_finish,
            "late_start":r.late_start,"late_finish":r.late_finish,
            "total_float":r.total_float_days
        })
    return result
