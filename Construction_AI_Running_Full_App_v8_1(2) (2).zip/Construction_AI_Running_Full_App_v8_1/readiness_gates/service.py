from db.models import ReadinessGate,QualityIssue,InspectionTestRecord

def ensure_gate(db,project_id,activity_id,gate_type,title,source_entity_type="",source_entity_id=None,blocking=True):
    row=db.query(ReadinessGate).filter(
        ReadinessGate.project_id==project_id,
        ReadinessGate.schedule_activity_id==activity_id,
        ReadinessGate.gate_type==gate_type,
        ReadinessGate.source_entity_type==source_entity_type,
        ReadinessGate.source_entity_id==source_entity_id
    ).first()
    if row:
        row.title=title; row.blocking=blocking
        db.commit(); return row
    row=ReadinessGate(
        project_id=project_id,schedule_activity_id=activity_id,gate_type=gate_type,
        source_entity_type=source_entity_type,source_entity_id=source_entity_id,
        title=title,status="OPEN",blocking=blocking
    )
    db.add(row); db.commit(); db.refresh(row); return row

def close_gate(db,source_entity_type,source_entity_id):
    rows=db.query(ReadinessGate).filter(
        ReadinessGate.source_entity_type==source_entity_type,
        ReadinessGate.source_entity_id==source_entity_id
    ).all()
    for r in rows: r.status="CLOSED"
    db.commit()

def sync_quality_gates(db,project_id):
    issues=db.query(QualityIssue).filter(
        QualityIssue.project_id==project_id,
        QualityIssue.status!="CLOSED",
        QualityIssue.schedule_activity_id.isnot(None)
    ).all()
    for q in issues:
        ensure_gate(db,project_id,q.schedule_activity_id,"QUALITY",
                    f"Open quality issue: {q.title}","QUALITY_ISSUE",q.id,True)

def sync_inspection_gates(db,project_id):
    rows=db.query(InspectionTestRecord).filter(
        InspectionTestRecord.project_id==project_id,
        InspectionTestRecord.schedule_activity_id.isnot(None),
        InspectionTestRecord.result.in_(["PENDING","FAILED","PARTIAL"])
    ).all()
    for r in rows:
        ensure_gate(db,project_id,r.schedule_activity_id,"INSPECTION",
                    f"{r.inspection_type}: {r.result}","INSPECTION_TEST",r.id,True)

def activity_gate_status(db,project_id,activity_id):
    rows=db.query(ReadinessGate).filter(
        ReadinessGate.project_id==project_id,
        ReadinessGate.schedule_activity_id==activity_id,
        ReadinessGate.status=="OPEN",
        ReadinessGate.blocking==True
    ).all()
    return {
        "ready":len(rows)==0,
        "open_gates":[{"id":r.id,"type":r.gate_type,"title":r.title} for r in rows]
    }
