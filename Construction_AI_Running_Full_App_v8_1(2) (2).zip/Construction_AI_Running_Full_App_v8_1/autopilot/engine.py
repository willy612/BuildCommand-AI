from datetime import date
from db.models import (
    SuperintendentAction,MakeReadyAction,ScheduleDriftAlert,
    ScheduleActivity,OutboundNotification
)

SEVERITY_WEIGHT={"CRITICAL":100,"HIGH":75,"WARNING":60,"AT RISK":50,"NORMAL":20}

def _upsert(db,project_id,activity_id,action_type,title,why,recommended,owner,due,severity,score):
    row=db.query(SuperintendentAction).filter(
        SuperintendentAction.project_id==project_id,
        SuperintendentAction.schedule_activity_id==activity_id,
        SuperintendentAction.action_type==action_type,
        SuperintendentAction.status=="OPEN"
    ).first()
    if not row:
        row=SuperintendentAction(
            project_id=project_id,schedule_activity_id=activity_id,action_type=action_type,
            title=title,why=why,recommended_action=recommended,owner_role=owner,
            due_date=due,severity=severity,score=score,status="OPEN"
        );db.add(row)
    else:
        row.title=title;row.why=why;row.recommended_action=recommended
        row.owner_role=owner;row.due_date=due;row.severity=severity;row.score=score
    return row

def build_daily_actions(db,project_id):
    today=date.today()
    generated=[]

    for mr in db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,MakeReadyAction.status=="OPEN"
    ).all():
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==mr.schedule_activity_id).first()
        try:
            due=date.fromisoformat(mr.required_by)
            overdue=max(0,(today-due).days)
        except Exception: overdue=0
        severity="CRITICAL" if overdue>=3 or mr.priority=="CRITICAL" else "HIGH"
        score=SEVERITY_WEIGHT[severity]+min(overdue*4,25)+mr.escalation_level*5
        title=f"Clear {mr.gate_name}: {a.name if a else mr.title}"
        why=f"{mr.reason} Required clear date: {mr.required_by or 'not set'}."
        recommended="Resolve the constraint or obtain a committed resolution date today."
        generated.append(_upsert(db,project_id,mr.schedule_activity_id,"MAKE_READY",
                                 title,why,recommended,"superintendent",
                                 mr.required_by,severity,score))

    for alert in db.query(ScheduleDriftAlert).filter(
        ScheduleDriftAlert.project_id==project_id,ScheduleDriftAlert.status=="OPEN"
    ).all():
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==alert.schedule_activity_id).first()
        severity=alert.severity
        score=SEVERITY_WEIGHT.get(severity,60)+min(abs(alert.variance_days)*3,30)
        title=f"Resolve field/CPM drift: {a.name if a else alert.schedule_activity_id}"
        why=alert.message
        recommended="Confirm whether the field plan or master schedule should move, then document the agreed plan."
        generated.append(_upsert(db,project_id,alert.schedule_activity_id,"SCHEDULE_DRIFT",
                                 title,why,recommended,"superintendent","",severity,score))
    db.commit()
    return sorted(generated,key=lambda x:x.score,reverse=True)

def prepare_action_message(db,action):
    subject=f"Action required: {action.title}"
    body=(
        f"{action.title}\n\nWhy this matters:\n{action.why}\n\n"
        f"Recommended action:\n{action.recommended_action}\n\n"
        f"Please confirm status, owner, and expected resolution."
    )
    row=OutboundNotification(
        project_id=action.project_id,channel="IN_APP",recipient="",
        subject=subject,body=body,status="DRAFT"
    )
    db.add(row);db.commit();db.refresh(row);return row
