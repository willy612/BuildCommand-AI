from jobs.queue import get_job_queue

def submit_ingestion(db,job_id):
    from workers.tasks import ingest_document_task
    return get_job_queue().submit(ingest_document_task,db,job_id)

def submit_embeddings(db,project_id,limit=None):
    from workers.tasks import embed_project_task
    return get_job_queue().submit(embed_project_task,db,project_id,limit)
