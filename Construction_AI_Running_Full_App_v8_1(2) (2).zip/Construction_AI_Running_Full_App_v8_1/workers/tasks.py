from ingestion.pipeline import ingest_document
from search.semantic_search import backfill_embeddings

def ingest_document_task(db,job_id):
    return ingest_document(db,job_id)

def embed_project_task(db,project_id,limit=None):
    return backfill_embeddings(db,project_id,limit=limit)
