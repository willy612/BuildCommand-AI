from db.models import (
    Subcontractor,LookaheadCommitment,QualityIssue,ProductionRecord,
    SubcontractorPerformanceSnapshot
)

def _safe_ratio(a,b):
    return (a/b) if b else 0.0

def build_subcontractor_snapshot(db,project_id,subcontractor_id):
    sub=db.query(Subcontractor).filter(Subcontractor.id==subcontractor_id).first()
    if not sub:return None

    commitments=db.query(LookaheadCommitment).filter(
        LookaheadCommitment.project_id==project_id,
        LookaheadCommitment.subcontractor_id==subcontractor_id
    ).all()

    total=len(commitments)
    confirmed=sum(1 for c in commitments if c.status=="CONFIRMED")
    delayed=sum(1 for c in commitments if c.status in ("DELAY_REPORTED","CANNOT_MEET_DATE","DECLINED"))
    pending=sum(1 for c in commitments if c.status=="PENDING")
    response_reliability=_safe_ratio(confirmed,total)

    # Conservative start reliability proxy: confirmed commitments not later converted into delay.
    start_reliability=_safe_ratio(max(0,confirmed-delayed),total)

    # Manpower reliability from explicit commitment text presence + no manpower issue.
    manpower_known=sum(1 for c in commitments if (c.manpower_commitment or "").strip())
    manpower_issues=sum(1 for c in commitments if c.status=="MANPOWER_ISSUE")
    manpower_reliability=_safe_ratio(max(0,manpower_known-manpower_issues),total)

    prod=db.query(ProductionRecord).filter(
        ProductionRecord.project_id==project_id,
        ProductionRecord.subcontractor_id==subcontractor_id
    ).all()
    installed=sum(r.quantity_installed or 0 for r in prod)
    planned=sum(r.planned_quantity or 0 for r in prod)
    production_reliability=min(1.0,_safe_ratio(installed,planned)) if planned else 0.0

    # Early warning behavior: delay/issue explicitly reported before total failure.
    warned=sum(1 for c in commitments if c.status in (
        "DELAY_REPORTED","NEED_INFORMATION","MATERIAL_ISSUE","MANPOWER_ISSUE","ACCESS_ISSUE"
    ))
    early_warning_rate=_safe_ratio(warned,total)

    q_open=db.query(QualityIssue).filter(
        QualityIssue.project_id==project_id,
        QualityIssue.subcontractor_id==subcontractor_id,
        QualityIssue.status!="CLOSED"
    ).count()
    q_closed=db.query(QualityIssue).filter(
        QualityIssue.project_id==project_id,
        QualityIssue.subcontractor_id==subcontractor_id,
        QualityIssue.status=="CLOSED"
    ).count()

    # Context score is intentionally explainable and not a vendor grade.
    score=(
        response_reliability*25+
        start_reliability*25+
        manpower_reliability*15+
        production_reliability*20+
        min(early_warning_rate,1.0)*10+
        max(0,5-min(q_open,5))
    )
    explanation=(
        f"Commitments {confirmed}/{total} confirmed; "
        f"{delayed} delay/inability report(s); "
        f"manpower reliability {manpower_reliability:.0%}; "
        f"production reliability {production_reliability:.0%}; "
        f"early-warning rate {early_warning_rate:.0%}; "
        f"{q_open} open quality item(s)."
    )

    row=SubcontractorPerformanceSnapshot(
        project_id=project_id,subcontractor_id=subcontractor_id,
        trade=sub.trade or "",commitments_total=total,commitments_confirmed=confirmed,
        commitments_delayed=delayed,commitments_pending=pending,
        response_reliability=response_reliability,start_reliability=start_reliability,
        manpower_reliability=manpower_reliability,production_reliability=production_reliability,
        early_warning_rate=early_warning_rate,quality_open_count=q_open,
        quality_closed_count=q_closed,context_score=round(score,1),explanation=explanation
    )
    db.add(row);db.commit();db.refresh(row);return row

def refresh_project_subcontractor_intelligence(db,project_id):
    subs=db.query(Subcontractor).join(
        LookaheadCommitment,LookaheadCommitment.subcontractor_id==Subcontractor.id
    ).filter(LookaheadCommitment.project_id==project_id).distinct().all()
    rows=[]
    for s in subs:
        row=build_subcontractor_snapshot(db,project_id,s.id)
        if row:rows.append(row)
    return sorted(rows,key=lambda x:x.context_score)

def subcontractor_context_for_activity(db,project_id,subcontractor_id):
    row=db.query(SubcontractorPerformanceSnapshot).filter(
        SubcontractorPerformanceSnapshot.project_id==project_id,
        SubcontractorPerformanceSnapshot.subcontractor_id==subcontractor_id
    ).order_by(SubcontractorPerformanceSnapshot.created_at.desc()).first()
    if not row:return None
    return {
        "score":row.context_score,
        "response_reliability":row.response_reliability,
        "start_reliability":row.start_reliability,
        "manpower_reliability":row.manpower_reliability,
        "production_reliability":row.production_reliability,
        "early_warning_rate":row.early_warning_rate,
        "explanation":row.explanation
    }
