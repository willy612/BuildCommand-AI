from db.models import (
    CompanyLearningSignal,SubcontractorPerformanceSnapshot,Project
)

def capture_subcontractor_learning(db,company_id,project_id):
    rows=db.query(SubcontractorPerformanceSnapshot).filter(
        SubcontractorPerformanceSnapshot.project_id==project_id
    ).all()
    created=0
    for r in rows:
        context=f"sub:{r.subcontractor_id}:trade:{r.trade}"
        exists=db.query(CompanyLearningSignal).filter(
            CompanyLearningSignal.company_id==company_id,
            CompanyLearningSignal.project_id==project_id,
            CompanyLearningSignal.signal_type=="SUBCONTRACTOR_CONTEXT",
            CompanyLearningSignal.context_key==context
        ).first()
        if exists: continue
        db.add(CompanyLearningSignal(
            company_id=company_id,project_id=project_id,
            signal_type="SUBCONTRACTOR_CONTEXT",category=r.trade or "General",
            context_key=context,numeric_value=r.context_score,unit="context_score",
            outcome="OBSERVED",evidence=r.explanation,confidence=0.7
        ));created+=1
    db.commit()
    return created
