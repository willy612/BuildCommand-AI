from db.models import LookaheadScheduleAlignment,ScheduleDriftAlert

def sync_drift_alerts(db,project_id,warning_days=3,critical_days=7):
    rows=db.query(LookaheadScheduleAlignment).filter(
        LookaheadScheduleAlignment.project_id==project_id
    ).order_by(LookaheadScheduleAlignment.created_at.desc()).all()

    latest={}
    for r in rows:
        latest.setdefault(r.schedule_activity_id,r)

    created=[]
    for aid,r in latest.items():
        variance=abs(int(r.variance_days or 0))
        if variance<warning_days:
            continue
        severity="CRITICAL" if variance>=critical_days else "WARNING"
        existing=db.query(ScheduleDriftAlert).filter(
            ScheduleDriftAlert.project_id==project_id,
            ScheduleDriftAlert.schedule_activity_id==aid,
            ScheduleDriftAlert.status=="OPEN"
        ).first()
        message=r.reason or f"Field/CPM variance is {r.variance_days:+d} days."
        if existing:
            existing.severity=severity;existing.variance_days=r.variance_days;existing.message=message
        else:
            existing=ScheduleDriftAlert(
                project_id=project_id,schedule_activity_id=aid,
                alert_type="FIELD_CPM_VARIANCE",severity=severity,
                variance_days=r.variance_days,message=message,status="OPEN"
            )
            db.add(existing);created.append(existing)
    db.commit()
    return created
