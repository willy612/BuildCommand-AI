from db.models import CostChangeEvent

def create_cost_change(db,project_id,title,description="",change_event_id=None,
                       responsible_party="",estimated_cost=0.0):
    row=CostChangeEvent(
        project_id=project_id,change_event_id=change_event_id,title=title,
        description=description,responsible_party=responsible_party,
        estimated_cost=float(estimated_cost or 0),status="POTENTIAL"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def approve_cost_change(db,event_id,approved_cost):
    row=db.query(CostChangeEvent).filter(CostChangeEvent.id==event_id).first()
    if not row: return False
    row.approved_cost=float(approved_cost or 0)
    row.status="APPROVED"
    db.commit()
    return True
