from alignment.service import compare_lookahead_to_cpm
from lookahead.engine import lookahead_activities

def align_current_lookahead(db,project_id,weeks=6):
    rows=[]
    for a in lookahead_activities(db,project_id,weeks=weeks):
        rows.append({
            "external_id":a.external_id,
            "planned_start":a.planned_start
        })
    return compare_lookahead_to_cpm(db,project_id,rows)
