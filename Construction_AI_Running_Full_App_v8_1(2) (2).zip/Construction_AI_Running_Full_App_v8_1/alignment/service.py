from datetime import datetime
from db.models import ScheduleActivity,LookaheadScheduleAlignment

def _parse(v):
    if not v:return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try:return datetime.strptime(str(v)[:10],fmt).date()
        except:pass
    return None

def compare_lookahead_to_cpm(db,project_id,lookahead_rows):
    """
    lookahead_rows: iterable of dicts with activity_id/external_id and planned_start.
    """
    results=[]
    for row in lookahead_rows:
        ext=str(row.get("external_id") or row.get("activity_id") or "")
        if not ext: continue
        a=db.query(ScheduleActivity).filter(
            ScheduleActivity.project_id==project_id,ScheduleActivity.external_id==ext
        ).first()
        if not a: continue
        la=_parse(row.get("planned_start"))
        cpm=_parse(a.planned_start)
        if not la or not cpm: continue
        variance=(la-cpm).days
        if abs(variance)<=2:
            status="ALIGNED";reason="Field lookahead is within two days of CPM start."
        elif variance>2:
            status="FIELD_LATER";reason=f"Field plan starts {variance} days later than CPM."
        else:
            status="FIELD_EARLIER";reason=f"Field plan starts {abs(variance)} days earlier than CPM."
        rec=LookaheadScheduleAlignment(
            project_id=project_id,schedule_activity_id=a.id,
            lookahead_start=la.isoformat(),cpm_start=cpm.isoformat(),
            variance_days=variance,alignment_status=status,reason=reason
        )
        db.add(rec);results.append(rec)
    db.commit()
    return results
