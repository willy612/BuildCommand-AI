from db.models import (
    SubcontractorPortalUser, ProjectSubcontractor, LookaheadCommitment,
    ScheduleActivity, SubcontractorResponse
)

def portal_projects(db,portal_user):
    return db.query(ProjectSubcontractor).filter(
        ProjectSubcontractor.subcontractor_id==portal_user.subcontractor_id,
        ProjectSubcontractor.status=="ACTIVE"
    ).all()

def portal_commitments(db,portal_user,project_id):
    return db.query(LookaheadCommitment).filter(
        LookaheadCommitment.project_id==project_id,
        LookaheadCommitment.subcontractor_id==portal_user.subcontractor_id
    ).all()

def submit_commitment_response(db,commitment,status,response_text="",manpower="",
                               material_status="",equipment_status="",delay_reason=""):
    allowed={"CONFIRMED","DELAY_REPORTED","NEED_INFORMATION","MATERIAL_ISSUE",
             "MANPOWER_ISSUE","ACCESS_ISSUE","CANNOT_MEET_DATE"}
    if status not in allowed: raise ValueError("Invalid response status")
    commitment.status=status
    commitment.response_text=response_text
    commitment.manpower_commitment=manpower
    commitment.material_status=material_status
    commitment.equipment_status=equipment_status
    commitment.delay_reason=delay_reason
    commitment.superintendent_review_status="PENDING"
    db.add(SubcontractorResponse(
        project_id=commitment.project_id,subcontractor_id=commitment.subcontractor_id,
        schedule_activity_id=commitment.schedule_activity_id,response_type=status,
        response_text=response_text or delay_reason,status="PENDING_REVIEW"
    ))
    db.commit()
    return commitment
