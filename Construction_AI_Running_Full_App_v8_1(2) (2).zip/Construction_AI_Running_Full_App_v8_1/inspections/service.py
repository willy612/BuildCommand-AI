from db.models import InspectionTestRecord
from readiness_gates.service import close_gate

def create_inspection(db,project_id,inspection_type,authority="",planned_date="",
                      location_id=None,schedule_activity_id=None,notes="",source_ref=""):
    row=InspectionTestRecord(
        project_id=project_id,inspection_type=inspection_type,authority=authority,
        planned_date=planned_date,location_id=location_id,schedule_activity_id=schedule_activity_id,
        notes=notes,source_ref=source_ref,result="PENDING"
    )
    db.add(row); db.commit(); db.refresh(row); return row

def record_result(db,record_id,result,actual_date="",notes=""):
    row=db.query(InspectionTestRecord).filter(InspectionTestRecord.id==record_id).first()
    if not row: return None
    row.result=result
    row.actual_date=actual_date
    if notes: row.notes=notes
    db.commit(); db.refresh(row)
    if result=="PASSED":
        close_gate(db,"INSPECTION_TEST",row.id)
    return row
