from collections import defaultdict
from db.models import ProductionRecord,Subcontractor,ScheduleActivity

def manpower_by_trade(db,project_id):
    rows=db.query(ProductionRecord).filter(ProductionRecord.project_id==project_id).all()
    daily=defaultdict(lambda:defaultdict(int))
    for r in rows:
        trade="Unassigned"
        if r.subcontractor_id:
            s=db.query(Subcontractor).filter(Subcontractor.id==r.subcontractor_id).first()
            if s: trade=s.trade or s.name
        daily[r.work_date][trade]+=int(r.crew_size or 0)
    return {d:dict(v) for d,v in sorted(daily.items())}

def production_trends(db,project_id):
    rows=db.query(ProductionRecord).filter(ProductionRecord.project_id==project_id).all()
    by_activity=defaultdict(list)
    for r in rows: by_activity[r.schedule_activity_id].append(r)
    result=[]
    for aid,items in by_activity.items():
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==aid).first()
        installed=sum(i.quantity_installed or 0 for i in items)
        planned=sum(i.planned_quantity or 0 for i in items)
        labor=sum((i.crew_size or 0)*(i.regular_hours or 0) for i in items)
        result.append({
            "activity":a.name if a else str(aid),
            "installed":installed,"planned":planned,"labor_hours":labor,
            "productivity":installed/labor if labor else None,
            "pace_ratio":installed/planned if planned else None
        })
    return result
