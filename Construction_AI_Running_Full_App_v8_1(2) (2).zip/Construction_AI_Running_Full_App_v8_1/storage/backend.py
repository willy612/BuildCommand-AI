from pathlib import Path
import shutil, hashlib
from config.settings import FILE_STORAGE_DIR

class LocalStorageBackend:
    def put_file(self,project_id,source_path,filename):
        root=Path(FILE_STORAGE_DIR)/str(project_id)
        root.mkdir(parents=True,exist_ok=True)
        dest=root/filename
        i=1
        while dest.exists():
            dest=root/f"{dest.stem}_{i}{dest.suffix}"
            i+=1
        shutil.copy2(source_path,dest)
        return str(dest)

    def delete_file(self,path):
        p=Path(path)
        if p.exists():
            p.unlink()

    def checksum(self,path):
        h=hashlib.sha256()
        with open(path,"rb") as f:
            for chunk in iter(lambda:f.read(1024*1024),b""):
                h.update(chunk)
        return h.hexdigest()


def get_storage_backend():
    import os
    mode=os.getenv("STORAGE_BACKEND","local").lower()
    if mode=="local":
        return LocalStorageBackend()
    if mode in ("s3","r2"):
        from storage.providers.s3_compatible import S3CompatibleStorage
        return S3CompatibleStorage()
    raise RuntimeError(f"Unsupported STORAGE_BACKEND: {mode}")
