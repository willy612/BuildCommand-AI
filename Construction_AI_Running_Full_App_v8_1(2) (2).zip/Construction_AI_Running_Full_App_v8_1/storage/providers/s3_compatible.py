import os
from pathlib import Path

try:
    import boto3
except ImportError:
    boto3=None

class S3CompatibleStorage:
    def __init__(self):
        if boto3 is None:
            raise RuntimeError("boto3 is required for S3-compatible storage")
        self.bucket=os.environ["S3_BUCKET"]
        self.prefix=os.getenv("S3_PREFIX","projects")
        endpoint=os.getenv("S3_ENDPOINT_URL") or None
        self.client=boto3.client(
            "s3",
            endpoint_url=endpoint,
            region_name=os.getenv("AWS_REGION") or None,
            aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID") or None,
            aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY") or None,
        )

    def put_file(self,project_id,source_path,filename):
        key=f"{self.prefix}/{project_id}/{filename}"
        self.client.upload_file(str(source_path),self.bucket,key)
        return f"s3://{self.bucket}/{key}"

    def delete_file(self,path):
        prefix=f"s3://{self.bucket}/"
        if not path.startswith(prefix):
            return
        key=path[len(prefix):]
        self.client.delete_object(Bucket=self.bucket,Key=key)
