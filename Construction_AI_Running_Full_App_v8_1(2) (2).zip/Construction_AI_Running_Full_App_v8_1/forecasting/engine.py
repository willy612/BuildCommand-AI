from datetime import datetime,date
from collections import deque
from db.models import (
    ScheduleActivity,ScheduleRelationship,MakeReadyAction,
    ScheduleExposureRecord,ConstraintClearanceHistory
)
from production.service import activity_production_metrics

def _parse(value):
    if not value: return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try: return datetime.strptime(str(value),fmt).date()
        except Exception: pass
    return None

def downstream_activities(db,project_id,source_external_id,max_depth=6):
    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    successors={}
    for r in rels:
        successors.setdefault(r.predecessor_external_id,[]).append(r.successor_external_id)
    q=deque([(source_external_id,0)])
    seen={source_external_id}
    found=[]
    while q:
        current,depth=q.popleft()
        if depth>=max_depth: continue
        for nxt in successors.get(current,[]):
            if nxt in seen: continue
            seen.add(nxt)
            a=db.query(ScheduleActivity).filter(
                ScheduleActivity.project_id==project_id,
                ScheduleActivity.external_id==nxt
            ).first()
            if a:
                found.append((a,depth+1))
                q.append((nxt,depth+1))
    return found

def calculate_exposure(db,project_id,make_ready_action):
    source=db.query(ScheduleActivity).filter(
        ScheduleActivity.id==make_ready_action.schedule_activity_id
    ).first()
    if not source: return []
    today=date.today()
    required=_parse(make_ready_action.required_by) or today
    overdue=max(0,(today-required).days)
    downstream=downstream_activities(db,project_id,source.external_id)
    created=[]
    for activity,depth in downstream:
        risk=max(0,overdue-(depth-1))
        existing=db.query(ScheduleExposureRecord).filter(
            ScheduleExposureRecord.project_id==project_id,
            ScheduleExposureRecord.source_activity_id==source.id,
            ScheduleExposureRecord.exposed_activity_id==activity.id,
            ScheduleExposureRecord.make_ready_action_id==make_ready_action.id
        ).first()
        if existing:
            existing.relationship_depth=depth; existing.risk_days=risk
        else:
            existing=ScheduleExposureRecord(
                project_id=project_id,source_activity_id=source.id,
                exposed_activity_id=activity.id,make_ready_action_id=make_ready_action.id,
                relationship_depth=depth,risk_days=risk
            )
            db.add(existing); created.append(existing)
    db.commit()
    return created

def activity_drift_signal(db,project_id,activity):
    metrics=activity_production_metrics(db,project_id,activity.id)
    reasons=[]
    level="NORMAL"
    if metrics["pace_ratio"] is not None:
        if metrics["pace_ratio"]<0.75:
            level="HIGH"; reasons.append(f"Installed quantity is {metrics['pace_ratio']:.0%} of reported plan.")
        elif metrics["pace_ratio"]<0.9:
            level="WATCH"; reasons.append(f"Installed quantity is {metrics['pace_ratio']:.0%} of reported plan.")
    if metrics["days_reported"]>=2 and metrics["productivity"] is not None:
        reasons.append(f"Observed productivity: {metrics['productivity']:.2f} {activity.name and 'units' or 'units'}/labor-hour.")
    return {"level":level,"reasons":reasons,"metrics":metrics}

def milestone_exposure(db,project_id):
    actions=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.status=="OPEN"
    ).all()
    rows=[]
    for action in actions:
        calculate_exposure(db,project_id,action)
    exposures=db.query(ScheduleExposureRecord).filter(
        ScheduleExposureRecord.project_id==project_id
    ).all()
    for e in exposures:
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==e.exposed_activity_id).first()
        if a and (getattr(a,"is_milestone",False) or "milestone" in (a.name or "").lower()):
            rows.append({"activity":a.name,"risk_days":e.risk_days,"depth":e.relationship_depth})
    return sorted(rows,key=lambda x:x["risk_days"],reverse=True)

def record_clearance(db,action,actual_date=None):
    actual=_parse(actual_date) if actual_date else date.today()
    planned=_parse(action.required_by) or actual
    row=ConstraintClearanceHistory(
        project_id=action.project_id,make_ready_action_id=action.id,
        planned_clear_date=planned.isoformat(),actual_clear_date=actual.isoformat(),
        variance_days=(actual-planned).days,gate_name=action.gate_name
    )
    db.add(row); db.commit(); db.refresh(row); return row
