from abc import ABC, abstractmethod

class ScheduleIntegration(ABC):
    @abstractmethod
    def fetch_schedule(self,project_external_id):
        raise NotImplementedError

class DocumentIntegration(ABC):
    @abstractmethod
    def fetch_documents(self,project_external_id):
        raise NotImplementedError

class RFIIntegration(ABC):
    @abstractmethod
    def fetch_rfis(self,project_external_id):
        raise NotImplementedError

class SubmittalIntegration(ABC):
    @abstractmethod
    def fetch_submittals(self,project_external_id):
        raise NotImplementedError
