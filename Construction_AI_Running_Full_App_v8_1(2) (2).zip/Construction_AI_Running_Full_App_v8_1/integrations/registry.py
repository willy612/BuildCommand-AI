_REGISTRY={}

def register(name,adapter):
    _REGISTRY[name]=adapter

def get(name):
    return _REGISTRY.get(name)

def available():
    return sorted(_REGISTRY.keys())
