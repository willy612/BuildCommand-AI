from datetime import datetime,date
from db.models import MakeReadyAction,LookaheadCommitment,QualityIssue,Subcontractor,SubcontractorReliabilitySnapshot

def constraint_aging(db,project_id):
    rows=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.status=="OPEN"
    ).all()
    today=date.today()
    result=[]
    for r in rows:
        try: due=datetime.strptime(r.required_by,"%Y-%m-%d").date()
        except Exception: due=today
        age=max(0,(today-due).days)
        result.append({
            "id":r.id,"title":r.title,"gate":r.gate_name,"required_by":r.required_by,
            "age_days":age,"priority":r.priority,"escalation_level":r.escalation_level
        })
    return sorted(result,key=lambda x:x["age_days"],reverse=True)

def subcontractor_reliability(db,project_id):
    subs=db.query(Subcontractor).join(
        LookaheadCommitment,LookaheadCommitment.subcontractor_id==Subcontractor.id
    ).filter(LookaheadCommitment.project_id==project_id).distinct().all()
    rows=[]
    for s in subs:
        commitments=db.query(LookaheadCommitment).filter(
            LookaheadCommitment.project_id==project_id,
            LookaheadCommitment.subcontractor_id==s.id
        ).all()
        total=len(commitments)
        confirmed=sum(1 for c in commitments if c.status=="CONFIRMED")
        delays=sum(1 for c in commitments if c.status in ("DELAY_REPORTED","CANNOT_MEET_DATE","DECLINED"))
        pending=sum(1 for c in commitments if c.status=="PENDING")
        q_open=db.query(QualityIssue).filter(
            QualityIssue.project_id==project_id,
            QualityIssue.subcontractor_id==s.id,
            QualityIssue.status!="CLOSED"
        ).count()
        q_closed=db.query(QualityIssue).filter(
            QualityIssue.project_id==project_id,
            QualityIssue.subcontractor_id==s.id,
            QualityIssue.status=="CLOSED"
        ).count()

        # Neutral, explainable score; do not use as blame.
        score=100.0
        if total:
            score -= (delays/total)*35
            score -= (pending/total)*15
            score += (confirmed/total)*10
        score -= min(q_open*3,20)
        score=max(0,min(100,score))
        rows.append({
            "subcontractor_id":s.id,"name":s.name,"trade":s.trade,
            "total_commitments":total,"confirmed":confirmed,"delay_reports":delays,
            "no_response":pending,"open_quality_items":q_open,"closed_quality_items":q_closed,
            "score":round(score,1)
        })
    return sorted(rows,key=lambda x:x["score"])
