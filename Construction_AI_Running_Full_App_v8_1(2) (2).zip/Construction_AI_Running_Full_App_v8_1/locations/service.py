from db.models import ProjectLocation,PhotoLocationLink

def create_location(db,project_id,name,location_type="AREA",code="",parent_id=None):
    row=ProjectLocation(project_id=project_id,name=name,location_type=location_type,code=code,parent_id=parent_id)
    db.add(row); db.commit(); db.refresh(row); return row

def locations(db,project_id):
    return db.query(ProjectLocation).filter(ProjectLocation.project_id==project_id,ProjectLocation.active==True).all()

def link_photo(db,photo_record_id,location_id):
    existing=db.query(PhotoLocationLink).filter(
        PhotoLocationLink.photo_record_id==photo_record_id,
        PhotoLocationLink.location_id==location_id
    ).first()
    if existing: return existing
    row=PhotoLocationLink(photo_record_id=photo_record_id,location_id=location_id)
    db.add(row); db.commit(); db.refresh(row); return row
