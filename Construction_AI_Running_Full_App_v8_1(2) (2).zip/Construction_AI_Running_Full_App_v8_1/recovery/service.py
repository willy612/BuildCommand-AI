from db.models import RecoveryScenario,ScheduleActivityAdvanced

def propose_recovery(db,project_id,activity):
    adv=db.query(ScheduleActivityAdvanced).filter(
        ScheduleActivityAdvanced.schedule_activity_id==activity.id
    ).first()
    remaining=float(adv.remaining_duration_days if adv else 0) or 0
    scenarios=[]
    options=[
        ("CREW_INCREASE","Evaluate increasing qualified crew/manpower on the constrained activity.",0.15),
        ("OVERTIME","Evaluate targeted overtime or an additional shift where safe and contractually appropriate.",0.10),
        ("RESEQUENCE","Evaluate resequencing independent work to protect downstream starts.",0.20),
        ("CONSTRAINT_CLEARANCE","Escalate prerequisite constraints and secure firm clear dates before adding labor.",0.0),
    ]
    for typ,desc,factor in options:
        recovered=round(remaining*factor,1) if remaining else 0.0
        row=RecoveryScenario(
            project_id=project_id,schedule_activity_id=activity.id,
            scenario_type=typ,description=desc,modeled_days_recovered=recovered,
            assumptions="Screening scenario only. Superintendent/PM/scheduler must validate constructability, cost, safety, labor, contracts, and CPM impact."
        )
        db.add(row);scenarios.append(row)
    db.commit()
    return scenarios
