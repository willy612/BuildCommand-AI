from pathlib import Path

def parse_xer_sections(path):
    """
    Lightweight P6 XER section reader.
    Returns raw tabular sections keyed by table name.

    This does not yet map every Primavera field; it gives the app a safe foundation
    for TASK, TASKPRED, PROJWBS, CALENDAR, ACTVCODE, and ACTVTYPE mapping.
    """
    path=Path(path)
    sections={}
    current=None
    headers=[]
    for raw in path.read_text(encoding="utf-8",errors="ignore").splitlines():
        if raw.startswith("%T"):
            parts=raw.split("\t")
            current=parts[1].strip() if len(parts)>1 else ""
            sections[current]=[]
            headers=[]
        elif raw.startswith("%F") and current:
            headers=raw.split("\t")[1:]
        elif raw.startswith("%R") and current:
            vals=raw.split("\t")[1:]
            row={headers[i]:vals[i] if i<len(vals) else "" for i in range(len(headers))}
            sections[current].append(row)
    return sections
