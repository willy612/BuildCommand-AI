from db.models import (
    ScheduleActivity,ScheduleRelationship,ScheduleActivityAdvanced,
    ScheduleRelationshipAdvanced,WBSNode,ProjectCalendar,ActivityCodeAssignment
)

def _first(row,*keys):
    for k in keys:
        if row.get(k) not in (None,""): return row.get(k)
    return ""

def import_xer_sections(db,project_id,sections):
    counts={"activities":0,"relationships":0,"wbs":0,"calendars":0}
    wbs_rows=sections.get("PROJWBS",[])
    for r in wbs_rows:
        ext=str(_first(r,"wbs_id","wbs_short_name"))
        if not ext: continue
        existing=db.query(WBSNode).filter(WBSNode.project_id==project_id,WBSNode.external_id==ext).first()
        if not existing:
            db.add(WBSNode(
                project_id=project_id,external_id=ext,
                parent_external_id=str(_first(r,"parent_wbs_id")),
                code=str(_first(r,"wbs_short_name")),
                name=str(_first(r,"wbs_name","wbs_short_name") or ext)
            )); counts["wbs"]+=1
    db.commit()

    for r in sections.get("CALENDAR",[]):
        name=str(_first(r,"clndr_name","clndr_id"))
        if not name: continue
        if not db.query(ProjectCalendar).filter(ProjectCalendar.project_id==project_id,ProjectCalendar.name==name).first():
            db.add(ProjectCalendar(project_id=project_id,name=name));counts["calendars"]+=1
    db.commit()

    task_map={}
    for r in sections.get("TASK",[]):
        ext=str(_first(r,"task_code","task_id"))
        if not ext: continue
        a=db.query(ScheduleActivity).filter(
            ScheduleActivity.project_id==project_id,ScheduleActivity.external_id==ext
        ).first()
        if not a:
            a=ScheduleActivity(
                project_id=project_id,external_id=ext,
                name=str(_first(r,"task_name") or ext),
                planned_start=str(_first(r,"target_start_date","early_start_date","start_date")),
                planned_finish=str(_first(r,"target_end_date","early_end_date","end_date")),
                percent_complete=float(_first(r,"phys_complete_pct","complete_pct") or 0),
                status=str(_first(r,"status_code") or "NOT_STARTED")
            )
            db.add(a);db.commit();db.refresh(a);counts["activities"]+=1
        task_map[str(_first(r,"task_id"))]=a
        adv=db.query(ScheduleActivityAdvanced).filter(ScheduleActivityAdvanced.schedule_activity_id==a.id).first()
        if not adv:
            adv=ScheduleActivityAdvanced(schedule_activity_id=a.id);db.add(adv)
        adv.baseline_start=str(_first(r,"target_start_date"))
        adv.baseline_finish=str(_first(r,"target_end_date"))
        adv.actual_start=str(_first(r,"act_start_date"))
        adv.actual_finish=str(_first(r,"act_end_date"))
        try: adv.remaining_duration_days=float(_first(r,"remain_drtn_hr_cnt") or 0)/8.0
        except: pass
        try: adv.total_float_days=float(_first(r,"total_float_hr_cnt") or 0)/8.0
        except: pass
    db.commit()

    existing_pairs={(r.predecessor_external_id,r.successor_external_id) for r in db.query(ScheduleRelationship).filter(
        ScheduleRelationship.project_id==project_id).all()}
    for r in sections.get("TASKPRED",[]):
        pred=task_map.get(str(_first(r,"pred_task_id")))
        succ=task_map.get(str(_first(r,"task_id")))
        if not pred or not succ: continue
        pair=(pred.external_id,succ.external_id)
        if pair in existing_pairs: continue
        typ=str(_first(r,"pred_type") or "FS").upper()
        typ={"PR_FS":"FS","PR_SS":"SS","PR_FF":"FF","PR_SF":"SF"}.get(typ,typ)
        try: lag=float(_first(r,"lag_hr_cnt") or 0)/8.0
        except: lag=0.0
        rel=ScheduleRelationship(
            project_id=project_id,predecessor_external_id=pred.external_id,
            successor_external_id=succ.external_id,relationship_type=typ,lag_days=lag
        )
        db.add(rel);db.commit();db.refresh(rel)
        db.add(ScheduleRelationshipAdvanced(relationship_id=rel.id,relationship_type=typ,lag_days=lag))
        existing_pairs.add(pair);counts["relationships"]+=1
    db.commit()
    return counts
