from db.models import WBSNode,ActivityCodeAssignment

def add_wbs_node(db,project_id,external_id,name,code="",parent_external_id=""):
    row=WBSNode(project_id=project_id,external_id=external_id,name=name,code=code,parent_external_id=parent_external_id)
    db.add(row);db.commit();db.refresh(row);return row

def assign_activity_code(db,activity_id,code_type,code_value):
    row=ActivityCodeAssignment(schedule_activity_id=activity_id,code_type=code_type,code_value=code_value)
    db.add(row);db.commit();db.refresh(row);return row
