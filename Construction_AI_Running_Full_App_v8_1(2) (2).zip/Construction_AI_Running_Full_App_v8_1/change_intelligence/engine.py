import json
import difflib
import re
from collections import Counter

def _terms(text):
    return [x.lower() for x in re.findall(r"[A-Za-z0-9#./_-]+", text or "") if len(x)>2]

def compare_text(old_text,new_text):
    old_lines=(old_text or "").splitlines()
    new_lines=(new_text or "").splitlines()
    diff=list(difflib.unified_diff(old_lines,new_lines,lineterm=""))
    old_terms=Counter(_terms(old_text))
    new_terms=Counter(_terms(new_text))
    added=[]
    removed=[]
    for term,count in new_terms.items():
        delta=count-old_terms.get(term,0)
        if delta>0: added.extend([term]*min(delta,3))
    for term,count in old_terms.items():
        delta=count-new_terms.get(term,0)
        if delta>0: removed.extend([term]*min(delta,3))
    ratio=difflib.SequenceMatcher(None,old_text or "",new_text or "").ratio()
    return {
        "similarity":round(ratio,4),
        "changed":ratio<0.995,
        "added_terms":added[:50],
        "removed_terms":removed[:50],
        "diff_excerpt":"\n".join(diff[:200])
    }

def page_pairs(old_pages,new_pages):
    old_by_sheet={p.get("sheet_number"):p for p in old_pages if p.get("sheet_number")}
    new_by_sheet={p.get("sheet_number"):p for p in new_pages if p.get("sheet_number")}
    sheets=sorted(set(old_by_sheet)|set(new_by_sheet))
    pairs=[]
    for s in sheets:
        pairs.append((s,old_by_sheet.get(s),new_by_sheet.get(s)))
    return pairs

def revision_comparison(old_pages,new_pages):
    results=[]
    for sheet,old,new in page_pairs(old_pages,new_pages):
        if old and new:
            cmp=compare_text(old.get("text_excerpt",""),new.get("text_excerpt",""))
            status="CHANGED" if cmp["changed"] else "UNCHANGED"
        elif new and not old:
            cmp={"similarity":0,"changed":True,"added_terms":[],"removed_terms":[],"diff_excerpt":""}
            status="ADDED_SHEET"
        else:
            cmp={"similarity":0,"changed":True,"added_terms":[],"removed_terms":[],"diff_excerpt":""}
            status="REMOVED_SHEET"
        results.append({
            "sheet_number":sheet,
            "status":status,
            "old_page":old,
            "new_page":new,
            **cmp
        })
    return results

def task_relevance(change,tasks):
    text=" ".join([
        change.get("sheet_number",""),
        " ".join(change.get("added_terms",[])),
        " ".join(change.get("removed_terms",[])),
        change.get("diff_excerpt","")
    ]).lower()
    terms=set(_terms(text))
    scored=[]
    for t in tasks:
        hay=" ".join([t.get("name",""),t.get("phase",""),t.get("system",""),t.get("purpose","")]).lower()
        tterms=set(_terms(hay))
        score=len(terms&tterms)
        if score:
            scored.append((score,t))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [{"task_id":t["id"],"name":t["name"],"score":score} for score,t in scored[:8]]

def schedule_relevance(change,schedule_rows):
    text=" ".join(change.get("added_terms",[])+change.get("removed_terms",[])+[change.get("diff_excerpt","")]).lower()
    terms=set(_terms(text))
    scored=[]
    for a in schedule_rows:
        hay=f"{getattr(a,'name','')} {getattr(a,'phase','')} {getattr(a,'trade','')}".lower()
        score=len(terms & set(_terms(hay)))
        if score:
            scored.append((score,a))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [{
        "activity_id":a.id,
        "external_id":a.external_id,
        "name":a.name,
        "score":score
    } for score,a in scored[:8]]

def infer_change_flags(change):
    text=(" ".join(change.get("added_terms",[])+change.get("removed_terms",[]))+" "+change.get("diff_excerpt","")).lower()
    rfi_terms=["conflict","clarify","verify","coordinate","tbd","field verify","unknown"]
    cost_terms=["add","additional","replace","new","increase","decrease","delete","remove","alternate"]
    schedule_terms=["sequence","phase","before","after","relocate","rework","remove","new","additional"]
    return {
        "possible_rfi":any(x in text for x in rfi_terms),
        "possible_cost_change":any(x in text for x in cost_terms),
        "possible_schedule_change":any(x in text for x in schedule_terms)
    }

def summarize_change(change):
    if change["status"]=="ADDED_SHEET":
        return f"Sheet {change['sheet_number']} was added."
    if change["status"]=="REMOVED_SHEET":
        return f"Sheet {change['sheet_number']} was removed."
    if change["status"]=="UNCHANGED":
        return f"Sheet {change['sheet_number']} appears materially unchanged in extracted text."
    added=", ".join(change.get("added_terms",[])[:8]) or "none identified"
    removed=", ".join(change.get("removed_terms",[])[:8]) or "none identified"
    return f"Sheet {change['sheet_number']} changed. Added terms: {added}. Removed terms: {removed}."
