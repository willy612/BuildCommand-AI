from db.models import IntelligenceAuditEvent

def audit(db,company_id,event_type,project_id=None,user_id=None,entity_type="",entity_id=None,decision="",detail=""):
    row=IntelligenceAuditEvent(
        company_id=company_id,project_id=project_id,user_id=user_id,event_type=event_type,
        entity_type=entity_type,entity_id=entity_id,decision=decision,detail=detail
    )
    db.add(row);db.commit();db.refresh(row);return row
