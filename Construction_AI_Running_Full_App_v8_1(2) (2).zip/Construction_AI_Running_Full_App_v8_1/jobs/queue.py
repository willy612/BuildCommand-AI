from dataclasses import dataclass
from typing import Callable, Any

@dataclass
class JobResult:
    status: str
    result: Any = None
    error: str = ""

class InlineJobQueue:
    """
    Development-safe queue. Executes immediately.
    Production can replace this with Celery/RQ/Arq/Dramatiq without changing callers.
    """
    def submit(self,fn:Callable,*args,**kwargs):
        try:
            return JobResult(status="COMPLETE",result=fn(*args,**kwargs))
        except Exception as e:
            return JobResult(status="FAILED",error=str(e))

def get_job_queue():
    return InlineJobQueue()
