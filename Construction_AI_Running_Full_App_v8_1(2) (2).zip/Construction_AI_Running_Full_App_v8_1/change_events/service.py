import json
from db.models import ChangeEvent,ChangeImpactItem,Subcontractor,ActivityAssignment,ScheduleActivity

def create_change_event(db,project_id,title,summary,source_document_id=None,prior_document_id=None,
                        affected_tasks=None,affected_schedule=None,flags=None):
    affected_tasks=affected_tasks or []
    affected_schedule=affected_schedule or []
    flags=flags or {}
    sub_ids=set()
    for sched in affected_schedule:
        for row in db.query(ActivityAssignment).filter(
            ActivityAssignment.project_id==project_id,
            ActivityAssignment.schedule_activity_id==sched.get("activity_id")
        ).all():
            sub_ids.add(row.subcontractor_id)
    subs=[]
    for sid in sub_ids:
        s=db.query(Subcontractor).filter(Subcontractor.id==sid).first()
        if s: subs.append({"subcontractor_id":sid,"name":s.name,"trade":s.trade})

    event=ChangeEvent(
        project_id=project_id,source_document_id=source_document_id,prior_document_id=prior_document_id,
        title=title,summary=summary,
        affected_tasks_json=json.dumps(affected_tasks),
        affected_schedule_json=json.dumps(affected_schedule),
        affected_subcontractors_json=json.dumps(subs),
        possible_rfi=bool(flags.get("possible_rfi")),
        possible_cost_change=bool(flags.get("possible_cost_change")),
        possible_schedule_change=bool(flags.get("possible_schedule_change")),
        status="PENDING_REVIEW"
    )
    db.add(event); db.commit(); db.refresh(event)

    for t in affected_tasks:
        db.add(ChangeImpactItem(
            change_event_id=event.id,impact_type="TASK",entity_type="construction_task",
            entity_id=t.get("task_id",""),label=t.get("name",""),severity="WARNING",
            reason="Potential task impact inferred from revision text."
        ))
    for a in affected_schedule:
        db.add(ChangeImpactItem(
            change_event_id=event.id,impact_type="SCHEDULE",entity_type="schedule_activity",
            entity_id=str(a.get("activity_id","")),label=a.get("name",""),severity="WARNING",
            reason="Potential schedule activity impact inferred from revision text."
        ))
    for s in subs:
        db.add(ChangeImpactItem(
            change_event_id=event.id,impact_type="SUBCONTRACTOR",entity_type="subcontractor",
            entity_id=str(s.get("subcontractor_id","")),label=s.get("name",""),severity="INFO",
            reason="Subcontractor assigned to a potentially affected schedule activity."
        ))
    db.commit()
    return event

def approve_change_event(db,event_id):
    e=db.query(ChangeEvent).filter(ChangeEvent.id==event_id).first()
    if not e: return False
    e.status="APPROVED"
    db.commit()
    return True
