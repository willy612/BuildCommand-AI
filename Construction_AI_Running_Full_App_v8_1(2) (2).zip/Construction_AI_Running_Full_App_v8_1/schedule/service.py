import re
from db.models import ScheduleActivity, ScheduleRelationship

def persist_schedule(db, project_id, rows):
    db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).delete()
    db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).delete()
    for r in rows:
        db.add(ScheduleActivity(
            project_id=project_id, external_id=r["activity_id"], name=r["name"],
            planned_start=r.get("planned_start",""), planned_finish=r.get("planned_finish",""),
            percent_complete=r.get("percent_complete",0), phase=r.get("phase",""),
            trade=r.get("trade",""), status=r.get("status","NOT_STARTED")
        ))
        for p in r.get("predecessors",[]):
            db.add(ScheduleRelationship(
                project_id=project_id, predecessor_external_id=p,
                successor_external_id=r["activity_id"], relationship_type="FS"
            ))
    db.commit()

def _tokens(text):
    stop={"the","and","for","with","work","install","installation","activity","construction"}
    return {x for x in re.findall(r"[a-z0-9]+",(text or "").lower()) if len(x)>2 and x not in stop}

def suggest_task_mapping(activity, tasks, limit=5):
    a=_tokens(" ".join([activity.name,activity.phase or "",activity.trade or ""]))
    scored=[]
    for t in tasks:
        b=_tokens(" ".join([t.get("name",""),t.get("phase",""),t.get("system",""),t.get("purpose","")]))
        union=a|b
        score=(len(a&b)/len(union)) if union else 0
        if score: scored.append((score,t))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [{"task_id":t["id"],"name":t["name"],"score":round(score,3)} for score,t in scored[:limit]]

def apply_task_mapping(db, activity_id, task_id):
    row=db.query(ScheduleActivity).filter(ScheduleActivity.id==activity_id).first()
    if not row: return False
    row.mapped_task_id=task_id
    db.commit()
    return True

def list_schedule(db, project_id):
    return db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
