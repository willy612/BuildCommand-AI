from datetime import date, datetime, timedelta
from db.models import ScheduleActivity, ActivityAssignment, Subcontractor, LookaheadCommitment

def _as_date(value):
    if not value:
        return None
    if isinstance(value,date):
        return value
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try:
            return datetime.strptime(str(value),fmt).date()
        except Exception:
            pass
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        return None

def lookahead_activities(db, project_id, start=None, weeks=6):
    start=_as_date(start) or date.today()
    finish=start+timedelta(weeks=weeks)
    rows=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    result=[]
    for a in rows:
        d=_as_date(a.planned_start)
        if d and start <= d <= finish:
            result.append(a)
    return sorted(result,key=lambda x:_as_date(x.planned_start) or finish)

def activity_subcontractors(db, project_id, activity_id):
    return db.query(Subcontractor).join(
        ActivityAssignment,ActivityAssignment.subcontractor_id==Subcontractor.id
    ).filter(
        ActivityAssignment.project_id==project_id,
        ActivityAssignment.schedule_activity_id==activity_id
    ).all()

def ensure_commitment(db, project_id, activity, subcontractor_id, response_lead_days=7):
    existing=db.query(LookaheadCommitment).filter(
        LookaheadCommitment.project_id==project_id,
        LookaheadCommitment.schedule_activity_id==activity.id,
        LookaheadCommitment.subcontractor_id==subcontractor_id
    ).first()
    if existing:
        return existing
    start=_as_date(activity.planned_start)
    due=(start-timedelta(days=response_lead_days)).isoformat() if start else ""
    row=LookaheadCommitment(
        project_id=project_id,schedule_activity_id=activity.id,
        subcontractor_id=subcontractor_id,
        requested_start=activity.planned_start,
        requested_finish=activity.planned_finish,
        response_due=due,status="PENDING"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def commitment_health(commitment):
    status=commitment.status
    if status=="DELAY_REPORTED":
        return "AT_RISK"
    if status=="CONFIRMED":
        return "READY"
    if status in ("DECLINED","CANNOT_MEET_DATE"):
        return "HOLD"
    return "NOT_VERIFIED"
