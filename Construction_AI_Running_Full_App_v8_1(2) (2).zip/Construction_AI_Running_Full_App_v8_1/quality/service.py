from db.models import QualityIssue
from readiness_gates.service import close_gate

def create_issue(db,project_id,title,description="",category="PUNCH",priority="NORMAL",
                 location_id=None,schedule_activity_id=None,subcontractor_id=None,source_photo_id=None,due_date=""):
    row=QualityIssue(
        project_id=project_id,title=title,description=description,category=category,priority=priority,
        location_id=location_id,schedule_activity_id=schedule_activity_id,
        subcontractor_id=subcontractor_id,source_photo_id=source_photo_id,due_date=due_date,status="OPEN"
    )
    db.add(row); db.commit(); db.refresh(row); return row

def submit_verification_photo(db,issue_id,photo_id):
    row=db.query(QualityIssue).filter(QualityIssue.id==issue_id).first()
    if not row: return None
    row.verification_photo_id=photo_id
    row.status="READY_FOR_VERIFICATION"
    db.commit(); db.refresh(row); return row

def close_issue(db,issue_id):
    row=db.query(QualityIssue).filter(QualityIssue.id==issue_id).first()
    if not row: return None
    row.status="CLOSED"
    db.commit(); db.refresh(row)
    close_gate(db,"QUALITY_ISSUE",row.id)
    return row
