from db.models import (
    ScheduleVersion,ScheduleVersionActivity,
    ScheduleActivity,ScheduleActivityAdvanced
)

def snapshot_current_schedule(db,project_id,version_name,data_date="",source_type="XER",source_filename="",notes=""):
    version=ScheduleVersion(
        project_id=project_id,version_name=version_name,data_date=data_date,
        source_type=source_type,source_filename=source_filename,notes=notes
    )
    db.add(version);db.commit();db.refresh(version)

    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    for a in acts:
        adv=db.query(ScheduleActivityAdvanced).filter(
            ScheduleActivityAdvanced.schedule_activity_id==a.id
        ).first()
        db.add(ScheduleVersionActivity(
            schedule_version_id=version.id,external_id=a.external_id,name=a.name,
            planned_start=a.planned_start,planned_finish=a.planned_finish,
            percent_complete=a.percent_complete or 0,
            total_float_days=(adv.total_float_days if adv else 0) or 0,
            remaining_duration_days=(adv.remaining_duration_days if adv else 0) or 0
        ))
    db.commit()
    return version

def compare_versions(db,old_version_id,new_version_id):
    old={r.external_id:r for r in db.query(ScheduleVersionActivity).filter(
        ScheduleVersionActivity.schedule_version_id==old_version_id).all()}
    new={r.external_id:r for r in db.query(ScheduleVersionActivity).filter(
        ScheduleVersionActivity.schedule_version_id==new_version_id).all()}
    ids=sorted(set(old)|set(new))
    rows=[]
    for ext in ids:
        o=old.get(ext); n=new.get(ext)
        if o and not n:
            rows.append({"external_id":ext,"status":"REMOVED","name":o.name})
        elif n and not o:
            rows.append({"external_id":ext,"status":"ADDED","name":n.name})
        else:
            changes=[]
            for field in ["planned_start","planned_finish","percent_complete","total_float_days","remaining_duration_days"]:
                ov=getattr(o,field); nv=getattr(n,field)
                if ov!=nv: changes.append({"field":field,"old":ov,"new":nv})
            rows.append({"external_id":ext,"status":"CHANGED" if changes else "UNCHANGED","name":n.name,"changes":changes})
    return rows
