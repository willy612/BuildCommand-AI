import os
from dataclasses import dataclass

@dataclass
class Identity:
    subject: str
    email: str
    company_id: int
    user_id: int
    role: str

class AuthProvider:
    def verify(self, token: str) -> Identity:
        raise NotImplementedError

class DevelopmentAuthProvider(AuthProvider):
    def verify(self, token: str) -> Identity:
        # Development only. Replace with OIDC/JWT provider in deployment.
        return Identity(
            subject="dev-user",
            email=os.getenv("DEV_USER_EMAIL", "admin@example.com"),
            company_id=int(os.getenv("DEV_COMPANY_ID", "1")),
            user_id=int(os.getenv("DEV_USER_ID", "1")),
            role=os.getenv("DEV_USER_ROLE", "owner_admin"),
        )

def get_auth_provider():
    mode=os.getenv("AUTH_PROVIDER","development").lower()
    if mode=="development":
        return DevelopmentAuthProvider()
    raise RuntimeError(
        f"Auth provider '{mode}' is not configured. "
        "Implement OIDC/JWT verification before production launch."
    )
