from portfolio.dashboard import company_portfolio
from approvals.service import pending_approvals
from inbox.service import user_inbox
from platform.tenancy import accessible_projects

def role_home_data(db,user):
    data={"role":user.role,"projects":accessible_projects(db,user)}
    if user.role in ("owner_admin","operations_manager","project_executive"):
        data["portfolio"]=company_portfolio(db,user.company_id)
    else:
        data["portfolio"]=[]
    data["approvals"]=pending_approvals(db)
    data["inbox"]=user_inbox(db,user.company_id,user.id)
    return data
