import streamlit as st
from datetime import datetime,timedelta

def _date(value):
    if not value: return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try: return datetime.strptime(str(value),fmt).date()
        except Exception: pass
    return None

def lookahead_board(rows,sub_lookup_fn):
    today=datetime.today().date()
    weeks=[today+timedelta(days=7*i) for i in range(6)]
    cols=st.columns(6)
    for i,start in enumerate(weeks):
        end=start+timedelta(days=6)
        with cols[i]:
            st.markdown(f"**Week {i+1}**")
            st.caption(f"{start:%b %d}–{end:%b %d}")
            week_rows=[a for a in rows if _date(a.planned_start) and start <= _date(a.planned_start) <= end]
            if not week_rows:
                st.caption("No starts")
            for a in week_rows[:8]:
                subs=sub_lookup_fn(a)
                sub=", ".join(s.name for s in subs) if subs else "No sub"
                st.markdown(f"**{a.name}**")
                st.caption(f"{a.planned_start} · {sub}")
