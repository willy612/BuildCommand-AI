import streamlit as st

CSS = """
<style>
.block-container {padding-top: 1.25rem; padding-bottom: 2rem; max-width: 1500px;}
[data-testid="stSidebar"] {border-right: 1px solid rgba(128,128,128,.18);}
.hero {
  padding: 1.25rem 1.35rem;
  border: 1px solid rgba(128,128,128,.2);
  border-radius: 18px;
  margin-bottom: 1rem;
}
.kpi {
  padding: 1rem;
  border: 1px solid rgba(128,128,128,.18);
  border-radius: 16px;
  min-height: 115px;
}
.badge {
  display:inline-block; padding:.25rem .55rem; border-radius:999px;
  font-size:.78rem; border:1px solid rgba(128,128,128,.25);
}
.muted {opacity:.72;}
.section-title {margin-top:.35rem;margin-bottom:.55rem;}
</style>
"""

def apply_theme():
    st.markdown(CSS, unsafe_allow_html=True)

def hero(title, subtitle="", eyebrow=""):
    st.markdown(
        f"""<div class="hero">
        <div class="muted" style="font-size:.8rem;text-transform:uppercase;letter-spacing:.08em">{eyebrow}</div>
        <h2 style="margin:.15rem 0 .25rem 0">{title}</h2>
        <div class="muted">{subtitle}</div>
        </div>""",
        unsafe_allow_html=True
    )

def kpi(label, value, note=""):
    st.markdown(
        f"""<div class="kpi">
        <div class="muted" style="font-size:.82rem">{label}</div>
        <div style="font-size:1.8rem;font-weight:700;margin:.1rem 0">{value}</div>
        <div class="muted" style="font-size:.78rem">{note}</div>
        </div>""",
        unsafe_allow_html=True
    )
