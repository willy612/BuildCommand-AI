import streamlit as st

def activity_card(title,status="",meta="",owner="",note=""):
    icon = {
        "READY":"✅","HOLD":"⛔","AT RISK":"⚠️","NOT VERIFIED":"❓",
        "CONFIRMED":"✅","PENDING":"🕒","DELAY_REPORTED":"⚠️"
    }.get(status,"•")
    st.markdown(
        f"""
        <div style="
            border:1px solid rgba(128,128,128,.18);
            border-radius:16px;padding:14px 16px;margin-bottom:10px;">
          <div style="font-weight:700;font-size:1.02rem">{icon} {title}</div>
          <div style="opacity:.7;font-size:.84rem;margin-top:3px">{meta}</div>
          <div style="margin-top:8px"><b>{status or '—'}</b>{' · '+owner if owner else ''}</div>
          <div style="opacity:.78;font-size:.84rem;margin-top:4px">{note}</div>
        </div>
        """,
        unsafe_allow_html=True
    )
