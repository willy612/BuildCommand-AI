# Database migration policy

The prototype currently creates tables from ORM metadata.

Before production:
1. adopt Alembic (or equivalent) migrations;
2. create a baseline migration from the current schema;
3. never use destructive automatic schema changes at application startup;
4. test forward migration and rollback against a production-like copy;
5. back up the database before every production migration;
6. record migration version in deployment metadata.

This directory intentionally does not fake a production migration history.
