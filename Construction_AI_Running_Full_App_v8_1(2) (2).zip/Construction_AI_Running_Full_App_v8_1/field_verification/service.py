from db.models import (
    FieldVerificationProposal, PunchQualityItem, ConstraintProposal,
    FieldUpdate, KnowledgeChunk
)

def candidate_requirements(db,project_id,terms,limit=8):
    q=db.query(KnowledgeChunk).filter(KnowledgeChunk.project_id==project_id)
    rows=q.limit(250).all()
    terms=[t.lower() for t in terms if len(t)>2]
    scored=[]
    for r in rows:
        text=(r.text or "").lower()
        score=sum(1 for t in terms if t in text)
        if score:
            scored.append((score,r))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [r for _,r in scored[:limit]]

def create_verification(db,project_id,photo_record_id,title,field_observation,
                        requirement_text="",source_document_id=None,source_page=None,
                        source_ref="",result="NOT_VERIFIED",suggested_action="",
                        schedule_activity_id=None,confidence=0.0):
    row=FieldVerificationProposal(
        project_id=project_id,photo_record_id=photo_record_id,
        schedule_activity_id=schedule_activity_id,title=title,
        field_observation=field_observation,requirement_text=requirement_text,
        source_document_id=source_document_id,source_page=source_page,
        source_ref=source_ref,result=result,suggested_action=suggested_action,
        confidence=confidence,status="PENDING_REVIEW"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def approve_verification(db,proposal_id,action="NO_ACTION"):
    p=db.query(FieldVerificationProposal).filter(FieldVerificationProposal.id==proposal_id).first()
    if not p: return None
    p.status="APPROVED"
    created=None
    if action=="PUNCH":
        created=PunchQualityItem(
            project_id=p.project_id,schedule_activity_id=p.schedule_activity_id,
            source_photo_id=p.photo_record_id,title=p.title,
            description=p.field_observation+"\n\nRequirement: "+(p.requirement_text or ""),
            category="QUALITY",status="OPEN"
        )
        db.add(created)
    elif action=="CONSTRAINT":
        created=ConstraintProposal(
            project_id=p.project_id,schedule_activity_id=p.schedule_activity_id,
            source_type="FIELD_VERIFICATION",source_id=str(p.id),
            category="QUALITY",description=p.field_observation,
            schedule_exposure="Potential field/document mismatch requires review.",
            recommended_action=p.suggested_action or "Verify against governing project documents.",
            confidence=p.confidence,status="PENDING_REVIEW"
        )
        db.add(created)
    elif action=="PROGRESS":
        created=FieldUpdate(
            project_id=p.project_id,schedule_activity_id=p.schedule_activity_id,
            update_type="PROGRESS",text=p.field_observation,status="RECORDED"
        )
        db.add(created)
    db.commit()
    return created or p
