import re
from field_verification.service import candidate_requirements,create_verification

def _terms(text):
    return [x.lower() for x in re.findall(r"[A-Za-z0-9_-]+",text or "") if len(x)>3]

def propose_document_checks(db,photo):
    observation=(photo.observation or photo.caption or "").strip()
    if not observation:
        return []
    requirements=candidate_requirements(db,photo.project_id,_terms(observation),limit=5)
    proposals=[]
    if not requirements:
        proposals.append(create_verification(
            db,photo.project_id,photo.id,
            "Field observation needs document verification",
            observation,result="NOT_VERIFIED",
            suggested_action="Locate the governing plan, detail, specification, approved submittal, or RFI before accepting the condition.",
            schedule_activity_id=photo.schedule_activity_id,confidence=0.35
        ))
        return proposals

    for chunk in requirements[:3]:
        proposals.append(create_verification(
            db,photo.project_id,photo.id,
            "Compare field condition to project requirement",
            observation,requirement_text=chunk.text,
            source_document_id=chunk.document_id,source_page=chunk.page_number,
            source_ref=chunk.source_ref,result="REVIEW_REQUIRED",
            suggested_action="Superintendent/PM to compare visible field condition with cited project requirement.",
            schedule_activity_id=photo.schedule_activity_id,confidence=0.55
        ))
    return proposals
