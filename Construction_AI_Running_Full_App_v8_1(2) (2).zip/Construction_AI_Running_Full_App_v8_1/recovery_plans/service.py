from datetime import date
from db.models import ApprovedRecoveryPlan,RecoveryOutcomeReview,RecoveryOptionEvaluation

def approve_option(db,option_id,user_id=None,target_completion="",notes=""):
    option=db.query(RecoveryOptionEvaluation).filter(RecoveryOptionEvaluation.id==option_id).first()
    if not option:return None
    option.status="APPROVED"
    plan=ApprovedRecoveryPlan(
        project_id=option.project_id,schedule_activity_id=option.schedule_activity_id,
        recovery_option_evaluation_id=option.id,approved_by_user_id=user_id,
        approved_date=date.today().isoformat(),target_completion=target_completion,
        predicted_days_recovered=option.modeled_project_days_recovered,
        predicted_cost=option.estimated_cost,status="ACTIVE",notes=notes
    )
    db.add(plan);db.commit();db.refresh(plan);return plan

def record_outcome(db,plan_id,actual_completion="",actual_days_recovered=0,actual_cost=0,lessons=""):
    plan=db.query(ApprovedRecoveryPlan).filter(ApprovedRecoveryPlan.id==plan_id).first()
    if not plan:return None
    met=float(actual_days_recovered or 0) >= float(plan.predicted_days_recovered or 0)*0.8
    delta=abs(float(actual_days_recovered or 0)-float(plan.predicted_days_recovered or 0))
    rating="STRONG" if met and delta<=1 else "MIXED" if met else "WEAK"
    row=RecoveryOutcomeReview(
        approved_recovery_plan_id=plan.id,actual_completion=actual_completion,
        actual_days_recovered=float(actual_days_recovered or 0),
        actual_cost=float(actual_cost or 0),met_target=met,
        outcome_rating=rating,lessons=lessons
    )
    db.add(row)
    plan.status="COMPLETE"
    db.commit();db.refresh(row);return row

def learned_recovery_summary(db,project_id):
    from db.models import RecoveryOutcomeReview,ApprovedRecoveryPlan,RecoveryOptionEvaluation
    plans=db.query(ApprovedRecoveryPlan).filter(ApprovedRecoveryPlan.project_id==project_id).all()
    grouped={}
    for p in plans:
        opt=db.query(RecoveryOptionEvaluation).filter(RecoveryOptionEvaluation.id==p.recovery_option_evaluation_id).first()
        out=db.query(RecoveryOutcomeReview).filter(RecoveryOutcomeReview.approved_recovery_plan_id==p.id).first()
        if not opt or not out:continue
        g=grouped.setdefault(opt.scenario_type,{"count":0,"predicted":0.0,"actual":0.0,"cost":0.0,"strong":0})
        g["count"]+=1;g["predicted"]+=p.predicted_days_recovered or 0
        g["actual"]+=out.actual_days_recovered or 0;g["cost"]+=out.actual_cost or 0
        g["strong"]+=1 if out.outcome_rating=="STRONG" else 0
    for g in grouped.values():
        g["strong_rate"]=g["strong"]/g["count"] if g["count"] else 0
    return grouped
