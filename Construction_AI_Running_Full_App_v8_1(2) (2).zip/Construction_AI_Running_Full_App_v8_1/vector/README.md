# Vector backend

Current fallback: embeddings stored as JSON.

Production target:
- PostgreSQL
- pgvector extension
- vector column on knowledge_chunks
- IVFFlat or HNSW index
- hybrid ranking with keyword + vector + revision/source weighting

The abstraction exists so pgvector can replace JSON storage without changing higher-level retrieval APIs.
