import json
import os
from search.semantic_search import cosine

class JsonVectorBackend:
    def score(self,row,query_vector):
        if not row.embedding_json:
            return 0.0
        try:
            return max(0.0,cosine(query_vector,json.loads(row.embedding_json)))
        except Exception:
            return 0.0

def get_vector_backend():
    # Production target: pgvector.
    return JsonVectorBackend()
