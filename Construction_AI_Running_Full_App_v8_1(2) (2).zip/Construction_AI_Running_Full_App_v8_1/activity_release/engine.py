import json
from datetime import datetime
from db.models import (
    ScheduleActivity,ScheduleRelationship,ReadinessGate,PermitRecord,
    LookaheadCommitment,ProcurementItem,ActivityReleaseDecision
)
from site_conditions.service import blocking_site_conditions

READY="READY"
HOLD="HOLD"
AT_RISK="AT RISK"
NOT_VERIFIED="NOT VERIFIED"

def _predecessor_gate(db,project_id,activity):
    rels=db.query(ScheduleRelationship).filter(
        ScheduleRelationship.project_id==project_id,
        ScheduleRelationship.successor_external_id==activity.external_id
    ).all()
    if not rels:
        return {"gate":"Predecessors","status":READY,"reason":"No predecessor relationships are recorded."}
    rows=[]
    for r in rels:
        pred=db.query(ScheduleActivity).filter(
            ScheduleActivity.project_id==project_id,
            ScheduleActivity.external_id==r.predecessor_external_id
        ).first()
        if pred:
            rows.append(pred)
    incomplete=[p for p in rows if not (p.status=="COMPLETE" or float(p.percent_complete or 0)>=100)]
    if incomplete:
        return {"gate":"Predecessors","status":HOLD,
                "reason":"Incomplete predecessor(s): "+", ".join(p.name for p in incomplete[:5])}
    return {"gate":"Predecessors","status":READY,"reason":"Recorded predecessors are complete."}

def _readiness_gate(db,project_id,activity):
    rows=db.query(ReadinessGate).filter(
        ReadinessGate.project_id==project_id,
        ReadinessGate.schedule_activity_id==activity.id,
        ReadinessGate.status=="OPEN"
    ).all()
    blocking=[r for r in rows if r.blocking]
    if blocking:
        return {"gate":"Inspection / Quality","status":HOLD,
                "reason":"; ".join(r.title for r in blocking[:5])}
    if rows:
        return {"gate":"Inspection / Quality","status":AT_RISK,
                "reason":f"{len(rows)} open non-blocking gate(s)."}
    return {"gate":"Inspection / Quality","status":READY,"reason":"No open inspection/quality gates."}

def _permit_gate(db,project_id,activity):
    task_id=activity.mapped_task_id or ""
    if not task_id:
        return {"gate":"Permit / authorization","status":NOT_VERIFIED,
                "reason":"Schedule activity is not mapped to a construction task."}
    row=db.query(PermitRecord).filter(
        PermitRecord.project_id==project_id,
        PermitRecord.task_id==task_id
    ).first()
    if not row:
        return {"gate":"Permit / authorization","status":NOT_VERIFIED,
                "reason":"No permit/authorization record is linked to the mapped task."}
    if row.status in ("VERIFIED","APPROVED","NOT_REQUIRED"):
        return {"gate":"Permit / authorization","status":READY,"reason":row.status}
    return {"gate":"Permit / authorization","status":HOLD,
            "reason":f"Permit/authorization status is {row.status}."}

def _sub_commitment_gate(db,project_id,activity):
    rows=db.query(LookaheadCommitment).filter(
        LookaheadCommitment.project_id==project_id,
        LookaheadCommitment.schedule_activity_id==activity.id
    ).all()
    if not rows:
        return {"gate":"Subcontractor commitment","status":NOT_VERIFIED,
                "reason":"No subcontractor commitment is recorded for this activity."}
    bad=[r for r in rows if r.status in ("DELAY_REPORTED","CANNOT_MEET_DATE","DECLINED")]
    risk=[r for r in rows if r.status in ("NEED_INFORMATION","MATERIAL_ISSUE","MANPOWER_ISSUE","ACCESS_ISSUE","PENDING")]
    if bad:
        return {"gate":"Subcontractor commitment","status":HOLD,
                "reason":f"{len(bad)} subcontractor commitment(s) report a delay or inability to meet the date."}
    if risk:
        return {"gate":"Subcontractor commitment","status":AT_RISK,
                "reason":f"{len(risk)} subcontractor commitment(s) are unresolved or at risk."}
    return {"gate":"Subcontractor commitment","status":READY,
            "reason":"Assigned subcontractor commitments are confirmed."}

def _procurement_gate(db,project_id,activity):
    task_id=activity.mapped_task_id or ""
    rows=db.query(ProcurementItem).filter(ProcurementItem.project_id==project_id).all()
    linked=[r for r in rows if r.task_id==task_id] if task_id else []
    if not linked:
        return {"gate":"Submittals / procurement","status":NOT_VERIFIED,
                "reason":"No procurement items are linked to this activity's mapped task."}
    critical=[]
    risk=[]
    for r in linked:
        if r.submittal_status in ("REJECTED","REVISION_REQUIRED") or r.procurement_status=="ON_HOLD":
            critical.append(r)
        elif r.submittal_status not in ("APPROVED","APPROVED_AS_NOTED") or r.procurement_status in ("NOT_RELEASED",):
            risk.append(r)
    if critical:
        return {"gate":"Submittals / procurement","status":HOLD,
                "reason":"Critical item(s): "+", ".join(r.name for r in critical[:5])}
    if risk:
        return {"gate":"Submittals / procurement","status":AT_RISK,
                "reason":"Unresolved item(s): "+", ".join(r.name for r in risk[:5])}
    return {"gate":"Submittals / procurement","status":READY,
            "reason":"Linked submittal/procurement items show no current blocker."}

def _site_gate(db,project_id,activity):
    rows=blocking_site_conditions(db,project_id,activity.id)
    if rows:
        return {"gate":"Site conditions","status":HOLD,
                "reason":"; ".join(r.description or r.condition_type for r in rows[:5])}
    return {"gate":"Site conditions","status":READY,"reason":"No blocking site condition is recorded."}

def evaluate_activity_release(db,project_id,activity_id):
    activity=db.query(ScheduleActivity).filter(
        ScheduleActivity.id==activity_id,
        ScheduleActivity.project_id==project_id
    ).first()
    if not activity:
        raise ValueError("Schedule activity not found")

    gates=[
        _predecessor_gate(db,project_id,activity),
        _readiness_gate(db,project_id,activity),
        _permit_gate(db,project_id,activity),
        _sub_commitment_gate(db,project_id,activity),
        _procurement_gate(db,project_id,activity),
        _site_gate(db,project_id,activity),
    ]

    if any(g["status"]==HOLD for g in gates):
        status=HOLD
    elif any(g["status"] in (AT_RISK,NOT_VERIFIED) for g in gates):
        status=AT_RISK
    else:
        status=READY

    reasons=[g for g in gates if g["status"]!=READY]

    row=db.query(ActivityReleaseDecision).filter(
        ActivityReleaseDecision.project_id==project_id,
        ActivityReleaseDecision.schedule_activity_id==activity_id
    ).order_by(ActivityReleaseDecision.evaluated_at.desc()).first()

    decision=ActivityReleaseDecision(
        project_id=project_id,schedule_activity_id=activity_id,
        status=status,reasons_json=json.dumps(reasons),
        evaluated_at=datetime.utcnow()
    )
    db.add(decision); db.commit(); db.refresh(decision)

    return {
        "activity_id":activity.id,
        "external_id":activity.external_id,
        "name":activity.name,
        "status":status,
        "gates":gates,
        "blocking_reasons":[g for g in gates if g["status"]==HOLD],
        "risk_reasons":[g for g in gates if g["status"] in (AT_RISK,NOT_VERIFIED)],
        "decision_id":decision.id
    }

def evaluate_project_lookahead(db,project_id,activities):
    return [evaluate_activity_release(db,project_id,a.id) for a in activities]
