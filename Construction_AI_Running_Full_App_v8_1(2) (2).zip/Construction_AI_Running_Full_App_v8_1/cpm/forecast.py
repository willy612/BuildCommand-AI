from datetime import datetime,date,timedelta
from collections import defaultdict,deque
from db.models import (
    ScheduleActivity,ScheduleRelationship,ActivityForecastSnapshot,
    ProjectForecastSnapshot,ScheduleExposureRecord
)
from production.service import activity_production_metrics

def _parse(v):
    if not v: return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try: return datetime.strptime(str(v),fmt).date()
        except Exception: pass
    return None

def _duration(a):
    s=_parse(a.planned_start); f=_parse(a.planned_finish)
    if s and f: return max(1,(f-s).days+1)
    return 1

def remaining_duration_forecast(db,project_id,a):
    planned=_duration(a)
    pct=float(a.percent_complete or 0)
    metrics=activity_production_metrics(db,project_id,a.id)
    if pct>=100: return 0.0,0.95
    baseline=max(1.0,planned*(1-pct/100.0))
    confidence=0.45
    if metrics["pace_ratio"] is not None and metrics["pace_ratio"]>0:
        # pace below plan expands remaining duration; cap prevents absurd forecasts.
        factor=min(2.5,max(0.6,1.0/metrics["pace_ratio"]))
        baseline*=factor
        confidence=0.70 if metrics["days_reported"]>=3 else 0.58
    return round(baseline,1),confidence

def _topological(activities,relationships):
    by_ext={a.external_id:a for a in activities}
    indeg={a.external_id:0 for a in activities}
    succ=defaultdict(list)
    for r in relationships:
        if r.predecessor_external_id in by_ext and r.successor_external_id in by_ext:
            succ[r.predecessor_external_id].append(r.successor_external_id)
            indeg[r.successor_external_id]+=1
    q=deque([k for k,v in indeg.items() if v==0])
    order=[]
    while q:
        n=q.popleft(); order.append(n)
        for s in succ[n]:
            indeg[s]-=1
            if indeg[s]==0:q.append(s)
    # cycles/unlinked fall back to planned order
    for a in sorted(activities,key=lambda x:(_parse(x.planned_start) or date.max)):
        if a.external_id not in order: order.append(a.external_id)
    return order,succ

def forecast_project(db,project_id):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    if not acts: return None,[]
    by_ext={a.external_id:a for a in acts}
    order,succ=_topological(acts,rels)
    pred=defaultdict(list)
    for p,ss in succ.items():
        for s in ss: pred[s].append(p)

    today=date.today()
    fstart={}
    ffinish={}
    snapshots=[]
    for ext in order:
        a=by_ext[ext]
        remaining,conf=remaining_duration_forecast(db,project_id,a)
        planned_start=_parse(a.planned_start) or today
        start=max(today,planned_start)
        if pred[ext]:
            predecessor_finishes=[ffinish[p] for p in pred[ext] if p in ffinish]
            if predecessor_finishes:
                start=max(start,max(predecessor_finishes)+timedelta(days=1))
        finish=start+timedelta(days=max(0,int(round(remaining))-1))
        fstart[ext]=start; ffinish[ext]=finish
        pf=_parse(a.planned_finish) or finish
        variance=(finish-pf).days
        critical=variance>0 or len(succ.get(ext,[]))>0 and any(
            (e.risk_days or 0)>0 for e in db.query(ScheduleExposureRecord).filter(
                ScheduleExposureRecord.source_activity_id==a.id
            ).all()
        )
        snap=ActivityForecastSnapshot(
            project_id=project_id,schedule_activity_id=a.id,data_date=today.isoformat(),
            planned_finish=pf.isoformat(),forecast_finish=finish.isoformat(),
            remaining_duration_days=remaining,forecast_variance_days=variance,
            confidence=conf,critical_candidate=bool(critical)
        )
        db.add(snap); snapshots.append(snap)

    planned_completion=max((_parse(a.planned_finish) or today) for a in acts)
    forecast_completion=max(ffinish.values())
    critical_count=sum(1 for s in snapshots if s.critical_candidate)
    avg_conf=sum(s.confidence for s in snapshots)/len(snapshots)
    proj=ProjectForecastSnapshot(
        project_id=project_id,data_date=today.isoformat(),
        planned_completion=planned_completion.isoformat(),
        forecast_completion=forecast_completion.isoformat(),
        variance_days=(forecast_completion-planned_completion).days,
        milestone_confidence=round(avg_conf,2),
        critical_activity_count=critical_count
    )
    db.add(proj); db.commit()
    return proj,snapshots
