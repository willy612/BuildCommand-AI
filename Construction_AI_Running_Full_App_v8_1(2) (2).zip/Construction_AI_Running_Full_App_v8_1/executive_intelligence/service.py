from db.models import (
    Project,PredictiveRiskSnapshot,ApprovedRecoveryPlan,
    ProductionIntelligenceSnapshot,MakeReadyAction,ExecutiveRiskSnapshot
)

def refresh_executive_snapshots(db,company_id):
    projects=db.query(Project).filter(Project.company_id==company_id).all()
    out=[]
    for p in projects:
        risks=db.query(PredictiveRiskSnapshot).filter(
            PredictiveRiskSnapshot.project_id==p.id
        ).order_by(PredictiveRiskSnapshot.created_at.desc()).all()
        latest={}
        for r in risks:latest.setdefault(r.schedule_activity_id,r)
        vals=list(latest.values())
        critical=sum(1 for r in vals if r.probability_band=="CRITICAL")
        high=sum(1 for r in vals if r.probability_band=="HIGH")
        recovery=db.query(ApprovedRecoveryPlan).filter(
            ApprovedRecoveryPlan.project_id==p.id,
            ApprovedRecoveryPlan.status=="ACTIVE"
        ).count()
        prod=db.query(ProductionIntelligenceSnapshot).filter(
            ProductionIntelligenceSnapshot.project_id==p.id
        ).order_by(ProductionIntelligenceSnapshot.created_at.desc()).all()
        lp={}
        for r in prod:lp.setdefault(r.schedule_activity_id,r)
        prod_risk=sum(1 for r in lp.values() if r.planned_quantity_per_day and r.pace_ratio<.85)
        make_ready=db.query(MakeReadyAction).filter(
            MakeReadyAction.project_id==p.id,
            MakeReadyAction.status=="OPEN"
        ).count()
        score=min(100,critical*20+high*10+recovery*4+prod_risk*5+min(make_ready,10)*2)
        explanation=(
            f"{critical} critical and {high} high predictive risks; "
            f"{recovery} active recovery plan(s); {prod_risk} production activity(ies) below 85% pace; "
            f"{make_ready} open make-ready action(s)."
        )
        row=ExecutiveRiskSnapshot(
            company_id=company_id,project_id=p.id,critical_risk_count=critical,
            high_risk_count=high,open_recovery_plan_count=recovery,
            production_at_risk_count=prod_risk,open_make_ready_count=make_ready,
            executive_score=score,explanation=explanation
        )
        db.add(row);out.append(row)
    db.commit()
    return sorted(out,key=lambda x:x.executive_score,reverse=True)
