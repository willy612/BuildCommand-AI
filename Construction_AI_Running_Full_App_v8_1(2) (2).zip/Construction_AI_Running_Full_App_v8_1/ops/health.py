from core.config import Settings

def health_report(db=None):
    report={"status":"ok","environment":Settings.ENV,"checks":{}}
    config_errors=Settings.validate()
    report["checks"]["config"]={"ok":not config_errors,"errors":config_errors}
    if db is not None:
        try:
            db.execute("SELECT 1")
            report["checks"]["database"]={"ok":True}
        except Exception as e:
            report["checks"]["database"]={"ok":False,"error":str(e)}
    if any(not x.get("ok",False) for x in report["checks"].values()):
        report["status"]="degraded"
    return report
