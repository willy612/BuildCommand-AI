from datetime import datetime
import hashlib

_memory_locks=set()

def idempotency_key(name,*parts):
    raw="|".join([name]+[str(p) for p in parts])
    return hashlib.sha256(raw.encode()).hexdigest()

def run_once(key,fn,*args,**kwargs):
    # Development-safe in-process guard. Replace with DB/Redis lock in multi-worker production.
    if key in _memory_locks:return {"status":"duplicate","key":key}
    _memory_locks.add(key)
    try:
        value=fn(*args,**kwargs)
        return {"status":"completed","key":key,"value":value,"completed_at":datetime.utcnow().isoformat()}
    except Exception:
        _memory_locks.discard(key)
        raise
