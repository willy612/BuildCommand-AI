from datetime import datetime,date
from db.models import MakeReadyAction,OutboundNotification,Subcontractor,SubcontractorContact

def prepare_followups(db,project_id):
    rows=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.status=="OPEN"
    ).all()
    created=[]
    today=date.today()
    for a in rows:
        try: due=datetime.strptime(a.required_by,"%Y-%m-%d").date()
        except Exception: continue
        overdue=(today-due).days
        if overdue<0: continue
        level=1 if overdue<=2 else 2 if overdue<=7 else 3
        if level<=a.escalation_level: continue
        recipient=""
        if a.responsible_type=="SUBCONTRACTOR" and a.responsible_id:
            c=db.query(SubcontractorContact).filter(
                SubcontractorContact.subcontractor_id==a.responsible_id,
                SubcontractorContact.active==True
            ).order_by(SubcontractorContact.primary_contact.desc()).first()
            recipient=c.email if c else ""
        subject=f"Make-ready action overdue: {a.title}"
        body=(
            f"{a.title}\n\nReason: {a.reason}\nRequired by: {a.required_by}\n"
            f"Escalation level: {level}\n\nPlease confirm resolution or report the constraint."
        )
        n=OutboundNotification(
            project_id=project_id,subcontractor_id=a.responsible_id if a.responsible_type=="SUBCONTRACTOR" else None,
            channel="EMAIL" if recipient else "IN_APP",recipient=recipient,
            subject=subject,body=body,status="DRAFT"
        )
        db.add(n)
        a.escalation_level=level
        a.last_followup_at=datetime.utcnow()
        created.append(n)
    db.commit()
    return created
