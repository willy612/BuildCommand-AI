from db.models import Project, ConstraintRecord, LookaheadCommitment, IngestionJob, ScheduleActivity

def company_portfolio(db,company_id):
    projects=db.query(Project).filter(Project.company_id==company_id).all()
    result=[]
    for p in projects:
        blockers=db.query(ConstraintRecord).filter(
            ConstraintRecord.project_id==p.id,
            ConstraintRecord.status=="OPEN",
            ConstraintRecord.blocking==True
        ).count()
        delayed=db.query(LookaheadCommitment).filter(
            LookaheadCommitment.project_id==p.id,
            LookaheadCommitment.status.in_(["DELAY_REPORTED","CANNOT_MEET_DATE","DECLINED"])
        ).count()
        no_response=db.query(LookaheadCommitment).filter(
            LookaheadCommitment.project_id==p.id,
            LookaheadCommitment.status=="PENDING"
        ).count()
        failed_ingestion=db.query(IngestionJob).filter(
            IngestionJob.project_id==p.id,IngestionJob.status=="FAILED"
        ).count()
        activities=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==p.id).count()
        risk_score=blockers*5+delayed*4+no_response*1+failed_ingestion*2
        result.append({
            "project_id":p.id,"name":p.name,"project_number":p.project_number,
            "jurisdiction":p.jurisdiction,"status":p.status,
            "blocking_constraints":blockers,"sub_delays":delayed,
            "pending_commitments":no_response,"failed_ingestion":failed_ingestion,
            "schedule_activities":activities,"portfolio_risk_score":risk_score
        })
    return sorted(result,key=lambda x:x["portfolio_risk_score"],reverse=True)
