import os
from brain.master_brain import find_task, format_task
from brain.plan_reader import search_chunks, format_sources

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None

SYSTEM_PROMPT = """
You are Construction AI, a superintendent-style construction assistant.

Use six coordinated sources:
1. Master Construction Brain
2. Permit/Jurisdiction Brain
3. Inspection & Testing Brain
4. Job Safety Brain
5. Project Plan/Document Brain
6. Project State + Schedule/Planning Brain

For project-specific questions, prioritize retrieved CURRENT or APPROVED project-document chunks.
Do not invent project-specific dimensions, elevations, materials, schedules, details, permits, or code requirements.
When sources are ambiguous or conflicting, state that and require human verification.
Cite the source sheet/page/section in the answer when available.
Approved project documents and applicable requirements control the work.
"""

def ask_construction_ai(question, project_context, project_state):
    task = find_task(question)
    brain_view = format_task(task, project_state)
    retrieved = search_chunks(project_state.get("knowledge_chunks", []), question, top_k=6)

    source_context = "\n\n".join(
        f"SOURCE: {c.get('source_ref')}\n{c.get('content')}" for c in retrieved
    ) or "No project-document text matched this question."

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or OpenAI is None:
        result = brain_view
        if retrieved:
            result += "\n\n### Project document matches\n"
            for c in retrieved:
                excerpt = c.get("content","").replace("\n"," ")[:500]
                result += f"- **{c.get('source_ref')}** — {excerpt}\n"
        return result

    client = OpenAI(api_key=api_key)
    response = client.responses.create(
        model=os.getenv("OPENAI_MODEL", "gpt-5.4-mini"),
        instructions=SYSTEM_PROMPT,
        input=f"""PROJECT CONTEXT:
{project_context}

PROJECT STATE:
{project_state}

USER QUESTION:
{question}

MASTER BRAIN:
{brain_view}

RETRIEVED PROJECT SOURCES:
{source_context}
"""
    )
    answer = response.output_text
    sources = format_sources(retrieved)
    if sources:
        answer += "\n\n### Sources used\n" + "\n".join(f"- {s}" for s in sources)
    return answer
