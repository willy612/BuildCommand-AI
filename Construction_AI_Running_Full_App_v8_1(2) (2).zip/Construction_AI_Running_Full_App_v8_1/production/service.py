from datetime import date
from db.models import ProductionRecord

def record_production(db,project_id,activity_id,work_date=None,subcontractor_id=None,
                      crew_size=0,regular_hours=0,overtime_hours=0,
                      quantity_installed=0,quantity_unit="",planned_quantity=0,notes=""):
    row=ProductionRecord(
        project_id=project_id,schedule_activity_id=activity_id,
        subcontractor_id=subcontractor_id,work_date=work_date or date.today().isoformat(),
        crew_size=int(crew_size or 0),regular_hours=float(regular_hours or 0),
        overtime_hours=float(overtime_hours or 0),quantity_installed=float(quantity_installed or 0),
        quantity_unit=quantity_unit,planned_quantity=float(planned_quantity or 0),notes=notes
    )
    db.add(row); db.commit(); db.refresh(row); return row

def activity_production_metrics(db,project_id,activity_id):
    rows=db.query(ProductionRecord).filter(
        ProductionRecord.project_id==project_id,
        ProductionRecord.schedule_activity_id==activity_id
    ).all()
    installed=sum(r.quantity_installed or 0 for r in rows)
    planned=sum(r.planned_quantity or 0 for r in rows)
    labor=sum((r.crew_size or 0)*(r.regular_hours or 0) for r in rows)
    productivity=(installed/labor) if labor>0 else None
    pace_ratio=(installed/planned) if planned>0 else None
    return {
        "days_reported":len(rows),"installed":installed,"planned":planned,
        "labor_hours":labor,"productivity":productivity,"pace_ratio":pace_ratio
    }
