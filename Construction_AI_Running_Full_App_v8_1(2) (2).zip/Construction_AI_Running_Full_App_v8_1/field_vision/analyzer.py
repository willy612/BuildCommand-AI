import os
from field_vision.service import create_proposal

def analyze_photo(db,photo,context=""):
    """
    Provider-neutral field vision entrypoint.

    v3.2 deliberately keeps external vision provider credentials/configuration out of core logic.
    In production, connect this function to the selected multimodal model/provider and require
    structured JSON output matching the proposal fields.

    Until configured, it creates a review item based on the superintendent caption/observation
    rather than pretending the image was analyzed.
    """
    configured=bool(os.getenv("FIELD_VISION_PROVIDER"))
    if not configured:
        text=(photo.observation or photo.caption or "").strip()
        if not text:
            return []
        return [create_proposal(
            db,photo.project_id,photo.id,"GENERAL",
            "Review field photo observation",
            text,
            "Superintendent review required before converting this observation into project action.",
            schedule_activity_id=photo.schedule_activity_id,
            confidence=0.50
        )]
    raise NotImplementedError("Configured field vision provider adapter has not been installed.")
