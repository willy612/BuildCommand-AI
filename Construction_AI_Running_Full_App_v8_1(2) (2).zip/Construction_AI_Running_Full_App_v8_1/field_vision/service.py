from db.models import FieldVisionProposal

SYSTEM_RULES = """
Analyze construction field imagery conservatively.
Do not claim hidden conditions, code compliance, structural adequacy, completed inspections,
or work quality that cannot be established from visible evidence.
Return proposed observations for human review, never final project truth.
Useful categories: PROGRESS, QUALITY, SAFETY, COORDINATION, PUNCH, DELIVERY, HOUSEKEEPING, GENERAL.
"""

def create_proposal(db,project_id,photo_record_id,observation_type,title,observation,
                    suggested_action="",schedule_activity_id=None,
                    suggested_percent_complete=None,confidence=0.0):
    row=FieldVisionProposal(
        project_id=project_id,photo_record_id=photo_record_id,
        schedule_activity_id=schedule_activity_id,
        observation_type=observation_type,title=title,observation=observation,
        suggested_action=suggested_action,
        suggested_percent_complete=suggested_percent_complete,
        confidence=float(confidence or 0),status="PENDING_REVIEW"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def approve_proposal(db,proposal_id):
    row=db.query(FieldVisionProposal).filter(FieldVisionProposal.id==proposal_id).first()
    if not row: return None
    row.status="APPROVED"
    db.commit(); db.refresh(row)
    return row

def reject_proposal(db,proposal_id):
    row=db.query(FieldVisionProposal).filter(FieldVisionProposal.id==proposal_id).first()
    if not row: return None
    row.status="REJECTED"
    db.commit(); db.refresh(row)
    return row
