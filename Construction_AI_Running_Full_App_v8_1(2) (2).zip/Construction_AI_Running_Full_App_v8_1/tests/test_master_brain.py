from brain.master_brain import find_task,evaluate
from brain.project_state import new_project_state,set_permit,add_test
def test_mat(): assert find_task('mat footing')['id']=='foundation.mat'
def test_storm_hold():
    s=new_project_state(); t=find_task('storm drainage'); assert evaluate(s,t)['status']=='HOLD'
def test_failed_test_holds():
    s=new_project_state(); t=find_task('storm drainage'); set_permit(s,t['id'],'APPROVED'); add_test(s,{'task_id':t['id'],'required':True,'result':'FAILED'}); assert evaluate(s,t)['status']=='HOLD'
