from communications.lookahead import draft_lookahead_email, parse_sub_response

def test_draft_contains_activity():
    d=draft_lookahead_email("Project A","ABC Electric","Underground Electrical","2026-09-08","2026-09-12","2026-09-01")
    assert "Underground Electrical" in d["body"]
    assert "confirm" in d["body"].lower()

def test_delay_response():
    r=parse_sub_response("We will be late by 4 days because the material delivery slipped.")
    assert r["response_type"]=="DELAY_REPORTED"
    assert r["proposed_delay_days"]==4

def test_confirmation_response():
    r=parse_sub_response("Confirmed. We will meet the scheduled start.")
    assert r["response_type"]=="CONFIRMED"
