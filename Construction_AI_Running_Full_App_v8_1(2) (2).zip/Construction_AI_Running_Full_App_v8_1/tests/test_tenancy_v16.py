from platform.tenancy import COMPANY_ROLES,PROJECT_ROLES

def test_company_roles():
    assert "operations_manager" in COMPANY_ROLES
    assert "project_executive" in COMPANY_ROLES

def test_project_roles():
    assert "superintendent" in PROJECT_ROLES
