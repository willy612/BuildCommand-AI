from brain.visual_plan_reader import visual_record_to_chunks
from brain.sheet_linker import extract_sheet_refs

def test_visual_chunks():
    record={
        "document_id":"d1","page_number":2,"sheet_number":"S2.1","discipline":"structural",
        "revision":"2","status":"CURRENT","source_ref":"Plans.pdf | page 2 | sheet S2.1",
        "visual_summary":"Foundation plan",
        "callouts":[{"label":"3/S5.2"}],
        "dimensions":[{"label":"24 in"}],
        "notes":["See structural notes"],
        "visual_elements":[{"type":"footing","label":"F1"}],
        "potential_conflicts_or_questions":[]
    }
    chunks=visual_record_to_chunks(record)
    assert len(chunks) >= 4
    assert any(c["source_type"]=="visual" for c in chunks)

def test_sheet_refs():
    refs=extract_sheet_refs("See detail 3/S5.2 and section A4.1")
    assert "S5.2" in refs
