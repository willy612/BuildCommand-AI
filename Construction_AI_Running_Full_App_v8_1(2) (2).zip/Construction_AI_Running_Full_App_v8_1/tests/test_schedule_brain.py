from brain.project_state import new_project_state
from brain.schedule_brain import evaluate_activity

def test_schedule_hold_when_permit_missing():
    state = new_project_state()
    activity = {
        "activity_id": "T1",
        "name": "Storm",
        "percent_complete": 0,
        "predecessors": [],
        "constraints": [],
        "required_permits": ["civil.storm"],
        "required_inspections": [],
        "required_tests": []
    }
    result = evaluate_activity(activity, state)
    assert result["status"] == "HOLD"

def test_schedule_ready_when_no_constraints():
    state = new_project_state()
    activity = {
        "activity_id": "T2",
        "name": "Planning",
        "percent_complete": 0,
        "predecessors": [],
        "constraints": [],
        "required_permits": [],
        "required_inspections": [],
        "required_tests": []
    }
    result = evaluate_activity(activity, state)
    assert result["status"] == "READY"
