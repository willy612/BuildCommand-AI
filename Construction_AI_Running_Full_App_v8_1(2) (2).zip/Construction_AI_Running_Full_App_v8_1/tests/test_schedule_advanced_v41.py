from schedule_advanced.importer import _norm

def test_norm():
    assert _norm(" Activity ID ")=="activity id"
