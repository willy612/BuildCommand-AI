from brain.plan_reader import guess_sheet_number, infer_discipline, split_into_chunks, search_chunks

def test_sheet_guess():
    text = "S2.1\nFOUNDATION PLAN\nGENERAL NOTES"
    assert guess_sheet_number(text) == "S2.1"

def test_discipline():
    assert infer_discipline("S2.1","FOUNDATION PLAN") == "structural"

def test_chunking():
    chunks = split_into_chunks("A " * 3000, max_chars=500, overlap=50)
    assert len(chunks) > 1

def test_search():
    chunks=[{"content":"FOOTING REINFORCEMENT #5 BARS","status":"CURRENT","source_ref":"S2.1"}]
    assert search_chunks(chunks,"footing reinforcement",1)[0]["source_ref"]=="S2.1"
