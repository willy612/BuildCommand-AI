from brain.auto_dependencies import generate_dependencies

def test_footing_dependencies():
    state={"documents":[{"document_id":"s1","document_type":"structural","status":"CURRENT"}]}
    tasks=[{"id":"foundation.footings","name":"Footings"}]
    g=generate_dependencies(state,tasks)
    assert any(x["task_id"]=="foundation.footings" for x in g["task_document_links"])
    assert "foundation.footings" in g["task_prerequisites"]
