from brain.master_brain import find_task

def test_gas():
    assert find_task("underground gas")["id"] == "civil.underground_gas"

def test_tilt():
    assert find_task("tilt panels")["id"] == "structural.tilt_panels"

def test_roof():
    assert find_task("roof waterproofing")["id"] == "envelope.roof_waterproofing"

def test_grid():
    assert find_task("grid ceiling")["id"] == "interiors.hard_lid_or_grid"

def test_tile():
    assert find_task("tile waterproofing")["id"] == "finishes.tile_waterproofing"
