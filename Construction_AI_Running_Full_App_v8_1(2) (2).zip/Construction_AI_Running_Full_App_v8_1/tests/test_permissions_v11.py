from auth.permissions import can

def test_superintendent_can_approve():
    assert can("superintendent","approve")

def test_viewer_cannot_write():
    assert not can("viewer","write")
