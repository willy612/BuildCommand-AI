from pathlib import Path
from imports.schedule_import import parse_schedule_csv

def test_schedule_parse(tmp_path):
    p=tmp_path/"schedule.csv"
    p.write_text("Activity ID,Activity Name,Start,Finish,Predecessors\\nA1,Footings,2026-01-01,2026-01-03,\\nA2,Stem Walls,2026-01-04,2026-01-06,A1\\n")
    rows=parse_schedule_csv(p)
    assert len(rows)==2
    assert rows[1]["predecessors"]==["A1"]
    assert "A2" in rows[0]["successors"]
