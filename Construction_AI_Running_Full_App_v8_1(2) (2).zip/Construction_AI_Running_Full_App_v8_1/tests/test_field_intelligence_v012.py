from brain.field_intelligence import fallback_parse, new_pending_update, approve_pending_update

def test_explicit_pass_proposes_inspection():
    parsed=fallback_parse("Underground plumbing passed inspection.")
    assert any(c["change_type"]=="inspection" and c["payload"]["result"]=="PASSED"
               for c in parsed["proposed_changes"])

def test_constraint_proposal():
    parsed=fallback_parse("Transformer pad is delayed because embeds are missing.")
    assert any(c["change_type"]=="constraint" for c in parsed["proposed_changes"])

def test_human_approval_required():
    parsed=fallback_parse("Footing inspection passed.")
    assert all(c["requires_human_approval"] for c in parsed["proposed_changes"])

def test_approve_commits_change():
    state={"pending_field_updates":[]}
    parsed=fallback_parse("Footing inspection passed.")
    update=new_pending_update("Footing inspection passed.",parsed)
    state["pending_field_updates"].append(update)
    assert approve_pending_update(state,update["id"],[0])
    assert len(state.get("inspections",[]))==1
