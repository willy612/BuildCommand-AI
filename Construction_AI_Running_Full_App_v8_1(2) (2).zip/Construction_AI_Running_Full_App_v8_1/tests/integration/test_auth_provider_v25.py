from auth_provider.provider import DevelopmentAuthProvider

def test_dev_auth():
    i=DevelopmentAuthProvider().verify("")
    assert i.company_id >= 1
