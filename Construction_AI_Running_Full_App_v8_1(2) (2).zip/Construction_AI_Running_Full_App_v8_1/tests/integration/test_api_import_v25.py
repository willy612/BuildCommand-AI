def test_api_import():
    import api.main
    assert api.main.app is not None
