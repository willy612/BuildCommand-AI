from brain.readiness_engine import evaluate_readiness

TASK={"id":"foundation.footings","name":"Footings"}

def base_state():
    return {
        "documents":[{"status":"CURRENT","filename":"S.pdf"}],
        "permits":{"foundation.footings":"VERIFIED"},
        "task_prerequisites":{"foundation.footings":{"Field prerequisites verified":True}},
        "safety_readiness":{"foundation.footings":True},
        "inspections":[],
        "tests":[],
        "rfis":[],
        "procurement_items":[],
        "schedule_activities":[]
    }

def test_missing_evidence_is_not_ready():
    result=evaluate_readiness(base_state(),TASK)
    assert result["status"]=="AT RISK"

def test_failed_inspection_holds():
    s=base_state()
    s["inspections"]=[{"task_id":"foundation.footings","required":True,"result":"FAILED"}]
    assert evaluate_readiness(s,TASK)["status"]=="HOLD"

def test_blocking_rfi_holds():
    s=base_state()
    s["rfis"]=[{"task_ids":["foundation.footings"],"blocking":True,"status":"OPEN"}]
    assert evaluate_readiness(s,TASK)["status"]=="HOLD"
