from field_execution.constraint_intelligence import classify_constraint

def test_rfi_delay():
    r=classify_constraint("We cannot start because RFI 32 is not approved and this may delay us 3 days.")
    assert r["blocking"] is True
    assert r["category"]=="RFI_DESIGN"
    assert r["delay_days"]==3

def test_material_delay():
    r=classify_constraint("Material delivery is delayed and we can't proceed.")
    assert r["blocking"] is True
    assert r["category"]=="MATERIAL"
