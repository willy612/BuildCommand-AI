from recovery_optimizer.service import DEFAULT_SCENARIOS

def test_scenarios_present():
    names={x[0] for x in DEFAULT_SCENARIOS}
    assert "ADD_CREW" in names
    assert "RESEQUENCE" in names
