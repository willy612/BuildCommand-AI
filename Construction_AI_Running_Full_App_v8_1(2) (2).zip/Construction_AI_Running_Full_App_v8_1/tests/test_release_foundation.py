from core.config import Settings
from ops.jobs import idempotency_key

def test_idempotency_key_stable():
    assert idempotency_key("risk",1,2)==idempotency_key("risk",1,2)

def test_human_approval_default():
    assert Settings.REQUIRE_HUMAN_APPROVAL is True
