from brain.closeout_warranty import closeout_status

def test_closeout_percent():
    s={"closeout_items":[
        {"required":True,"status":"COMPLETE"},
        {"required":True,"status":"OPEN"}
    ]}
    assert closeout_status(s)["percent_complete"]==50
