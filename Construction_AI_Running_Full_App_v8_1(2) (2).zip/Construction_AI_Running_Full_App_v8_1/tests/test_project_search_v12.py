from search.project_search import _terms

def test_terms():
    assert 'footing' in _terms('footing reinforcement S2.1')
