from make_ready.engine import LEAD_DAYS

def test_make_ready_lead_times():
    assert LEAD_DAYS["Submittals / procurement"] > LEAD_DAYS["Site conditions"]
    assert LEAD_DAYS["Subcontractor commitment"] >= 7
