from search.semantic_search import cosine

def test_cosine_identity():
    assert round(cosine([1,0],[1,0]),5)==1.0
