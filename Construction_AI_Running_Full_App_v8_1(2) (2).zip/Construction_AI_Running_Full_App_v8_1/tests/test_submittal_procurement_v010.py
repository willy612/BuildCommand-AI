from brain.submittal_procurement import calculate_required_dates, assess_item

def item():
    return {
        "required_on_site_date":"2026-10-15",
        "gc_review_days":5,
        "design_review_days":10,
        "resubmit_buffer_days":7,
        "fabrication_days":30,
        "shipping_days":5,
        "release_buffer_days":0,
        "submittal_status":"NOT_STARTED",
        "procurement_status":"NOT_RELEASED",
    }

def test_backward_dates():
    d=calculate_required_dates(item())
    assert d["required_on_site_date"]=="2026-10-15"
    assert d["ship_by_date"]=="2026-10-10"
    assert d["release_by_date"]=="2026-09-10"
    assert d["submit_by_date"]=="2026-08-19"

def test_late_submission_risk():
    result=assess_item(item(), today="2026-08-25")
    assert result["risk"]=="AT_RISK"

def test_missed_release_is_critical():
    x=item()
    x["submittal_status"]="APPROVED"
    result=assess_item(x, today="2026-09-15")
    assert result["risk"]=="CRITICAL"
