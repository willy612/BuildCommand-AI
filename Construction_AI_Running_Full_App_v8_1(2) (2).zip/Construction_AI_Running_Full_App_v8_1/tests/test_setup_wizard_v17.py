from setup_wizard.service import percent_complete
from types import SimpleNamespace

def test_percent():
    row=SimpleNamespace(
        company_info_complete=True,team_complete=True,jurisdiction_complete=True,
        documents_complete=False,schedule_complete=False,subcontractors_complete=False,
        requirements_complete=False
    )
    assert percent_complete(row)==43
