from brain.document_intake import intake_metadata, detect_revision
from brain.project_setup import startup_readiness
from brain.project_state import new_project_state

def test_document_classification():
    assert intake_metadata("Structural_Plans_Rev2.pdf")["document_type"] == "structural"

def test_revision_detection():
    assert detect_revision("Civil_Set_Rev3.pdf") == "3"

def test_readiness_missing_docs():
    state = new_project_state()
    state["jurisdiction"] = "Example City"
    result = startup_readiness(state)
    assert result["status"] == "INCOMPLETE"
