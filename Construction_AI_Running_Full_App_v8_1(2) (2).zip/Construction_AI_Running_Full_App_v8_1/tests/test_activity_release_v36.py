def test_release_status_terms():
    from activity_release.engine import READY,HOLD,AT_RISK
    assert READY=="READY"
    assert HOLD=="HOLD"
    assert AT_RISK=="AT RISK"
