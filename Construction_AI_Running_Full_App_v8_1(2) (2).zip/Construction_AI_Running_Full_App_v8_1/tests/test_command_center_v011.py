from brain.command_center import priority_actions, swppp_board

TASKS=[{"id":"foundation.footings","name":"Footings"}]

def test_failed_swppp_priority():
    state={
        "schedule_activities":[],
        "procurement_items":[],
        "rfis":[],
        "safety_readiness":{},
        "swppp_status":"FAILED",
        "inspections":[],
        "tests":[]
    }
    actions=priority_actions(state,TASKS)
    assert actions[0]["category"]=="SWPPP"
    assert actions[0]["priority"]==1

def test_blocking_rfi_priority():
    state={
        "schedule_activities":[],
        "procurement_items":[],
        "rfis":[{"id":"RFI-1","status":"OPEN","blocking":True,"subject":"Footing conflict"}],
        "safety_readiness":{},
        "swppp_status":"ACTIVE",
        "inspections":[],
        "tests":[]
    }
    actions=priority_actions(state,TASKS)
    assert actions[0]["category"]=="RFI"
    assert actions[0]["priority"]==1

def test_swppp_active_not_attention():
    assert swppp_board({"swppp_status":"ACTIVE"})["attention"] is False
