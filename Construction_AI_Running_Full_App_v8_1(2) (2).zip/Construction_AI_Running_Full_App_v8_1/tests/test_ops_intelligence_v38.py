from operations.settings import DEFAULTS

def test_lead_time_defaults():
    assert DEFAULTS["Submittals / procurement"] >= DEFAULTS["Permit / authorization"]
    assert DEFAULTS["Site conditions"] <= 3
