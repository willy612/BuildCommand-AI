from services.notification_service import build_notifications

def test_priority_one_becomes_critical():
    result=build_notifications([{"priority":1,"category":"Safety","title":"Excavation","reason":"JHA missing"}])
    assert result[0]["severity"]=="critical"
