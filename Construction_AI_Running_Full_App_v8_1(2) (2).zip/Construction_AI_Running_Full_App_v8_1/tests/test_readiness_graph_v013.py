from brain.readiness_graph import build_readiness_graph, evaluate_task_from_graph, downstream_impact

TASKS=[{"id":"foundation.footings","name":"Footings","phase":"Foundation"}]

def test_failed_inspection_blocks_task():
    state={
        "completed_tasks":[],
        "documents":[],
        "permits":{"foundation.footings":"VERIFIED"},
        "inspections":[{"task_id":"foundation.footings","inspection_type":"Rebar","required":True,"result":"FAILED"}],
        "tests":[],
        "safety_readiness":{"foundation.footings":True},
        "rfis":[],
        "constraints":[],
        "procurement_items":[],
        "task_prerequisites":{"foundation.footings":{"Compaction complete":True}},
        "schedule_activities":[]
    }
    graph=build_readiness_graph(state,TASKS)
    result=evaluate_task_from_graph(graph,"foundation.footings")
    assert result["status"]=="HOLD"
    assert any(x["type"]=="inspection" for x in result["blockers"])

def test_open_blocking_rfi_blocks_task():
    state={
        "completed_tasks":[], "documents":[], "permits":{},
        "inspections":[], "tests":[], "safety_readiness":{},
        "rfis":[{"id":"RFI-1","status":"OPEN","blocking":True,"subject":"Footing conflict","task_ids":["foundation.footings"]}],
        "constraints":[], "procurement_items":[], "task_prerequisites":{}, "schedule_activities":[]
    }
    graph=build_readiness_graph(state,TASKS)
    assert evaluate_task_from_graph(graph,"foundation.footings")["status"]=="HOLD"

def test_downstream_impact():
    graph={
        "nodes":[{"id":"a"},{"id":"b"},{"id":"c"}],
        "edges":[
            {"from":"a","to":"b","relation":"REQUIRES","blocking":True},
            {"from":"b","to":"c","relation":"PRECEDES","blocking":True}
        ]
    }
    impacts=downstream_impact(graph,"a")
    assert [x["node_id"] for x in impacts]==["b","c"]
