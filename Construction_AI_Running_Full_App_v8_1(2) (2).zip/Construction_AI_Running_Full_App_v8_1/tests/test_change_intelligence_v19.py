from change_intelligence.engine import compare_text,infer_change_flags

def test_compare_detects_change():
    r=compare_text("FOOTING F1 24 IN WIDE","FOOTING F1 30 IN WIDE")
    assert r["changed"] is True

def test_flags():
    change={"added_terms":["additional","beam"],"removed_terms":[],"diff_excerpt":"field verify"}
    f=infer_change_flags(change)
    assert f["possible_cost_change"] is True
    assert f["possible_rfi"] is True
