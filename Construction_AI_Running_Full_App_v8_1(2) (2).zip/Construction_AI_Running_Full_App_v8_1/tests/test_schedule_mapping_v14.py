from types import SimpleNamespace
from schedule.service import suggest_task_mapping

def test_mapping_finds_footings():
    a=SimpleNamespace(name="Form and reinforce concrete footings",phase="Foundation",trade="Concrete")
    tasks=[{"id":"foundation.footings","name":"Footings","phase":"Foundation","system":"Concrete","purpose":"Construct reinforced footings"}]
    assert suggest_task_mapping(a,tasks)[0]["task_id"]=="foundation.footings"
