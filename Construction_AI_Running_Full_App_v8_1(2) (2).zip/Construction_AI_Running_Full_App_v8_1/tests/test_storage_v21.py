from storage.backend import get_storage_backend

def test_storage_backend_exists():
    assert get_storage_backend() is not None
