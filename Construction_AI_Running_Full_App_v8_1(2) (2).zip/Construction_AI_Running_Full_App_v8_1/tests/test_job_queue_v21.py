from jobs.queue import get_job_queue

def test_inline_job():
    r=get_job_queue().submit(lambda x:x+1,1)
    assert r.status=="COMPLETE"
    assert r.result==2
