import re
from db.models import ConstraintProposal, ConstraintRecord

CATEGORY_PATTERNS=[
    ("RFI_DESIGN",["rfi","design","drawing","detail","clarification","approval"]),
    ("MATERIAL",["material","delivery","fabrication","shipment","equipment not here"]),
    ("MANPOWER",["manpower","crew","labor","short staffed"]),
    ("ACCESS",["access","blocked","cannot get","can't get","logistics"]),
    ("PREDECESSOR",["predecessor","not complete","not ready","waiting on","prior work"]),
    ("INSPECTION_TEST",["inspection","test","testing","inspector"]),
    ("PERMIT",["permit","city approval","ahj"]),
    ("SAFETY",["safety","jha","fall protection","competent person"]),
]

DELAY_TERMS=["delay","delayed","cannot start","can't start","cannot proceed","can't proceed",
             "waiting on","not approved","not ready","will be late","holding us"]

def classify_constraint(text):
    q=(text or "").lower()
    category="OTHER"
    for cat,terms in CATEGORY_PATTERNS:
        if any(t in q for t in terms):
            category=cat
            break
    blocking=any(t in q for t in DELAY_TERMS)
    days=0.0
    match=re.search(r"(\d+(?:\.\d+)?)\s*(?:day|days)",q)
    if match:
        try: days=float(match.group(1))
        except Exception: pass
    confidence=0.85 if blocking and category!="OTHER" else 0.65 if blocking else 0.45
    return {"category":category,"blocking":blocking,"delay_days":days,"confidence":confidence}

def propose_constraint(db, project_id, text, schedule_activity_id=None, subcontractor_id=None,
                       source_type="FIELD_UPDATE", source_id="", required_by=""):
    result=classify_constraint(text)
    if not result["blocking"]:
        return None
    proposal=ConstraintProposal(
        project_id=project_id,schedule_activity_id=schedule_activity_id,
        subcontractor_id=subcontractor_id,source_type=source_type,source_id=str(source_id or ""),
        category=result["category"],description=text,responsible_party="UNASSIGNED",
        required_by=required_by,
        schedule_exposure=(f"Potential {result['delay_days']:g}-day exposure." if result["delay_days"] else
                           "Potential impact to planned activity start/finish."),
        recommended_action="Assign an owner, verify root cause, and clear the constraint before the affected activity.",
        confidence=result["confidence"],status="PENDING_REVIEW"
    )
    db.add(proposal); db.commit(); db.refresh(proposal)
    return proposal

def approve_constraint(db, proposal_id, task_id=""):
    p=db.query(ConstraintProposal).filter(ConstraintProposal.id==proposal_id).first()
    if not p: return None
    row=ConstraintRecord(
        project_id=p.project_id,task_id=task_id,category=p.category,
        description=p.description,blocking=True,status="OPEN",
        responsible_party=p.responsible_party,due_date=p.required_by
    )
    db.add(row)
    p.status="APPROVED"
    db.commit(); db.refresh(row)
    return row
