from db.models import DailyFieldReport, FieldUpdate

def record_field_update(db,project_id,text,user_id=None,schedule_activity_id=None,
                        subcontractor_id=None,update_type="PROGRESS",percent_complete=None):
    row=FieldUpdate(
        project_id=project_id,user_id=user_id,schedule_activity_id=schedule_activity_id,
        subcontractor_id=subcontractor_id,update_type=update_type,text=text,
        percent_complete_proposal=percent_complete
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def get_or_create_daily_report(db,project_id,report_date,user_id=None):
    row=db.query(DailyFieldReport).filter(
        DailyFieldReport.project_id==project_id,
        DailyFieldReport.report_date==report_date
    ).first()
    if not row:
        row=DailyFieldReport(project_id=project_id,report_date=report_date,superintendent_user_id=user_id)
        db.add(row); db.commit(); db.refresh(row)
    return row

def update_daily_report(db,row,**kwargs):
    allowed={"weather","site_conditions","work_completed","delays","safety_notes",
             "inspection_notes","tomorrow_plan","status"}
    for k,v in kwargs.items():
        if k in allowed: setattr(row,k,v)
    db.commit(); db.refresh(row)
    return row
