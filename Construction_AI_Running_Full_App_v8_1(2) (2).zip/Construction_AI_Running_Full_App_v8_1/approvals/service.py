import json
from datetime import datetime
from db.models import ApprovalQueueItem

def create_approval(db, project_id, approval_type, title, summary="", payload=None,
                    requested_by_user_id=None, entity_type="", entity_id=""):
    row=ApprovalQueueItem(
        project_id=project_id,requested_by_user_id=requested_by_user_id,
        approval_type=approval_type,entity_type=entity_type,entity_id=str(entity_id or ""),
        title=title,summary=summary,payload_json=json.dumps(payload or {},default=str),
        status="PENDING"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def pending_approvals(db, project_id=None):
    q=db.query(ApprovalQueueItem).filter(ApprovalQueueItem.status=="PENDING")
    if project_id is not None:
        q=q.filter(ApprovalQueueItem.project_id==project_id)
    return q.order_by(ApprovalQueueItem.created_at.asc()).all()

def decide_approval(db, item_id, user_id, approve=True, notes=""):
    row=db.query(ApprovalQueueItem).filter(ApprovalQueueItem.id==item_id).first()
    if not row: return False
    row.status="APPROVED" if approve else "REJECTED"
    row.decided_by_user_id=user_id
    row.decision_notes=notes
    row.decided_at=datetime.utcnow()
    db.commit()
    return True
