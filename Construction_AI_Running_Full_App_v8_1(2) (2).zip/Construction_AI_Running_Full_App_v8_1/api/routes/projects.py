from fastapi import APIRouter, Depends
from db.session import SessionLocal
from security.dependencies import auth_context
from security.scoped_queries import scoped_project, scoped_documents, scoped_schedule

router=APIRouter(prefix="/v2/projects",tags=["projects"])

@router.get("/{project_id}")
def get_project(project_id:int,ctx=Depends(auth_context)):
    db=SessionLocal()
    try:
        p=scoped_project(db,ctx,project_id)
        return {
            "id":p.id,"name":p.name,"project_number":p.project_number,
            "jurisdiction":p.jurisdiction,"status":p.status
        }
    finally:
        db.close()

@router.get("/{project_id}/documents")
def get_documents(project_id:int,ctx=Depends(auth_context)):
    db=SessionLocal()
    try:
        rows=scoped_documents(db,ctx,project_id).all()
        return [{"id":r.id,"filename":r.filename,"status":r.status,"revision":r.revision} for r in rows]
    finally:
        db.close()

@router.get("/{project_id}/schedule")
def get_schedule(project_id:int,ctx=Depends(auth_context)):
    db=SessionLocal()
    try:
        rows=scoped_schedule(db,ctx,project_id).all()
        return [{"id":r.id,"external_id":r.external_id,"name":r.name,"status":r.status} for r in rows]
    finally:
        db.close()
