from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
from db.session import init_db,SessionLocal
from db.models import Project,ChangeEvent,ScheduleActivity
from portfolio.dashboard import company_portfolio
from schedule_impact.engine import create_schedule_impact
from cost.change_service import create_cost_change
from security.auth import AuthContext
from security.tenant_guard import require_project_access

from api.routes.projects import router as projects_router

app=FastAPI(title="Construction AI API",version="2.5")
app.include_router(projects_router)
init_db()

class CostChangeCreate(BaseModel):
    project_id:int
    change_event_id:int|None=None
    title:str
    description:str=""
    responsible_party:str=""
    estimated_cost:float=0.0

class ScheduleImpactCreate(BaseModel):
    project_id:int
    change_event_id:int|None=None
    source_activity_id:int
    exposure_days:float=0.0

@app.get("/health")
def health():
    return {"status":"ok","version":"2.0"}

@app.get("/companies/{company_id}/portfolio")
def portfolio(company_id:int):
    db=SessionLocal()
    try:
        return company_portfolio(db,company_id)
    finally:
        db.close()

@app.get("/projects/{project_id}")
def project(project_id:int):
    db=SessionLocal()
    try:
        row=db.query(Project).filter(Project.id==project_id).first()
        if not row: raise HTTPException(404,"Project not found")
        return {
            "id":row.id,"name":row.name,"project_number":row.project_number,
            "jurisdiction":row.jurisdiction,"status":row.status
        }
    finally:
        db.close()

@app.post("/cost-changes")
def post_cost_change(payload:CostChangeCreate):
    db=SessionLocal()
    try:
        row=create_cost_change(db,**payload.model_dump())
        return {"id":row.id,"status":row.status}
    finally:
        db.close()

@app.post("/schedule-impacts")
def post_schedule_impact(payload:ScheduleImpactCreate):
    db=SessionLocal()
    try:
        row,downstream=create_schedule_impact(db,**payload.model_dump())
        return {"id":row.id,"status":row.status,"downstream":downstream}
    finally:
        db.close()


# NOTE: Prototype header-based auth adapter.
# Replace with OIDC/JWT dependency in deployment.
def demo_auth_context(user_id:int=1,company_id:int=1,role:str="owner_admin"):
    return AuthContext(user_id=user_id,company_id=company_id,role=role)
