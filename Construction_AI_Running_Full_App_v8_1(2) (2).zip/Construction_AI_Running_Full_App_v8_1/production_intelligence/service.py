from collections import defaultdict
from db.models import (
    ProductionRecord,ProductionIntelligenceSnapshot,CompanyProductionBenchmark,
    ScheduleActivity,CompanyLearningSignal
)

def _safe(a,b):
    return float(a or 0)/float(b) if b else 0.0

def build_activity_production_snapshot(db,project_id,activity_id):
    a=db.query(ScheduleActivity).filter(ScheduleActivity.id==activity_id).first()
    if not a:return None
    rows=db.query(ProductionRecord).filter(
        ProductionRecord.project_id==project_id,
        ProductionRecord.schedule_activity_id==activity_id
    ).order_by(ProductionRecord.work_date.asc()).all()
    if not rows:return None

    qty=sum(float(r.quantity_installed or 0) for r in rows)
    planned=sum(float(r.planned_quantity or 0) for r in rows)
    labor=sum(float(r.labor_hours or 0) for r in rows)
    crew_vals=[float(r.crew_size or 0) for r in rows if (r.crew_size or 0)>0]
    avg_crew=sum(crew_vals)/len(crew_vals) if crew_vals else 0.0
    days=len({r.work_date for r in rows if r.work_date}) or len(rows)
    qpd=_safe(qty,days)
    planned_qpd=_safe(planned,days)
    qplh=_safe(qty,labor)
    pace=_safe(qpd,planned_qpd) if planned_qpd else 0.0

    recent=rows[-3:]
    prior=rows[-6:-3]
    recent_rate=_safe(sum(float(r.quantity_installed or 0) for r in recent),len(recent))
    prior_rate=_safe(sum(float(r.quantity_installed or 0) for r in prior),len(prior))
    if len(recent)>=2 and prior:
        if recent_rate>prior_rate*1.1:trend="IMPROVING"
        elif recent_rate<prior_rate*0.9:trend="FADING"
        else:trend="STABLE"
    else:trend="INSUFFICIENT_DATA"

    remaining_qty=max(0,float(getattr(a,"planned_quantity",0) or 0)-qty)
    projected=_safe(remaining_qty,qpd) if qpd else 0.0
    explanation=(
        f"{qty:.1f} installed over {days} observation day(s); "
        f"{qpd:.1f} {getattr(a,'quantity_unit','units') or 'units'}/day; "
        f"{qplh:.3f} per labor-hour; average crew {avg_crew:.1f}; "
        f"pace ratio {pace:.0%} vs recorded daily plan; trend {trend}."
    )
    row=ProductionIntelligenceSnapshot(
        project_id=project_id,schedule_activity_id=activity_id,
        subcontractor_id=(rows[-1].subcontractor_id if rows else None),
        trade=getattr(a,"trade","") or "",activity_type=getattr(a,"phase","") or a.name,
        quantity_unit=getattr(a,"quantity_unit","") or "",
        observation_days=days,total_quantity=qty,total_labor_hours=labor,
        average_crew=avg_crew,quantity_per_day=qpd,quantity_per_labor_hour=qplh,
        planned_quantity_per_day=planned_qpd,pace_ratio=pace,
        projected_remaining_days=projected,trend=trend,explanation=explanation
    )
    db.add(row);db.commit();db.refresh(row);return row

def refresh_project_production(db,project_id):
    ids=[x[0] for x in db.query(ProductionRecord.schedule_activity_id).filter(
        ProductionRecord.project_id==project_id,
        ProductionRecord.schedule_activity_id!=None
    ).distinct().all()]
    out=[]
    for aid in ids:
        r=build_activity_production_snapshot(db,project_id,aid)
        if r:out.append(r)
    return out

def refresh_company_benchmarks(db,company_id):
    project_ids=[p.id for p in db.query(__import__("db.models",fromlist=["Project"]).Project).filter(
        __import__("db.models",fromlist=["Project"]).Project.company_id==company_id
    ).all()]
    rows=db.query(ProductionIntelligenceSnapshot).filter(
        ProductionIntelligenceSnapshot.project_id.in_(project_ids)
    ).all() if project_ids else []
    latest={}
    for r in sorted(rows,key=lambda x:x.created_at,reverse=True):
        latest.setdefault((r.project_id,r.schedule_activity_id),r)

    groups=defaultdict(list)
    for r in latest.values():
        groups[(r.trade or "",r.activity_type or "",r.quantity_unit or "")].append(r)

    result=[]
    for (trade,atype,unit),vals in groups.items():
        n=len(vals)
        avg_qpd=sum(v.quantity_per_day or 0 for v in vals)/n
        avg_qplh=sum(v.quantity_per_labor_hour or 0 for v in vals)/n
        avg_crew=sum(v.average_crew or 0 for v in vals)/n
        conf=min(.95,.3+n*.1)
        row=db.query(CompanyProductionBenchmark).filter(
            CompanyProductionBenchmark.company_id==company_id,
            CompanyProductionBenchmark.trade==trade,
            CompanyProductionBenchmark.activity_type==atype,
            CompanyProductionBenchmark.quantity_unit==unit
        ).first()
        if not row:
            row=CompanyProductionBenchmark(company_id=company_id,trade=trade,activity_type=atype,quantity_unit=unit)
            db.add(row)
        row.sample_count=n;row.average_quantity_per_day=avg_qpd
        row.average_quantity_per_labor_hour=avg_qplh;row.average_crew=avg_crew
        row.confidence=conf;result.append(row)
    db.commit();return result

def capture_production_learning(db,company_id,project_id):
    rows=db.query(ProductionIntelligenceSnapshot).filter(
        ProductionIntelligenceSnapshot.project_id==project_id
    ).all()
    latest={}
    for r in sorted(rows,key=lambda x:x.created_at,reverse=True):
        latest.setdefault(r.schedule_activity_id,r)
    created=0
    for r in latest.values():
        key=f"{r.trade}|{r.activity_type}|{r.quantity_unit}|activity:{r.schedule_activity_id}"
        exists=db.query(CompanyLearningSignal).filter(
            CompanyLearningSignal.company_id==company_id,
            CompanyLearningSignal.project_id==project_id,
            CompanyLearningSignal.signal_type=="PRODUCTION_RATE",
            CompanyLearningSignal.context_key==key
        ).first()
        if exists:continue
        db.add(CompanyLearningSignal(
            company_id=company_id,project_id=project_id,
            signal_type="PRODUCTION_RATE",category=r.trade or "General",
            context_key=key,numeric_value=r.quantity_per_day,unit=f"{r.quantity_unit}/day",
            outcome=r.trend,evidence=r.explanation,
            confidence=min(.9,.4+r.observation_days*.05)
        ));created+=1
    db.commit();return created
