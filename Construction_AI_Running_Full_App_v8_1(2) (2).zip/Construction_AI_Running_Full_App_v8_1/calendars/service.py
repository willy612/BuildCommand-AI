import json
from datetime import datetime,timedelta
from db.models import ProjectCalendar,ProjectCalendarHoliday

DEFAULT_WEEK={0:True,1:True,2:True,3:True,4:True,5:False,6:False}

def get_or_create_default_calendar(db,project_id):
    row=db.query(ProjectCalendar).filter(
        ProjectCalendar.project_id==project_id,
        ProjectCalendar.name=="Default"
    ).first()
    if row:return row
    row=ProjectCalendar(project_id=project_id,name="Default",workweek_json=json.dumps(DEFAULT_WEEK),hours_per_day=8)
    db.add(row);db.commit();db.refresh(row);return row

def calendar_config(db,calendar_id):
    c=db.query(ProjectCalendar).filter(ProjectCalendar.id==calendar_id).first()
    if not c:return None
    try:week={int(k):bool(v) for k,v in json.loads(c.workweek_json or "{}").items()}
    except:week=DEFAULT_WEEK
    holidays={h.holiday_date for h in db.query(ProjectCalendarHoliday).filter(
        ProjectCalendarHoliday.calendar_id==calendar_id
    ).all()}
    return {"calendar":c,"week":week or DEFAULT_WEEK,"holidays":holidays}

def is_workday(d,config):
    return bool(config["week"].get(d.weekday(),False)) and d.isoformat() not in config["holidays"]

def add_workdays(start,days,config):
    d=start
    remaining=abs(int(round(days)))
    step=1 if days>=0 else -1
    while remaining:
        d+=timedelta(days=step)
        if is_workday(d,config):remaining-=1
    return d
