import json
from db.models import AuditLog

def log_action(db, action, project_id=None, user_id=None, entity_type="", entity_id="", payload=None):
    row = AuditLog(
        project_id=project_id,
        user_id=user_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id or ""),
        payload_json=json.dumps(payload or {}, default=str)
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row
