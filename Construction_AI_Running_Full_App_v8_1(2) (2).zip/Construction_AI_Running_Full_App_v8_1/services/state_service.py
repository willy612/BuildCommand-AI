from db.models import (
    TaskState, PermitRecord, InspectionRecord, TestRecord,
    ProcurementItem, RFIRecord, ConstraintRecord,
    Document, DocumentPage, KnowledgeChunk, ScheduleActivity, LookaheadCommitment
)

def load_project_state(db, project_id):
    state = {
        "completed_tasks": [],
        "permits": {},
        "inspections": [],
        "tests": [],
        "procurement_items": [],
        "rfis": [],
        "constraints": [],
        "safety_readiness": {},
        "task_prerequisites": {},
        "schedule_activities": [],
        "documents": [],
        "plan_pages": [],
        "knowledge_chunks": []
    }

    task_rows = db.query(TaskState).filter(TaskState.project_id == project_id).all()
    state["completed_tasks"] = [r.task_id for r in task_rows if r.status == "COMPLETE"]

    for r in db.query(PermitRecord).filter(PermitRecord.project_id == project_id).all():
        state["permits"][r.task_id] = r.status

    state["inspections"] = [{
        "id":r.id,"task_id":r.task_id,"inspection_type":r.inspection_type,
        "authority_or_agency":r.authority_or_agency,"required":r.required,
        "scheduled_date":r.scheduled_date,"result":r.result,
        "report_number":r.report_number,"notes":r.notes
    } for r in db.query(InspectionRecord).filter(InspectionRecord.project_id == project_id).all()]

    state["tests"] = [{
        "id":r.id,"task_id":r.task_id,"test_type":r.test_type,
        "testing_agency":r.testing_agency,"required":r.required,
        "scheduled_date":r.scheduled_date,"result":r.result,
        "report_number":r.report_number,"notes":r.notes
    } for r in db.query(TestRecord).filter(TestRecord.project_id == project_id).all()]

    state["procurement_items"] = [{
        "id":r.id,"name":r.name,"task_ids":[r.task_id] if r.task_id else [],
        "required":True,"spec_section":r.spec_section,"trade":r.trade,
        "responsible_company":r.responsible_company,
        "submittal_status":r.submittal_status,
        "procurement_status":r.procurement_status,
        "required_on_site_date":r.required_on_site_date,
        "fabrication_days":r.fabrication_days,
        "shipping_days":r.shipping_days,
        "gc_review_days":r.gc_review_days,
        "design_review_days":r.design_review_days,
        "resubmit_buffer_days":r.resubmit_buffer_days,
        "notes":r.notes
    } for r in db.query(ProcurementItem).filter(ProcurementItem.project_id == project_id).all()]

    state["rfis"] = [{
        "id":r.rfi_number or str(r.id),
        "subject":r.subject,"status":r.status,"blocking":r.blocking,
        "task_ids":[r.task_id] if r.task_id else [],"notes":r.notes
    } for r in db.query(RFIRecord).filter(RFIRecord.project_id == project_id).all()]

    state["constraints"] = [{
        "id":r.id,"task_id":r.task_id,"category":r.category,
        "description":r.description,"blocking":r.blocking,"status":r.status,
        "responsible_party":r.responsible_party,"due_date":r.due_date
    } for r in db.query(ConstraintRecord).filter(ConstraintRecord.project_id == project_id).all()]

    state["documents"] = [{
        "document_id":str(r.id),
        "filename":r.filename,"document_type":r.document_type,
        "discipline":r.discipline,"sheet_or_section":r.sheet_or_section,
        "title":r.title,"revision":r.revision,"status":r.status,
        "storage_path":r.storage_path
    } for r in db.query(Document).filter(Document.project_id == project_id).all()]

    state["plan_pages"] = [{
        "document_id":str(r.document_id),
        "page_number":r.page_number,"sheet_number":r.sheet_number,
        "sheet_title":r.sheet_title,"discipline":r.discipline,
        "source_ref":r.source_ref,"text_excerpt":r.text_excerpt
    } for r in db.query(DocumentPage)
        .join(Document, DocumentPage.document_id == Document.id)
        .filter(Document.project_id == project_id).all()]


    state["schedule_activities"] = [{
        "activity_id":r.external_id,"name":r.name,
        "planned_start":r.planned_start,"planned_finish":r.planned_finish,
        "percent_complete":r.percent_complete,"phase":r.phase,"trade":r.trade,
        "task_id":r.mapped_task_id,"status":r.status
    } for r in db.query(ScheduleActivity).filter(ScheduleActivity.project_id == project_id).all()]


    state["subcontractor_commitments"] = [{
        "id":r.id,
        "activity_id":r.schedule_activity_id,
        "subcontractor_id":r.subcontractor_id,
        "requested_start":r.requested_start,
        "requested_finish":r.requested_finish,
        "response_due":r.response_due,
        "status":r.status,
        "manpower_commitment":r.manpower_commitment,
        "material_status":r.material_status,
        "equipment_status":r.equipment_status,
        "delay_reason":r.delay_reason,
        "response_text":r.response_text,
        "superintendent_review_status":r.superintendent_review_status
    } for r in db.query(LookaheadCommitment).filter(LookaheadCommitment.project_id == project_id).all()]

    state["knowledge_chunks"] = [{
        "document_id":str(r.document_id),
        "page_number":r.page_number,"sheet_number":r.sheet_number,
        "discipline":r.discipline,"section":r.section,
        "source_type":r.source_type,"source_ref":r.source_ref,
        "content":r.content,"status":r.status
    } for r in db.query(KnowledgeChunk).filter(KnowledgeChunk.project_id == project_id).all()]

    return state
