def build_notifications(command_actions):
    notifications=[]
    for a in command_actions:
        if a.get("priority") == 1:
            notifications.append({
                "severity":"critical",
                "title":f"{a.get('category')}: {a.get('title')}",
                "message":a.get("reason","")
            })
        elif a.get("priority") == 2:
            notifications.append({
                "severity":"warning",
                "title":f"{a.get('category')}: {a.get('title')}",
                "message":a.get("reason","")
            })
    return notifications
