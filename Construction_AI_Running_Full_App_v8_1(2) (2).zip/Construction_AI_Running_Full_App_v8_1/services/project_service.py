from db.models import Project

def create_project(db, **fields):
    project = Project(**fields)
    db.add(project)
    db.commit()
    db.refresh(project)
    return project

def list_projects(db):
    return db.query(Project).order_by(Project.created_at.desc()).all()

def get_project(db, project_id):
    return db.query(Project).filter(Project.id == project_id).first()
