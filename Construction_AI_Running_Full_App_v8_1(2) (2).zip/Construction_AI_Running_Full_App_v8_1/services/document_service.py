import hashlib
import shutil
from pathlib import Path

from config.settings import FILE_STORAGE_DIR
from db.models import Document

def _hash_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def store_document(db, project_id, source_path, filename, **metadata):
    project_dir = FILE_STORAGE_DIR / str(project_id)
    project_dir.mkdir(parents=True, exist_ok=True)

    dest = project_dir / filename
    counter = 1
    while dest.exists():
        dest = project_dir / f"{dest.stem}_{counter}{dest.suffix}"
        counter += 1

    shutil.copy2(source_path, dest)
    row = Document(
        project_id=project_id,
        filename=dest.name,
        storage_path=str(dest),
        source_hash=_hash_file(dest),
        **metadata
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row

def list_documents(db, project_id):
    return db.query(Document).filter(Document.project_id == project_id).all()
