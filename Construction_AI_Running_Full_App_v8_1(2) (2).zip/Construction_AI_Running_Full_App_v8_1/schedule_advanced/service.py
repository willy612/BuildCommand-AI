from db.models import (
    ScheduleActivity,ScheduleRelationship,
    ScheduleActivityAdvanced,ScheduleRelationshipAdvanced
)

def persist_rich_schedule(db,project_id,activities,relationships):
    by_ext={a.external_id:a for a in db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()}
    for item in activities:
        row=by_ext.get(item["external_id"])
        if not row:
            row=ScheduleActivity(
                project_id=project_id,external_id=item["external_id"],name=item["name"],
                planned_start=item["planned_start"],planned_finish=item["planned_finish"],
                percent_complete=item["percent_complete"],status="NOT_STARTED"
            )
            db.add(row); db.commit(); db.refresh(row); by_ext[row.external_id]=row
        else:
            row.name=item["name"]; row.planned_start=item["planned_start"]; row.planned_finish=item["planned_finish"]
            row.percent_complete=item["percent_complete"]
            db.commit()
        adv=db.query(ScheduleActivityAdvanced).filter(ScheduleActivityAdvanced.schedule_activity_id==row.id).first()
        if not adv:
            adv=ScheduleActivityAdvanced(schedule_activity_id=row.id)
            db.add(adv)
        for k,v in item["advanced"].items(): setattr(adv,k,v)
    db.commit()

    db.query(ScheduleRelationshipAdvanced).delete()
    db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).delete()
    db.commit()
    for r in relationships:
        base=ScheduleRelationship(
            project_id=project_id,predecessor_external_id=r["pred"],
            successor_external_id=r["succ"],relationship_type=r["type"],lag_days=r["lag"]
        )
        db.add(base); db.commit(); db.refresh(base)
        db.add(ScheduleRelationshipAdvanced(
            relationship_id=base.id,relationship_type=r["type"],lag_days=r["lag"]
        ))
    db.commit()
