from datetime import datetime,date
from db.models import ScheduleActivity,ScheduleActivityAdvanced

def _parse(v):
    if not v:return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try:return datetime.strptime(str(v),fmt).date()
        except:pass
    return None

def schedule_health(db,project_id):
    rows=db.query(ScheduleActivity,ScheduleActivityAdvanced).join(
        ScheduleActivityAdvanced,ScheduleActivityAdvanced.schedule_activity_id==ScheduleActivity.id,
        isouter=True
    ).filter(ScheduleActivity.project_id==project_id).all()
    result=[]
    for a,adv in rows:
        tf=adv.total_float_days if adv else 0.0
        baseline_finish=_parse(adv.baseline_finish) if adv else None
        planned_finish=_parse(a.planned_finish)
        baseline_variance=(planned_finish-baseline_finish).days if baseline_finish and planned_finish else 0
        critical=tf<=0
        near_critical=0<tf<=10
        result.append({
            "activity_id":a.id,"external_id":a.external_id,"name":a.name,
            "total_float":tf,"free_float":adv.free_float_days if adv else 0.0,
            "baseline_variance_days":baseline_variance,
            "critical":critical,"near_critical":near_critical,
            "data_date":adv.data_date if adv else ""
        })
    return result
