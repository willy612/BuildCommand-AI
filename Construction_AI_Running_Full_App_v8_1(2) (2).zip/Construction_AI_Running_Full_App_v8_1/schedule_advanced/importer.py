import csv
from pathlib import Path

def _norm(v): return str(v or "").strip().lower()

ALIASES={
    "activity_id":["activity id","activity_id","id"],
    "name":["activity name","name","activity"],
    "start":["start","planned start","start date"],
    "finish":["finish","planned finish","finish date"],
    "baseline_start":["baseline start","bl start"],
    "baseline_finish":["baseline finish","bl finish"],
    "data_date":["data date","status date"],
    "total_float":["total float","tf"],
    "free_float":["free float","ff"],
    "actual_start":["actual start"],
    "actual_finish":["actual finish"],
    "remaining_duration":["remaining duration","remaining dur"],
    "calendar":["calendar","calendar name"],
    "constraint_type":["constraint type"],
    "constraint_date":["constraint date"],
    "percent_complete":["percent complete","% complete"],
    "predecessors":["predecessors","predecessor"],
    "relationship_types":["relationship types","relationship type"],
    "lags":["lags","lag"],
}

def _find(headers,aliases):
    for h in headers:
        if _norm(h) in aliases: return h
    return None

def parse_rich_schedule_csv(path):
    path=Path(path)
    with path.open("r",encoding="utf-8-sig",newline="") as f:
        reader=csv.DictReader(f)
        headers=reader.fieldnames or []
        h={k:_find(headers,v) for k,v in ALIASES.items()}
        activities=[]
        relationships=[]
        for raw in reader:
            aid=str(raw.get(h["activity_id"],"")).strip()
            name=str(raw.get(h["name"],"")).strip()
            if not aid or not name: continue
            def num(key,default=0.0):
                try:return float(str(raw.get(h[key],"")).replace("%","").strip() or default)
                except:return default
            activities.append({
                "external_id":aid,"name":name,
                "planned_start":str(raw.get(h["start"],"")).strip(),
                "planned_finish":str(raw.get(h["finish"],"")).strip(),
                "percent_complete":num("percent_complete"),
                "advanced":{
                    "baseline_start":str(raw.get(h["baseline_start"],"")).strip(),
                    "baseline_finish":str(raw.get(h["baseline_finish"],"")).strip(),
                    "data_date":str(raw.get(h["data_date"],"")).strip(),
                    "total_float_days":num("total_float"),
                    "free_float_days":num("free_float"),
                    "actual_start":str(raw.get(h["actual_start"],"")).strip(),
                    "actual_finish":str(raw.get(h["actual_finish"],"")).strip(),
                    "remaining_duration_days":num("remaining_duration"),
                    "calendar_name":str(raw.get(h["calendar"],"")).strip(),
                    "constraint_type":str(raw.get(h["constraint_type"],"")).strip(),
                    "constraint_date":str(raw.get(h["constraint_date"],"")).strip(),
                }
            })
            preds=[x.strip() for x in str(raw.get(h["predecessors"],"")).replace(";",",").split(",") if x.strip()]
            types=[x.strip().upper() for x in str(raw.get(h["relationship_types"],"")).replace(";",",").split(",") if x.strip()]
            lags=[x.strip() for x in str(raw.get(h["lags"],"")).replace(";",",").split(",") if x.strip()]
            for i,p in enumerate(preds):
                rel=types[i] if i<len(types) else "FS"
                try:lag=float(lags[i]) if i<len(lags) else 0.0
                except:lag=0.0
                relationships.append({"pred":p,"succ":aid,"type":rel,"lag":lag})
        return activities,relationships
