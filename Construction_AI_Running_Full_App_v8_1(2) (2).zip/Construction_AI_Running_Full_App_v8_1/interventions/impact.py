from collections import deque
from db.models import ScheduleActivity,ScheduleRelationship

def downstream_impact(db,project_id,activity_id,max_depth=4):
    source=db.query(ScheduleActivity).filter(ScheduleActivity.id==activity_id).first()
    if not source:return []
    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    succ={}
    for r in rels:succ.setdefault(r.predecessor_external_id,[]).append(r.successor_external_id)
    by_ext={a.external_id:a for a in db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()}
    q=deque([(source.external_id,0)]);seen={source.external_id};out=[]
    while q:
        ext,depth=q.popleft()
        if depth>=max_depth:continue
        for nxt in succ.get(ext,[]):
            if nxt in seen:continue
            seen.add(nxt);a=by_ext.get(nxt)
            if a:
                out.append({"activity_id":a.id,"external_id":a.external_id,"name":a.name,"depth":depth+1})
            q.append((nxt,depth+1))
    return out
