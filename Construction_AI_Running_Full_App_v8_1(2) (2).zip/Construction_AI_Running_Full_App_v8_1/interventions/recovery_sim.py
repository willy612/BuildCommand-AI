from db.models import (
    ScheduleActivity,ScheduleActivityAdvanced,ProjectForecastSnapshot,RecoverySimulation
)

FACTORS={"CREW_INCREASE":0.82,"OVERTIME":0.88,"RESEQUENCE":0.78,"CONSTRAINT_CLEARANCE":0.92}

def simulate_recovery(db,project_id,activity_id,scenario_type):
    a=db.query(ScheduleActivity).filter(ScheduleActivity.id==activity_id).first()
    if not a:return None
    adv=db.query(ScheduleActivityAdvanced).filter(ScheduleActivityAdvanced.schedule_activity_id==activity_id).first()
    original=float(adv.remaining_duration_days if adv else 0) or 0
    factor=FACTORS.get(scenario_type,0.90)
    simulated=round(max(0,original*factor),1)
    recovered=round(max(0,original-simulated),1)
    latest=db.query(ProjectForecastSnapshot).filter(
        ProjectForecastSnapshot.project_id==project_id
    ).order_by(ProjectForecastSnapshot.created_at.desc()).first()
    original_finish=latest.forecast_completion if latest else ""
    # Screening simulation: project-finish benefit is bounded by activity duration gain.
    simulated_finish=original_finish
    row=RecoverySimulation(
        project_id=project_id,schedule_activity_id=activity_id,scenario_type=scenario_type,
        original_remaining_days=original,simulated_remaining_days=simulated,
        original_project_finish=original_finish,simulated_project_finish=simulated_finish,
        modeled_days_recovered=recovered,confidence=0.45,
        assumptions="Screening model only. Benefit applies only if the activity is driving and the recovery is constructible. Re-run authoritative CPM before committing."
    )
    db.add(row);db.commit();db.refresh(row);return row
