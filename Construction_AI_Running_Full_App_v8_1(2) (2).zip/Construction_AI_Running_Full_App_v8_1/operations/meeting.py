from db.models import MakeReadyAction,ScheduleActivity

def weekly_make_ready_rows(db,project_id):
    rows=db.query(MakeReadyAction).filter(
        MakeReadyAction.project_id==project_id,
        MakeReadyAction.status=="OPEN"
    ).order_by(MakeReadyAction.required_by.asc()).all()
    result=[]
    for r in rows:
        a=db.query(ScheduleActivity).filter(ScheduleActivity.id==r.schedule_activity_id).first()
        result.append({
            "activity":a.name if a else r.title,
            "activity_id":a.external_id if a else "",
            "gate":r.gate_name,"action":r.title,"reason":r.reason,
            "required_by":r.required_by,"priority":r.priority,
            "escalation_level":r.escalation_level
        })
    return result
