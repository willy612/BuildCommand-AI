from db.models import ProjectRoleAssignment,User,SubcontractorContact

ROLE_PREFERENCES={
    "Permit / authorization":["project_manager","project_engineer"],
    "Submittals / procurement":["project_engineer","project_manager"],
    "Inspection / Quality":["superintendent","assistant_superintendent","project_engineer"],
    "Site conditions":["superintendent","assistant_superintendent"],
    "Predecessors":["superintendent","project_manager"],
    "Subcontractor commitment":["superintendent","project_manager"],
}

def route_project_user(db,project_id,gate_name):
    for role in ROLE_PREFERENCES.get(gate_name,["project_manager","superintendent"]):
        row=db.query(ProjectRoleAssignment).filter(
            ProjectRoleAssignment.project_id==project_id,
            ProjectRoleAssignment.role==role,
            ProjectRoleAssignment.active==True
        ).order_by(ProjectRoleAssignment.primary_assignment.desc()).first()
        if row:
            user=db.query(User).filter(User.id==row.user_id).first()
            if user:
                return {"user_id":user.id,"name":user.display_name or user.email,"email":user.email,"role":role}
    return None
