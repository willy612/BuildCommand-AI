from db.models import MakeReadyLeadTimeSetting

DEFAULTS={
    "Predecessors":3,
    "Inspection / Quality":2,
    "Permit / authorization":10,
    "Subcontractor commitment":14,
    "Submittals / procurement":21,
    "Site conditions":2,
}

def lead_times(db,company_id):
    result=dict(DEFAULTS)
    rows=db.query(MakeReadyLeadTimeSetting).filter(MakeReadyLeadTimeSetting.company_id==company_id).all()
    for r in rows:
        result[r.gate_name]=r.lead_days
    return result

def set_lead_time(db,company_id,gate_name,days):
    row=db.query(MakeReadyLeadTimeSetting).filter(
        MakeReadyLeadTimeSetting.company_id==company_id,
        MakeReadyLeadTimeSetting.gate_name==gate_name
    ).first()
    if not row:
        row=MakeReadyLeadTimeSetting(company_id=company_id,gate_name=gate_name,lead_days=int(days))
        db.add(row)
    else:
        row.lead_days=int(days)
    db.commit(); db.refresh(row); return row
