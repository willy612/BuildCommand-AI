from db.models import IntelligenceAuditEvent

RESTRICTED_ACTIONS={
    "SEND_EXTERNAL_COMMUNICATION",
    "AUTHORITATIVE_SCHEDULE_CHANGE",
    "APPROVE_RECOVERY_EXECUTION",
    "VENDOR_DECISION",
}

def require_human_approval(db,company_id,user_id,action_type,project_id=None,approved=False,detail=""):
    if action_type in RESTRICTED_ACTIONS and not approved:
        db.add(IntelligenceAuditEvent(
            company_id=company_id,project_id=project_id,user_id=user_id,
            event_type="APPROVAL_BLOCK",entity_type=action_type,
            decision="BLOCKED_PENDING_HUMAN_APPROVAL",detail=detail
        ))
        db.commit()
        raise PermissionError(f"{action_type} requires explicit human approval.")
    return True
