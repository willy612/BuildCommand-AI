class TenantAccessError(PermissionError):
    pass

def require_company(entity,user_company_id):
    entity_company=getattr(entity,"company_id",None)
    if entity_company is None:
        raise TenantAccessError("Entity does not expose company_id for tenant validation.")
    if int(entity_company)!=int(user_company_id):
        raise TenantAccessError("Cross-company access denied.")
    return entity

def require_project_company(db,project_id,user_company_id):
    from db.models import Project
    p=db.query(Project).filter(Project.id==project_id).first()
    if not p:raise TenantAccessError("Project not found.")
    return require_company(p,user_company_id)
