from db.models import Project, Document, ScheduleActivity

def scoped_project(db, ctx, project_id):
    from security.tenant_guard import require_project_access
    return require_project_access(db,ctx,project_id)

def scoped_documents(db,ctx,project_id):
    scoped_project(db,ctx,project_id)
    return db.query(Document).filter(Document.project_id==project_id)

def scoped_schedule(db,ctx,project_id):
    scoped_project(db,ctx,project_id)
    return db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id)
