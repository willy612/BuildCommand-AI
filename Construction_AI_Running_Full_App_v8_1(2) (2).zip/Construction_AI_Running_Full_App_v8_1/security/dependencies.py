from fastapi import Header, HTTPException
from security.auth import AuthContext
from auth_provider.provider import get_auth_provider

def auth_context(authorization: str | None = Header(default=None)):
    provider=get_auth_provider()
    token=""
    if authorization:
        token=authorization.removeprefix("Bearer ").strip()
    try:
        identity=provider.verify(token)
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))
    return AuthContext(
        user_id=identity.user_id,
        company_id=identity.company_id,
        role=identity.role,
        email=identity.email
    )
