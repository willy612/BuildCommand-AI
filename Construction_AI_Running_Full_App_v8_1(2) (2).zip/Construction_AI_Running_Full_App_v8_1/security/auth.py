from dataclasses import dataclass

@dataclass
class AuthContext:
    user_id: int
    company_id: int
    role: str
    email: str = ""

def require_authenticated(ctx):
    if not ctx or not ctx.user_id or not ctx.company_id:
        raise PermissionError("Authentication required")
    return ctx
