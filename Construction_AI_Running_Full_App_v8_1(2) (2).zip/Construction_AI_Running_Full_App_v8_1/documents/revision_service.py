from db.models import Document, DocumentRevisionEvent

def activate_revision(db, project_id, new_document_id, document_type=None, discipline=None, sheet_or_section=None):
    new=db.query(Document).filter(Document.id==new_document_id,Document.project_id==project_id).first()
    if not new: raise ValueError("Document not found")
    q=db.query(Document).filter(Document.project_id==project_id,Document.id!=new.id)
    if document_type or new.document_type:
        q=q.filter(Document.document_type==(document_type or new.document_type))
    if discipline or new.discipline:
        q=q.filter(Document.discipline==(discipline or new.discipline))
    target_sheet=sheet_or_section or new.sheet_or_section
    if target_sheet:
        q=q.filter(Document.sheet_or_section==target_sheet)
    superseded=[]
    for old in q.all():
        if old.status in ("CURRENT","APPROVED"):
            old.status="SUPERSEDED"
            superseded.append(old.id)
            db.add(DocumentRevisionEvent(
                project_id=project_id,document_id=new.id,
                superseded_document_id=old.id,
                reason=f"Activated revision {new.revision or 'new'}"
            ))
    new.status="CURRENT"
    db.commit()
    return superseded
