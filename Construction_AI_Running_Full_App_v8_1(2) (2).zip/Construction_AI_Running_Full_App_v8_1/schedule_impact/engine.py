import json
from collections import defaultdict, deque
from db.models import ScheduleActivity, ScheduleRelationship, ScheduleImpactEvent

def build_schedule_graph(db,project_id):
    activities={a.external_id:a for a in db.query(ScheduleActivity).filter(
        ScheduleActivity.project_id==project_id
    ).all()}
    succ=defaultdict(list)
    for r in db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all():
        succ[r.predecessor_external_id].append((r.successor_external_id,r.relationship_type,r.lag_days))
    return activities,succ

def downstream_activities(db,project_id,source_external_id,max_depth=20):
    activities,succ=build_schedule_graph(db,project_id)
    seen={source_external_id}
    q=deque([(source_external_id,0)])
    rows=[]
    while q:
        current,depth=q.popleft()
        if depth>=max_depth: continue
        for nxt,rel,lag in succ.get(current,[]):
            if nxt in seen: continue
            seen.add(nxt)
            a=activities.get(nxt)
            rows.append({
                "external_id":nxt,
                "name":a.name if a else nxt,
                "depth":depth+1,
                "relationship":rel,
                "lag_days":lag
            })
            q.append((nxt,depth+1))
    return rows

def create_schedule_impact(db,project_id,change_event_id,source_activity_id,exposure_days):
    source=db.query(ScheduleActivity).filter(ScheduleActivity.id==source_activity_id).first()
    downstream=downstream_activities(db,project_id,source.external_id) if source else []
    row=ScheduleImpactEvent(
        project_id=project_id,change_event_id=change_event_id,
        source_activity_id=source_activity_id,exposure_days=float(exposure_days or 0),
        downstream_activity_ids_json=json.dumps([x["external_id"] for x in downstream]),
        milestone_exposure_json=json.dumps([]),status="PENDING_REVIEW"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row,downstream
