import re
from db.models import CommunicationDraft, SubcontractorResponse

def draft_lookahead_email(project_name, sub_name, activity_name, start, finish, response_due, recipient_email=""):
    subject=f"Lookahead Confirmation Required — {activity_name} — {project_name}"
    body=f"""Hello {sub_name},

Your work is currently scheduled as follows:

Activity: {activity_name}
Planned start: {start or 'TBD'}
Planned finish: {finish or 'TBD'}

Please confirm by {response_due or 'the requested response date'} that you can meet this schedule.

Please include:
- manpower available for the activity;
- material and equipment readiness;
- any outstanding submittal or procurement issue;
- any RFI, access, predecessor, inspection, testing, or coordination issue;
- any condition that could delay the planned start or finish.

If you cannot meet the dates, please state the expected delay and the reason so the project team can address it before the work reaches the field.

Thank you.
"""
    return {"recipient_email":recipient_email,"subject":subject,"body":body}

def save_draft(db, project_id, subcontractor_id, schedule_activity_id, draft):
    row=CommunicationDraft(
        project_id=project_id,subcontractor_id=subcontractor_id,
        schedule_activity_id=schedule_activity_id,
        recipient_email=draft.get("recipient_email",""),
        subject=draft.get("subject",""),body=draft.get("body",""),
        status="DRAFT",communication_type="LOOKAHEAD_CONFIRMATION"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row

def parse_sub_response(text):
    q=(text or "").lower()
    if any(x in q for x in ["cannot meet","can't meet","will be late","delay","delayed"]):
        rtype="DELAY_REPORTED"
    elif any(x in q for x in ["confirm","confirmed","we can make","on schedule","will meet"]):
        rtype="CONFIRMED"
    elif any(x in q for x in ["need information","need info","waiting on rfi","need rfi"]):
        rtype="NEED_INFORMATION"
    elif "material" in q or "delivery" in q:
        rtype="MATERIAL_ISSUE"
    elif "manpower" in q or "crew" in q:
        rtype="MANPOWER_ISSUE"
    elif "access" in q:
        rtype="ACCESS_ISSUE"
    else:
        rtype="OTHER"

    delay_days=0
    m=re.search(r"(\d+(?:\.\d+)?)\s*(?:day|days)",q)
    if m and rtype=="DELAY_REPORTED":
        try: delay_days=float(m.group(1))
        except Exception: pass

    return {
        "response_type":rtype,
        "response_text":text,
        "proposed_delay_days":delay_days,
        "requires_superintendent_review":True
    }

def save_response(db, project_id, subcontractor_id, schedule_activity_id, parsed):
    row=SubcontractorResponse(
        project_id=project_id,subcontractor_id=subcontractor_id,
        schedule_activity_id=schedule_activity_id,
        response_type=parsed["response_type"],
        response_text=parsed["response_text"],
        proposed_delay_days=parsed["proposed_delay_days"],
        status="PENDING_REVIEW"
    )
    db.add(row); db.commit(); db.refresh(row)
    return row
