import difflib
import re
from db.models import ScheduleActivity,FieldScheduleMatch

def _norm(text):
    text=(text or "").lower()
    text=re.sub(r"[^a-z0-9 ]+"," ",text)
    return " ".join(text.split())

def suggest_matches(db,project_id,field_label,top_k=5):
    rows=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    target=_norm(field_label)
    scored=[]
    for a in rows:
        hay=_norm(f"{a.external_id} {a.name} {a.phase or ''} {a.trade or ''}")
        score=difflib.SequenceMatcher(None,target,hay).ratio()
        if target and target in hay: score+=0.15
        scored.append((score,a))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [{"activity_id":a.id,"external_id":a.external_id,"name":a.name,"score":round(min(score,1.0),3)}
            for score,a in scored[:top_k]]

def save_match(db,project_id,field_label,schedule_activity_id,score,method="FUZZY",approved=False):
    row=FieldScheduleMatch(
        project_id=project_id,field_label=field_label,schedule_activity_id=schedule_activity_id,
        match_method=method,match_score=float(score or 0),
        status="APPROVED" if approved else "PENDING_REVIEW"
    )
    db.add(row);db.commit();db.refresh(row);return row
