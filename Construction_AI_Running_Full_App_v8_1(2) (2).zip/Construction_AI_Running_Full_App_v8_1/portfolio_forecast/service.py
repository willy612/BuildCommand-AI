from db.models import Project,ProjectForecastSnapshot,PortfolioForecastSnapshot
from brain.command_center import command_summary
from services.state_service import load_project_state
from brain.master_brain import load_tasks

def refresh_company_portfolio_forecast(db,company_id):
    projects=db.query(Project).filter(Project.company_id==company_id,Project.status=="ACTIVE").all()
    tasks=load_tasks()
    rows=[]
    for p in projects:
        latest=db.query(ProjectForecastSnapshot).filter(
            ProjectForecastSnapshot.project_id==p.id
        ).order_by(ProjectForecastSnapshot.created_at.desc()).first()
        state=load_project_state(db,p.id)
        summary=command_summary(state,tasks)
        hold=summary.get("HOLD",0); risk=summary.get("AT_RISK",0)
        variance=latest.variance_days if latest else 0
        conf=latest.milestone_confidence if latest else 0.0
        score=max(0,variance)*2 + hold*5 + risk*2 + (1-conf)*10
        snap=PortfolioForecastSnapshot(
            company_id=company_id,project_id=p.id,
            data_date=latest.data_date if latest else "",
            planned_completion=latest.planned_completion if latest else "",
            forecast_completion=latest.forecast_completion if latest else "",
            variance_days=variance,confidence=conf,hold_count=hold,
            at_risk_count=risk,intervention_score=round(score,1)
        )
        db.add(snap)
        rows.append((p,snap))
    db.commit()
    return sorted(rows,key=lambda x:x[1].intervention_score,reverse=True)
