import logging, json, sys

def configure_logging(level="INFO"):
    logging.basicConfig(
        level=getattr(logging,level.upper(),"INFO"),
        stream=sys.stdout,
        format="%(asctime)s %(levelname)s %(name)s %(message)s"
    )

def event(logger,event_name,**fields):
    logger.info(json.dumps({"event":event_name,**fields},default=str))
