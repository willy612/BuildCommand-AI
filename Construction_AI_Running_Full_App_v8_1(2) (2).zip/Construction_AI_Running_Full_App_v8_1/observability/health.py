from db.session import SessionLocal
from sqlalchemy import text

def database_health():
    db=SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        return {"database":"ok"}
    except Exception as e:
        return {"database":"error","detail":str(e)}
    finally:
        db.close()
