from datetime import datetime,date,timedelta
from collections import defaultdict,deque
from db.models import (
    ScheduleActivity,ScheduleRelationship,ScheduleActivityAdvanced,
    ScheduleRelationshipAdvanced,CPMCalculationSnapshot,ScheduleUpdateSnapshot
)

def _parse(v):
    if not v:return None
    for fmt in ("%Y-%m-%d","%m/%d/%Y","%m/%d/%y"):
        try:return datetime.strptime(str(v),fmt).date()
        except:pass
    return None

def _workday_add(start,days):
    # v4.2 default 5-day calendar. Named calendar support is persisted but
    # project-specific holidays require a future calendar table.
    d=start
    remaining=max(0,int(round(days)))
    while remaining:
        d+=timedelta(days=1)
        if d.weekday()<5: remaining-=1
    return d

def _workdays_between(a,b):
    if not a or not b:return 0
    sign=1 if b>=a else -1
    lo,hi=(a,b) if b>=a else (b,a)
    count=0; d=lo
    while d<hi:
        d+=timedelta(days=1)
        if d.weekday()<5: count+=1
    return count*sign

def _duration(a,adv):
    if adv and adv.remaining_duration_days and adv.remaining_duration_days>0:
        return max(1,int(round(adv.remaining_duration_days)))
    s=_parse(a.planned_start); f=_parse(a.planned_finish)
    return max(1,_workdays_between(s,f)+1) if s and f else 1

def calculate_cpm(db,project_id):
    acts=db.query(ScheduleActivity).filter(ScheduleActivity.project_id==project_id).all()
    if not acts:return None,[]
    by_ext={a.external_id:a for a in acts}
    adv_by={}
    for a in acts:
        adv_by[a.external_id]=db.query(ScheduleActivityAdvanced).filter(
            ScheduleActivityAdvanced.schedule_activity_id==a.id
        ).first()

    rels=db.query(ScheduleRelationship).filter(ScheduleRelationship.project_id==project_id).all()
    succ=defaultdict(list); pred=defaultdict(list); indeg={k:0 for k in by_ext}
    for r in rels:
        if r.predecessor_external_id not in by_ext or r.successor_external_id not in by_ext:continue
        ar=db.query(ScheduleRelationshipAdvanced).filter(
            ScheduleRelationshipAdvanced.relationship_id==r.id
        ).first()
        typ=(ar.relationship_type if ar else getattr(r,"relationship_type","FS") or "FS").upper()
        lag=float(ar.lag_days if ar else getattr(r,"lag_days",0) or 0)
        edge=(r.predecessor_external_id,r.successor_external_id,typ,lag)
        succ[r.predecessor_external_id].append(edge)
        pred[r.successor_external_id].append(edge)
        indeg[r.successor_external_id]+=1

    q=deque([x for x,v in indeg.items() if v==0]); order=[]
    while q:
        n=q.popleft(); order.append(n)
        for _,s,_,_ in succ[n]:
            indeg[s]-=1
            if indeg[s]==0:q.append(s)
    for a in acts:
        if a.external_id not in order:order.append(a.external_id)

    data_dates=[_parse(adv.data_date) for adv in adv_by.values() if adv and adv.data_date]
    data_date=max([d for d in data_dates if d] or [date.today()])
    dur={k:_duration(by_ext[k],adv_by[k]) for k in by_ext}
    ES={}; EF={}

    # Forward pass with FS/SS/FF/SF semantics.
    for k in order:
        a=by_ext[k]
        base=max(data_date,_parse(a.planned_start) or data_date)
        es=base
        for p,s,typ,lag in pred[k]:
            lag=int(round(lag))
            if typ=="FS":
                cand=_workday_add(EF[p],lag+1)
            elif typ=="SS":
                cand=_workday_add(ES[p],lag)
            elif typ=="FF":
                req_finish=_workday_add(EF[p],lag)
                cand=_workday_add(req_finish,-(dur[k]-1)) if dur[k]>1 else req_finish
            elif typ=="SF":
                req_finish=_workday_add(ES[p],lag)
                cand=_workday_add(req_finish,-(dur[k]-1)) if dur[k]>1 else req_finish
            else:
                cand=_workday_add(EF[p],lag+1)
            if cand>es:es=cand
        # basic start constraint support
        adv=adv_by[k]
        if adv and adv.constraint_date and adv.constraint_type:
            cd=_parse(adv.constraint_date)
            ct=(adv.constraint_type or "").upper()
            if cd and ct in ("START ON OR AFTER","SNET","START NO EARLIER THAN") and cd>es:
                es=cd
        ES[k]=es
        EF[k]=_workday_add(es,dur[k]-1)

    project_finish=max(EF.values())
    LS={}; LF={}
    for k in reversed(order):
        lf=project_finish
        if succ[k]:
            candidates=[]
            for p,s,typ,lag in succ[k]:
                lag=int(round(lag))
                if typ=="FS":
                    candidates.append(_workday_add(LS[s],-(lag+1)))
                elif typ=="SS":
                    target=_workday_add(LS[s],-lag)
                    candidates.append(_workday_add(target,dur[k]-1))
                elif typ=="FF":
                    candidates.append(_workday_add(LF[s],-lag))
                elif typ=="SF":
                    target=_workday_add(LF[s],-lag)
                    candidates.append(_workday_add(target,dur[k]-1))
                else:
                    candidates.append(_workday_add(LS[s],-(lag+1)))
            if candidates:lf=min(candidates)
        LF[k]=lf
        LS[k]=_workday_add(lf,-(dur[k]-1)) if dur[k]>1 else lf

    snapshots=[]
    for k in order:
        a=by_ext[k]
        tf=_workdays_between(ES[k],LS[k])
        snap=CPMCalculationSnapshot(
            project_id=project_id,schedule_activity_id=a.id,data_date=data_date.isoformat(),
            early_start=ES[k].isoformat(),early_finish=EF[k].isoformat(),
            late_start=LS[k].isoformat(),late_finish=LF[k].isoformat(),
            total_float_days=tf,critical=tf<=0
        )
        db.add(snap); snapshots.append(snap)

    planned=max([_parse(a.planned_finish) for a in acts if _parse(a.planned_finish)] or [project_finish])
    update=ScheduleUpdateSnapshot(
        project_id=project_id,data_date=data_date.isoformat(),
        planned_completion=planned.isoformat(),calculated_completion=project_finish.isoformat(),
        critical_count=sum(1 for s in snapshots if s.critical),
        negative_float_count=sum(1 for s in snapshots if s.total_float_days<0)
    )
    db.add(update);db.commit()
    return update,snapshots
