from collections import defaultdict
from datetime import datetime
from db.models import (
    CompanyLearningSignal,CompanyKnowledgePattern,CompanyPlaybookRule,
    RecoveryOutcomeReview,ApprovedRecoveryPlan,RecoveryOptionEvaluation,
    LookaheadScheduleAlignment,ScheduleDriftAlert,Project
)

def capture_project_learning(db,company_id,project_id):
    created=0

    plans=db.query(ApprovedRecoveryPlan).filter(
        ApprovedRecoveryPlan.project_id==project_id
    ).all()
    for p in plans:
        opt=db.query(RecoveryOptionEvaluation).filter(
            RecoveryOptionEvaluation.id==p.recovery_option_evaluation_id
        ).first()
        out=db.query(RecoveryOutcomeReview).filter(
            RecoveryOutcomeReview.approved_recovery_plan_id==p.id
        ).first()
        if not opt or not out: continue
        key=f"{opt.scenario_type}"
        exists=db.query(CompanyLearningSignal).filter(
            CompanyLearningSignal.company_id==company_id,
            CompanyLearningSignal.project_id==project_id,
            CompanyLearningSignal.signal_type=="RECOVERY_OUTCOME",
            CompanyLearningSignal.context_key==key,
            CompanyLearningSignal.evidence.like(f"%plan_id={p.id}%")
        ).first()
        if not exists:
            db.add(CompanyLearningSignal(
                company_id=company_id,project_id=project_id,
                signal_type="RECOVERY_OUTCOME",category=opt.scenario_type,
                context_key=key,numeric_value=out.actual_days_recovered or 0,
                unit="days_recovered",outcome=out.outcome_rating,
                evidence=f"plan_id={p.id}; predicted={p.predicted_days_recovered}; actual_cost={out.actual_cost}",
                confidence=0.8 if out.outcome_rating in ("STRONG","WEAK") else 0.65
            ));created+=1

    alignments=db.query(LookaheadScheduleAlignment).filter(
        LookaheadScheduleAlignment.project_id==project_id
    ).all()
    for a in alignments[-500:]:
        key=f"activity:{a.schedule_activity_id}"
        exists=db.query(CompanyLearningSignal).filter(
            CompanyLearningSignal.company_id==company_id,
            CompanyLearningSignal.project_id==project_id,
            CompanyLearningSignal.signal_type=="FIELD_CPM_VARIANCE",
            CompanyLearningSignal.context_key==key,
            CompanyLearningSignal.evidence.like(f"%alignment_id={a.id}%")
        ).first()
        if not exists:
            db.add(CompanyLearningSignal(
                company_id=company_id,project_id=project_id,
                signal_type="FIELD_CPM_VARIANCE",category=a.alignment_status,
                context_key=key,numeric_value=float(a.variance_days or 0),
                unit="days",outcome=a.alignment_status,
                evidence=f"alignment_id={a.id}; {a.reason}",confidence=0.75
            ));created+=1
    db.commit()
    return created

def refresh_company_patterns(db,company_id):
    signals=db.query(CompanyLearningSignal).filter(
        CompanyLearningSignal.company_id==company_id
    ).all()
    grouped=defaultdict(list)
    for s in signals:
        grouped[(s.signal_type,s.category)].append(s)

    updated=[]
    for (ptype,category),rows in grouped.items():
        n=len(rows)
        avg=sum(float(r.numeric_value or 0) for r in rows)/n
        successes=sum(1 for r in rows if r.outcome in ("STRONG","ALIGNED","SUCCESS"))
        success_rate=successes/n if n else 0
        confidence=min(0.95,0.35+n*0.08)

        if ptype=="RECOVERY_OUTCOME":
            rec=(f"{category} has {n} recorded outcome(s), averaging {avg:.1f} actual days recovered. "
                 f"Strong-outcome rate: {success_rate:.0%}. Use as company evidence, not a guarantee.")
        else:
            rec=(f"{category} has {n} field/CPM observation(s), averaging {avg:+.1f} days variance. "
                 "Use this history when prioritizing schedule alignment risk.")

        row=db.query(CompanyKnowledgePattern).filter(
            CompanyKnowledgePattern.company_id==company_id,
            CompanyKnowledgePattern.pattern_type==ptype,
            CompanyKnowledgePattern.category==category
        ).first()
        if not row:
            row=CompanyKnowledgePattern(
                company_id=company_id,pattern_type=ptype,category=category
            );db.add(row)
        row.sample_count=n;row.average_value=avg;row.success_rate=success_rate
        row.confidence=confidence;row.recommendation=rec;row.last_refreshed_at=datetime.utcnow()
        updated.append(row)
    db.commit()
    return updated

def memory_for_action(db,company_id,action):
    patterns=db.query(CompanyKnowledgePattern).filter(
        CompanyKnowledgePattern.company_id==company_id
    ).order_by(CompanyKnowledgePattern.confidence.desc()).all()
    relevant=[]
    if action.action_type=="SCHEDULE_DRIFT":
        relevant=[p for p in patterns if p.pattern_type=="FIELD_CPM_VARIANCE"][:3]
    elif action.action_type=="MAKE_READY":
        relevant=[p for p in patterns if p.pattern_type=="RECOVERY_OUTCOME"][:3]
    return relevant

def generate_playbook_candidates(db,company_id,min_samples=3):
    patterns=db.query(CompanyKnowledgePattern).filter(
        CompanyKnowledgePattern.company_id==company_id,
        CompanyKnowledgePattern.sample_count>=min_samples
    ).all()
    created=[]
    for p in patterns:
        name=f"{p.pattern_type}: {p.category}"
        existing=db.query(CompanyPlaybookRule).filter(
            CompanyPlaybookRule.company_id==company_id,
            CompanyPlaybookRule.rule_name==name
        ).first()
        if existing: continue
        rule=CompanyPlaybookRule(
            company_id=company_id,rule_name=name,
            trigger_type=p.pattern_type,trigger_category=p.category,
            recommended_action=p.recommendation,
            evidence_summary=f"{p.sample_count} samples; confidence {p.confidence:.0%}",
            confidence=p.confidence,active=True
        )
        db.add(rule);created.append(rule)
    db.commit()
    return created
