from db.models import CompanyLearningSignal,CompanyKnowledgePattern,CompanyPlaybookRule

def company_memory_stats(db,company_id):
    return {
        "signals":db.query(CompanyLearningSignal).filter(CompanyLearningSignal.company_id==company_id).count(),
        "patterns":db.query(CompanyKnowledgePattern).filter(CompanyKnowledgePattern.company_id==company_id).count(),
        "playbooks":db.query(CompanyPlaybookRule).filter(
            CompanyPlaybookRule.company_id==company_id,
            CompanyPlaybookRule.active==True
        ).count(),
    }
