from datetime import date,datetime,timedelta
from db.models import (
    CompanyPlaybookRule,PlaybookExecution,PlaybookChecklistItem,
    PredictiveRiskSnapshot,ScheduleActivity
)

DEFAULT_CHECKLISTS={
    "FIELD_CPM_VARIANCE":[
        "Verify current field status against schedule activity.",
        "Identify the controlling constraint or predecessor.",
        "Confirm subcontractor manpower and material readiness.",
        "Test recovery options before committing acceleration.",
        "Escalate unresolved driving issue to PM/scheduler."
    ],
    "RECOVERY_OUTCOME":[
        "Confirm the recovery condition matches prior evidence.",
        "Validate safety and constructability.",
        "Validate cost and subcontractor availability.",
        "Run recovery sandbox / optimizer.",
        "Record actual outcome after execution."
    ],
    "PRODUCTION_RATE":[
        "Verify installed quantity and unit consistency.",
        "Confirm crew size and labor hours.",
        "Check access, material flow, inspections, and rework.",
        "Compare remaining quantity with observed production rate.",
        "Escalate if projected finish threatens downstream work."
    ],
    "SUBCONTRACTOR_CONTEXT":[
        "Confirm start date and manpower commitment.",
        "Confirm material/equipment readiness.",
        "Verify predecessor and access readiness.",
        "Request early warning of any expected delay.",
        "Record commitment response."
    ]
}

def trigger_playbooks(db,company_id,project_id,owner_user_id=None):
    rules=db.query(CompanyPlaybookRule).filter(
        CompanyPlaybookRule.company_id==company_id,
        CompanyPlaybookRule.active==True
    ).all()
    created=[]
    for rule in rules:
        existing=db.query(PlaybookExecution).filter(
            PlaybookExecution.project_id==project_id,
            PlaybookExecution.company_playbook_rule_id==rule.id,
            PlaybookExecution.status=="OPEN"
        ).first()
        if existing: continue
        should_trigger=False;reason=""
        if rule.trigger_type=="FIELD_CPM_VARIANCE":
            risk=db.query(PredictiveRiskSnapshot).filter(
                PredictiveRiskSnapshot.project_id==project_id,
                PredictiveRiskSnapshot.risk_score>=55
            ).first()
            should_trigger=bool(risk)
            reason="High predictive schedule risk exists."
        elif rule.trigger_type in ("RECOVERY_OUTCOME","PRODUCTION_RATE","SUBCONTRACTOR_CONTEXT"):
            should_trigger=True
            reason=f"Company evidence-backed {rule.trigger_type.lower()} playbook available."

        if not should_trigger: continue
        today=date.today()
        ex=PlaybookExecution(
            company_id=company_id,project_id=project_id,
            company_playbook_rule_id=rule.id,owner_user_id=owner_user_id,
            status="OPEN",triggered_reason=reason,
            due_date=(today+timedelta(days=3)).isoformat(),
            escalation_date=(today+timedelta(days=5)).isoformat()
        )
        db.add(ex);db.commit();db.refresh(ex)
        items=DEFAULT_CHECKLISTS.get(rule.trigger_type,[
            "Review evidence.","Confirm responsible owner.","Take recommended action.","Record outcome."
        ])
        for i,item in enumerate(items,1):
            db.add(PlaybookChecklistItem(
                playbook_execution_id=ex.id,item_order=i,item_text=item,status="OPEN"
            ))
        db.commit();created.append(ex)
    return created

def complete_playbook(db,execution_id,helped,feedback=""):
    ex=db.query(PlaybookExecution).filter(PlaybookExecution.id==execution_id).first()
    if not ex:return None
    ex.status="COMPLETE";ex.completed_date=date.today().isoformat()
    ex.helped=bool(helped);ex.feedback=feedback
    db.commit();return ex
