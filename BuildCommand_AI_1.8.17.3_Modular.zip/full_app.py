"""BuildCommand AI 1.8.17.3 — Modular Architecture Migration.
Safe compatibility loader for the verified 1.8.17.2 runtime.
Render: uvicorn full_app:app
"""
from pathlib import Path as _BCPath
_BC_ROOT=_BCPath(__file__).resolve().parent
_BC_FRAGMENT_FILES=sorted((_BC_ROOT/"buildcommand_parts").glob("part_*.py"))
if not _BC_FRAGMENT_FILES: raise RuntimeError("BuildCommand modular source fragments are missing")
for _bc_part in _BC_FRAGMENT_FILES:
    exec(compile(_bc_part.read_text(encoding="utf-8"),str(_bc_part),"exec"),globals(),globals())
BUILD_COMMAND_RELEASE="1.8.17.3"
BUILD_COMMAND_RELEASE_NAME="Modular Architecture Migration"
try: app.version=BUILD_COMMAND_RELEASE
except Exception: pass
