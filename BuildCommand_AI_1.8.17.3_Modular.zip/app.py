from full_app import app
