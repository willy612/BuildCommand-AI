# BuildCommand AI 1.8.17.3 modular source fragment 004
# Generated from verified 1.8.17.2; execute only through full_app.py.

def _v33_trade_for_item(item, proposed_trade):
    """v34.1 field-tested Blueprint Brain trade classifier."""
    req=str(item.get("requirement") or "").strip().lower()
    text=" ".join(str(item.get(k) or "") for k in
                  ["requirement","source_note","source_spec","related_trade"]).lower()
    proposed=_v33_normalize_trade(proposed_trade)

    def has(*terms): return any(x in text for x in terms)

    # ------------------------------------------------------------
    # 1) ACTION FIRST: demolition ownership
    # Demolition must be the work action, not merely context such as
    # "patching resulting from demolition."
    explicit_demo=(
        req.startswith("demo ") or req.startswith("demolish ") or
        req.startswith("remove existing ") or req.startswith("remove and dispose ") or
        " existing to be removed" in req or " shall be demolished" in req or
        " demolition of " in req
    )

    # Access/coordination removal is NOT demolition scope when it is explicitly remove-and-replace.
    access_remove_replace=has("remove and replace ceiling tile","remove and replace ceiling tiles",
                              "remove and replace ceiling grid","remove/reinstall ceiling",
                              "remove and reinstall ceiling","temporarily remove ceiling")

    if explicit_demo and not access_remove_replace:
        # If the primary requirement is clearly general architectural demo and merely says
        # MEP removals remain by their trades, keep the item in Demolition.
        general_demo_objects=has("restroom partition","toilet partition","accessories","finish flooring",
                                 "wall finish","ceiling finish","metal stud partition","gypsum partition",
                                 "drywall partition","door and frame","casework","millwork","storefront",
                                 "ceramic tile","flooring","ceiling tile","ceiling grid")
        exception_language=has("remain assigned to their respective trades","system-specific",
                               "mep removals remain","mep removal remains")
        if general_demo_objects and exception_language:
            return "Demolition"

        # Protected MEP/system demo.
        if has("fire alarm","smoke detector","horn strobe","pull station","notification appliance"):
            return "Fire Alarm"
        if has("card reader","card access","access control","electronic strike","electric strike",
               "electrified strike","request to exit","rex device","door contact","security contact",
               "camera","cctv","security system","intrusion alarm","data cabling","telecom cabling",
               "low voltage","low-voltage","intercom"):
            return "Low Voltage"
        if has("sprinkler","fire suppression","fire protection piping"):
            return "Fire Sprinkler"
        if has("receptacle","outlet","switch","panelboard","electrical panel","transformer","conduit",
               "wire","wiring","branch circuit","breaker","light fixture","lighting fixture","feeder"):
            return "Electrical"
        if has("water closet","urinal","lavatory","wash fountain","mop sink","floor sink","floor drain",
               "drinking fountain","plumbing fixture","sanitary piping","waste piping","vent piping",
               "domestic water","water heater","plumbing piping"):
            return "Plumbing"
        if has("ductwork","duct","diffuser","grille","register","vav","rtu","ahu","fan coil",
               "exhaust fan","air handler","mechanical equipment","hvac equipment","refrigerant piping"):
            return "HVAC / Mechanical"
        return "Demolition"

    # ------------------------------------------------------------
    # 2) GC / coordination responsibilities
    # ------------------------------------------------------------
    if has("coordinate installation and utility rough-ins","coordinate installation","coordinate utility rough-ins",
           "confirm which appliances","confirm which equipment","confirm owner-furnished",
           "owner furnished versus contractor furnished","owner-furnished versus contractor-furnished",
           "verify furnished by","confirm furnished by","confirm procurement responsibility"):
        return "GC / General Contractor"

    # ------------------------------------------------------------
    # 3) Explicit work-action overrides equipment/location words
    # ------------------------------------------------------------
    if has("electrical connections","electrical connection","disconnecting means","provide power",
           "power connection","branch circuit","electrical circuit","electrical feed","provide disconnect"):
        return "Electrical"

    # Plumbing fixture/equipment package. Location inside millwork never changes ownership.
    if has("plumbing fixture schedule","water closets","urinals","lavatories","wash fountains",
           "mop sink","floor sink","floor drains","drinking fountains","break-room sinks",
           "break room sinks","disposal connections","instantaneous electric water heater","iwh-1",
           "chronomite"):
        return "Plumbing"

    # HVAC equipment package. Roof-mounted/roof curb is location/accessory, not Roofing.
    if has("exhaust fan","ef-1","greenheck","upblast fan","upblast exhaust fan","full-size exhaust duct",
           "full size exhaust duct","backdraft damper"):
        return "HVAC / Mechanical"

    # Roof repair work specifically belongs to Roofing.
    if has("patch roof","roof patch","repair roof","roof repair","restore roof","roof membrane patch",
           "patch roofing","repair roof membrane","restore roof membrane","roof flashing",
           "flash roof penetration","watertight roof restoration"):
        return "Roofing"

    # ------------------------------------------------------------
    # 4) Protected specialty systems
    # ------------------------------------------------------------
    if has("card reader","card access","access control","electronic strike","electric strike",
           "electrified strike","request to exit","rex device","door contact","security contact",
           "camera","cctv","security system","intrusion alarm","data cabling","telecom cabling",
           "low voltage","low-voltage","intercom"):
        return "Low Voltage"

    if has("sprinkler head","sprinkler heads","sprinkler piping","fire sprinkler","fire suppression piping",
           "sprinkler branch","sprinkler drop"):
        return "Fire Sprinkler"

    if has("fire extinguisher cabinet","fire extinguisher cabinets","semi-recessed fire extinguisher",
           "larson or equal"):
        return "Specialties"

    # ------------------------------------------------------------
    # 5) Framing/Drywall primary assemblies and supports
    # ------------------------------------------------------------
    if has("concealed wood blocking","wood blocking","plywood backing","wood backing","in-wall backing",
           "in wall backing","metal backing","concealed backing","support framing","equivalent supports"):
        return "Framing / Drywall"

    if has("marlite","symmetrix","smart seam","frp","fiberglass reinforced panel",
           "fiberglass-reinforced panel","wainscot"):
        return "Framing / Drywall"

    if has("wall type b","gypsum-board ceiling","gypsum board ceiling","resilient channels",
           "resilient channel","acoustical sealant","taped joints","metal-stud jamb","metal stud jamb",
           "metal-stud header","metal stud header","rough openings","rough opening","stud framing",
           "metal studs","metal stud","steel studs","steel stud","gypsum board","gyp board","drywall",
           "shaftwall","shaft wall"):
        return "Framing / Drywall"

    if has("wall patch","patch wall","patch drywall","drywall patch","gypsum patch","patch gypsum",
           "repair drywall","repair gypsum","gyp board patch","patch gyp","patch and repair wall",
           "patch gypsum board","wall or ceiling openings resulting from demolition"):
        return "Framing / Drywall"

    # ------------------------------------------------------------
    # 6) Ceilings
    # ------------------------------------------------------------
    if has("suspended acoustical tile ceiling","suspended acoustical tile ceilings",
           "acoustical tile ceiling","acoustical tile ceilings","acoustic ceiling tile",
           "acoustical ceiling tile","ceiling tiles and grid","ceiling tile and grid",
           "ceiling tiles","ceiling grid","act ceiling","suspension system"):
        return "Ceilings"

    # ------------------------------------------------------------
    # 7) Doors vs Storefront/Glazing -- primary system first
    # ------------------------------------------------------------
    interior_door_system=has("interior doors and frames","interior door and frame","hollow-metal framed windows",
                             "hollow metal framed windows","interior hollow-metal","interior hollow metal",
                             "door schedule","door hardware sets","rotary white birch doors","hollow-metal doors",
                             "hollow metal doors")
    if interior_door_system:
        return "Doors / Frames / Hardware"

    # True storefront/glazing system only; generic 'glazing' is not enough.
    if has("aluminum storefront","storefront system","store front system","curtain wall","aluminum entrance",
           "exterior storefront","storefront doors","storefront frames"):
        return "Storefront / Glazing"

    if has("door frame","door frames","wood door","wood doors","hollow metal frame","hollow-metal frame",
           "door hardware","hardware set","door closer","panic hardware","exit device","lockset",
           "door threshold","door sweep","door hinges"):
        return "Doors / Frames / Hardware"

    # ------------------------------------------------------------
    # 8) Finishes / tile / flooring / paint
    # ------------------------------------------------------------
    if has("faux tile backsplash","tile backsplash","backsplash wt2","aspect ideas a9550",
           "ceramic tile","porcelain tile","wall tile","floor tile","tile base","tile grout",
           "tile mortar","tile adhesive","setting bed","tile setting","tile trim","schluter"):
        return "Tile"

    if has("rubber base","resilient base","vinyl base","cove base","lvt","luxury vinyl","vct",
           "carpet tile","sheet vinyl","resilient flooring","floor transition","transition strip"):
        return "Flooring"

    if has("paint or refinish","paint patched","paint patch","repaint","touch-up paint","touch up paint",
           "paint repair","refinish patched","finish paint","painting of patched surfaces"):
        return "Painting"

    if has("casework","millwork","cabinet","countertop"):
        return "Millwork / Casework"

    # Conservative fallbacks: do not allow location/source words to steal ownership.
    if has("electrical","receptacle","panelboard","conduit","circuit"):
        return "Electrical"
    if has("plumbing","sanitary","domestic water"):
        return "Plumbing"
    if has("hvac","mechanical","ductwork","diffuser","vav"):
        return "HVAC / Mechanical"
    if has("paint","painting","primer","finish coat"):
        return "Painting"

    return proposed


def _v33_reclassify_data(data):
    """Rebuild every parent trade scope from final item ownership."""
    grouped={}
    for td in data.get("trade_scopes") or []:
        proposed=_v33_normalize_trade(td.get("trade"))
        for item in td.get("items") or []:
            if not isinstance(item,dict):
                continue
            target=_v33_trade_for_item(item, proposed) or "Unassigned"
            clean=dict(item)
            clean["assigned_trade"]=target
            # Preserve source and original proposed trade for auditability.
            if proposed and proposed != target:
                clean["original_proposed_trade"]=proposed
            grouped.setdefault(target,[]).append(clean)

    division_defaults={
        "GC / General Contractor":"01","Demolition":"02","Concrete":"03","Masonry":"04",
        "Structural Steel":"05","Rough Carpentry":"06","Waterproofing":"07","Roofing":"07",
        "Doors / Frames / Hardware":"08","Storefront / Glazing":"08","Framing / Drywall":"09",
        "Ceilings":"09","Flooring":"09","Tile":"09","Painting":"09","Specialties":"10",
        "Fire Sprinkler":"21","Plumbing":"22","HVAC / Mechanical":"23","Controls":"23",
        "Electrical":"26","Low Voltage":"27","Fire Alarm":"28"
    }
    rebuilt=[]
    for trade in sorted(grouped):
        items=grouped[trade]
        rebuilt.append({
            "trade":trade,
            "division":division_defaults.get(trade,""),
            "summary":f"BuildCommand source-backed scope for {trade}.",
            "items":items
        })
    data["trade_scopes"]=rebuilt
    notes=data.setdefault("review_notes",[])
    notes.append("v34.1 rebuilt every parent trade scope from final action-first ownership; source sheet/location cannot override the primary work assembly.")
    return data


_V441_TRADES=set(V33_TRADES)


def _v441_primary_trade(requirement, proposed):
    s=str(requirement or "").lower().strip()
    def has(*terms): return any(x in s for x in terms)

    # Exact live Blueprint Brain corrections from field review.
    if has("patch concrete and floor surfaces disturbed by electrical or plumbing work"):
        return "Concrete"

    if has("prime and refinish all wall, ceiling, and other surfaces patched after demolition or mep installation"):
        return "Painting"

    if has("bobrick toilet tissue holders","stainless-steel grab bars","paper towel/waste receptacles",
           "soap dispensers","robe hooks","framed mirrors","toilet-seat-cover dispensers",
           "sanitary-napkin disposals"):
        return "Toilet / Bath Accessories"

    if has("electric water heater wh-1","bradford white cehd120"):
        return "Plumbing"

    if has("seven-day programmable thermostats","programmable thermostats") and has("rooftop units","rtu"):
        return "HVAC / Mechanical"

    # 1. PRIMARY ACTION FIRST.
    explicit_demo=(
        s.startswith("demo ") or s.startswith("demolish ") or
        s.startswith("remove existing ") or s.startswith("remove the existing ") or
        s.startswith("remove the architectural ") or s.startswith("remove architectural ") or
        s.startswith("remove and dispose ") or s.startswith("perform non-system") or
        "specifically marked for removal" in s or "identified for demolition" in s
    )
    if explicit_demo:
        return "Demolition"

    # Generic firestopping coordination/spec language is excluded later, not routed as a trade scope.
    # Finish actions beat substrate/material words.
    if has("paint ","paint gypsum","paint hollow","prime and refinish","prime and paint",
           "paint or refinish","repaint","touch-up paint","touch up paint",
           "refinish all wall","finish paint","painting of patched surfaces"):
        return "Painting"

    # Supporting construction work owns itself even when caused by MEP.
    if has("slab cutting","sawcut slab","saw cut slab","concrete cutting",
           "trenching and restoration","patch concrete","concrete patch",
           "restore concrete","slab restoration"):
        return "Concrete"

    # Ceiling coordination/layout belongs to ceilings; device names are interfaces only.
    if has("coordinate ceiling grid layout","ceiling grid layout and openings",
           "coordinate ceiling openings","suspended acoustical tile ceiling",
           "acoustical tile ceiling","acoustic ceiling tile","acoustical ceiling tile",
           "ceiling tile and grid","ceiling tiles and grid","ceiling grid","act ceiling",
           "suspension system"):
        return "Ceilings"

    # Duct smoke devices tied to air-conditioning units are HVAC in this BuildCommand ownership model.
    if has("duct smoke detector","duct smoke detectors"):
        return "HVAC / Mechanical"

    # Electronic accessible/automatic door operators and touch pads are Low Voltage.
    if has("electronic accessible door operator","automatic door operator",
           "accessible door operator","door operator with","touch pads","activation touch pad"):
        return "Low Voltage"

    # Toilet/bath accessories are not plumbing.
    if has("grab bar","grab bars","toilet partition","toilet partitions","urinal screen","urinal screens",
           "toilet tissue holder","paper towel/waste","paper towel dispenser","soap dispenser",
           "robe hook","framed mirror","toilet-seat-cover","toilet seat cover",
           "sanitary-napkin","sanitary napkin","bath accessory","bathroom accessory",
           "toilet room accessory"):
        return "Toilet / Bath Accessories"

    # Storefront hardware remains storefront when explicitly part of storefront/entrance assembly.
    if has("storefront door hardware","storefront entrance hardware","aluminum entrance hardware"):
        return "Storefront / Glazing"

    # Protected specialty systems.
    if has("fire alarm","horn strobe","pull station","notification appliance","smoke detector"):
        return "Fire Alarm"
    if has("card access","card reader","access control","electronic strike","electric strike",
           "electrified strike","request to exit","rex device","door contact","cctv","camera",
           "security system","intrusion alarm","data cabling","telecom cabling","intercom"):
        return "Low Voltage"
    if has("sprinkler head","sprinkler heads","sprinkler piping","fire sprinkler",
           "fire suppression piping","sprinkler branch","sprinkler drop"):
        return "Fire Sprinkler"

    if has("patch roof","roof patch","repair roof","roof repair","restore roof","roof membrane patch",
           "patch roofing","repair roof membrane","flash roof penetration","roof flashing",
           "watertight roof","roof penetration patch"):
        return "Roofing"

    if has("electrical connection","electrical connections","disconnecting means","provide power",
           "branch circuit","electrical feed","power connection","provide disconnect"):
        return "Electrical"

    if has("water closet","urinal","lavatory","wash fountain","mop sink","floor sink","floor drain",
           "drinking fountain","plumbing fixture","break-room sink","break room sink",
           "disposal connection","instantaneous electric water heater","electric domestic water heater",
           "water heater wh-","chronomite","iwh-1","expansion tank","recirculation pump"):
        return "Plumbing"

    if has("exhaust fan","upblast fan","greenheck","backdraft damper","full-size exhaust duct",
           "full size exhaust duct","rtu","ahu","air handler","vav","diffuser","grille","ductwork",
           "thermostat","thermostats","rooftop unit","air-conditioning unit","air conditioning unit"):
        return "HVAC / Mechanical"

    if has("concealed wood blocking","wood blocking","wood backing","plywood backing","metal backing",
           "in-wall backing","in wall backing","support framing","rough opening","metal-stud jamb",
           "metal stud jamb","metal-stud header","metal stud header","stud framing","metal studs",
           "steel studs","gypsum board","gyp board","drywall","shaftwall","shaft wall",
           "patch gypsum","patch drywall","wall patch","patch wall","repair drywall",
           "marlite","symmetrix","frp","wainscot"):
        return "Framing / Drywall"

    if has("interior doors and frames","interior door and frame","hollow-metal framed window",
           "hollow metal framed window","door schedule","door hardware set","hollow-metal door",
           "hollow metal door","door frame","door hardware","lockset","panic hardware","exit device"):
        return "Doors / Frames / Hardware"

    if has("aluminum storefront","storefront system","store front system","curtain wall",
           "aluminum entrance","exterior storefront","storefront door","storefront frame"):
        return "Storefront / Glazing"

    if has("faux tile backsplash","tile backsplash","ceramic tile","porcelain tile","wall tile",
           "floor tile","tile base","tile grout","tile mortar","tile adhesive","schluter",
           "rubber base","resilient base","vinyl base","cove base","lvt","luxury vinyl","vct",
           "carpet tile","sheet vinyl","resilient flooring","floor transition","transition strip"):
        return "Flooring / Tile"

    if has("fire extinguisher cabinet","fire extinguisher cabinets","semi-recessed fire extinguisher"):
        return "Specialties"

    if has("casework","millwork","countertop"):
        return "Millwork"

    return _v33_normalize_trade(proposed)


def _v442_exclude_scope_item(requirement):
    s=str(requirement or "").lower()
    if "firestop cable, raceway, piping, and similar penetrations" in s:
        return True
    # User-approved exclusion: generic firestop penetration specification/coordination statement.
    return (
        ("firestop" in s or "firestopping" in s) and
        ("penetration" in s or "penetrations" in s) and
        ("listed assembl" in s or "restore" in s or "original rating" in s)
    )


def _v441_apply_approved_learning(pid, requirement, trade):
    try:
        _v43_ensure_tables()
        c=db()
        rows=c.execute("""
            SELECT * FROM learning_rules
            WHERE company_id=? AND approval_status='APPROVED'
              AND (project_id=? OR scope_level='COMPANY STANDARD')
              AND rule_type IN ('TRADE ASSIGNMENT','SCOPE BOUNDARY')
            ORDER BY CASE WHEN project_id=? THEN 0 ELSE 1 END,id DESC
        """,(current_company_id(),pid,pid)).fetchall()
        c.close()
        low=str(requirement or "").lower()
        for r in rows:
            subject=str(r["subject"] or "").strip().lower()
            if subject and subject in low:
                learned=str(r["learned_rule"] or "").strip()
                target=learned.split("->")[-1].strip() if "->" in learned else learned
                target=_v33_normalize_trade(target)
                if target in _V441_TRADES:
                    return target
    except Exception:
        pass
    return trade


def _v441_reclassify_with_learning(pid,data):
    grouped={}
    for td in data.get("trade_scopes") or []:
        proposed=_v33_normalize_trade(td.get("trade"))
        for item in td.get("items") or []:
            if not isinstance(item,dict): continue
            req=str(item.get("requirement") or "").strip()
            if not req: continue
            if _v442_exclude_scope_item(req):
                continue
            target=_v33_trade_for_item(item,proposed) or proposed
            target=_v441_primary_trade(req,target)
            target=_v441_apply_approved_learning(pid,req,target)
            clean=dict(item)
            clean["assigned_trade"]=target
            if proposed != target:
                clean["original_proposed_trade"]=proposed
            grouped.setdefault(target,[]).append(clean)

    div={
        "GC / General Contractor":"01","Demolition":"02","Concrete":"03","Masonry":"04",
        "Structural Steel":"05","Rough Carpentry":"06","Waterproofing":"07","Roofing":"07",
        "Doors / Frames / Hardware":"08","Storefront / Glazing":"08","Framing / Drywall":"09",
        "Ceilings":"09","Flooring / Tile":"09","Painting":"09","Millwork":"12",
        "Toilet / Bath Accessories":"10","Specialties":"10","Fire Sprinkler":"21","Plumbing":"22","HVAC / Mechanical":"23",
        "Controls":"23","Electrical":"26","Low Voltage":"27","Fire Alarm":"28"
    }
    data["trade_scopes"]=[
        {"trade":trade,"division":div.get(trade,""),
         "summary":f"BuildCommand source-backed scope for {trade}.","items":items}
        for trade,items in sorted(grouped.items())
    ]
    data.setdefault("review_notes",[]).append(
        "v44.1 Blueprint Ownership Guard applied action/assembly routing and approved learning rules before save."
    )
    return data


def _save_blueprint_result(pid, docs, data, model_name):
    data=_v33_reclassify_data(data)
    data=_v441_reclassify_with_learning(pid,data)
    company_id=current_company_id(); user_id=current_user_id(); now=datetime.utcnow().isoformat()
    c=db()
    c.execute("INSERT INTO blueprint_runs(company_id,project_id,status,source_files,project_summary,detected_disciplines,cross_discipline_flags,rfi_candidates,review_notes,model_name,created_by,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(
        company_id,pid,"COMPLETE",json.dumps([d["original_name"] for d in docs]),str(data.get("project_summary") or ""),json.dumps(data.get("detected_disciplines") or []),json.dumps(data.get("cross_discipline_flags") or []),json.dumps(data.get("rfi_candidates") or []),json.dumps(data.get("review_notes") or []),model_name,user_id,now
    ))
    run_id=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    for trade_data in data.get("trade_scopes") or []:
        trade=(trade_data.get("trade") or "Unassigned").strip() or "Unassigned"
        division=str(trade_data.get("division") or "").strip()
        summary=str(trade_data.get("summary") or "").strip()
        items=trade_data.get("items") or []
        scope_text=_blueprint_scope_text(trade_data)
        c.execute("INSERT INTO blueprint_trade_scopes(company_id,project_id,run_id,trade,division,summary,scope_text,item_count,created) VALUES(?,?,?,?,?,?,?,?,?)",(company_id,pid,run_id,trade,division,summary,scope_text,len(items),now))
        trade_scope_id=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
        for item in items:
            req=str(item.get("requirement") or "").strip()
            if not req:
                continue
            confidence=str(item.get("confidence") or "MEDIUM").upper()
            if confidence not in {"HIGH","MEDIUM","LOW"}: confidence="MEDIUM"
            item_type=str(item.get("item_type") or "SCOPE").upper()
            c.execute("INSERT INTO blueprint_scope_items(company_id,project_id,run_id,trade_scope_id,trade,requirement,source_sheet,source_detail,source_spec,source_note,related_trade,confidence,item_type,status,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(
                company_id,pid,run_id,trade_scope_id,trade,req,str(item.get("source_sheet") or ""),str(item.get("source_detail") or ""),str(item.get("source_spec") or ""),str(item.get("source_note") or ""),str(item.get("related_trade") or ""),confidence,item_type,"NOT_STARTED",now
            ))
    c.commit(); c.close(); return run_id


def _blueprint_latest(pid):
    c=db(); run=c.execute("SELECT * FROM blueprint_runs WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 1",(current_company_id(),pid)).fetchone()
    scopes=[]
    if run:
        scopes=c.execute("SELECT * FROM blueprint_trade_scopes WHERE company_id=? AND project_id=? AND run_id=? ORDER BY trade",(current_company_id(),pid,run["id"])).fetchall()
    c.close(); return run,scopes


def _ensure_v34_estimator_tables():
    """
    v34.2 estimator schema repair.
    PostgreSQL needs a sequence/default for estimator_items.id. Earlier v34 used
    c.execute(CREATE TABLE...) instead of executescript(), so PgCompat did not
    translate INTEGER PRIMARY KEY to BIGSERIAL. Repair existing installs in place.
    """
    c=db()
    if DATABASE_KIND=="postgres":
        c.execute("""
            CREATE TABLE IF NOT EXISTS estimator_items(
                id BIGSERIAL PRIMARY KEY,
                company_id BIGINT,
                project_id BIGINT,
                blueprint_scope_item_id BIGINT,
                trade TEXT,
                description TEXT,
                source_ref TEXT,
                quantity DOUBLE PRECISION DEFAULT 0,
                unit TEXT DEFAULT '',
                material_unit_cost DOUBLE PRECISION DEFAULT 0,
                labor_unit_cost DOUBLE PRECISION DEFAULT 0,
                subcontract_quote DOUBLE PRECISION DEFAULT 0,
                allowance DOUBLE PRECISION DEFAULT 0,
                markup_pct DOUBLE PRECISION DEFAULT 0,
                notes TEXT DEFAULT '',
                verified INTEGER DEFAULT 0,

                ai_quantity DOUBLE PRECISION,
                ai_unit TEXT DEFAULT '',
                ai_confidence TEXT DEFAULT '',
                ai_basis TEXT DEFAULT '',
                ai_source TEXT DEFAULT '',
                ai_updated TEXT,
                created TEXT,
                updated TEXT
            )
        """)
        # Repair a v34 table that already exists with "id INTEGER PRIMARY KEY"
        # and therefore has no sequence/default.
        try:
            c.execute("CREATE SEQUENCE IF NOT EXISTS estimator_items_id_seq")
            c.execute("ALTER SEQUENCE estimator_items_id_seq OWNED BY estimator_items.id")
            c.execute("""
                ALTER TABLE estimator_items
                ALTER COLUMN id SET DEFAULT nextval('estimator_items_id_seq')
            """)
            c.execute("""
                SELECT setval(
                    'estimator_items_id_seq',
                    GREATEST(COALESCE((SELECT MAX(id) FROM estimator_items),0)+1,1),
                    false
                )
            """)
        except Exception:
            c.rollback()
            c=db()
            # If another deploy/request repaired it concurrently, normal use can continue.
    else:
        c.execute("""
            CREATE TABLE IF NOT EXISTS estimator_items(
                id INTEGER PRIMARY KEY,
                company_id INTEGER,
                project_id INTEGER,
                blueprint_scope_item_id INTEGER,
                trade TEXT,
                description TEXT,
                source_ref TEXT,
                quantity REAL DEFAULT 0,
                unit TEXT DEFAULT '',
                material_unit_cost REAL DEFAULT 0,
                labor_unit_cost REAL DEFAULT 0,
                subcontract_quote REAL DEFAULT 0,
                allowance REAL DEFAULT 0,
                markup_pct REAL DEFAULT 0,
                notes TEXT DEFAULT '',
                verified INTEGER DEFAULT 0,

                ai_quantity REAL,
                ai_unit TEXT DEFAULT '',
                ai_confidence TEXT DEFAULT '',
                ai_basis TEXT DEFAULT '',
                ai_source TEXT DEFAULT '',
                ai_updated TEXT,

                created TEXT,
                updated TEXT
            )
        """)

    # v36 automatic takeoff proposal fields. Add safely to existing v34/v35 tables.
    v36_columns=[
        ("ai_quantity","DOUBLE PRECISION" if DATABASE_KIND=="postgres" else "REAL"),
        ("ai_unit","TEXT DEFAULT ''"),
        ("ai_confidence","TEXT DEFAULT ''"),
        ("ai_basis","TEXT DEFAULT ''"),
        ("ai_source","TEXT DEFAULT ''"),
        ("ai_updated","TEXT")
    ]
    for col,col_type in v36_columns:
        try:
            c.execute(f"ALTER TABLE estimator_items ADD COLUMN {col} {col_type}")
            c.commit()
        except Exception:
            try: c.rollback()
            except Exception: pass

    # Helpful lookup/index; duplicate historical rows are tolerated, so no UNIQUE migration.
    try:
        c.execute("""
            CREATE INDEX IF NOT EXISTS idx_estimator_project_scope
            ON estimator_items(company_id,project_id,blueprint_scope_item_id)
        """)
    except Exception:
        pass
    c.commit(); c.close()


def _latest_blueprint_run(pid):
    c=db()
    row=c.execute("""SELECT * FROM blueprint_runs
                     WHERE company_id=? AND project_id=?
                     ORDER BY id DESC LIMIT 1""",
                  (current_company_id(),pid)).fetchone()
    c.close(); return row


def _seed_estimator_from_latest(pid):
    """
    Sync estimator rows from the latest cleaned Blueprint/Plan Intelligence run.
    Existing user-entered pricing/quantities are preserved, while trade, description,
    and source references are refreshed from v34.1+ corrected scope ownership.
    """
    _ensure_v34_estimator_tables()
    run=_latest_blueprint_run(pid)
    if not run:
        return {"added":0,"updated":0,"run_id":None}

    c=db()
    rows=c.execute("""
        SELECT i.id,i.requirement,i.source_sheet,i.source_detail,i.source_spec,s.trade
        FROM blueprint_scope_items i
        JOIN blueprint_trade_scopes s ON s.id=i.trade_scope_id
        WHERE i.company_id=? AND i.project_id=? AND s.run_id=?
        ORDER BY s.trade,i.id
    """,(current_company_id(),pid,run["id"])).fetchall()

    added=0; updated=0; now=datetime.utcnow().isoformat()
    latest_scope_ids=set()

    for r in rows:
        scope_item_id=int(r["id"])
        latest_scope_ids.add(scope_item_id)
        refs=[str(r[x] or "").strip() for x in ["source_sheet","source_detail","source_spec"]
              if str(r[x] or "").strip()]
        source_ref=" · ".join(refs)

        existing=c.execute("""
            SELECT id,trade,description,source_ref
            FROM estimator_items
            WHERE company_id=? AND project_id=? AND blueprint_scope_item_id=?
            ORDER BY id LIMIT 1
        """,(current_company_id(),pid,scope_item_id)).fetchone()

        if existing:
            # Keep estimator-entered numbers/notes but refresh scope truth.
            if ((existing["trade"] or "") != (r["trade"] or "") or
                (existing["description"] or "") != (r["requirement"] or "") or
                (existing["source_ref"] or "") != source_ref):
                c.execute("""
                    UPDATE estimator_items
                    SET trade=?,description=?,source_ref=?,updated=?
                    WHERE id=? AND company_id=? AND project_id=?
                """,(r["trade"],r["requirement"],source_ref,now,
                     existing["id"],current_company_id(),pid))
                updated+=1
            continue

        c.execute("""
            INSERT INTO estimator_items(
                company_id,project_id,blueprint_scope_item_id,trade,description,source_ref,
                quantity,unit,material_unit_cost,labor_unit_cost,subcontract_quote,allowance,
                markup_pct,notes,verified,created,updated
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,(current_company_id(),pid,scope_item_id,r["trade"],r["requirement"],
             source_ref,0,"",0,0,0,0,0,"",0,now,now))
        added+=1

    c.commit(); c.close()
    return {"added":added,"updated":updated,"run_id":run["id"]}


def _estimate_math(row):
    qty=float(row["quantity"] or 0); mat=float(row["material_unit_cost"] or 0)
    labor=float(row["labor_unit_cost"] or 0); sub=float(row["subcontract_quote"] or 0)
    allowance=float(row["allowance"] or 0); markup=float(row["markup_pct"] or 0)
    direct=(qty*(mat+labor))+sub+allowance
    return direct,direct*(1+(markup/100.0))


@app.get("/brain",response_class=HTMLResponse)
def buildcommand_core_brain():
    pid=project_id(); run=_latest_blueprint_run(pid); c=db()
    project=c.execute("SELECT name,number FROM projects WHERE id=?",(pid,)).fetchone()
    scope_count=item_count=cross_count=rfi_count=0
    if run:
        scope_count=c.execute("SELECT COUNT(*) n FROM blueprint_trade_scopes WHERE run_id=?",(run["id"],)).fetchone()["n"]
        item_count=c.execute("SELECT COUNT(*) n FROM blueprint_scope_items WHERE run_id=?",(run["id"],)).fetchone()["n"]
        try: cross_count=len(json.loads(run["cross_discipline_flags"] or "[]"))
        except: cross_count=0
        try: rfi_count=len(json.loads(run["rfi_candidates"] or "[]"))
        except: rfi_count=0
    open_issues=c.execute("SELECT COUNT(*) n FROM project_issues WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchone()["n"]
    activities=c.execute("SELECT COUNT(*) n FROM activities WHERE project_id=?",(pid,)).fetchone()["n"]
    c.close()
    project_label=f'{esc(project["number"])} - {esc(project["name"])}' if project else "Current Project"
    latest=(f'<span class="badge READY">PLAN INTELLIGENCE READY</span><div class="small" style="margin-top:8px">Latest run #{run["id"]} · {esc(run["created"] or "")}</div>'
            if run else '<span class="badge WATCH">NO PLAN ANALYSIS YET</span>')
    body=f"""
    <div class="hero">
      <div class="eyebrow">BuildCommand Core Brain · v34.1</div>
      <h1>One construction brain. One project memory.</h1>
      <div class="muted">{project_label}</div><div style="margin-top:12px">{latest}</div>
    </div>
    <div class="grid4">
      <div class="card"><div class="label">Trade Scopes</div><div class="kpi">{scope_count}</div></div>
      <div class="card"><div class="label">Scope Items</div><div class="kpi">{item_count}</div></div>
      <div class="card"><div class="label">Cross-Discipline</div><div class="kpi">{cross_count}</div></div>
      <div class="card"><div class="label">RFI Candidates</div><div class="kpi">{rfi_count}</div></div>
    </div>
    <div class="grid2">
      <div class="card">
        <h2>Ask the BuildCommand Brain</h2>
        <form method="post" action="/brain">
          <textarea name="question" required placeholder="Example: What are the biggest scope and estimating risks on this project?"></textarea>
          <button type="submit">Ask BuildCommand</button>
        </form>
        <p class="small">Core Brain uses operations data plus the latest source-backed plan intelligence.</p>
      </div>
      <div class="card">
        <h2>One Brain Tools</h2>
        <p><a href="/plans-specs-ai"><b>Plan Intake</b></a> — read plans and create trade scopes.</p>
        <p><a href="/brain/estimator"><b>Estimator Intelligence</b></a> — estimate from those same scope items.</p>
        <p><a href="/issues"><b>RFIs / Issues</b></a> — manage scope gaps and coordination issues.</p>
        <p><a href="/schedule"><b>Schedule</b></a> — connect scope to execution.</p>
      </div>
    </div>
    <div class="grid2">
      <div class="card"><h2>Operations connected</h2><div class="kpi">{activities}</div><div class="muted">schedule activities</div></div>
      <div class="card"><h2>Open issues connected</h2><div class="kpi">{open_issues}</div><div class="muted">project issues</div></div>
    </div>"""
    return shell("BuildCommand Brain",body)


@app.post("/brain",response_class=HTMLResponse)
def buildcommand_core_brain_answer(question:str=Form(...)):
    pid=project_id(); run=_latest_blueprint_run(pid); c=db()
    scope_rows=[]
    if run:
        scope_rows=c.execute("""
            SELECT s.trade,i.requirement,i.source_sheet,i.source_detail,i.source_spec
            FROM blueprint_scope_items i
            JOIN blueprint_trade_scopes s ON s.id=i.trade_scope_id
            WHERE i.company_id=? AND i.project_id=? AND s.run_id=?
            ORDER BY s.trade,i.id LIMIT 500
        """,(current_company_id(),pid,run["id"])).fetchall()
    c.close()
    plan_context="\n".join(
        f'- {r["trade"]}: {r["requirement"]} | source: {r["source_sheet"] or ""} {r["source_detail"] or ""} {r["source_spec"] or ""}'
        for r in scope_rows
    ) or "No plan/scope intelligence available yet."
    api_key=os.environ.get("OPENAI_API_KEY")
    if not api_key:
        answer="OPENAI_API_KEY is not configured."
    else:
        try:
            operations=build_project_context(pid)
            client=OpenAI(api_key=api_key)
            resp=client.responses.create(
                model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
                instructions="""You are the BuildCommand Core Brain, a construction operations and estimating intelligence system.
Use only supplied project facts as job-specific facts.
Think across estimating, trade scope, drawings, schedule, field execution, RFIs, procurement, inspections and closeout.
Never invent quantities, dimensions, costs, field conditions, commitments or drawing requirements.
If quantity/cost is not supported, say ESTIMATOR VERIFICATION REQUIRED.
Classify by actual work, not by drawing discipline.
Non-MEP demolition belongs to Demolition; MEP/system demo stays with the system trade.
Blocking/backing belongs to Framing/Drywall. Roof patching belongs to Roofing.
Sprinkler heads/piping belong to Fire Sprinkler.
Card access/electronic strikes/cameras/security belong to Low Voltage.
Storefront/glazing is separate from standard Doors/Frames/Hardware.""",
                input=f"""PROJECT OPERATIONS DATA
{operations}

LATEST PLAN / TRADE SCOPE INTELLIGENCE
{plan_context}

USER QUESTION
{question}"""
            )
            answer=resp.output_text
        except Exception as exc:
            answer=f"BuildCommand Brain could not complete the analysis: {exc}"
    body=f"""<div class="hero"><div class="eyebrow">BuildCommand Core Brain</div><h1>Project Answer</h1></div>
    <div class="grid2"><div class="card"><div class="small">QUESTION</div><h3>{esc(question)}</h3><p><a href="/brain">← Back to Brain</a></p></div>
    <div class="card"><div class="small">BUILDCOMMAND BRAIN</div><div style="white-space:pre-wrap;line-height:1.6">{esc(answer)}</div></div></div>"""
    return shell("BuildCommand Brain",body)


def _suggest_takeoff_unit(trade, description):
    t=(str(description or "")+" "+str(trade or "")).lower()

    # Counts / equipment
    if any(x in t for x in [
        "door","frame","window","sprinkler head","receptacle","outlet","switch",
        "fixture","water closet","urinal","lavatory","sink","floor drain","cleanout",
        "diffuser","grille","vav","fan","rtu","ahu","panel","transformer","disconnect",
        "card reader","camera","fire extinguisher cabinet","cabinet","appliance"
    ]):
        return "EA"

    # Linear measurements
    if any(x in t for x in [
        "rubber base","resilient base","cove base","base molding","curb","handrail",
        "guardrail","pipe","piping","conduit","duct","ductwork","gutter","flashing",
        "joint sealant","wall base"
    ]):
        return "LF"

    # Area measurements
    if any(x in t for x in [
        "flooring","carpet","lvt","vct","tile","wall tile","floor tile","ceiling",
        "ceiling tile","drywall","gypsum board","wallboard","paint","painting",
        "frp","marlite","wainscot","roof membrane","roofing","waterproofing",
        "storefront glazing","glazing","insulation"
    ]):
        return "SF"

    # Volume
    if any(x in t for x in ["concrete","slab","footing","grade beam","grout fill"]):
        return "CY"

    # Earthwork
    if any(x in t for x in ["excavation","backfill","import soil","export soil"]):
        return "CY"

    # Lump-sum / coordination / general conditions
    if any(x in t for x in [
        "coordinate","confirm","verify","allowance","general conditions","mobilization",
        "testing","commissioning","permit","closeout","temporary protection"
    ]):
        return "LS"

    return "EA"


def _takeoff_status(row):
    qty=float(row["quantity"] or 0)
    verified=bool(int(row["verified"] or 0))
    if verified:
        return "VERIFIED"
    if qty > 0:
        return "QUANTITY_ENTERED"
    return "NEEDS_TAKEOFF"


def _ensure_takeoff_component_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        c.execute("""
            CREATE TABLE IF NOT EXISTS takeoff_components(
                id BIGSERIAL PRIMARY KEY,
                company_id BIGINT,
                project_id BIGINT,
                estimator_item_id BIGINT,
                component_name TEXT,
                description TEXT,
                unit TEXT,
                quantity DOUBLE PRECISION,
                confidence TEXT DEFAULT 'VERIFY',
                basis TEXT DEFAULT '',
                source_ref TEXT DEFAULT '',
                status TEXT DEFAULT 'PROPOSED',
                created TEXT,
                updated TEXT
            )
        """)
    else:
        c.execute("""
            CREATE TABLE IF NOT EXISTS takeoff_components(
                id INTEGER PRIMARY KEY,
                company_id INTEGER,
                project_id INTEGER,
                estimator_item_id INTEGER,
                component_name TEXT,
                description TEXT,
                unit TEXT,
                quantity REAL,
                confidence TEXT DEFAULT 'VERIFY',
                basis TEXT DEFAULT '',
                source_ref TEXT DEFAULT '',
                status TEXT DEFAULT 'PROPOSED',
                created TEXT,
                updated TEXT
            )
        """)
    try:
        c.execute("""CREATE INDEX IF NOT EXISTS idx_takeoff_components_parent
                     ON takeoff_components(company_id,project_id,estimator_item_id)""")
    except Exception:
        pass
    c.commit()
    c.close()


def _component_split_prompt(rows):
    lines=[]
    for r in rows:
        lines.append(
            f'ESTIMATOR_ID={r["id"]} | TRADE={r["trade"]} | '
            f'SCOPE={r["description"]} | SOURCE={r["source_ref"] or ""}'
        )
    return """You are BuildCommand Takeoff Component Splitter.

Break each construction estimator scope item into separate measurable takeoff components ONLY when the scope contains multiple distinct measurable objects or measurement types.

RULES:
- Preserve the parent trade. Do not reclassify.
- Do not invent quantities.
- One component should normally have one measurement unit.
- Use EA for countable fixtures/equipment/devices, LF for linear work, SF for area work, CY for volume, LS for coordination/non-measurable scope.
- Do not split a simple single-measurement scope unnecessarily.
- Example: "Provide exhaust fan, roof curb, backdraft damper and full-size duct" becomes exhaust fan EA; roof curb EA; backdraft damper EA; exhaust duct LF.
- Example: "Provide water closets, lavatories, floor drains and domestic water piping" becomes water closets EA; lavatories EA; floor drains EA; domestic water piping LF.
- Keep the same source reference unless a more specific source is obvious.
- Return JSON only.

Return:
{
  "results":[
    {
      "estimator_id":123,
      "components":[
        {"name":"Exhaust fan EF-1","description":"Provide EF-1 exhaust fan","unit":"EA","source":"M401"},
        {"name":"Exhaust duct","description":"Provide full-size exhaust duct","unit":"LF","source":"M401"}
      ]
    }
  ]
}

ESTIMATOR SCOPE ITEMS
---------------------
""" + "\n".join(lines)


@app.post("/brain/takeoff/split-components",response_class=HTMLResponse)
def split_takeoff_components():
    pid=project_id()
    _seed_estimator_from_latest(pid)
    _ensure_takeoff_component_tables()
    run=_latest_blueprint_run(pid)
    if not run:
        return shell("Takeoff Components",'<div class="card"><h2>No current plan analysis found.</h2></div>')

    c=db()
    rows=c.execute("""
        SELECT e.*
        FROM estimator_items e
        JOIN blueprint_scope_items b ON b.id=e.blueprint_scope_item_id
        WHERE e.company_id=? AND e.project_id=? AND b.run_id=?
        ORDER BY e.trade,e.id
        LIMIT 180
    """,(current_company_id(),pid,run["id"])).fetchall()
    c.close()

    if not rows:
        return shell("Takeoff Components",'<div class="card"><h2>No estimator items found.</h2></div>')
    if not os.environ.get("OPENAI_API_KEY"):
        return shell("Takeoff Components",'<div class="card"><h2>OPENAI_API_KEY is not configured.</h2></div>')

    try:
        client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp=client.responses.create(
            model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
            input=_component_split_prompt(rows)
        )
        data=_v36_parse_json(resp.output_text)
        valid={int(r["id"]):r for r in rows}
        now=datetime.utcnow().isoformat()
        c=db()
        created=0

        for result in data.get("results") or []:
            try:
                eid=int(result.get("estimator_id"))
            except Exception:
                continue
            if eid not in valid:
                continue

            comps=result.get("components") or []
            if len(comps)<=1:
                continue

            c.execute("""DELETE FROM takeoff_components
                         WHERE company_id=? AND project_id=? AND estimator_item_id=? AND status='PROPOSED'""",
                      (current_company_id(),pid,eid))

            for comp in comps[:25]:
                name=str(comp.get("name") or "").strip()
                desc=str(comp.get("description") or name).strip()
                unit=str(comp.get("unit") or "").upper()
                if not name or unit not in {"EA","LF","SF","CY","LS","HR","DAY","TON","GAL"}:
                    continue
                source=str(comp.get("source") or valid[eid]["source_ref"] or "")
                c.execute("""
                    INSERT INTO takeoff_components(
                        company_id,project_id,estimator_item_id,component_name,description,
                        unit,quantity,confidence,basis,source_ref,status,created,updated
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,(current_company_id(),pid,eid,name,desc,unit,None,"VERIFY",
                     "Component split from cleaned parent scope; quantity not yet verified.",
                     source,"PROPOSED",now,now))
                created+=1

        c.commit()
        c.close()

        body = (
            '<div class="hero"><div class="eyebrow">BuildCommand · v36.1</div>'
            '<h1>Takeoff components created.</h1></div>'
            f'<div class="card"><div class="kpi">{created}</div>'
            '<div class="muted">measurable child components created without changing the parent scopes.</div>'
            '<p><a href="/brain/takeoff/components"><b>Review components →</b></a></p></div>'
        )
        return shell("Takeoff Components",body)

    except Exception as exc:
        return shell(
            "Takeoff Components",
            f'<div class="card"><h2>Component split did not complete.</h2><p>{esc(str(exc))}</p></div>'
        )


@app.get("/brain/takeoff/components",response_class=HTMLResponse)
def takeoff_components_page():
    pid=project_id()
    _ensure_takeoff_component_tables()
    c=db()
    rows=c.execute("""
        SELECT tc.*,e.trade,e.description parent_description
        FROM takeoff_components tc
        JOIN estimator_items e ON e.id=tc.estimator_item_id
        WHERE tc.company_id=? AND tc.project_id=?
        ORDER BY e.trade,tc.estimator_item_id,tc.id
    """,(current_company_id(),pid)).fetchall()
    c.close()

    cards=[]
    for r in rows:
        qty="" if r["quantity"] is None else r["quantity"]
        confidence_options=''.join(
            f'<option {"selected" if r["confidence"]==x else ""}>{x}</option>'
            for x in ["HIGH","MEDIUM","LOW","VERIFY"]
        )
        status_options=''.join(
            f'<option {"selected" if r["status"]==x else ""}>{x}</option>'
            for x in ["PROPOSED","ACCEPTED","VERIFIED"]
        )

        cards.append(
            f'<div class="card">'
            f'<div class="small">{esc(r["trade"])} · Parent estimator item #{r["estimator_item_id"]}</div>'
            f'<h3>{esc(r["component_name"])}</h3>'
            f'<div>{esc(r["description"])}</div>'
            f'<div class="small">Source: {esc(r["source_ref"] or "")}</div>'
            f'<form method="post" action="/brain/takeoff/component/{r["id"]}" style="margin-top:10px">'
            '<div class="grid4">'
            f'<div><label>Qty</label><input name="quantity" type="number" step="0.01" value="{qty}"></div>'
            f'<div><label>Unit</label><input name="unit" value="{esc(r["unit"] or "")}"></div>'
            f'<div><label>Confidence</label><select name="confidence">{confidence_options}</select></div>'
            f'<div><label>Status</label><select name="status">{status_options}</select></div>'
            '</div>'
            f'<label>Basis / note</label><input name="basis" value="{esc(r["basis"] or "")}">'
            '<button type="submit" style="margin-top:10px">Save Component</button>'
            '</form></div>'
        )

    body = (
        '<div class="hero"><div class="eyebrow">Takeoff Component Splitter · v36.1</div>'
        '<h1>One scope. Separate measurable pieces.</h1></div>'
        '<div class="card"><p><a href="/brain/takeoff">← Back to Takeoff Intelligence</a></p></div>'
        + ("".join(cards) if cards else '<div class="card"><h2>No split components yet.</h2></div>')
    )
    return shell("Takeoff Components",body)


@app.post("/brain/takeoff/component/{component_id}")
def update_takeoff_component(component_id:int,quantity:str=Form(""),unit:str=Form("EA"),
                             confidence:str=Form("VERIFY"),status:str=Form("PROPOSED"),
                             basis:str=Form("")):
    pid=project_id()
    try:
        q=float(quantity) if str(quantity).strip() else None
    except Exception:
        q=None

    unit=unit.upper().strip()
    if unit not in {"EA","LF","SF","CY","LS","HR","DAY","TON","GAL"}:
        unit="EA"
    if confidence not in {"HIGH","MEDIUM","LOW","VERIFY"}:
        confidence="VERIFY"
    if status not in {"PROPOSED","ACCEPTED","VERIFIED"}:
        status="PROPOSED"

    c=db()
    c.execute("""UPDATE takeoff_components SET quantity=?,unit=?,confidence=?,status=?,basis=?,updated=?
                 WHERE id=? AND company_id=? AND project_id=?""",
              (q,unit,confidence,status,basis,datetime.utcnow().isoformat(),
               component_id,current_company_id(),pid))
    c.commit()
    c.close()
    return RedirectResponse("/brain/takeoff/components",status_code=303)


def _v36_latest_plan_docs(pid):
    run=_latest_blueprint_run(pid)
    if not run:
        return run,[]
    try:
        names=json.loads(run["source_files"] or "[]")
    except Exception:
        names=[]
    docs=[]
    c=db()
    for name in names:
        d=c.execute("""
            SELECT * FROM attachments
            WHERE company_id=? AND project_id=? AND original_name=?
            ORDER BY id DESC LIMIT 1
        """,(current_company_id(),pid,name)).fetchone()
        if d:
            docs.append(d)
    c.close()
    return run,docs


def _v36_scope_targets(pid,run_id):
    c=db()
    rows=c.execute("""
        SELECT e.id estimator_id,e.trade,e.description,e.source_ref,e.quantity,e.unit,e.verified,
               b.id scope_item_id,b.confidence scope_confidence
        FROM estimator_items e
        JOIN blueprint_scope_items b ON b.id=e.blueprint_scope_item_id
        WHERE e.company_id=? AND e.project_id=? AND b.run_id=?
        ORDER BY e.trade,e.id
        LIMIT 180
    """,(current_company_id(),pid,run_id)).fetchall()
    c.close()
    return rows


def _v36_takeoff_prompt(targets):
    lines=[]
    for r in targets:
        lines.append(
            f'ESTIMATOR_ID={r["estimator_id"]} | TRADE={r["trade"]} | '
            f'DESCRIPTION={r["description"]} | SOURCE={r["source_ref"] or ""} | '
            f'SUGGESTED_UNIT={_suggest_takeoff_unit(r["trade"],r["description"])}'
        )
    return """You are BuildCommand Automatic Plan Takeoff Brain.

Analyze the attached construction plan PDFs visually and textually against the TAKEOFF TARGETS below.

STRICT RULES:
1. Never guess a quantity.
2. Return a numeric quantity only when the documents provide enough evidence to count or calculate it with reasonable confidence.
3. Prefer explicit schedules, legends, tagged fixture/equipment counts, door/window schedules, device plans, room finish schedules, and clearly dimensioned/calculable information.
4. Do NOT infer scaled LF/SF/CY measurements from a drawing image unless a reliable explicit scale/dimension and geometry are sufficiently clear. If not, return quantity=null and confidence=VERIFY.
5. A scope statement that says "provide doors" is not itself proof of the number of doors. Use schedules/plans as evidence.
6. Avoid double-counting the same tagged object shown on multiple sheets/details.
7. Preserve trade ownership from the supplied target; this task is quantity extraction, not reclassification.
8. For each non-null quantity, cite the best supporting sheet/schedule/detail in source and briefly explain the basis.
9. Confidence must be HIGH, MEDIUM, LOW, or VERIFY.
10. Return JSON only.

Return:
{
  "results":[
    {
      "estimator_id":123,
      "quantity":12,
      "unit":"EA",
      "confidence":"HIGH",
      "basis":"12 unique door marks listed in the door schedule.",
      "source":"A601 Door Schedule"
    },
    {
      "estimator_id":124,
      "quantity":null,
      "unit":"SF",
      "confidence":"VERIFY",
      "basis":"Area requires scaled takeoff; no reliable explicit area found.",
      "source":"A201/A801"
    }
  ],
  "review_notes":[]
}

TAKEOFF TARGETS
----------------
"""+"\n".join(lines)


def _v36_parse_json(raw):
    s=(raw or "").strip()
    if s.startswith("```"):
        s=re.sub(r"^```(?:json)?\s*","",s,flags=re.I)
        s=re.sub(r"\s*```$","",s)
    start=s.find("{"); end=s.rfind("}")
    if start>=0 and end>start:
        s=s[start:end+1]
    return json.loads(s)


@app.post("/brain/takeoff/auto",response_class=HTMLResponse)
def automatic_plan_takeoff():
    pid=project_id()
    _seed_estimator_from_latest(pid)
    run,docs=_v36_latest_plan_docs(pid)
    if not run:
        return shell("Automatic Takeoff",'<div class="card"><h2>No Plan Intelligence run found.</h2><p>Run Plan Intake first.</p></div>')
    if not docs:
        return shell("Automatic Takeoff",'<div class="card"><h2>Source plan files are unavailable.</h2><p>BuildCommand found the scope run but could not locate its original project attachments.</p></div>')
    if not os.environ.get("OPENAI_API_KEY"):
        return shell("Automatic Takeoff",'<div class="card"><h2>OPENAI_API_KEY is not configured.</h2></div>')

    targets=_v36_scope_targets(pid,run["id"])
    if not targets:
        return shell("Automatic Takeoff",'<div class="card"><h2>No current estimator targets found.</h2></div>')

    total=sum(int(d["size_bytes"] or 0) for d in docs if Path(d["original_name"] or "").suffix.lower()==".pdf")
    if total>=50*1024*1024:
        return shell("Automatic Takeoff",f'<div class="card"><h2>Plan set too large for one automatic takeoff pass.</h2><p>Current PDF total: {total/1024/1024:.1f} MB. Run Plan Intake in smaller volumes before automatic takeoff.</p></div>')

    client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    uploaded=[]; content=[]
    try:
        for d in docs:
            path=os.path.join(UPLOAD_DIR,d["stored_name"])
            if not os.path.isfile(path):
                continue
            if Path(d["original_name"] or "").suffix.lower()==".pdf":
                with open(path,"rb") as fh:
                    remote=client.files.create(file=fh,purpose="user_data")
                uploaded.append(remote.id)
                content.append({"type":"input_file","file_id":remote.id})
        if not content:
            return shell("Automatic Takeoff",'<div class="card"><h2>No PDF plan files were available for visual takeoff.</h2></div>')

        content.append({"type":"input_text","text":_v36_takeoff_prompt(targets)})
        response=client.responses.create(
            model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
            input=[{"role":"user","content":content}]
        )
        data=_v36_parse_json(response.output_text)
        results=data.get("results") or []
        valid_ids={int(r["estimator_id"]) for r in targets}
        now=datetime.utcnow().isoformat()
        saved=0; proposed=0; verify=0
        c=db()
        for item in results:
            try:
                eid=int(item.get("estimator_id"))
            except Exception:
                continue
            if eid not in valid_ids:
                continue
            q=item.get("quantity")
            try:
                q=float(q) if q is not None else None
            except Exception:
                q=None
            unit=str(item.get("unit") or "").upper().strip()
            if unit not in {"EA","LF","SF","CY","LS","HR","DAY","TON","GAL"}:
                unit=""
            confidence=str(item.get("confidence") or "VERIFY").upper()
            if confidence not in {"HIGH","MEDIUM","LOW","VERIFY"}:
                confidence="VERIFY"
            basis=str(item.get("basis") or "")[:4000]
            source=str(item.get("source") or "")[:1500]
            # Only present usable proposals; never overwrite estimator-entered quantity.
            c.execute("""
                UPDATE estimator_items
                SET ai_quantity=?,ai_unit=?,ai_confidence=?,ai_basis=?,ai_source=?,ai_updated=?
                WHERE id=? AND company_id=? AND project_id=?
            """,(q,unit,confidence,basis,source,now,eid,current_company_id(),pid))
            saved+=1
            if q is not None and confidence in {"HIGH","MEDIUM"}:
                proposed+=1
            else:
                verify+=1
        c.commit(); c.close()

        notes=data.get("review_notes") or []
        note_html="".join(f'<div class="action">{esc(n)}</div>' for n in notes)
        body=f"""
        <div class="hero">
          <div class="eyebrow">BuildCommand Brain · Automatic Plan Takeoff · v36</div>
          <h1>Automatic takeoff pass complete.</h1>
        </div>
        <div class="grid3">
          <div class="card"><div class="label">Targets reviewed</div><div class="kpi">{saved}</div></div>
          <div class="card"><div class="label">Quantity proposals</div><div class="kpi">{proposed}</div></div>
          <div class="card"><div class="label">Needs verification</div><div class="kpi">{verify}</div></div>
        </div>
        <div class="card">
          <h2>Important</h2>
          <p>No estimator quantity was overwritten. AI results are proposals only. Review them on Takeoff Intelligence and accept only the quantities you trust.</p>
          <p><a href="/brain/takeoff"><b>Review takeoff proposals →</b></a></p>
        </div>
        {f'<div class="card"><h2>AI Review Notes</h2>{note_html}</div>' if note_html else ''}
        """
        return shell("Automatic Plan Takeoff",body)
    except Exception as exc:
        return shell("Automatic Takeoff",f'<div class="hero"><h1>Automatic takeoff did not complete.</h1></div><div class="card"><p>{esc(str(exc))}</p><p><a href="/brain/takeoff">← Back to Takeoff Intelligence</a></p></div>')
    finally:
        for fid in uploaded:
            try: client.files.delete(fid)
            except Exception: pass


@app.post("/brain/takeoff/item/{item_id}/accept-ai")
def accept_ai_takeoff(item_id:int):
    pid=project_id(); c=db()
    row=c.execute("""
        SELECT * FROM estimator_items
        WHERE id=? AND company_id=? AND project_id=?
    """,(item_id,current_company_id(),pid)).fetchone()
    if not row:
        c.close(); return HTMLResponse("Estimator item not found.",404)
    if row["ai_quantity"] is None or (row["ai_confidence"] or "") not in {"HIGH","MEDIUM"}:
        c.close()
        return shell("Takeoff Intelligence",'<div class="card"><h2>This AI quantity is not eligible for acceptance.</h2><p>Only HIGH or MEDIUM confidence numeric proposals can be accepted. Verify the item manually.</p><p><a href="/brain/takeoff">← Back</a></p></div>')
    unit=(row["ai_unit"] or row["unit"] or "EA").upper()
    c.execute("""
        UPDATE estimator_items
        SET quantity=?,unit=?,verified=0,notes=?,updated=?
        WHERE id=? AND company_id=? AND project_id=?
    """,(row["ai_quantity"],unit,
         ((row["notes"] or "")+" | AI takeoff accepted for estimator verification").strip(" |"),
         datetime.utcnow().isoformat(),item_id,current_company_id(),pid))
    c.commit(); c.close()
    return RedirectResponse("/brain/takeoff",status_code=303)


@app.get("/brain/takeoff", response_class=HTMLResponse)
def estimator_takeoff_intelligence():
    pid=project_id()
    sync=_seed_estimator_from_latest(pid)
    c=db()
    project=c.execute("SELECT name,number FROM projects WHERE id=?",(pid,)).fetchone()
    run=_latest_blueprint_run(pid)

    if run:
        rows=c.execute("""
            SELECT e.*
            FROM estimator_items e
            JOIN blueprint_scope_items b ON b.id=e.blueprint_scope_item_id
            WHERE e.company_id=? AND e.project_id=? AND b.run_id=?
            ORDER BY e.trade,e.id
        """,(current_company_id(),pid,run["id"])).fetchall()
    else:
        rows=[]
    c.close()

    counts={"NEEDS_TAKEOFF":0,"QUANTITY_ENTERED":0,"VERIFIED":0}
    cards=[]
    for r in rows:
        status=_takeoff_status(r)
        counts[status]+=1
        suggested=_suggest_takeoff_unit(r["trade"],r["description"])
        current_unit=(r["unit"] or "").strip()
        unit=current_unit or suggested
        badge = "READY" if status=="VERIFIED" else ("WATCH" if status=="QUANTITY_ENTERED" else "HIGH")

        cards.append(f"""
        <div class="card">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:center">
            <div><b>{esc(r["trade"])}</b></div>
            <span class="badge {badge}">{status.replace("_"," ")}</span>
          </div>
          <h3>{esc(r["description"])}</h3>
          <div class="small">Source: {esc(r["source_ref"] or "Source not identified")}</div>
          <div class="small" style="margin-top:6px">Suggested takeoff unit: <b>{esc(suggested)}</b></div>
          {(
            f'<div class="action" style="margin-top:10px"><b>AI PLAN TAKEOFF PROPOSAL:</b> '
            + (f'{r["ai_quantity"]:g} {esc(r["ai_unit"] or suggested)}' if r["ai_quantity"] is not None else 'VERIFY / no reliable quantity')
            + f' · Confidence: {esc(r["ai_confidence"] or "VERIFY")}<br>'
            + f'<span class="small">Basis: {esc(r["ai_basis"] or "")}<br>Source: {esc(r["ai_source"] or "")}</span>'
            + (f'<form method="post" action="/brain/takeoff/item/{r["id"]}/accept-ai" style="margin-top:8px"><button type="submit">Accept AI Quantity</button></form>'
               if r["ai_quantity"] is not None and (r["ai_confidence"] or "") in ["HIGH","MEDIUM"] else '')
            + '</div>'
          ) if (r["ai_confidence"] or r["ai_basis"] or r["ai_source"]) else ''}

          <form method="post" action="/brain/takeoff/item/{r["id"]}" style="margin-top:12px">
            <div class="grid4">
              <div>
                <label>Quantity</label>
                <input name="quantity" type="number" step="0.01" value="{r["quantity"] or 0}">
              </div>
              <div>
                <label>Unit</label>
                <select name="unit">
                  {''.join(f'<option value="{u}" {"selected" if unit==u else ""}>{u}</option>' for u in ["EA","LF","SF","CY","LS","HR","DAY","TON","GAL"])}
                </select>
              </div>
              <div>
                <label>Estimator verified</label>
                <select name="verified">
                  <option value="0" {"selected" if not r["verified"] else ""}>No</option>
                  <option value="1" {"selected" if r["verified"] else ""}>Yes</option>
                </select>
              </div>
              <div>
                <label>Takeoff note</label>
                <input name="notes" value="{esc(r["notes"] or "")}" placeholder="Counted on A201, verify addendum, etc.">
              </div>
            </div>
            <button type="submit" style="margin-top:10px">Save Takeoff</button>
          </form>
        </div>
        """)

    project_label=f'{esc(project["number"])} - {esc(project["name"])}' if project else "Current Project"
    body=f"""
    <div class="hero">
      <div class="eyebrow">BuildCommand Brain · Takeoff Intelligence · v36.1</div>
      <h1>Scope → measurable takeoff targets.</h1>
      <div class="muted">{project_label}</div>
    </div>

    <div class="grid4">
      <div class="card"><div class="label">Scope Items</div><div class="kpi">{len(rows)}</div></div>
      <div class="card"><div class="label">Needs Takeoff</div><div class="kpi">{counts["NEEDS_TAKEOFF"]}</div></div>
      <div class="card"><div class="label">Qty Entered</div><div class="kpi">{counts["QUANTITY_ENTERED"]}</div></div>
      <div class="card"><div class="label">Verified</div><div class="kpi">{counts["VERIFIED"]}</div></div>
    </div>

    <div class="card">
      <h2>How BuildCommand handles takeoffs</h2>
      <p>
        BuildCommand identifies what should be counted or measured and suggests the likely unit.
        It does <b>not invent a quantity</b>. Quantities remain estimator-entered or estimator-verified
        until a future scaled-drawing takeoff engine is connected.
      </p>
      <form method="post" action="/brain/takeoff/split-components" style="margin:14px 0">
        <button type="submit">Split Mixed Scopes into Takeoff Components</button>
      </form>
      <p><a href="/brain/takeoff/components"><b>Review Takeoff Components →</b></a></p>
      <form method="post" action="/brain/takeoff/auto" style="margin:14px 0">
        <button type="submit">Run Automatic Plan Takeoff</button>
      </form>
      <p class="small">AI proposals never overwrite estimator quantities. HIGH/MEDIUM proposals must still be accepted and then estimator-verified.</p>
      <p><a href="/brain/estimator"><b>← Back to Estimator Intelligence</b></a></p>
    </div>

    {"".join(cards) if cards else '<div class="card"><h2>No takeoff items yet</h2><p>Run Plan Intake first.</p></div>'}
    """
    return shell("Takeoff Intelligence",body)


@app.post("/brain/takeoff/item/{item_id}")
def estimator_takeoff_update(
    item_id:int,
    quantity:float=Form(0),
    unit:str=Form("EA"),
    verified:int=Form(0),
    notes:str=Form("")
):
    allowed={"EA","LF","SF","CY","LS","HR","DAY","TON","GAL"}
    unit=(unit or "EA").upper()
    if unit not in allowed:
        unit="EA"

    pid=project_id()
    c=db()
    c.execute("""
        UPDATE estimator_items
        SET quantity=?,unit=?,verified=?,notes=?,updated=?
        WHERE id=? AND company_id=? AND project_id=?
    """,(quantity,unit,verified,notes,datetime.utcnow().isoformat(),
         item_id,current_company_id(),pid))
    c.commit(); c.close()
    return RedirectResponse("/brain/takeoff",status_code=303)


@app.get("/brain/estimator",response_class=HTMLResponse)
def estimator_intelligence():
    pid=project_id(); sync=_seed_estimator_from_latest(pid); c=db()
    project=c.execute("SELECT name,number FROM projects WHERE id=?",(pid,)).fetchone()
    run=_latest_blueprint_run(pid)
    if run:
        rows=c.execute("""
            SELECT e.*
            FROM estimator_items e
            JOIN blueprint_scope_items b ON b.id=e.blueprint_scope_item_id
            WHERE e.company_id=? AND e.project_id=? AND b.run_id=?
            ORDER BY e.trade,e.id
        """,(current_company_id(),pid,run["id"])).fetchall()
    else:
        rows=[]
    c.close()
    trade_totals={}; grand=0.0; cards=[]
    for r in rows:
        direct,total=_estimate_math(r); grand+=total
        trade_totals[r["trade"]]=trade_totals.get(r["trade"],0)+total
        verify_label="✓ VERIFIED" if int(r["verified"] or 0) else "VERIFY"
        cards.append(f"""
        <div class="card">
          <div class="small">{esc(r["trade"])} · {verify_label}</div>
          <h3>{esc(r["description"])}</h3>
          <div class="small">Source: {esc(r["source_ref"] or "Source not identified")}</div>
          <form method="post" action="/brain/estimator/item/{r["id"]}">
            <div class="grid4" style="margin-top:12px">
              <div><label>Qty</label><input name="quantity" type="number" step="0.01" value="{r["quantity"] or 0}"></div>
              <div><label>Unit</label><input name="unit" value="{esc(r["unit"] or "")}" placeholder="EA, LF, SF"></div>
              <div><label>Material / unit</label><input name="material_unit_cost" type="number" step="0.01" value="{r["material_unit_cost"] or 0}"></div>
              <div><label>Labor / unit</label><input name="labor_unit_cost" type="number" step="0.01" value="{r["labor_unit_cost"] or 0}"></div>
            </div>
            <div class="grid4" style="margin-top:10px">
              <div><label>Sub quote</label><input name="subcontract_quote" type="number" step="0.01" value="{r["subcontract_quote"] or 0}"></div>
              <div><label>Allowance</label><input name="allowance" type="number" step="0.01" value="{r["allowance"] or 0}"></div>
              <div><label>Markup %</label><input name="markup_pct" type="number" step="0.01" value="{r["markup_pct"] or 0}"></div>
              <div><label>Verified</label><select name="verified"><option value="0" {"selected" if not r["verified"] else ""}>No</option><option value="1" {"selected" if r["verified"] else ""}>Yes</option></select></div>
            </div>
            <label style="margin-top:10px">Estimator notes</label><input name="notes" value="{esc(r["notes"] or "")}">
            <div style="margin-top:10px"><b>Extended total: ${total:,.2f}</b></div>
            <button type="submit" style="margin-top:10px">Save Estimate Item</button>
          </form>
        </div>""")
    totals="".join(f"<tr><td>{esc(k)}</td><td>${v:,.2f}</td></tr>" for k,v in sorted(trade_totals.items()))
    project_label=f'{esc(project["number"])} - {esc(project["name"])}' if project else "Current Project"
    body=f"""
    <div class="hero"><div class="eyebrow">BuildCommand Brain · Estimator Intelligence · v34.2</div>
      <h1>Plans → scope → estimate.</h1><div class="muted">{project_label}</div></div>
    <div class="grid2">
      <div class="card"><div class="label">Current Estimate</div><div class="kpi">${grand:,.2f}</div>
        <div class="small">{len(rows)} source-backed scope items · {sync["added"]} new · {sync["updated"]} refreshed</div></div>
      <div class="card"><h2>Estimator Brain Review</h2>
        <form method="post" action="/brain/estimator/review">
          <textarea name="focus" placeholder="Find bid gaps, allowances, long-lead items and takeoff verification needs."></textarea>
          <button type="submit">Analyze Estimate Risk</button>
        </form></div>
    </div>
    <div class="card"><h2>Takeoff Intelligence</h2><p>Turn cleaned scope items into quantity targets and verification status.</p><p><a href="/brain/takeoff"><b>Open Takeoff Intelligence →</b></a></p></div>
    <div class="card"><h2>Trade Totals</h2><table><tr><th>Trade</th><th>Current Total</th></tr>{totals}</table></div>
    <div class="card"><h2>Estimator rule</h2><p>BuildCommand organizes and identifies takeoff targets, but quantities and costs remain <b>unverified until an estimator confirms them</b>. Source references stay attached.</p></div>
    {"".join(cards) if cards else '<div class="card"><h2>No estimator items yet</h2><p>Run Plan Intake first, then return here.</p></div>'}"""
    return shell("Estimator Intelligence",body)


@app.post("/brain/estimator/item/{item_id}")
def estimator_item_update(item_id:int,quantity:float=Form(0),unit:str=Form(""),
    material_unit_cost:float=Form(0),labor_unit_cost:float=Form(0),
    subcontract_quote:float=Form(0),allowance:float=Form(0),
    markup_pct:float=Form(0),notes:str=Form(""),verified:int=Form(0)):
    pid=project_id(); c=db()
    c.execute("""UPDATE estimator_items SET quantity=?,unit=?,material_unit_cost=?,labor_unit_cost=?,
        subcontract_quote=?,allowance=?,markup_pct=?,notes=?,verified=?,updated=?
        WHERE id=? AND company_id=? AND project_id=?""",
        (quantity,unit,material_unit_cost,labor_unit_cost,subcontract_quote,allowance,
         markup_pct,notes,verified,datetime.utcnow().isoformat(),item_id,current_company_id(),pid))
    c.commit(); c.close()
    return RedirectResponse("/brain/estimator",status_code=303)


@app.post("/brain/estimator/review",response_class=HTMLResponse)
def estimator_brain_review(focus:str=Form("")):
    pid=project_id(); _seed_estimator_from_latest(pid); c=db()
    run=_latest_blueprint_run(pid)
    if run:
        rows=c.execute("""
            SELECT e.*
            FROM estimator_items e
            JOIN blueprint_scope_items b ON b.id=e.blueprint_scope_item_id
            WHERE e.company_id=? AND e.project_id=? AND b.run_id=?
            ORDER BY e.trade,e.id
        """,(current_company_id(),pid,run["id"])).fetchall()
    else:
        rows=[]
    c.close()
    lines=[]
    for r in rows:
        direct,total=_estimate_math(r)
        lines.append(f'{r["trade"]} | {r["description"]} | source={r["source_ref"]} | '
                     f'qty={r["quantity"]} {r["unit"]} | mat={r["material_unit_cost"]} | '
                     f'labor={r["labor_unit_cost"]} | sub={r["subcontract_quote"]} | '
                     f'allowance={r["allowance"]} | markup={r["markup_pct"]}% | total={total:.2f} | '
                     f'verified={bool(r["verified"])} | notes={r["notes"]}')
    api_key=os.environ.get("OPENAI_API_KEY")
    if not api_key:
        answer="OPENAI_API_KEY is not configured."
    else:
        try:
            client=OpenAI(api_key=api_key)
            resp=client.responses.create(
                model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
                instructions="""You are BuildCommand Estimator Intelligence.
Review source-backed scope items and estimator-entered values.
Do not invent quantities or prices. Treat zero/unverified entries as missing, not as confirmed zero scope.
Identify bid gaps, missing takeoffs, missing quotes, allowances, cross-trade coordination,
scope exclusions needing confirmation, long-lead/procurement concerns, and high-risk items.
Prioritize what an estimator must verify before bid submission.""",
                input=f"""ESTIMATE WORKSHEET
{chr(10).join(lines)}

ESTIMATOR FOCUS
{focus or "Full bid-risk review"}"""
            )
            answer=resp.output_text
        except Exception as exc:
            answer=f"Estimator Intelligence could not complete review: {exc}"
    body=f"""<div class="hero"><div class="eyebrow">Estimator Intelligence</div><h1>Bid Risk Review</h1></div>
    <div class="card"><div style="white-space:pre-wrap;line-height:1.6">{esc(answer)}</div>
    <p><a href="/brain/estimator">← Back to Estimate</a></p></div>"""
    return shell("Estimator Brain Review",body)


@app.get("/plans-specs-ai",response_class=HTMLResponse)
def plans_specs_ai():
    pid=project_id(); c=db()
    docs=c.execute("SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid)).fetchall()
    c.close()
    eligible=[d for d in docs if Path(d["original_name"] or "").suffix.lower() in {".pdf",".txt",".csv",".xlsx",".xlsm"}]
    checks="".join(f'<label style="display:flex;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.08)"><input type="checkbox" name="attachment_ids" value="{d["id"]}" style="width:auto"><span><b>{esc(d["original_name"])}</b><br><span class="small">{(int(d["size_bytes"] or 0)/1024/1024):.1f} MB</span></span></label>' for d in eligible) or '<div class="muted">No PDF/TXT/CSV/Excel project documents are uploaded yet. Use Documents first.</div>'
    run,scopes=_blueprint_latest(pid)
    latest='<div class="muted">No Blueprint Brain analysis has been run yet.</div>'
    if run:
        scope_cards="".join(f'<div class="action"><a href="/blueprint-brain/trade/{s["id"]}" style="font-weight:800">{esc(s["trade"])}</a> <span class="badge READY">{s["item_count"]} ITEMS</span><div class="small">Division {esc(s["division"] or "—")} · {esc(s["summary"] or "")}</div></div>' for s in scopes)
        flags=json.loads(run["cross_discipline_flags"] or "[]")
        rfis=json.loads(run["rfi_candidates"] or "[]")
        latest=f'<div class="small">LATEST RUN · {esc(run["created"] or "")}</div><h3>{esc(run["project_summary"] or "")}</h3><div style="margin:14px 0"><span class="badge READY">{len(scopes)} TRADES</span> <span class="badge WATCH">{len(flags)} CROSS-DISCIPLINE</span> <span class="badge HIGH">{len(rfis)} RFI CANDIDATES</span></div>{scope_cards}<p><a href="/blueprint-brain/run/{run["id"]}">Open full intelligence report →</a></p>'
    body=f'<div class="hero"><div class="eyebrow">BuildCommand Plan Intelligence</div><h1>Plans → trade scopes → field execution.</h1><div class="muted">Reads PDF plan pages visually and textually, finds cross-discipline requirements, preserves sources, generates trade scopes, and flags gaps for GC review.</div></div><div class="grid2"><div class="card"><h2>Analyze Plan Set</h2><form method="post" action="/plans-specs-ai/analyze">{checks}<label style="margin-top:16px">Analysis focus (optional)</label><textarea name="focus" placeholder="Example: Full bid/scope review, or focus on MEP coordination"></textarea><button type="submit">Run Blueprint Brain</button></form><p class="small">Selected files must total less than 50 MB. PDF page images use high-detail analysis. AI-generated scopes require superintendent/PM review before contractual use.</p></div><div class="card"><h2>Latest Blueprint Intelligence</h2>{latest}</div></div>'
    return shell("Blueprint Brain",body)


@app.post("/plans-specs-ai",response_class=HTMLResponse)
def plans_specs_ai_answer(attachment_id:int=Form(...),question:str=Form(...)):
    pid=project_id(); c=db(); d=c.execute("SELECT * FROM attachments WHERE id=? AND company_id=? AND project_id=?",(attachment_id,current_company_id(),pid)).fetchone(); c.close()
    if not d: return HTMLResponse("Document not found",404)
    content=_attachment_text(d)
    if not content: answer=f'BuildCommand can see "{d["original_name"]}", but no readable text was extracted. Use Blueprint Brain for PDF visual analysis.'
    elif not os.environ.get("OPENAI_API_KEY"): answer="OPENAI_API_KEY is not configured."
    else:
        try:
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
            r=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions="Answer only from the supplied construction document. Say when unsupported and never invent drawing references.",input=f"DOCUMENT:\n{content[:96000]}\nQUESTION:\n{question}")
            answer=r.output_text
        except Exception as e: answer=f"Document AI failed: {e}"
    return shell("Blueprint Brain",f'<div class="hero"><h1>{esc(d["original_name"])}</h1></div><div class="card"><h2>Answer</h2><div style="white-space:pre-wrap">{esc(answer)}</div></div>')


@app.post("/plans-specs-ai/analyze",response_class=HTMLResponse)
def blueprint_analyze(attachment_ids:list[int] | None=Form(None),focus:str=Form("")):
    pid=project_id(); company_id=current_company_id()
    if not os.environ.get("OPENAI_API_KEY"):
        return shell("Blueprint Brain",'<div class="card"><h2>OPENAI_API_KEY is not configured.</h2><p>Add it in Render Environment settings and redeploy.</p></div>')
    ids=list(dict.fromkeys(attachment_ids or []))
    if not ids:
        return shell("Blueprint Brain",'<div class="hero"><div class="eyebrow">Blueprint Brain</div><h1>Select a plan set first.</h1></div><div class="card"><p>Choose at least one PDF or supported project document, then click <b>Run Blueprint Brain</b>.</p><p><a href="/plans-specs-ai">← Back to Blueprint Brain</a></p></div>')
    c=db(); docs=[]
    for aid in ids:
        d=c.execute("SELECT * FROM attachments WHERE id=? AND company_id=? AND project_id=?",(aid,company_id,pid)).fetchone()
        if d: docs.append(d)
    c.close()
    if not docs: return HTMLResponse("No valid project documents were selected.",404)
    total=sum(int(d["size_bytes"] or 0) for d in docs)
    if total>=50*1024*1024:
        return shell("Blueprint Brain",f'<div class="card"><h2>Plan set is too large for one analysis request.</h2><p>Selected total: {total/1024/1024:.1f} MB. Keep each Blueprint Brain batch under 50 MB, then run the remaining volumes separately.</p></div>')
    model=os.environ.get("OPENAI_MODEL","gpt-5.6")
    client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    uploaded=[]; input_content=[]; text_fallback=[]
    try:
        for d in docs:
            path=os.path.join(UPLOAD_DIR,d["stored_name"])
            if not os.path.isfile(path):
                continue
            ext=Path(d["original_name"] or "").suffix.lower()
            if ext==".pdf":
                with open(path,"rb") as fh:
                    remote=client.files.create(file=fh,purpose="user_data")
                uploaded.append(remote.id)
                input_content.append({"type":"input_file","file_id":remote.id})
            else:
                extracted=_attachment_text(d)
                if extracted:
                    text_fallback.append(f"\n--- FILE: {d['original_name']} ---\n{extracted[:120000]}")
        if not input_content and not text_fallback:
            return HTMLResponse("No readable selected files were available on the server.",400)
        names="\n".join(f"- {d['original_name']}" for d in docs)
        prompt=_blueprint_prompt(names)
        if focus.strip(): prompt += "\n\nGC ANALYSIS FOCUS:\n"+focus.strip()
        if text_fallback: prompt += "\n\nEXTRACTED NON-PDF DOCUMENT CONTENT:\n"+"\n".join(text_fallback)
        input_content.append({"type":"input_text","text":prompt})
        response=client.responses.create(model=model,input=[{"role":"user","content":input_content}])
        data=_blueprint_json(response.output_text)
        if not isinstance(data.get("trade_scopes"),list):
            raise ValueError("Blueprint Brain response did not contain trade_scopes.")
        run_id=_save_blueprint_result(pid,docs,data,model)
        return RedirectResponse(f"/blueprint-brain/run/{run_id}",status_code=303)
    except Exception as exc:
        return shell("Blueprint Brain",f'<div class="hero"><div class="eyebrow">Blueprint Brain</div><h1>Analysis did not complete.</h1></div><div class="card"><p>{esc(str(exc))}</p><p><a href="/plans-specs-ai">← Back to Blueprint Brain</a></p></div>')
    finally:
        for fid in uploaded:
            try: client.files.delete(fid)
            except Exception: pass


@app.get("/blueprint-brain",response_class=HTMLResponse)
def blueprint_brain_home():
    pid=project_id()
    company=current_company_id()
    c=db()
    runs=c.execute(
        "SELECT * FROM blueprint_runs WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 25",
        (company,pid)
    ).fetchall()
    c.close()

    cards=""
    for r in runs:
        cards+=(
            f'<div class="card"><div class="small">Run #{r["id"]} · {esc(r["created"] or "")}</div>'
            f'<h3>{esc(r["project_summary"] or "Blueprint analysis")}</h3>'
            f'<p><a href="/blueprint-brain/run/{r["id"]}">Open analysis →</a></p></div>'
        )

    body=(
        '<div class="hero"><div class="eyebrow">Blueprint Brain</div>'
        '<h1>Source-backed trade scopes.</h1>'
        '<p class="muted">Review the latest analysis, run final trade cleanup, or start a new project analysis.</p></div>'
        '<div class="grid3">'
        +_v37_link_card("Analyze Project","Run the unified project intelligence pipeline on selected plans/specs.","/build/analyze-project","Analyze")
        +('<div class="card"><h2>Final Trade Cleanup</h2>'
             '<p class="muted">Normalize existing Blueprint Brain trade ownership and duplicate scopes.</p>'
             '<form method="post" action="/blueprint-brain/final-cleanup">'
             '<button type="submit">Run Final Trade Cleanup</button></form></div>')
        +_v37_link_card("Project Scope Review","Open the unified source-backed project scope view.","/brain","Review")
        +'</div>'
        '<div class="card"><h2>Recent Blueprint Runs</h2></div>'
        +(cards or '<div class="card"><p class="muted">No Blueprint Brain analyses yet.</p></div>')
    )
    return shell("Blueprint Brain",body)


@app.get("/blueprint-brain/run/{run_id}",response_class=HTMLResponse)
def blueprint_run_detail(run_id:int):
    pid=project_id(); c=db(); run=c.execute("SELECT * FROM blueprint_runs WHERE id=? AND company_id=? AND project_id=?",(run_id,current_company_id(),pid)).fetchone()
    if not run: c.close(); return HTMLResponse("Blueprint analysis not found.",404)
    scopes=c.execute("SELECT * FROM blueprint_trade_scopes WHERE run_id=? AND company_id=? AND project_id=? ORDER BY trade",(run_id,current_company_id(),pid)).fetchall(); c.close()
    def _arr(field):
        try: return json.loads(run[field] or "[]")
        except Exception: return []
    files=_arr("source_files"); disciplines=_arr("detected_disciplines"); flags=_arr("cross_discipline_flags"); rfis=_arr("rfi_candidates"); notes=_arr("review_notes")
    scope_cards="".join(f'<div class="card"><div class="small">DIVISION {esc(s["division"] or "—")}</div><h2>{esc(s["trade"])}</h2><p>{esc(s["summary"] or "")}</p><span class="badge READY">{s["item_count"]} SCOPE ITEMS</span><p><a href="/blueprint-brain/trade/{s["id"]}">Open trade scope →</a></p></div>' for s in scopes)
    def list_html(items,empty): return "".join(f'<div class="action">{esc(x)}</div>' for x in items) or f'<div class="muted">{esc(empty)}</div>'
    body=f'<div class="hero"><div class="eyebrow">Blueprint Intelligence Run #{run_id}</div><h1>{esc(run["project_summary"] or "Plan set analyzed")}</h1><div class="muted">Sources: {esc(", ".join(files))}</div></div><div class="grid3"><div class="card"><div class="label">Trades</div><div class="kpi">{len(scopes)}</div></div><div class="card"><div class="label">Cross-Discipline Flags</div><div class="kpi">{len(flags)}</div></div><div class="card"><div class="label">RFI Candidates</div><div class="kpi">{len(rfis)}</div></div></div><div class="card"><h2>Detected Disciplines</h2><p>{esc(" · ".join(disciplines) or "Not identified")}</p></div><div class="grid2"><div class="card"><h2>Cross-Discipline Requirements</h2>{list_html(flags,"No cross-discipline flags returned.")}</div><div class="card"><h2>Potential Scope Gaps / RFIs</h2>{list_html(rfis,"No RFI candidates returned.")}</div></div><div class="card"><h2>GC Review Notes</h2>{list_html(notes,"No additional review notes returned.")}</div><h2>Trade Scopes</h2><div class="grid2">{scope_cards}</div><div class="card"><p class="small"><b>BuildCommand review rule:</b> AI-generated scope intelligence is a coordination aid. Verify against the complete contract documents, addenda, RFIs, subcontract agreements, and design-professional direction before issuing contractual scope.</p></div>'
    return shell("Blueprint Intelligence",body)


@app.get("/blueprint-brain/trade/{scope_id}",response_class=HTMLResponse)
def blueprint_trade_scope(scope_id:int):
    pid=project_id(); c=db(); scope=c.execute("SELECT * FROM blueprint_trade_scopes WHERE id=? AND company_id=? AND project_id=?",(scope_id,current_company_id(),pid)).fetchone()
    if not scope: c.close(); return HTMLResponse("Trade scope not found.",404)
    items=c.execute("SELECT * FROM blueprint_scope_items WHERE trade_scope_id=? AND company_id=? AND project_id=? ORDER BY id",(scope_id,current_company_id(),pid)).fetchall(); c.close()
    cards=[]
    for item in items:
        refs=[]
        if item["source_sheet"]: refs.append("Sheet "+item["source_sheet"])
        if item["source_detail"]: refs.append("Detail "+item["source_detail"])
        if item["source_spec"]: refs.append("Spec "+item["source_spec"])
        if item["source_note"]: refs.append(item["source_note"])
        conf=item["confidence"] if item["confidence"] in {"HIGH","MEDIUM","LOW"} else "WATCH"
        typ=item["item_type"] or "SCOPE"
        confidence_badge="HIGH" if conf=="HIGH" else "WATCH"
        type_badge="HIGH" if typ=="RFI_CANDIDATE" else "WATCH" if typ in ["CROSS_DISCIPLINE","COORDINATION"] else "READY"
        related=(' · <b>Related trade:</b> '+esc(item["related_trade"])) if item["related_trade"] else ''
        options=''.join(f'<option {"selected" if item["status"]==st else ""}>{st}</option>' for st in ["NOT_STARTED","IN_PROGRESS","INSPECTION_REQUIRED","COMPLETE","VERIFIED"])
        trade_options=''.join(f'<option value="{esc(t)}" {"selected" if item["trade"]==t else ""}>{esc(t)}</option>' for t in V33_TRADES)
        cards.append(f'<div class="action"><span class="badge {confidence_badge}">{esc(item["confidence"])}</span> <span class="badge {type_badge}">{esc(typ)}</span><h3>{esc(item["requirement"])}</h3><div class="small"><b>Assigned trade:</b> {esc(item["trade"])} · <b>Source:</b> {esc(" · ".join(refs) or "Source not clearly identified")}{related}</div><div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px"><form method="post" action="/blueprint-brain/item/{item["id"]}/status"><select name="status">{options}</select><button type="submit">Update status</button></form><form method="post" action="/blueprint-brain/item/{item["id"]}/trade"><select name="trade">{trade_options}</select><select name="learn_scope"><option>PROJECT ONLY</option><option>COMPANY STANDARD</option></select><button type="submit">Move & Learn</button></form></div></div>')
    body=f'<div class="hero"><div class="eyebrow">Division {esc(scope["division"] or "—")} · Blueprint Brain</div><h1>{esc(scope["trade"])} Scope of Work</h1><div class="muted">{esc(scope["summary"] or "")}</div></div><div class="card"><p><a href="/blueprint-brain/run/{scope["run_id"]}">← Full Blueprint Intelligence</a> · <a href="/blueprint-brain/trade/{scope_id}/export.txt">Export scope text</a></p></div><div class="card"><h2>Scope Boiler</h2><div style="white-space:pre-wrap">{esc(scope["scope_text"] or "")}</div></div><div class="card"><h2>Execution Checklist</h2>{"".join(cards) or "<div class=muted>No scope items.</div>"}</div>'
    return shell(scope["trade"]+" Scope",body)


@app.post("/blueprint-brain/item/{item_id}/status")
def blueprint_item_status(item_id:int,status:str=Form(...)):
    allowed={"NOT_STARTED","IN_PROGRESS","INSPECTION_REQUIRED","COMPLETE","VERIFIED"}; status=status.upper()
    if status not in allowed: return HTMLResponse("Invalid status",400)
    pid=project_id(); c=db(); item=c.execute("SELECT trade_scope_id FROM blueprint_scope_items WHERE id=? AND company_id=? AND project_id=?",(item_id,current_company_id(),pid)).fetchone()
    if not item: c.close(); return HTMLResponse("Scope item not found",404)
    c.execute("UPDATE blueprint_scope_items SET status=? WHERE id=? AND company_id=? AND project_id=?",(status,item_id,current_company_id(),pid)); c.commit(); scope_id=item["trade_scope_id"]; c.close(); return RedirectResponse(f"/blueprint-brain/trade/{scope_id}",status_code=303)


@app.post("/blueprint-brain/item/{item_id}/trade")
def blueprint_item_trade(item_id:int,trade:str=Form(...),learn_scope:str=Form("PROJECT ONLY")):
    trade=_v33_normalize_trade(trade)
    if trade not in V33_TRADES:
        return HTMLResponse("Invalid trade",400)
    if learn_scope not in {"PROJECT ONLY","COMPANY STANDARD"}:
        learn_scope="PROJECT ONLY"

    pid=project_id(); company_id=current_company_id(); c=db()
    item=c.execute("SELECT * FROM blueprint_scope_items WHERE id=? AND company_id=? AND project_id=?",(item_id,company_id,pid)).fetchone()
    if not item:
        c.close(); return HTMLResponse("Scope item not found",404)

    old_trade=item["trade"]; old_scope_id=item["trade_scope_id"]; run_id=item["run_id"]
    target=c.execute("SELECT * FROM blueprint_trade_scopes WHERE run_id=? AND company_id=? AND project_id=? AND trade=?",(run_id,company_id,pid,trade)).fetchone()
    if not target:
        div={"GC / General Contractor":"01","Demolition":"02","Roofing":"07",
             "Doors / Frames / Hardware":"08","Storefront / Glazing":"08",
             "Flooring":"09","Tile":"09","Painting":"09","Framing / Drywall":"09",
             "Ceilings":"09","Specialties":"10","Plumbing":"22","HVAC / Mechanical":"23",
             "Electrical":"26","Fire Sprinkler":"21","Fire Alarm":"28","Low Voltage":"27"}.get(trade,"")
        now=datetime.utcnow().isoformat()
        c.execute("INSERT INTO blueprint_trade_scopes(company_id,project_id,run_id,trade,division,summary,scope_text,item_count,created) VALUES(?,?,?,?,?,?,?,?,?)",
                  (company_id,pid,run_id,trade,div,f"BuildCommand classified scope for {trade}.","",0,now))
        target_id=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    else:
        target_id=target["id"]

    c.execute("UPDATE blueprint_scope_items SET trade=?,trade_scope_id=? WHERE id=? AND company_id=? AND project_id=?",
              (trade,target_id,item_id,company_id,pid))
    for sid in {old_scope_id,target_id}:
        count=c.execute("SELECT COUNT(*) n FROM blueprint_scope_items WHERE trade_scope_id=? AND company_id=? AND project_id=?",(sid,company_id,pid)).fetchone()["n"]
        c.execute("UPDATE blueprint_trade_scopes SET item_count=? WHERE id=? AND company_id=? AND project_id=?",(count,sid,company_id,pid))
    c.commit(); c.close()

    if old_trade != trade:
        _v43_ensure_tables()
        c=db(); now=datetime.utcnow().isoformat()
        subject=str(item["requirement"] or "")[:220]
        c.execute("""INSERT INTO learning_rules(
            company_id,project_id,rule_type,subject,learned_rule,source_ref,scope_level,
            approval_status,approved_by,confidence,created,updated
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (company_id,pid,"TRADE ASSIGNMENT",subject,f"{old_trade} -> {trade}",
         "Blueprint manual correction",learn_scope,"APPROVED",
         str(current_user_id()),"HIGH",now,now))
        c.commit(); c.close()

    return RedirectResponse(f"/blueprint-brain/trade/{target_id}",status_code=303)


@app.get("/blueprint-brain/trade/{scope_id}/export.txt")
def blueprint_trade_export(scope_id:int):
    pid=project_id(); c=db(); scope=c.execute("SELECT * FROM blueprint_trade_scopes WHERE id=? AND company_id=? AND project_id=?",(scope_id,current_company_id(),pid)).fetchone(); c.close()
    if not scope: return HTMLResponse("Trade scope not found.",404)
    header=f"BuildCommand AI - {scope['trade']} Scope of Work\nDivision {scope['division'] or '—'}\n\n"
    footer="\n\nGC REVIEW REQUIRED: Verify this AI-generated scope against the complete contract documents, addenda, RFIs, subcontract agreement, and design-professional direction before contractual use.\n"
    filename=re.sub(r"[^A-Za-z0-9_-]+","_",scope["trade"] or "trade")+"_scope.txt"
    return Response(content=header+(scope["scope_text"] or "")+footer,media_type="text/plain",headers={"Content-Disposition":f'attachment; filename="{filename}"'})


@app.get("/schedule-import",response_class=HTMLResponse)
def schedule_import_page():
    return shell("Schedule Import",'''<div class="hero"><div class="eyebrow">Schedule Import</div><h1>Import schedule activities from CSV.</h1><div class="muted">Headers: external_id,name,trade,start,finish,pct,status</div></div><div class="card"><form method="post" action="/schedule-import" enctype="multipart/form-data"><input type="file" name="file" accept=".csv" required><button>Import Schedule</button></form></div>''')


@app.post("/schedule-import")
async def schedule_import(file:UploadFile=File(...)):
    pid=project_id(); raw=await file.read()
    try: decoded=raw.decode("utf-8-sig")
    except Exception: return HTMLResponse("CSV must be UTF-8",400)
    reader=csv.DictReader(io.StringIO(decoded)); req={"external_id","name","trade","start","finish","pct","status"}
    if not req.issubset(set(reader.fieldnames or [])): return HTMLResponse("CSV missing required headers",400)
    rows=list(reader); c=db(); imported=0
    for row in rows:
        ext=(row.get("external_id") or "").strip(); name=(row.get("name") or "").strip()
        if not ext or not name: continue
        trade=(row.get("trade") or "").strip(); start=(row.get("start") or "").strip(); finish=(row.get("finish") or "").strip(); pct=float(row.get("pct") or 0); status=(row.get("status") or "NOT_STARTED").strip().upper()
        ex=c.execute("SELECT id FROM activities WHERE project_id=? AND external_id=?",(pid,ext)).fetchone()
        if ex:
            c.execute("UPDATE activities SET name=?,trade=?,start=?,finish=?,pct=?,status=? WHERE id=? AND project_id=?",(name,trade,start,finish,pct,status,ex["id"],pid))
        else:
            c.execute("INSERT INTO activities(project_id,external_id,name,trade,start,finish,pct,status) VALUES(?,?,?,?,?,?,?,?)",(pid,ext,name,trade,start,finish,pct,status))
        imported+=1
    c.execute("INSERT INTO schedule_import_batches(company_id,project_id,file_name,row_count,imported_count,created) VALUES(?,?,?,?,?,?)",(current_company_id(),pid,safe_filename(file.filename),len(rows),imported,datetime.utcnow().isoformat()))
    c.commit(); c.close()
    return RedirectResponse("/schedule",303)


def ensure_v29_tables():
    c=db()
    c.execute("CREATE TABLE IF NOT EXISTS photo_observations(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,attachment_id INTEGER,activity_id INTEGER,observation TEXT,severity TEXT DEFAULT 'WATCH',created TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS weather_impacts(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,activity_id INTEGER,impact_date TEXT,weather_type TEXT,lost_hours REAL DEFAULT 0,description TEXT,created TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS schedule_import_batches(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,file_name TEXT,row_count INTEGER DEFAULT 0,imported_count INTEGER DEFAULT 0,created TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS communication_drafts(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,sub_id INTEGER,draft_type TEXT,subject TEXT,body TEXT,status TEXT DEFAULT 'DRAFT',created TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS meeting_ai_summaries(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,source_text TEXT,summary_text TEXT,created TEXT)")
    c.commit(); c.close()


@app.get("/photo-intelligence",response_class=HTMLResponse)
def photo_intelligence():
    ensure_v29_tables()
    pid=project_id(); c=db()
    photos=c.execute(
        """
        SELECT *
        FROM attachments
        WHERE company_id=? AND project_id=?
          AND (
            lower(COALESCE(mime_type,'')) LIKE ?
            OR lower(COALESCE(original_name,'')) LIKE ?
            OR lower(COALESCE(original_name,'')) LIKE ?
            OR lower(COALESCE(original_name,'')) LIKE ?
            OR lower(COALESCE(original_name,'')) LIKE ?
          )
        ORDER BY id DESC
        """,
        (
            current_company_id(),
            pid,
            "image/%",
            "%.jpg",
            "%.jpeg",
            "%.png",
            "%.webp"
        )
    ).fetchall()
    obs=c.execute("SELECT p.*,a.original_name FROM photo_observations p LEFT JOIN attachments a ON a.id=p.attachment_id WHERE p.company_id=? AND p.project_id=? ORDER BY p.id DESC LIMIT 25",(current_company_id(),pid)).fetchall()
    c.close()
    opts="".join(f'<option value="{p["id"]}">{esc(p["original_name"])}</option>' for p in photos) or '<option value="">No photos uploaded</option>'
    recent="".join(f'<div class="action"><span class="badge {o["severity"]}">{esc(o["severity"])}</span> <b>{esc(o["original_name"] or "Photo")}</b><div>{esc(o["observation"])}</div></div>' for o in obs) or '<div class="muted">No observations yet.</div>'
    return shell("Photo Intelligence",f'''<div class="hero"><div class="eyebrow">Field Photo Intelligence</div><h1>Document photo observations.</h1></div><div class="grid2"><div class="card"><form method="post" action="/photo-intelligence"><select name="attachment_id">{opts}</select><textarea name="observation" required></textarea><select name="severity"><option>LOW</option><option selected>WATCH</option><option>HIGH</option><option>CRITICAL</option></select><button>Save Observation</button></form></div><div class="card">{recent}</div></div>''')


@app.post("/photo-intelligence")
def photo_intelligence_save(attachment_id:int=Form(...),observation:str=Form(...),severity:str=Form("WATCH")):
    ensure_v29_tables()
    pid=project_id(); c=db()
    c.execute("INSERT INTO photo_observations(company_id,project_id,attachment_id,activity_id,observation,severity,created) VALUES(?,?,?,NULL,?,?,?)",(current_company_id(),pid,attachment_id,observation.strip(),severity,datetime.utcnow().isoformat()))
    c.commit(); c.close(); return RedirectResponse("/photo-intelligence",303)


@app.get("/rfi-drafting",response_class=HTMLResponse)
def rfi_drafting():
    return shell("RFI Drafting",'''<div class="hero"><div class="eyebrow">AI RFI Drafting</div><h1>Turn a field issue into a professional RFI.</h1></div><div class="card"><form method="post" action="/rfi-drafting"><textarea name="field_issue" required></textarea><button>Draft RFI</button></form></div>''')


@app.post("/rfi-drafting",response_class=HTMLResponse)
def rfi_drafting_generate(field_issue:str=Form(...)):
    context=build_project_context(project_id())
    if os.environ.get("OPENAI_API_KEY"):
        try:
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"]); r=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions="Draft a professional construction RFI. Return SUBJECT, BACKGROUND, QUESTION, POTENTIAL IMPACT. Do not invent drawing/spec numbers, dates or costs.",input=f"{context}\nFIELD ISSUE:\n{field_issue}"); draft=r.output_text
        except Exception as e: draft=f"AI RFI drafting failed: {e}"
    else: draft="OPENAI_API_KEY is not configured."
    return shell("RFI Drafting",f'''<div class="hero"><h1>Draft Ready</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(draft)}</div></div><div class="card"><form method="post" action="/rfi-drafting/save"><input type="hidden" name="title" value="{esc(field_issue[:120])}"><textarea name="description">{esc(draft)}</textarea><button>Save to RFIs</button></form></div>''')


@app.post("/rfi-drafting/save")
def rfi_drafting_save(title:str=Form(...),description:str=Form(...)):
    pid=project_id(); c=db()
    c.execute("INSERT INTO project_issues(project_id,activity_id,issue_type,title,owner,due,priority,status,description,response,created) VALUES(?,NULL,'RFI',?,'',?,'WATCH','OPEN',?,'',?)",(pid,title.strip(),date.today().isoformat(),description.strip(),date.today().isoformat()))
    c.commit(); c.close(); return RedirectResponse("/issues",303)


@app.get("/sub-communications",response_class=HTMLResponse)
def sub_communications():
    pid=project_id(); c=db(); subs=c.execute("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(pid,)).fetchall(); drafts=c.execute("SELECT d.*,s.name sub_name FROM communication_drafts d LEFT JOIN subs s ON s.id=d.sub_id WHERE d.company_id=? AND d.project_id=? ORDER BY d.id DESC LIMIT 20",(current_company_id(),pid)).fetchall(); c.close()
    opts="".join(f'<option value="{s["id"]}">{esc(s["name"])} - {esc(s["trade"])}</option>' for s in subs)
    recent="".join(f'<div class="action"><b>{esc(d["draft_type"])}</b> · {esc(d["sub_name"] or "")}<div>{esc(d["subject"])}</div></div>' for d in drafts) or '<div class="muted">No drafts yet.</div>'
    return shell("Sub Communications",f'''<div class="hero"><div class="eyebrow">Subcontractor Communications</div><h1>Generate field follow-ups.</h1></div><div class="grid2"><div class="card"><form method="post" action="/sub-communications"><select name="sub_id">{opts}</select><select name="draft_type"><option>MANPOWER_REQUEST</option><option>DELAY_NOTICE</option><option>COORDINATION</option><option>FOLLOW_UP</option></select><textarea name="prompt" required></textarea><button>Generate Draft</button></form></div><div class="card">{recent}</div></div>''')


@app.post("/sub-communications",response_class=HTMLResponse)
def sub_communications_generate(sub_id:int=Form(...),draft_type:str=Form(...),prompt:str=Form(...)):
    pid=project_id(); c=db(); sub=c.execute("SELECT * FROM subs WHERE id=? AND project_id=?",(sub_id,pid)).fetchone(); c.close()
    if os.environ.get("OPENAI_API_KEY") and sub:
        try:
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"]); r=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions="Write a concise professional subcontractor communication. Firm, collaborative, no invented dates or contract terms.",input=f"SUB: {sub['name']} {sub['trade']}\nTYPE: {draft_type}\nNEED: {prompt}"); body=r.output_text
        except Exception as e: body=f"AI communication failed: {e}"
    else: body=prompt
    subject=f"{draft_type.replace('_',' ').title()} - {sub['name'] if sub else 'Subcontractor'}"
    c=db(); c.execute("INSERT INTO communication_drafts(company_id,project_id,sub_id,draft_type,subject,body,status,created) VALUES(?,?,?,?,?,?,'DRAFT',?)",(current_company_id(),pid,sub_id,draft_type,subject,body,datetime.utcnow().isoformat())); c.commit(); c.close()
    return shell("Sub Communications",f'<div class="hero"><h1>{esc(subject)}</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(body)}</div></div>')


@app.get("/meeting-minutes-ai",response_class=HTMLResponse)
def meeting_minutes_ai():
    return shell("AI Meeting Minutes",'''<div class="hero"><div class="eyebrow">Meeting Minutes AI</div><h1>Turn raw notes into decisions and actions.</h1></div><div class="card"><form method="post" action="/meeting-minutes-ai"><textarea name="source_text" required style="min-height:250px"></textarea><button>Generate Minutes</button></form></div>''')


@app.post("/meeting-minutes-ai",response_class=HTMLResponse)
def meeting_minutes_ai_generate(source_text:str=Form(...)):
    pid=project_id()
    if os.environ.get("OPENAI_API_KEY"):
        try:
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"]); r=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions="Convert construction meeting notes into DECISIONS, COMMITMENTS, ACTION ITEMS, RISKS/ISSUES, FOLLOW-UP. Do not invent owners or dates.",input=source_text); summary=r.output_text
        except Exception as e: summary=f"AI minutes failed: {e}"
    else: summary=source_text
    c=db(); c.execute("INSERT INTO meeting_ai_summaries(company_id,project_id,source_text,summary_text,created) VALUES(?,?,?,?,?)",(current_company_id(),pid,source_text,summary,datetime.utcnow().isoformat())); c.commit(); c.close()
    return shell("AI Meeting Minutes",f'''<div class="hero"><h1>Minutes Ready</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(summary)}</div></div><div class="card"><form method="post" action="/meeting-minutes-ai/save"><textarea name="summary">{esc(summary)}</textarea><button>Save to Meetings</button></form></div>''')


@app.post("/meeting-minutes-ai/save")
def meeting_minutes_ai_save(summary:str=Form(...)):
    pid=project_id(); c=db(); c.execute("INSERT INTO meeting_notes(project_id,meeting_date,meeting_type,title,attendees,decisions,commitments,follow_up,created) VALUES(?,?,'COORDINATION','AI Meeting Minutes','',?,'','',?)",(pid,date.today().isoformat(),summary.strip(),date.today().isoformat())); c.commit(); c.close(); return RedirectResponse("/meetings",303)


@app.get("/weather-impacts",response_class=HTMLResponse)
def weather_impacts():
    pid=project_id(); c=db(); acts=c.execute("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,)).fetchall(); rows=c.execute("SELECT w.*,a.external_id,a.name activity FROM weather_impacts w LEFT JOIN activities a ON a.id=w.activity_id WHERE w.company_id=? AND w.project_id=? ORDER BY w.impact_date DESC",(current_company_id(),pid)).fetchall(); c.close()
    opts='<option value="">No linked activity</option>'+''.join(f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>' for a in acts)
    hist=''.join(f'<div class="action"><b>{esc(r["impact_date"])} · {esc(r["weather_type"])}</b><div>{r["lost_hours"] or 0} lost hour(s) · {esc(r["external_id"] or "")} {esc(r["activity"] or "")}</div><div class="small">{esc(r["description"])}</div></div>' for r in rows) or '<div class="muted">No impacts logged.</div>'
    return shell("Weather Impacts",f'''<div class="hero"><div class="eyebrow">Weather Impact Log</div><h1>Document weather-related delay.</h1></div><div class="grid2"><div class="card"><form method="post" action="/weather-impacts"><input type="date" name="impact_date" value="{date.today().isoformat()}" required><select name="weather_type"><option>RAIN</option><option>HEAT</option><option>WIND</option><option>LIGHTNING</option><option>COLD</option><option>OTHER</option></select><select name="activity_id">{opts}</select><input type="number" step="0.5" min="0" name="lost_hours" value="0"><textarea name="description"></textarea><button>Log Impact</button></form></div><div class="card">{hist}</div></div>''')


@app.post("/weather-impacts")
def weather_impacts_save(impact_date:str=Form(...),weather_type:str=Form(...),activity_id:str=Form(""),lost_hours:float=Form(0),description:str=Form("")):
    pid=project_id(); linked=int(activity_id) if str(activity_id).strip() else None; c=db(); c.execute("INSERT INTO weather_impacts(company_id,project_id,activity_id,impact_date,weather_type,lost_hours,description,created) VALUES(?,?,?,?,?,?,?,?)",(current_company_id(),pid,linked,impact_date,weather_type,max(0,lost_hours),description.strip(),datetime.utcnow().isoformat())); c.commit(); c.close(); return RedirectResponse("/weather-impacts",303)


def _simple_pdf(title,lines,filename):
    if canvas is None: return HTMLResponse("reportlab is not installed",500)
    buf=io.BytesIO(); pdf=canvas.Canvas(buf); y=744; pdf.setFont("Helvetica-Bold",16); pdf.drawString(42,y,title); y-=28; pdf.setFont("Helvetica",9)
    for line in lines:
        words=str(line).split(); cur=""
        for word in words:
            test=(cur+" "+word).strip()
            if pdf.stringWidth(test,"Helvetica",9)>520:
                pdf.drawString(48,y,cur); y-=12; cur=word
                if y<50: pdf.showPage(); y=744; pdf.setFont("Helvetica",9)
            else: cur=test
        if cur: pdf.drawString(48,y,cur); y-=14
    pdf.setFont("Helvetica",8); pdf.drawString(42,28,"BuildCommand AI · Built by Wilson LaHood"); pdf.save(); buf.seek(0)
    return Response(buf.getvalue(),media_type="application/pdf",headers={"Content-Disposition":f'attachment; filename="{filename}"'})


@app.get("/pdf-reports",response_class=HTMLResponse)
def pdf_reports():
    return shell("PDF Reports",'''<div class="hero"><div class="eyebrow">Professional Reports</div><h1>Export project reports.</h1></div><div class="grid2"><div class="card"><a href="/pdf-reports/project-health.pdf">Project Health PDF</a></div><div class="card"><a href="/pdf-reports/lookahead.pdf">3-Week Lookahead PDF</a></div><div class="card"><a href="/pdf-reports/weekly.pdf">Weekly AI Report PDF</a></div><div class="card"><a href="/exports/daily-report.pdf">Daily Report PDF</a></div></div>''')


@app.get("/pdf-reports/project-health.pdf")
def pdf_health():
    h=project_health_snapshot(project_id()); return _simple_pdf("BuildCommand AI - Project Health",[f'Overall: {h["overall"]}/100',f'Schedule: {h["schedule"]}',f'Readiness: {h["readiness"]}',f'Procurement: {h["procurement"]}',f'Risk: {h["risk"]}',f'Field: {h["field"]}'],"buildcommand_project_health.pdf")


@app.get("/pdf-reports/lookahead.pdf")
def pdf_lookahead():
    pid=project_id(); today=date.today(); horizon=today+timedelta(days=21); c=db(); acts=c.execute("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,)).fetchall(); c.close(); lines=[f"Window: {today} through {horizon}"]
    for a in acts:
        s=parse_iso_date(a["start"])
        if s and today<=s<=horizon: lines.append(f'{a["external_id"]} - {a["name"]} | {a["trade"]} | {a["start"]} to {a["finish"]} | {a["pct"] or 0}%')
    return _simple_pdf("BuildCommand AI - 3 Week Lookahead",lines,"buildcommand_lookahead.pdf")


@app.get("/pdf-reports/weekly.pdf")
def pdf_weekly():
    pid=project_id(); c=db(); r=c.execute("SELECT * FROM weekly_ai_reports WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 1",(current_company_id(),pid)).fetchone(); c.close()
    if not r: return HTMLResponse("Generate a Weekly AI Report first.",404)
    return _simple_pdf("BuildCommand AI - Weekly Project Report",(r["report_text"] or "").splitlines(),"buildcommand_weekly_report.pdf")


@app.get("/cost-intelligence",response_class=HTMLResponse)
def cost_intelligence():
    pid=project_id(); c=db(); rows=c.execute("SELECT ce.*,a.external_id,a.name activity FROM change_events ce LEFT JOIN activities a ON a.id=ce.activity_id WHERE ce.project_id=? ORDER BY ce.id DESC",(pid,)).fetchall(); c.close()
    open_rows=[r for r in rows if r["status"] not in ["APPROVED","REJECTED"]]; approved=[r for r in rows if r["status"]=="APPROVED"]; open_cost=sum(float(r["estimated_cost"] or 0) for r in open_rows); approved_cost=sum(float(r["estimated_cost"] or 0) for r in approved); days=sum(float(r["schedule_days"] or 0) for r in open_rows)
    cards=''.join(f'<div class="card"><span class="badge {"READY" if r["status"]=="APPROVED" else "WATCH"}">{esc(r["status"])}</span><h3>{esc(r["title"])}</h3><p>${(r["estimated_cost"] or 0):,.0f} · {(r["schedule_days"] or 0):.1f} day(s)</p></div>' for r in rows) or '<div class="card">No change events.</div>'
    return shell("Cost Intelligence",f'''<div class="hero"><div class="eyebrow">Cost & Change Intelligence</div><h1>Change exposure in dollars and days.</h1></div><div class="grid3"><div class="card"><div class="label">Open Exposure</div><div class="kpi">${open_cost:,.0f}</div></div><div class="card"><div class="label">Approved</div><div class="kpi">${approved_cost:,.0f}</div></div><div class="card"><div class="label">Open Days</div><div class="kpi">{days:.1f}</div></div></div><div class="grid2">{cards}</div>''')


@app.get("/mobile-home",response_class=HTMLResponse)
def mobile_home():
    h=project_health_snapshot(project_id())
    return shell("Mobile Home",f'''<div class="hero"><div class="eyebrow">Superintendent Mobile</div><h1>Today in the Field</h1><div class="kpi">{h["overall"]}/100</div></div><div class="grid2"><div class="card"><a href="/quick-entry">🎤 Speak / Quick Note</a></div><div class="card"><a href="/documents">📷 Add Photo / Document</a></div><div class="card"><a href="/daily-report">📝 Daily Report</a></div><div class="card"><a href="/issues">⚠️ Issue / RFI</a></div><div class="card"><a href="/ai-command">📌 View Today</a></div><div class="card"><a href="/assistant">🤖 AI Assistant</a></div></div>''')


def v30_extract_text(row):
    if not row:
        return ""
    path=os.path.join(UPLOAD_DIR,row["stored_name"])
    ext=Path(row["original_name"] or "").suffix.lower()
    if not os.path.isfile(path):
        return ""
    try:
        if ext in {".txt",".csv"}:
            return Path(path).read_text(errors="ignore")[:250000]
        if ext==".pdf" and PdfReader is not None:
            return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages[:200])[:300000]
        if ext in {".xlsx",".xlsm"} and openpyxl is not None:
            wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
            lines=[]
            for ws in wb.worksheets[:20]:
                lines.append("SHEET: "+ws.title)
                for vals in ws.iter_rows(values_only=True):
                    lines.append(" | ".join("" if v is None else str(v) for v in vals))
                    if len(lines)>20000:
                        break
            return "\n".join(lines)[:300000]
    except Exception:
        return ""
    return ""


@app.get("/document-ai",response_class=HTMLResponse)
def v30_document_ai_page():
    pid=project_id(); c=db()
    docs=c.execute("SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 100",(current_company_id(),pid)).fetchall()
    c.close()
    options="".join(f'<option value="{d["id"]}">{esc(d["original_name"])}</option>' for d in docs) or '<option value="">No uploaded documents</option>'
    return shell("Deep Document AI",f"""
    <div class="hero"><div class="eyebrow">Deep Plans & Specs AI</div><h1>Read PDF, Excel, TXT, and CSV project documents.</h1></div>
    <div class="card"><form method="post" action="/document-ai"><select name="attachment_id">{options}</select>
    <textarea name="question" required placeholder="Ask a question about this document"></textarea>
    <button type="submit">Analyze Document</button></form></div>""")


@app.post("/document-ai",response_class=HTMLResponse)
def v30_document_ai_answer(attachment_id:int=Form(...),question:str=Form(...)):
    pid=project_id(); c=db()
    doc=c.execute("SELECT * FROM attachments WHERE id=? AND company_id=? AND project_id=?",(attachment_id,current_company_id(),pid)).fetchone()
    c.close()
    if not doc:
        return HTMLResponse("Document not found.",status_code=404)
    extracted=v30_extract_text(doc)
    if not extracted:
        answer="No readable text could be extracted from this file."
    else:
        try:
            client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
            response=client.responses.create(
                model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
                instructions="Answer only from the supplied construction document text. Do not invent drawing numbers or spec sections.",
                input=f"DOCUMENT: {doc['original_name']}\n\n{extracted[:96000]}\n\nQUESTION: {question}"
            )
            answer=response.output_text
        except Exception as exc:
            answer=f"Document AI failed: {exc}"
    return shell("Deep Document AI",f"""<div class="hero"><h1>{esc(doc["original_name"])}</h1></div>
    <div class="card"><div style="white-space:pre-wrap">{esc(answer)}</div></div>""")


@app.get("/advanced-schedule-import",response_class=HTMLResponse)
def v30_schedule_import_page():
    return shell("Advanced Schedule Import","""
    <div class="hero"><div class="eyebrow">Advanced Schedule Import</div><h1>Import CSV or Excel schedules.</h1></div>
    <div class="card"><form method="post" action="/advanced-schedule-import" enctype="multipart/form-data">
    <input type="file" name="file" accept=".csv,.xlsx" required><button type="submit">Import Schedule</button></form></div>""")


@app.post("/advanced-schedule-import")
async def v30_schedule_import(file:UploadFile=File(...)):
    pid=project_id(); filename=safe_filename(file.filename); ext=Path(filename).suffix.lower(); raw=await file.read(); rows=[]
    if ext==".csv":
        rows=list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
    elif ext==".xlsx":
        if openpyxl is None:
            return HTMLResponse("Excel support is unavailable.",status_code=500)
        tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".xlsx"); tmp.write(raw); tmp.close()
        try:
            wb=openpyxl.load_workbook(tmp.name,read_only=True,data_only=True); ws=wb[wb.sheetnames[0]]
            vals=list(ws.iter_rows(values_only=True))
            if vals:
                headers=[str(v or "").strip() for v in vals[0]]
                rows=[{headers[i]:r[i] for i in range(min(len(headers),len(r)))} for r in vals[1:]]
        finally:
            try: os.unlink(tmp.name)
            except Exception: pass
    else:
        return HTMLResponse("Use CSV or XLSX.",status_code=400)
    required={"external_id","name","trade","start","finish","pct","status"}
    if rows and not required.issubset(set(rows[0].keys())):
        return HTMLResponse("Schedule file is missing required headers.",status_code=400)
    c=db(); imported=0
    for row in rows:
        eid=str(row.get("external_id") or "").strip(); name=str(row.get("name") or "").strip()
        if not eid or not name: continue
        existing=c.execute("SELECT id FROM activities WHERE project_id=? AND external_id=?",(pid,eid)).fetchone()
        trade=str(row.get("trade") or "").strip(); start=str(row.get("start") or "").split(" ")[0]; finish=str(row.get("finish") or "").split(" ")[0]
        try: pct=float(row.get("pct") or 0)
        except Exception: pct=0
        status=str(row.get("status") or "NOT_STARTED").strip().upper()
        if existing:
            c.execute("UPDATE activities SET name=?,trade=?,start=?,finish=?,pct=?,status=? WHERE id=? AND project_id=?",(name,trade,start,finish,pct,status,existing["id"],pid))
        else:
            c.execute("INSERT INTO activities(project_id,external_id,name,trade,start,finish,pct,status) VALUES(?,?,?,?,?,?,?,?)",(pid,eid,name,trade,start,finish,pct,status))
        imported+=1
    c.execute("INSERT INTO schedule_import_sources(company_id,project_id,source_type,file_name,imported_count,created) VALUES(?,?,?,?,?,?)",(current_company_id(),pid,ext.replace(".","").upper(),filename,imported,datetime.utcnow().isoformat()))
    c.commit(); c.close()
    return RedirectResponse("/schedule",status_code=303)


@app.get("/photo-ai",response_class=HTMLResponse)
def v30_photo_ai_page():
    pid=project_id(); c=db()
    photos=c.execute("""SELECT * FROM attachments WHERE company_id=? AND project_id=? AND
    (lower(COALESCE(mime_type,'')) LIKE ? OR lower(COALESCE(original_name,'')) LIKE ? OR lower(COALESCE(original_name,'')) LIKE ? OR lower(COALESCE(original_name,'')) LIKE ? OR lower(COALESCE(original_name,'')) LIKE ?)
    ORDER BY id DESC LIMIT 50""",(current_company_id(),pid,"image/%","%.jpg","%.jpeg","%.png","%.webp")).fetchall(); c.close()
    options="".join(f'<option value="{p["id"]}">{esc(p["original_name"])}</option>' for p in photos) or '<option value="">No photos uploaded</option>'
    return shell("AI Photo Analysis",f"""<div class="hero"><div class="eyebrow">AI Photo Analysis</div><h1>Analyze field photos.</h1></div>
    <div class="card"><form method="post" action="/photo-ai"><select name="attachment_id">{options}</select>
    <select name="focus"><option>GENERAL</option><option>SAFETY</option><option>QUALITY</option><option>PROGRESS</option></select>
    <button type="submit">Analyze Photo</button></form></div>""")


@app.post("/photo-ai",response_class=HTMLResponse)
def v30_photo_ai(attachment_id:int=Form(...),focus:str=Form("GENERAL")):
    pid=project_id(); c=db()
    row=c.execute("SELECT * FROM attachments WHERE id=? AND company_id=? AND project_id=?",(attachment_id,current_company_id(),pid)).fetchone(); c.close()
    if not row: return HTMLResponse("Photo not found.",status_code=404)
    path=os.path.join(UPLOAD_DIR,row["stored_name"])
    if not os.path.isfile(path): return HTMLResponse("Stored photo unavailable.",status_code=404)
    try:
        data=Path(path).read_bytes(); mime=row["mime_type"] or "image/jpeg"; b64=base64.b64encode(data).decode("ascii")
        client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        response=client.responses.create(
            model=os.environ.get("OPENAI_VISION_MODEL",os.environ.get("OPENAI_MODEL","gpt-5.6")),
            instructions=f"Describe only visible construction facts. Focus: {focus}. Treat possible concerns as observations, not definitive code violations.",
            input=[{"role":"user","content":[{"type":"input_text","text":"Analyze this construction field photo."},{"type":"input_image","image_url":f"data:{mime};base64,{b64}"}]}]
        )
        result=response.output_text
    except Exception as exc:
        result=f"Photo AI failed: {exc}"
    return shell("AI Photo Analysis",f"""<div class="hero"><h1>{esc(row["original_name"])}</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(result)}</div></div>""")


@app.get("/auto-daily-report",response_class=HTMLResponse)
def v30_auto_daily_page():
    return shell("Auto Daily Report","""<div class="hero"><div class="eyebrow">Automatic Daily Report</div><h1>Generate today's report from BuildCommand activity.</h1></div>
    <div class="card"><form method="post" action="/auto-daily-report/generate"><button type="submit">Generate Draft Daily Report</button></form></div>""")


@app.post("/auto-daily-report/generate",response_class=HTMLResponse)
def v30_auto_daily_generate():
    context=build_project_context(project_id())
    try:
        client=OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        response=client.responses.create(
            model=os.environ.get("OPENAI_MODEL","gpt-5.6"),
            instructions="Draft a superintendent daily report using only supplied project data. Sections: WORK COMPLETED, MANPOWER, DELAYS/CONSTRAINTS, DELIVERIES, INSPECTIONS, SAFETY, TOMORROW PLAN. Say Not documented when missing.",
            input=context
        )
        draft=response.output_text
    except Exception as exc: draft=f"Auto daily report failed: {exc}"
    return shell("Auto Daily Report",f"""<div class="hero"><h1>Draft Ready</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(draft)}</div></div>""")


def v30_forecast(pid):
    c=db(); acts=c.execute("SELECT * FROM activities WHERE project_id=? AND status!='COMPLETE'",(pid,)).fetchall(); c.close()
    if not acts: return 0.0,.5,"No active activities."
    scores=[]; notes=[]
    for a in acts:
        score,band,reasons=activity_delay_signal(a); scores.append(score)
        if score>=45: notes.append(f'{a["external_id"]} {a["name"]}: {band}')
    avg=sum(scores)/len(scores)
    return round(avg/18.0,1),round(min(.9,.45+len(acts)*.03),2),"; ".join(notes[:5]) or "No major delay signal detected."


@app.get("/predictive-forecast",response_class=HTMLResponse)
def v30_predictive_forecast():
    pid=project_id(); h=project_health_snapshot(pid); projected,confidence,explanation=v30_forecast(pid)
    c=db(); c.execute("INSERT INTO forecast_snapshots(company_id,project_id,snapshot_date,health_score,projected_delay_days,confidence,explanation,created) VALUES(?,?,?,?,?,?,?,?)",
    (current_company_id(),pid,date.today().isoformat(),h["overall"],projected,confidence,explanation,datetime.utcnow().isoformat())); c.commit(); c.close()
    band="READY" if projected<1 else "WATCH" if projected<3 else "HIGH" if projected<6 else "CRITICAL"
    return shell("Predictive Forecast",f"""<div class="hero"><div class="eyebrow">Predictive Forecast</div><h1>{projected:.1f} projected delay day(s)</h1>
    <span class="badge {band}">{band}</span><div class="muted">Confidence {confidence*100:.0f}%</div></div><div class="card"><p>{esc(explanation)}</p></div>""")


@app.get("/sub-risk",response_class=HTMLResponse)
def v30_sub_risk():
    pid=project_id(); c=db(); subs=c.execute("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(pid,)).fetchall()
    updates=c.execute("SELECT * FROM subcontractor_updates WHERE project_id=? ORDER BY update_date DESC,id DESC",(pid,)).fetchall(); c.close()
    cards=""
    for s in subs:
        su=[u for u in updates if u["sub_id"]==s["id"]]; latest=su[0] if su else None; score=20; reasons=[]
        if not latest: score+=35; reasons.append("no recent field update")
        else:
            st=(latest["status"] or "").upper()
            if st=="CRITICAL": score+=55; reasons.append("latest status critical")
            elif st=="HIGH": score+=35; reasons.append("latest status high")
            elif st=="WATCH": score+=18; reasons.append("latest status watch")
            if (latest["manpower"] or 0)<=0: score+=20; reasons.append("latest manpower zero")
        score=min(100,score); band="CRITICAL" if score>=75 else "HIGH" if score>=50 else "WATCH" if score>=25 else "READY"; explanation="; ".join(reasons) or "No major risk signal."
        c2=db(); c2.execute("INSERT INTO sub_risk_snapshots(company_id,project_id,sub_id,risk_score,risk_band,explanation,created) VALUES(?,?,?,?,?,?,?)",(current_company_id(),pid,s["id"],score,band,explanation,datetime.utcnow().isoformat())); c2.commit(); c2.close()
        cards+=f'<div class="card"><span class="badge {band}">{band} · {score}</span><h3>{esc(s["name"])}</h3><p>{esc(explanation)}</p></div>'
    return shell("Sub Risk",f'<div class="hero"><h1>Subcontractor Risk</h1></div><div class="grid3">{cards}</div>')


@app.get("/change-package",response_class=HTMLResponse)
def v30_change_package_page():
    pid=project_id(); c=db(); rows=c.execute("SELECT * FROM change_events WHERE project_id=? ORDER BY id DESC",(pid,)).fetchall(); c.close()
    options="".join(f'<option value="{r["id"]}">{esc(r["title"])}</option>' for r in rows)
    return shell("Change Package",f"""<div class="hero"><div class="eyebrow">Change Order Documentation</div><h1>Build a change package.</h1></div>
    <div class="card"><form method="post" action="/change-package"><select name="change_event_id">{options}</select><button type="submit">Generate Change Package</button></form></div>""")


@app.post("/change-package",response_class=HTMLResponse)
def v30_change_package(change_event_id:int=Form(...)):
    pid=project_id(); c=db()
    ce=c.execute("""SELECT ce.*,a.external_id,a.name activity FROM change_events ce LEFT JOIN activities a ON a.id=ce.activity_id WHERE ce.id=? AND ce.project_id=?""",(change_event_id,pid)).fetchone(); c.close()
    if not ce: return HTMLResponse("Change event not found.",status_code=404)
    package="\n".join([
        "CHANGE EVENT", str(ce["title"] or ""), "",
        "TYPE", str(ce["event_type"] or ""), "",
        "LINKED ACTIVITY", f'{ce["external_id"] or ""} {ce["activity"] or ""}', "",
        "RESPONSIBLE PARTY", str(ce["responsible_party"] or "Unassigned"), "",
        "ESTIMATED COST IMPACT", f'${float(ce["estimated_cost"] or 0):,.0f}', "",
        "SCHEDULE IMPACT", f'{float(ce["schedule_days"] or 0):.1f} day(s)', "",
        "STATUS", str(ce["status"] or ""), "",
        "DESCRIPTION", str(ce["description"] or ""), "",
        "SUPPORTING DOCUMENTS", "Attach photos, RFIs, submittals, meeting notes, and pricing as applicable."
    ])
    c=db(); c.execute("INSERT INTO change_packages(company_id,project_id,change_event_id,package_text,created) VALUES(?,?,?,?,?)",(current_company_id(),pid,change_event_id,package,datetime.utcnow().isoformat())); c.commit(); c.close()
    return shell("Change Package",f'<div class="hero"><h1>{esc(ce["title"])}</h1></div><div class="card"><div style="white-space:pre-wrap">{esc(package)}</div></div>')


@app.get("/owner-dashboard",response_class=HTMLResponse)
def v30_owner_dashboard():
    pid=project_id(); h=project_health_snapshot(pid); c=db(); project=c.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone()
    changes=c.execute("SELECT * FROM change_events WHERE project_id=?",(pid,)).fetchall(); latest=c.execute("SELECT * FROM weekly_ai_reports WHERE project_id=? ORDER BY id DESC LIMIT 1",(pid,)).fetchone(); c.close()
    open_cost=sum(float(r["estimated_cost"] or 0) for r in changes if r["status"] not in ["APPROVED","REJECTED"]); approved=sum(float(r["estimated_cost"] or 0) for r in changes if r["status"]=="APPROVED")
    summary=esc(latest["report_text"][:1800]) if latest else "Generate a Weekly AI Report to populate the owner summary."
    return shell("Owner Dashboard",f"""<div class="hero"><div class="eyebrow">Owner / Executive View</div><h1>{esc(project["name"] if project else "Project")}</h1><div class="kpi">{h["overall"]}/100</div></div>
    <div class="grid4"><div class="card"><div class="label">Schedule</div><div class="kpi">{h["schedule"]}</div></div>
    <div class="card"><div class="label">Readiness</div><div class="kpi">{h["readiness"]}</div></div>
    <div class="card"><div class="label">Open Change</div><div class="kpi">${open_cost:,.0f}</div></div>
    <div class="card"><div class="label">Approved Changes</div><div class="kpi">${approved:,.0f}</div></div></div>
    <div class="card"><h2>Executive Summary</h2><div style="white-space:pre-wrap">{summary}</div></div>""")


@app.get("/portfolio-intelligence",response_class=HTMLResponse)
def v30_portfolio_intelligence():
    cid=current_company_id(); c=db(); projects=c.execute("SELECT * FROM projects WHERE company_id=? ORDER BY name",(cid,)).fetchall(); c.close()
    cards=""; scores=[]
    for p in projects:
        h=project_health_snapshot(p["id"]); scores.append(h["overall"]); band="READY" if h["overall"]>=85 else "WATCH" if h["overall"]>=70 else "HIGH" if h["overall"]>=50 else "CRITICAL"
        cards+=f'<div class="card"><span class="badge {band}">{h["overall"]}/100</span><h3>{esc(p["name"])}</h3><p>Schedule {h["schedule"]} · Readiness {h["readiness"]} · Procurement {h["procurement"]}</p></div>'
    avg=round(sum(scores)/len(scores)) if scores else 0
    return shell("Portfolio Intelligence",f'<div class="hero"><h1>Company Portfolio Health: {avg}/100</h1></div><div class="grid3">{cards}</div>')


@app.get("/mobile-field-plus",response_class=HTMLResponse)
def v30_mobile_field_plus():
    h=project_health_snapshot(project_id())
    return shell("Mobile Field+",f"""<div class="hero"><div class="eyebrow">Mobile Superintendent Workflow</div><h1>Field Mode</h1><div class="kpi">{h["overall"]}/100</div></div>
    <div class="grid2">
    <div class="card"><a href="/quick-entry">🎤 Speak Note</a></div>
    <div class="card"><a href="/photo-ai">📷 Analyze Photo</a></div>
    <div class="card"><a href="/auto-daily-report">📝 Auto Daily Report</a></div>
    <div class="card"><a href="/rfi-drafting">❓ Draft RFI</a></div>
    <div class="card"><a href="/lookahead-intelligence">📅 3-Week Lookahead</a></div>
    <div class="card"><a href="/predictive-forecast">📈 Forecast</a></div>
    <div class="card"><a href="/sub-risk">👷 Sub Risk</a></div>
    <div class="card"><a href="/assistant">🤖 Ask AI</a></div></div>""")


def audit_event(action,detail='',pid=None):
    try:
        c=db(); c.execute('INSERT INTO admin_audit_log(company_id,user_id,project_id,action,detail,created) VALUES(?,?,?,?,?,?)',(current_company_id(),current_user_id(),pid if pid is not None else project_id(),action,detail,datetime.utcnow().isoformat())); c.commit(); c.close()
    except Exception: pass


@app.get('/storage-status',response_class=HTMLResponse)
def storage_status_page():
    pid=project_id(); c=db(); rows=c.execute('SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC',(current_company_id(),pid)).fetchall(); c.close()
    present=sum(1 for r in rows if os.path.isfile(os.path.join(UPLOAD_DIR,r['stored_name']))); missing=len(rows)-present; persistent=not os.path.abspath(UPLOAD_DIR).startswith('/tmp/'); band='READY' if persistent and missing==0 else 'WATCH'
    return shell('Storage Status',f'''<div class="hero"><div class="eyebrow">Persistent Storage</div><h1><span class="badge {band}">{band}</span> {present}/{len(rows)} project file(s) present</h1></div><div class="grid2"><div class="card"><h2>Upload Path</h2><p>{esc(UPLOAD_DIR)}</p><p class="small">{'Persistent path detected.' if persistent else 'Temporary /tmp path detected.'}</p></div><div class="card"><h2>Missing Files</h2><div class="kpi">{missing}</div></div></div>''')


@app.get('/global-search',response_class=HTMLResponse)
def global_search_page(q:str=''):
    pid=project_id()
    company=current_company_id()
    results=[]
    q=(q or '').strip()

    if q:
        like=f'%{q.lower()}%'
        specs=[
            ("Schedule","activities","name","/schedule",False),
            ("RFI / Issue","project_issues","title","/issues",False),
            ("Action","action_items","title","/actions",False),
            ("Subcontractor","subs","name","/subcontractors",False),
            ("Document","attachments","original_name","/documents",True),
            ("Change","change_events","title","/changes",False),
            ("Blueprint Scope","blueprint_scope_items","requirement","/blueprint-brain",True),
            ("Estimator","estimator_items","description","/brain/estimator",True),
            ("Submittal","submittals","title","/submittals",False),
            ("Punch","punch_items","title","/punch",False),
            ("Procurement","procurement","item","/procurement",False),
        ]

        c=db()
        for kind,table,column,url,company_scoped in specs:
            try:
                if company_scoped:
                    sql=f"SELECT id,{column} AS label FROM {table} WHERE project_id=? AND company_id=? AND LOWER(COALESCE({column}, '')) LIKE ? ORDER BY id DESC LIMIT 25"
                    rows=c.execute(sql,(pid,company,like)).fetchall()
                else:
                    sql=f"SELECT id,{column} AS label FROM {table} WHERE project_id=? AND LOWER(COALESCE({column}, '')) LIKE ? ORDER BY id DESC LIMIT 25"
                    rows=c.execute(sql,(pid,like)).fetchall()

                for r in rows:
                    label=r["label"] if r["label"] is not None else ""
                    results.append((kind,label,url))
            except Exception:
                try:
                    c.rollback()
                except Exception:
                    pass
                continue
        c.close()

    html=''.join(
        f'<div class="search-result"><b>{esc(k)}</b> · <a href="{u}" style="color:#f0b44d">{esc(l)}</a></div>'
        for k,l,u in results
    ) or (
        '<div class="muted">No matching project records.</div>'
        if q else
        '<div class="muted">Search plans/scopes, estimator, schedule, RFIs, actions, subcontractors, documents, changes, submittals, punch and procurement.</div>'
    )

    body=(
        '<div class="hero"><div class="eyebrow">Search Everything</div>'
        '<h1>Search this project.</h1>'
        '<p class="muted">One search across the project instead of hunting through individual tools.</p></div>'
        '<div class="card"><form method="get" action="/global-search">'
        f'<input name="q" value="{esc(q)}" placeholder="Search plans, scope, estimator, schedule, RFIs, documents, changes...">'
        '<button type="submit">Search Everything</button></form></div>'
        f'<div class="card">{html}</div>'
    )
    return shell('Global Search',body)


@app.get('/favorites',response_class=HTMLResponse)
def favorites_page():
    c=db(); rows=c.execute('SELECT * FROM user_favorites WHERE company_id=? AND user_id=? ORDER BY id DESC',(current_company_id(),current_user_id())).fetchall(); c.close()
    options=''.join(f'<option value="{esc(u)}|{esc(n)}">{esc(n)}</option>' for n,u in NAV)
    cards=''.join(f'<div class="action"><a href="{esc(r["tool_url"])}" style="color:#f0b44d;font-weight:700">{esc(r["tool_name"])}</a><form method="post" action="/favorites/remove"><input type="hidden" name="favorite_id" value="{r["id"]}"><button type="submit">Remove</button></form></div>' for r in rows) or '<div class="muted">No pinned tools yet.</div>'
    return shell('Favorites',f'''<div class="hero"><div class="eyebrow">Favorites</div><h1>Pin your most-used tools.</h1></div><div class="grid2"><div class="card"><form method="post" action="/favorites"><select name="tool">{options}</select><button type="submit">Pin Tool</button></form></div><div class="card">{cards}</div></div>''')


@app.post('/favorites')
def favorites_add(tool:str=Form(...)):
    try: url,name=tool.split('|',1)
    except Exception: return RedirectResponse('/favorites',303)
    c=db(); ex=c.execute('SELECT id FROM user_favorites WHERE company_id=? AND user_id=? AND tool_url=?',(current_company_id(),current_user_id(),url)).fetchone()
    if not ex: c.execute('INSERT INTO user_favorites(company_id,user_id,tool_name,tool_url,created) VALUES(?,?,?,?,?)',(current_company_id(),current_user_id(),name,url,datetime.utcnow().isoformat())); c.commit()
    c.close(); audit_event('PIN_TOOL',name); return RedirectResponse('/favorites',303)


@app.post('/favorites/remove')
def favorites_remove(favorite_id:int=Form(...)):
    c=db(); c.execute('DELETE FROM user_favorites WHERE id=? AND company_id=? AND user_id=?',(favorite_id,current_company_id(),current_user_id())); c.commit(); c.close(); audit_event('UNPIN_TOOL',str(favorite_id)); return RedirectResponse('/favorites',303)


@app.get('/recent-activity',response_class=HTMLResponse)
def recent_activity_page():
    pid=project_id(); c=db(); entries=[]; sources=[('Action','action_items','title','created','/actions'),('RFI / Issue','project_issues','title','created','/issues'),('Document','attachments','original_name','created','/documents'),('Change','change_events','title','created','/changes'),('Daily Report','daily_reports','report_date','created','/daily-report')]
    for kind,table,label_col,date_col,url in sources:
        if table=='attachments': rows=c.execute(f'SELECT {label_col} label,{date_col} stamp FROM {table} WHERE project_id=? AND company_id=? ORDER BY id DESC LIMIT 12',(pid,current_company_id())).fetchall()
        else: rows=c.execute(f'SELECT {label_col} label,{date_col} stamp FROM {table} WHERE project_id=? ORDER BY id DESC LIMIT 12',(pid,)).fetchall()
        for r in rows: entries.append((r['stamp'] or '',kind,r['label'],url))
    c.close(); entries.sort(key=lambda x:x[0],reverse=True); html=''.join(f'<div class="action"><b>{esc(k)}</b> · <a href="{u}" style="color:#f0b44d">{esc(l)}</a><div class="small">{esc(s)}</div></div>' for s,k,l,u in entries[:40]) or '<div class="muted">No recent project activity.</div>'
    return shell('Recent Activity',f'<div class="hero"><div class="eyebrow">Recent Activity</div><h1>What changed recently?</h1></div><div class="card">{html}</div>')


@app.get('/project-clone',response_class=HTMLResponse)
def project_clone_page():
    pid=project_id(); c=db(); p=c.execute('SELECT * FROM projects WHERE id=? AND company_id=?',(pid,current_company_id())).fetchone(); c.close()
    return shell('Clone Project',f'''<div class="hero"><div class="eyebrow">Project Template</div><h1>Clone {esc(p['name'] if p else 'current project')}</h1></div><div class="card"><form method="post" action="/project-clone"><input name="name" placeholder="New Project Name" required><input name="number" placeholder="New Project Number" required><button type="submit">Clone Project Setup</button></form><p class="small">Copies schedule activities and subcontractor list only.</p></div>''')


@app.post('/project-clone')
def project_clone(name:str=Form(...),number:str=Form(...)):
    source=project_id(); cid=current_company_id(); c=db(); c.execute('INSERT INTO projects(name,number,status,company_id) VALUES(?,?,?,?)',(name.strip(),number.strip(),'PLANNING',cid)); new_id=c.execute('SELECT last_insert_rowid() id').fetchone()['id']
    for a in c.execute('SELECT * FROM activities WHERE project_id=? ORDER BY id',(source,)).fetchall(): c.execute("INSERT INTO activities(project_id,external_id,name,trade,start,finish,pct,status) VALUES(?,?,?,?,?,?,0,'NOT_STARTED')",(new_id,a['external_id'],a['name'],a['trade'],a['start'],a['finish']))
    for s in c.execute('SELECT * FROM subs WHERE project_id=? ORDER BY id',(source,)).fetchall(): c.execute('INSERT INTO subs(project_id,name,trade) VALUES(?,?,?)',(new_id,s['name'],s['trade']))
    c.commit(); c.close(); audit_event('CLONE_PROJECT',f'{source} -> {new_id}',new_id); return RedirectResponse('/',303)


@app.get('/project-archive',response_class=HTMLResponse)
def project_archive_page():
    cid=current_company_id(); c=db(); rows=c.execute('SELECT p.*,COALESCE(a.archived,0) archived FROM projects p LEFT JOIN project_archive_state a ON a.project_id=p.id WHERE p.company_id=? ORDER BY p.name',(cid,)).fetchall(); c.close()
    cards=''.join(f'''<div class="action"><b>{esc(r['number'])} - {esc(r['name'])}</b><div class="small">{'ARCHIVED' if r['archived'] else 'ACTIVE'}</div><form method="post" action="/project-archive"><input type="hidden" name="project_id_value" value="{r['id']}"><input type="hidden" name="archived" value="{0 if r['archived'] else 1}"><button type="submit">{'Restore' if r['archived'] else 'Archive'}</button></form></div>''' for r in rows)
    return shell('Archive Projects',f'<div class="hero"><div class="eyebrow">Project Lifecycle</div><h1>Archive or restore projects.</h1></div><div class="card">{cards}</div>')


@app.post('/project-archive')
def project_archive_save(project_id_value:int=Form(...),archived:int=Form(...)):
    cid=current_company_id(); c=db(); valid=c.execute('SELECT id FROM projects WHERE id=? AND company_id=?',(project_id_value,cid)).fetchone()
    if valid:
        ex=c.execute('SELECT project_id FROM project_archive_state WHERE project_id=?',(project_id_value,)).fetchone()
        if ex: c.execute('UPDATE project_archive_state SET archived=?,archived_at=? WHERE project_id=?',(1 if archived else 0,datetime.utcnow().isoformat() if archived else None,project_id_value))
        else: c.execute('INSERT INTO project_archive_state(project_id,company_id,archived,archived_at) VALUES(?,?,?,?)',(project_id_value,cid,1 if archived else 0,datetime.utcnow().isoformat() if archived else None))
        c.commit()
    c.close(); audit_event('ARCHIVE_PROJECT' if archived else 'RESTORE_PROJECT',str(project_id_value),project_id_value); return RedirectResponse('/project-archive',303)


@app.get('/document-tags',response_class=HTMLResponse)
def document_tags_page():
    pid=project_id(); c=db(); docs=c.execute('SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC',(current_company_id(),pid)).fetchall(); tags=c.execute('SELECT t.*,a.original_name FROM attachment_tags t JOIN attachments a ON a.id=t.attachment_id WHERE t.company_id=? AND a.project_id=? ORDER BY t.id DESC',(current_company_id(),pid)).fetchall(); c.close()
    options=''.join(f'<option value="{d["id"]}">{esc(d["original_name"])}</option>' for d in docs); recent=''.join(f'<div class="action"><b>{esc(t["tag"])}</b> · {esc(t["original_name"])}</div>' for t in tags) or '<div class="muted">No document tags yet.</div>'
    return shell('Document Tags',f'''<div class="hero"><div class="eyebrow">Document Organization</div><h1>Tag project files.</h1></div><div class="grid2"><div class="card"><form method="post" action="/document-tags"><select name="attachment_id">{options}</select><input name="tag" placeholder="electrical, permit, owner" required><button type="submit">Add Tag</button></form></div><div class="card">{recent}</div></div>''')


@app.post('/document-tags')
def document_tags_add(attachment_id:int=Form(...),tag:str=Form(...)):
    c=db(); valid=c.execute('SELECT id FROM attachments WHERE id=? AND company_id=?',(attachment_id,current_company_id())).fetchone()
    if valid: c.execute('INSERT INTO attachment_tags(company_id,attachment_id,tag,created) VALUES(?,?,?,?)',(current_company_id(),attachment_id,tag.strip().lower(),datetime.utcnow().isoformat())); c.commit()
    c.close(); audit_event('TAG_DOCUMENT',tag); return RedirectResponse('/document-tags',303)


@app.get('/notification-rules',response_class=HTMLResponse)
def notification_rules_page():
    c=db(); rows=c.execute('SELECT * FROM notification_rules WHERE company_id=? ORDER BY id DESC',(current_company_id(),)).fetchall(); c.close()
    recent=''.join(f'<div class="action"><span class="badge {esc(r["severity"])}">{esc(r["severity"])}</span> <b>{esc(r["rule_name"])}</b><div class="small">Threshold {r["threshold_value"]} - {"Enabled" if r["enabled"] else "Disabled"}</div></div>' for r in rows) or '<div class="muted">No custom notification rules yet.</div>'
    return shell('Notification Rules',f'''<div class="hero"><div class="eyebrow">Alert Rules</div><h1>Control what deserves attention.</h1></div><div class="grid2"><div class="card"><form method="post" action="/notification-rules"><input name="rule_name" placeholder="High schedule delay" required><select name="severity"><option>WATCH</option><option selected>HIGH</option><option>CRITICAL</option></select><input type="number" step="0.1" name="threshold_value" value="0"><button type="submit">Add Rule</button></form></div><div class="card">{recent}</div></div>''')


@app.post('/notification-rules')
def notification_rules_add(rule_name:str=Form(...),severity:str=Form('HIGH'),threshold_value:float=Form(0)):
    c=db(); c.execute('INSERT INTO notification_rules(company_id,rule_name,enabled,severity,threshold_value,created) VALUES(?,?,1,?,?,?)',(current_company_id(),rule_name.strip(),severity,threshold_value,datetime.utcnow().isoformat())); c.commit(); c.close(); audit_event('ADD_NOTIFICATION_RULE',rule_name); return RedirectResponse('/notification-rules',303)


@app.get('/health-history',response_class=HTMLResponse)
def health_history_page():
    pid=project_id(); h=project_health_snapshot(pid); c=db(); ex=c.execute('SELECT id FROM health_history WHERE company_id=? AND project_id=? AND snapshot_date=?',(current_company_id(),pid,date.today().isoformat())).fetchone()
    if not ex: c.execute('INSERT INTO health_history(company_id,project_id,snapshot_date,overall,schedule,readiness,procurement,risk,field,created) VALUES(?,?,?,?,?,?,?,?,?,?)',(current_company_id(),pid,date.today().isoformat(),h['overall'],h['schedule'],h['readiness'],h['procurement'],h['risk'],h['field'],datetime.utcnow().isoformat())); c.commit()
    rows=c.execute('SELECT * FROM health_history WHERE company_id=? AND project_id=? ORDER BY snapshot_date DESC,id DESC LIMIT 30',(current_company_id(),pid)).fetchall(); c.close()
    history=''.join(f'<div class="action"><b>{esc(r["snapshot_date"])}</b> - Overall {r["overall"]:.0f}/100<div class="small">Schedule {r["schedule"]:.0f} · Readiness {r["readiness"]:.0f} · Procurement {r["procurement"]:.0f} · Risk {r["risk"]:.0f} · Field {r["field"]:.0f}</div></div>' for r in rows)
    return shell('Health History',f'<div class="hero"><div class="eyebrow">Project Trend</div><h1>Health history</h1></div><div class="card">{history}</div>')


@app.get('/bulk-export')
def bulk_export():
    pid=project_id(); cid=current_company_id(); stamp=datetime.utcnow().strftime('%Y%m%d_%H%M%S'); zpath=f'/tmp/buildcommand_project_export_{stamp}.zip'; tables=['projects','activities','subs','action_items','project_issues','daily_reports','procurement','risks','change_events','attachments']; c=db()
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        for table in tables:
            if table=='projects': rows=c.execute('SELECT * FROM projects WHERE id=? AND company_id=?',(pid,cid)).fetchall()
            elif table=='attachments': rows=c.execute('SELECT * FROM attachments WHERE project_id=? AND company_id=?',(pid,cid)).fetchall()
            else: rows=c.execute(f'SELECT * FROM {table} WHERE project_id=?',(pid,)).fetchall()
            if not rows: continue
            headers=list(rows[0].keys()); sio=io.StringIO(); writer=csv.writer(sio); writer.writerow(headers)
            for r in rows: writer.writerow([r[h] for h in headers])
            z.writestr(f'{table}.csv',sio.getvalue())
    c.close(); audit_event('BULK_EXPORT',f'project {pid}',pid); return FileResponse(zpath,media_type='application/zip',filename=f'buildcommand_project_export_{stamp}.zip')


@app.get('/audit-log',response_class=HTMLResponse)
def audit_log_page():
    if not require_role('ADMIN'): return HTMLResponse('Not authorized.',status_code=403)
    c=db(); rows=c.execute('SELECT l.*,u.display_name FROM admin_audit_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.company_id=? ORDER BY l.id DESC LIMIT 100',(current_company_id(),)).fetchall(); c.close()
    html=''.join(f'<div class="action"><b>{esc(r["action"])}</b> - {esc(r["display_name"] or "System")}<div>{esc(r["detail"])}</div><div class="small">{esc(r["created"])}</div></div>' for r in rows) or '<div class="muted">No v31 audit events yet.</div>'
    return shell('Audit Log',f'<div class="hero"><div class="eyebrow">Admin Audit Log</div><h1>Track important workspace changes.</h1></div><div class="card">{html}</div>')


_V371_TRADE_REGRESSION_CASES = [
    ("Patch concrete and floor surfaces disturbed by electrical or plumbing work", "Concrete"),
    ("Prime and refinish all wall, ceiling, and other surfaces patched after demolition or MEP installation", "Painting"),
    ("Provide new suspended acoustical tile ceiling grid and tile", "Ceilings"),
    ("Coordinate ceiling grid openings with lights, diffusers, sprinkler heads and smoke detectors", "Ceilings"),
    ("Provide sprinkler heads and sprinkler drops at new ceiling", "Fire Sprinkler"),
    ("Provide duct smoke detectors for rooftop air-conditioning units", "HVAC / Mechanical"),
    ("Provide EF-1 roof-mounted exhaust fan", "HVAC / Mechanical"),
    ("Patch roof membrane at mechanical penetrations", "Roofing"),
    ("Provide electrical connection and disconnect for EF-1 exhaust fan", "Electrical"),
    ("Provide instantaneous electric water heater IWH-1", "Plumbing"),
    ("Provide water closets, urinals, lavatories, floor drains and drinking fountain", "Plumbing"),
    ("Sawcut slab, trench and restore concrete for below-grade plumbing", "Concrete"),
    ("Provide stainless-steel grab bars and toilet room accessories", "Toilet / Bath Accessories"),
    ("Provide toilet partitions and urinal screens", "Toilet / Bath Accessories"),
    ("Provide concealed wood blocking and backing for wall-mounted accessories", "Framing / Drywall"),
    ("Construct restroom Wall Type B gypsum board assemblies and resilient-channel gypsum ceilings", "Framing / Drywall"),
    ("Provide interior hollow-metal doors, frames and hardware", "Doors / Frames / Hardware"),
    ("Provide aluminum storefront system and exterior storefront doors", "Storefront / Glazing"),
    ("Provide rubber base, LVT flooring and tile backsplash", "Flooring / Tile"),
    ("Provide electronic accessible door operator with activation touch pads", "Low Voltage"),
    ("Provide card access, electronic strikes, cameras and door contacts", "Low Voltage"),
    ("Provide fire extinguisher cabinets", "Specialties"),
    ("Paint hollow-metal doors and frames", "Painting"),
    ("Remove existing architectural partitions, doors, ceilings and millwork", "Demolition"),
    ("Remove existing lavatories, urinals, water closets, floor drains and water heater", "Demolition"),
]


def _v371_trade_regression_results():
    results=[]
    for requirement, expected in _V371_TRADE_REGRESSION_CASES:
        actual=_v441_primary_trade(requirement, "Unassigned")
        results.append({
            "requirement": requirement,
            "expected": expected,
            "actual": actual,
            "passed": actual == expected,
        })
    return results


def _v371_trade_regression_summary():
    rows=_v371_trade_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    return {
        "version":"v371",
        "suite":"Blueprint Brain trade ownership",
        "passed":passed,
        "total":len(rows),
        "failed":len(rows)-passed,
        "ok":passed==len(rows),
        "results":rows,
    }


@app.get('/health/blueprint-v371')
def v371_blueprint_health():
    """Deterministic staging smoke test for core Blueprint Brain trade ownership rules."""
    return _v371_trade_regression_summary()


@app.get('/blueprint-reliability-v371', response_class=HTMLResponse)
def v371_blueprint_reliability_page():
    summary=_v371_trade_regression_summary()
    rows=''.join(
        f'<div class="action"><span class="badge {"READY" if r["passed"] else "WATCH"}">'
        f'{"PASS" if r["passed"] else "FAIL"}</span> <b>{esc(r["expected"])}</b>'
        f'<div>{esc(r["requirement"])}</div>'
        f'<div class="small">Classifier returned: {esc(r["actual"])}</div></div>'
        for r in summary['results']
    )
    status='READY' if summary['ok'] else 'WATCH'
    return shell('Blueprint Reliability v371',
        f'<div class="hero"><div class="eyebrow">BuildCommand v371</div>'
        f'<h1>Blueprint Brain Reliability Center</h1>'
        f'<p class="muted">Deterministic trade-ownership regression checks before production promotion.</p>'
        f'<p><span class="badge {status}">{summary["passed"]}/{summary["total"]} PASSED</span></p></div>'
        f'<div class="card">{rows}</div>')


_V372_SOURCE_WEIGHTS = {
    "source_spec": 4,
    "source_detail": 3,
    "source_sheet": 2,
    "source_note": 2,
}


def _v372_clean_source(value):
    v=str(value or "").strip()
    if not v or v.lower() in {"none","null","n/a","na","unknown","-"}:
        return ""
    return v


def _v372_source_evidence(item):
    """Return deterministic source-strength metadata for one Blueprint Brain item."""
    evidence=[]
    weighted=0
    for field,weight in _V372_SOURCE_WEIGHTS.items():
        value=_v372_clean_source(item.get(field) if hasattr(item,'get') else item[field])
        if value:
            evidence.append({"field":field,"value":value,"weight":weight})
            weighted += weight
    count=len(evidence)
    # Reward corroboration across source types, not repeated text from one field.
    corroboration=max(0,count-1)*2
    score=min(100, weighted*10 + corroboration*5)
    if count >= 3 or score >= 80:
        level="STRONG"
    elif count >= 2 or score >= 45:
        level="SUPPORTED"
    elif count == 1:
        level="SINGLE_SOURCE"
    else:
        level="UNSOURCED"
    return {"count":count,"weighted":weighted,"score":score,"level":level,"evidence":evidence}


def _v372_trade_check(requirement, stored_trade):
    predicted=_v441_primary_trade(str(requirement or ''), str(stored_trade or 'Unassigned'))
    stored=str(stored_trade or 'Unassigned')
    return {
        "stored":stored,
        "predicted":predicted,
        "agrees":predicted == stored,
    }


def _v372_item_intelligence(item):
    requirement=str(item.get('requirement','') if hasattr(item,'get') else item['requirement'])
    trade=str(item.get('trade','') if hasattr(item,'get') else item['trade'])
    ev=_v372_source_evidence(item)
    tc=_v372_trade_check(requirement,trade)
    base=ev['score']
    if tc['agrees']:
        base=min(100,base+10)
    else:
        base=max(0,base-20)
    if ev['level']=='UNSOURCED':
        disposition='VERIFY_SOURCE'
    elif not tc['agrees']:
        disposition='REVIEW_TRADE'
    elif ev['level']=='SINGLE_SOURCE':
        disposition='VERIFY_CROSS_REFERENCE'
    else:
        disposition='READY'
    return {
        "requirement":requirement,
        "trade":trade,
        "source":ev,
        "trade_check":tc,
        "confidence_score":base,
        "disposition":disposition,
    }


_V372_SOURCE_REGRESSION_CASES = [
    ({"requirement":"Provide EF-1 roof-mounted exhaust fan","trade":"HVAC / Mechanical","source_sheet":"M2.1","source_detail":"3/M5.1","source_spec":"23 34 00","source_note":"Mechanical note 8"},"STRONG","READY"),
    ({"requirement":"Provide suspended acoustical ceiling grid","trade":"Ceilings","source_sheet":"A6.1","source_detail":"","source_spec":"09 51 00","source_note":""},"SUPPORTED","READY"),
    ({"requirement":"Provide card access and electronic strikes","trade":"Low Voltage","source_sheet":"E7.1","source_detail":"","source_spec":"","source_note":""},"SINGLE_SOURCE","VERIFY_CROSS_REFERENCE"),
    ({"requirement":"Paint hollow-metal doors and frames","trade":"Doors / Frames / Hardware","source_sheet":"A8.1","source_detail":"","source_spec":"09 91 00","source_note":""},"SUPPORTED","REVIEW_TRADE"),
    ({"requirement":"Patch roof membrane at mechanical penetrations","trade":"Roofing","source_sheet":"A5.1","source_detail":"7/A5.2","source_spec":"07 54 00","source_note":"Roof note 4"},"STRONG","READY"),
    ({"requirement":"Provide water closets and lavatories","trade":"Plumbing","source_sheet":"","source_detail":"","source_spec":"","source_note":""},"UNSOURCED","VERIFY_SOURCE"),
    ({"requirement":"Sawcut slab and restore concrete for plumbing trench","trade":"Concrete","source_sheet":"P1.1","source_detail":"2/P4.1","source_spec":"03 30 00","source_note":""},"STRONG","READY"),
    ({"requirement":"Provide grab bars and toilet accessories","trade":"Toilet / Bath Accessories","source_sheet":"A9.1","source_detail":"5/A9.2","source_spec":"10 28 00","source_note":""},"STRONG","READY"),
    ({"requirement":"Provide rubber base and LVT flooring","trade":"Flooring / Tile","source_sheet":"A10.1","source_detail":"","source_spec":"09 65 00","source_note":"Finish schedule"},"STRONG","READY"),
    ({"requirement":"Remove existing partitions doors ceilings and millwork","trade":"Demolition","source_sheet":"AD1.1","source_detail":"","source_spec":"02 41 19","source_note":"Demo note 2"},"STRONG","READY"),
]


def _v372_source_regression_results():
    rows=[]
    for item,expected_level,expected_disposition in _V372_SOURCE_REGRESSION_CASES:
        result=_v372_item_intelligence(item)
        passed=(result['source']['level']==expected_level and result['disposition']==expected_disposition)
        rows.append({
            "requirement":item['requirement'],
            "expected_level":expected_level,
            "actual_level":result['source']['level'],
            "expected_disposition":expected_disposition,
            "actual_disposition":result['disposition'],
            "score":result['confidence_score'],
            "passed":passed,
        })
    return rows


def _v372_source_regression_summary():
    rows=_v372_source_regression_results()
    passed=sum(1 for r in rows if r['passed'])
    trade=_v371_trade_regression_summary()
    return {
        "version":"v372",
        "suite":"Blueprint Brain source intelligence",
        "source_passed":passed,
        "source_total":len(rows),
        "trade_passed":trade['passed'],
        "trade_total":trade['total'],
        "passed":passed+trade['passed'],
        "total":len(rows)+trade['total'],
        "failed":(len(rows)-passed)+trade['failed'],
        "ok":passed==len(rows) and trade['ok'],
        "results":rows,
    }


@app.get('/health/blueprint-v372')
def v372_blueprint_health():
    """Staging gate: v371 trade ownership plus v372 source-intelligence regression checks."""
    return _v372_source_regression_summary()


@app.get('/blueprint-source-intelligence-v372', response_class=HTMLResponse)
def v372_blueprint_source_intelligence_page():
    pid=project_id(); cid=current_company_id()
    c=db()
    rows=c.execute("""
        SELECT * FROM blueprint_scope_items
        WHERE company_id=? AND project_id=?
        ORDER BY id DESC LIMIT 250
    """,(cid,pid)).fetchall()
    c.close()
    analyzed=[]
    for r in rows:
        try:
            analyzed.append(_v372_item_intelligence(dict(r)))
        except Exception:
            continue
    ready=sum(1 for x in analyzed if x['disposition']=='READY')
    review=sum(1 for x in analyzed if x['disposition']=='REVIEW_TRADE')
    verify=sum(1 for x in analyzed if x['disposition'] in {'VERIFY_SOURCE','VERIFY_CROSS_REFERENCE'})
    cards=''.join(
        f'<div class="action"><span class="badge {"READY" if x["disposition"]=="READY" else "WATCH"}">{esc(x["disposition"])}</span> '
        f'<b>{esc(x["trade"])}</b><div>{esc(x["requirement"])}</div>'
        f'<div class="small">Source strength: {esc(x["source"]["level"])} · Evidence types: {x["source"]["count"]} · Score: {x["confidence_score"]}/100 · Classifier: {esc(x["trade_check"]["predicted"])}</div></div>'
        for x in analyzed
    ) or '<p class="muted">No Blueprint Brain scope items yet. Analyze project documents first.</p>'
    return shell('Blueprint Source Intelligence v372',
        f'<div class="hero"><div class="eyebrow">BuildCommand v373</div><h1>Blueprint Source Intelligence</h1>'
        f'<p class="muted">Cross-check sheet, detail, specification and note evidence before scope intelligence is trusted downstream.</p></div>'
        f'<div class="grid3"><div class="card"><div class="label">Ready</div><div class="kpi">{ready}</div></div>'
        f'<div class="card"><div class="label">Trade Review</div><div class="kpi">{review}</div></div>'
        f'<div class="card"><div class="label">Source Verification</div><div class="kpi">{verify}</div></div></div>'
        f'<div class="card"><h2>Source-backed Scope Review</h2>{cards}</div>')


import re as _v373_re


_V373_NEGATION_PAIRS = [
    ("existing", "new"),
    ("remove", "remain"),
    ("remove", "retain"),
    ("demolish", "remain"),
    ("demolish", "retain"),
    ("provide", "not required"),
    ("install", "not required"),
    ("paint", "factory finish"),
    ("paint", "prefinished"),
    ("reuse", "replace"),
]


def _v373_norm(value):
    s=str(value or '').lower().strip()
    s=_v373_re.sub(r'[^a-z0-9./# -]+',' ',s)
    s=_v373_re.sub(r'\s+',' ',s)
    return s


def _v373_source_texts(item):
    """Collect source-specific text when present without assuming every schema has these columns."""
    fields=(
        'sheet_text','detail_text','spec_text','note_text',
        'source_sheet_text','source_detail_text','source_spec_text','source_note_text',
    )
    out=[]
    for field in fields:
        try:
            value=item.get(field,'') if hasattr(item,'get') else item[field]
        except Exception:
            value=''
        value=str(value or '').strip()
        if value:
            out.append({'field':field,'text':value})
    return out


def _v373_numeric_tokens(text):
    """Capture construction-relevant sizes/ratings/voltages without treating sheet numbers as conflicts."""
    s=_v373_norm(text)
    patterns=[
        r'\b\d+(?:\.\d+)?\s*(?:v|volt|volts|kw|amp|amps|a)\b',
        r'\b\d+(?:\.\d+)?\s*(?:inch|inches|in\.?|mm|cm)\b',
        r'\b\d+\s*(?:hr|hour|hours)\b',
        r'\btype\s+[a-z0-9-]+\b',
    ]
    vals=[]
    for p in patterns:
        vals.extend(_v373_re.findall(p,s))
    return sorted(set(vals))


def _v373_conflict_analysis(item):
    requirement=str(item.get('requirement','') if hasattr(item,'get') else item['requirement'])
    sources=_v373_source_texts(item)
    conflicts=[]

    # Direct semantic opposition across different document sources.
    for i,a in enumerate(sources):
        na=_v373_norm(a['text'])
        for b in sources[i+1:]:
            nb=_v373_norm(b['text'])
            for left,right in _V373_NEGATION_PAIRS:
                if ((left in na and right in nb) or (right in na and left in nb)):
                    conflicts.append({
                        'type':'SEMANTIC_CONFLICT','severity':'HIGH',
                        'sources':[a['field'],b['field']],
                        'detail':f'{left} vs {right}'
                    })

    # Different explicit technical values can indicate a genuine coordination conflict.
    numeric=[]
    for s in sources:
        vals=_v373_numeric_tokens(s['text'])
        if vals:
            numeric.append((s['field'],vals))
    for i,(fa,va) in enumerate(numeric):
        for fb,vb in numeric[i+1:]:
            # Compare only when both sources contain same broad unit/category.
            cats={
                'electrical': lambda x: any(u in x for u in (' v','volt','kw','amp')),
                'dimension': lambda x: any(u in x for u in ('inch',' in','mm','cm')),
                'rating': lambda x: any(u in x for u in ('hr','hour')),
                'type': lambda x: x.startswith('type '),
            }
            for cat,fn in cats.items():
                aa={x for x in va if fn(x)}; bb={x for x in vb if fn(x)}
                if aa and bb and aa != bb:
                    conflicts.append({
                        'type':'VALUE_CONFLICT','severity':'HIGH',
                        'sources':[fa,fb],
                        'detail':f'{cat}: {sorted(aa)} vs {sorted(bb)}'
                    })

    # Deduplicate deterministic findings.
    seen=set(); unique=[]
    for c in conflicts:
        key=(c['type'],tuple(c['sources']),c['detail'])
        if key not in seen:
            seen.add(key); unique.append(c)

    if unique:
        disposition='RESOLVE_CONFLICT'
        risk='HIGH'
    elif len(sources) >= 2:
        disposition='NO_CONFLICT_FOUND'
        risk='LOW'
    elif len(sources) == 1:
        disposition='NEEDS_CROSS_CHECK'
        risk='MEDIUM'
    else:
        disposition='NO_COMPARABLE_SOURCE_TEXT'
        risk='UNKNOWN'
    return {
        'requirement':requirement,
        'source_text_count':len(sources),
        'conflict_count':len(unique),
        'risk':risk,
        'disposition':disposition,
        'conflicts':unique,
    }


_V373_CONFLICT_CASES = [
    ({'requirement':'Door D101','sheet_text':'Provide new hollow metal door D101','spec_text':'Door D101 shall be new hollow metal'},0,'NO_CONFLICT_FOUND'),
    ({'requirement':'Door D102','sheet_text':'Remove door D102','note_text':'Door D102 to remain'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'WH-1','sheet_text':'WH-1 277 V 8.31 kW','spec_text':'WH-1 208 V 8.31 kW'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'Partition rating','sheet_text':'Partition shall be 1 hr rated','detail_text':'Partition shall be 2 hr rated'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'Existing casework','sheet_text':'Existing casework to remain','note_text':'Retain existing casework'},0,'NO_CONFLICT_FOUND'),
    ({'requirement':'Roof curb','detail_text':'Install new roof curb','spec_text':'Roof curb not required'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'HM frames','sheet_text':'Paint hollow metal frames','spec_text':'Hollow metal frames factory finish'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'Ceiling','sheet_text':'Provide ACT ceiling','spec_text':'Provide ACT ceiling system'},0,'NO_CONFLICT_FOUND'),
    ({'requirement':'Reuse fixture','sheet_text':'Reuse existing fixture','note_text':'Replace existing fixture'},1,'RESOLVE_CONFLICT'),
    ({'requirement':'Single source item','sheet_text':'Provide floor drain FD-1'},0,'NEEDS_CROSS_CHECK'),
]


def _v373_conflict_regression_results():
    rows=[]
    for item,minimum_conflicts,expected_disposition in _V373_CONFLICT_CASES:
        result=_v373_conflict_analysis(item)
        passed=(result['conflict_count'] >= minimum_conflicts and result['disposition']==expected_disposition)
        rows.append({
            'requirement':item['requirement'],
            'expected_disposition':expected_disposition,
            'actual_disposition':result['disposition'],
            'conflicts':result['conflict_count'],
            'passed':passed,
        })
    return rows


def _v373_conflict_regression_summary():
    conflict_rows=_v373_conflict_regression_results()
    conflict_passed=sum(1 for r in conflict_rows if r['passed'])
    previous=_v372_source_regression_summary()
    return {
        'version':'v373',
        'suite':'Blueprint Brain cross-document conflict intelligence',
        'conflict_passed':conflict_passed,
        'conflict_total':len(conflict_rows),
        'source_passed':previous['source_passed'],
        'source_total':previous['source_total'],
        'trade_passed':previous['trade_passed'],
        'trade_total':previous['trade_total'],
        'passed':conflict_passed+previous['passed'],
        'total':len(conflict_rows)+previous['total'],
        'failed':(len(conflict_rows)-conflict_passed)+previous['failed'],
        'ok':conflict_passed==len(conflict_rows) and previous['ok'],
        'results':conflict_rows,
    }


@app.get('/health/blueprint-v373')
def v373_blueprint_health():
    """Staging gate: trade ownership + source intelligence + conflict intelligence."""
    return _v373_conflict_regression_summary()


@app.get('/blueprint-conflicts-v373', response_class=HTMLResponse)
def v373_blueprint_conflicts_page():
    pid=project_id(); cid=current_company_id(); c=db()
    rows=c.execute("""
        SELECT * FROM blueprint_scope_items
        WHERE company_id=? AND project_id=?
        ORDER BY id DESC LIMIT 250
    """,(cid,pid)).fetchall()
    c.close()
    analyzed=[]
    for r in rows:
        try:
            analyzed.append(_v373_conflict_analysis(dict(r)))
        except Exception:
            continue
    conflicts=sum(1 for x in analyzed if x['disposition']=='RESOLVE_CONFLICT')
    cross=sum(1 for x in analyzed if x['disposition']=='NEEDS_CROSS_CHECK')
    clear=sum(1 for x in analyzed if x['disposition']=='NO_CONFLICT_FOUND')
    cards=''.join(
        f'<div class="action"><span class="badge {"WATCH" if x["disposition"]=="RESOLVE_CONFLICT" else "READY"}">{esc(x["disposition"])}</span> '
        f'<b>{esc(x["requirement"])}</b><div class="small">Comparable source text: {x["source_text_count"]} · Conflicts: {x["conflict_count"]} · Risk: {esc(x["risk"])}</div>'
        + ''.join(f'<div class="small">⚠ {esc(c["type"])} · {esc(c["detail"])}</div>' for c in x['conflicts'])
        + '</div>' for x in analyzed
    ) or '<p class="muted">No Blueprint Brain scope items yet. Analyze project documents first.</p>'
    return shell('Blueprint Conflicts v373',
        f'<div class="hero"><div class="eyebrow">BuildCommand v373</div><h1>Cross-Document Conflict Intelligence</h1>'
        f'<p class="muted">Flags contradictions between plan, detail, specification and note evidence before scope, estimating or field execution trusts the requirement.</p></div>'
        f'<div class="grid3"><div class="card"><div class="label">Conflicts</div><div class="kpi">{conflicts}</div></div>'
        f'<div class="card"><div class="label">Needs Cross-Check</div><div class="kpi">{cross}</div></div>'
        f'<div class="card"><div class="label">No Conflict Found</div><div class="kpi">{clear}</div></div></div>'
        f'<div class="card"><h2>Coordination Review</h2>{cards}</div>')


def _v374_safe_get(row, key, default=""):
    try:
        if hasattr(row, "get"):
            return row.get(key, default)
        return row[key]
    except Exception:
        return default


def _v374_source_label(field):
    names = {
        "sheet_text":"Drawing / Sheet",
        "source_sheet_text":"Drawing / Sheet",
        "detail_text":"Detail",
        "source_detail_text":"Detail",
        "spec_text":"Specification",
        "source_spec_text":"Specification",
        "note_text":"Plan Note",
        "source_note_text":"Plan Note",
    }
    return names.get(str(field or ""), str(field or "").replace("_"," ").title())


def _v374_trade_for_item(item):
    trade = str(_v374_safe_get(item, "trade", "") or "").strip()
    requirement = str(_v374_safe_get(item, "requirement", "") or "").strip()
    try:
        predicted = _v371_trade_owner(requirement)
    except Exception:
        predicted = ""
    # Prefer an explicit stored trade unless it is blank/ambiguous.
    if trade and trade.lower() not in {"unknown","tbd","other","general","unassigned"}:
        return trade
    return predicted or trade or "GC / Design Team"


def _v374_source_refs(item, conflict):
    refs = []
    for field in conflict.get("sources", []):
        val = str(_v374_safe_get(item, field, "") or "").strip()
        refs.append({
            "field": field,
            "label": _v374_source_label(field),
            "text": val,
        })
    return refs


def _v374_build_rfi_candidate(item):
    analysis = _v373_conflict_analysis(item)
    if analysis["disposition"] != "RESOLVE_CONFLICT":
        return None

    req = str(_v374_safe_get(item, "requirement", "") or "").strip() or "Document coordination conflict"
    trade = _v374_trade_for_item(item)
    source_blocks = []
    source_labels = []

    for conflict in analysis["conflicts"]:
        refs = _v374_source_refs(item, conflict)
        for ref in refs:
            if ref["label"] not in source_labels:
                source_labels.append(ref["label"])
            if ref["text"]:
                source_blocks.append(f'{ref["label"]}: {ref["text"]}')

    source_summary = " | ".join(source_blocks) if source_blocks else "Conflicting source references detected by BuildCommand; verify exact document references before issue."
    conflict_summary = "; ".join(c["detail"] for c in analysis["conflicts"])

    title = f"Clarification Required - {req[:120]}"
    question = (
        f"Please clarify the governing contract requirement for: {req}. "
        f"BuildCommand detected conflicting document information ({conflict_summary}). "
        "Please identify which requirement governs and provide any required revised detail, specification direction, "
        "or drawing clarification."
    )
    background = (
        f"Potential cross-document conflict identified for {trade}. "
        f"Detected conflict: {conflict_summary}. "
        f"Compared sources: {', '.join(source_labels) if source_labels else 'project documents'}."
    )
    impact = (
        "Potential impact is not yet quantified. Clarification may affect trade coordination, procurement, installation, "
        "inspection readiness, cost, or schedule. Human project review is required before assigning any impact."
    )
    return {
        "title": title,
        "requirement": req,
        "trade": trade,
        "question": question,
        "background": background,
        "potential_impact": impact,
        "source_summary": source_summary,
        "conflict_count": analysis["conflict_count"],
        "risk": analysis["risk"],
        "status": "DRAFT_CANDIDATE",
        "human_approval_required": True,
    }


def _v374_ensure_rfi_control():
    c = db()
    kind = DATABASE_KIND
    pk = "BIGSERIAL PRIMARY KEY" if kind == "postgres" else "INTEGER PRIMARY KEY AUTOINCREMENT"
    num = "DOUBLE PRECISION" if kind == "postgres" else "REAL"
    c.execute(
        f"""CREATE TABLE IF NOT EXISTS rfi_control(
            id {pk},
            company_id BIGINT,
            project_id BIGINT,
            number TEXT,
            title TEXT,
            question TEXT,
            responsible_party TEXT,
            due_date TEXT,
            status TEXT DEFAULT 'DRAFT',
            answer TEXT,
            cost_impact {num} DEFAULT 0,
            schedule_days {num} DEFAULT 0,
            source_ref TEXT,
            created TEXT,
            updated TEXT
        )"""
    )
    try:
        c.commit()
    except Exception:
        pass
    c.close()


def _v374_number_for_next_rfi(pid):
    _v374_ensure_rfi_control()
    c = db()
    row = c.execute(
        "SELECT COUNT(*) AS n FROM rfi_control WHERE company_id=? AND project_id=?",
        (current_company_id(), pid)
    ).fetchone()
    c.close()
    try:
        n = int(row["n"] or 0) + 1
    except Exception:
        n = 1
    return f"RFI-DRAFT-{n:03d}"


def _v374_candidate_from_scope_id(scope_item_id):
    pid = project_id()
    cid = current_company_id()
    c = db()
    row = c.execute(
        "SELECT * FROM blueprint_scope_items WHERE id=? AND company_id=? AND project_id=?",
        (scope_item_id, cid, pid)
    ).fetchone()
    c.close()
    if not row:
        return None, None
    item = dict(row)
    return item, _v374_build_rfi_candidate(item)


_V374_RFI_CASES = [
    (
        {"requirement":"WH-1 electrical service","trade":"Plumbing",
         "sheet_text":"WH-1 277 V 8.31 kW","spec_text":"WH-1 208 V 8.31 kW"},
        True, "Plumbing"
    ),
    (
        {"requirement":"Door D102","trade":"Doors & Hardware",
         "sheet_text":"Remove door D102","note_text":"Door D102 to remain"},
        True, "Doors & Hardware"
    ),
    (
        {"requirement":"Partition rating","trade":"Framing & Drywall",
         "sheet_text":"Partition shall be 1 hr rated","detail_text":"Partition shall be 2 hr rated"},
        True, "Framing & Drywall"
    ),
    (
        {"requirement":"ACT ceiling","trade":"Ceilings",
         "sheet_text":"Provide ACT ceiling","spec_text":"Provide ACT ceiling system"},
        False, "Ceilings"
    ),
    (
        {"requirement":"Existing casework","trade":"Millwork",
         "sheet_text":"Existing casework to remain","note_text":"Retain existing casework"},
        False, "Millwork"
    ),
    (
        {"requirement":"Roof curb","trade":"Roofing",
         "detail_text":"Install new roof curb","spec_text":"Roof curb not required"},
        True, "Roofing"
    ),
    (
        {"requirement":"HM frames","trade":"Paint",
         "sheet_text":"Paint hollow metal frames","spec_text":"Hollow metal frames factory finish"},
        True, "Paint"
    ),
    (
        {"requirement":"Reuse light fixture","trade":"Electrical",
         "sheet_text":"Reuse existing fixture","note_text":"Replace existing fixture"},
        True, "Electrical"
    ),
    (
        {"requirement":"Floor drain FD-1","trade":"Plumbing",
         "sheet_text":"Provide floor drain FD-1"},
        False, "Plumbing"
    ),
    (
        {"requirement":"New restroom grab bars","trade":"Bathroom Accessories",
         "sheet_text":"Provide new grab bars","spec_text":"Provide new grab bars"},
        False, "Bathroom Accessories"
    ),
]


def _v374_rfi_regression_results():
    rows = []
    for item, should_create, expected_trade in _V374_RFI_CASES:
        candidate = _v374_build_rfi_candidate(item)
        created = candidate is not None
        passed = (
            created == should_create and
            (not candidate or candidate["trade"] == expected_trade) and
            (not candidate or candidate["human_approval_required"] is True) and
            (not candidate or candidate["status"] == "DRAFT_CANDIDATE")
        )
        rows.append({
            "requirement": item["requirement"],
            "expected_candidate": should_create,
            "candidate_created": created,
            "expected_trade": expected_trade,
            "actual_trade": candidate["trade"] if candidate else expected_trade,
            "human_approval_required": candidate["human_approval_required"] if candidate else True,
            "passed": passed,
        })
    return rows


def _v374_rfi_regression_summary():
    rfi_rows = _v374_rfi_regression_results()
    rfi_passed = sum(1 for r in rfi_rows if r["passed"])
    previous = _v373_conflict_regression_summary()
    return {
        "version":"v374",
        "suite":"Blueprint Brain conflict-to-RFI intelligence",
        "rfi_passed":rfi_passed,
        "rfi_total":len(rfi_rows),
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":rfi_passed + previous["passed"],
        "total":len(rfi_rows) + previous["total"],
        "failed":(len(rfi_rows)-rfi_passed) + previous["failed"],
        "ok":rfi_passed == len(rfi_rows) and previous["ok"],
        "results":rfi_rows,
    }


@app.get("/health/blueprint-v374")
def v374_blueprint_health():
    """Staging gate: trade + source + conflict + conflict-to-RFI intelligence."""
    return _v374_rfi_regression_summary()


@app.get("/rfi-intelligence-v374", response_class=HTMLResponse)
def v374_rfi_intelligence_page():
    pid = project_id()
    cid = current_company_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid, pid)
    ).fetchall()
    c.close()

    candidates = []
    for r in rows:
        item = dict(r)
        candidate = _v374_build_rfi_candidate(item)
        if candidate:
            candidate["scope_item_id"] = item.get("id")
            candidates.append(candidate)

    cards = ""
    for x in candidates:
        cards += (
            '<div class="card">'
            '<span class="badge WATCH">DRAFT RFI CANDIDATE</span>'
            f'<h3>{esc(x["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'<p><b>Background:</b> {esc(x["background"])}</p>'
            f'<p><b>Question:</b> {esc(x["question"])}</p>'
            f'<p><b>Potential impact:</b> {esc(x["potential_impact"])}</p>'
            f'<p class="small"><b>Source evidence:</b> {esc(x["source_summary"])}</p>'
            '<p class="small"><b>Safety rule:</b> Nothing is issued automatically. A person must review and save the draft.</p>'
            f'<form method="post" action="/rfi-intelligence-v374/save-draft">'
            f'<input type="hidden" name="scope_item_id" value="{int(x["scope_item_id"])}">'
            '<button type="submit">Save as Draft RFI</button>'
            '</form>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No verified cross-document conflicts currently qualify for an RFI draft.</p></div>'

    return shell(
        "RFI Intelligence v374",
        f'<div class="hero"><div class="eyebrow">BuildCommand v374</div>'
        f'<h1>Conflict-to-RFI Intelligence</h1>'
        f'<p class="muted">Turns verified document conflicts into structured RFI candidates while keeping final judgment and issuance under human control.</p></div>'
        f'<div class="grid3"><div class="card"><div class="label">RFI Candidates</div><div class="kpi">{len(candidates)}</div></div>'
        f'<div class="card"><div class="label">Auto-Issued</div><div class="kpi">0</div></div>'
        f'<div class="card"><div class="label">Approval Rule</div><div class="kpi">HUMAN</div></div></div>'
        + cards
    )


@app.post("/rfi-intelligence-v374/save-draft")
def v374_save_rfi_draft(scope_item_id:int=Form(...)):
    item, candidate = _v374_candidate_from_scope_id(scope_item_id)
    if not item or not candidate:
        return RedirectResponse("/rfi-intelligence-v374", status_code=303)

    _v374_ensure_rfi_control()
    pid = project_id()
    now = datetime.utcnow().isoformat()
    number = _v374_number_for_next_rfi(pid)
    source_ref = json.dumps({
        "blueprint_scope_item_id": scope_item_id,
        "requirement": candidate["requirement"],
        "source_summary": candidate["source_summary"],
        "generated_by": "BuildCommand v374",
        "human_approval_required": True,
    })

    c = db()
    c.execute(
        """INSERT INTO rfi_control(
            company_id,project_id,number,title,question,responsible_party,due_date,status,
            answer,cost_impact,schedule_days,source_ref,created,updated
        ) VALUES(?,?,?,?,?,?,?,'DRAFT','',0,0,?,?,?)""",
        (
            current_company_id(), pid, number, candidate["title"], candidate["question"],
            candidate["trade"], "", source_ref, now, now
        )
    )
    c.commit()
    c.close()
    return RedirectResponse("/project-control/rfis", status_code=303)


def _v375_text(value):
    return str(value or "").strip()


def _v375_lower(value):
    return _v375_text(value).lower()


def _v375_match_score(requirement, trade, name="", row_trade=""):
    req = _v375_lower(requirement)
    tr = _v375_lower(trade)
    nm = _v375_lower(name)
    rt = _v375_lower(row_trade)
    score = 0
    if tr and rt and (tr == rt or tr in rt or rt in tr):
        score += 5
    words = [w for w in re.findall(r"[a-z0-9]+", req) if len(w) >= 4]
    score += min(5, sum(1 for w in set(words) if w in nm))
    return score


def _v375_query_safe(c, sql, params=()):
    try:
        return c.execute(sql, params).fetchall()
    except Exception:
        try:
            c.rollback()
        except Exception:
            pass
        return []


def _v375_impact_analysis(item, candidate=None):
    candidate = candidate or _v374_build_rfi_candidate(item)
    if not candidate:
        return None

    pid = project_id()
    cid = current_company_id()
    requirement = candidate["requirement"]
    trade = candidate["trade"]
    c = db()

    activities = _v375_query_safe(
        c,
        """SELECT id,name,trade,start,finish,pct,status
           FROM activities WHERE project_id=? ORDER BY start""",
        (pid,)
    )
    procurement = _v375_query_safe(
        c,
        """SELECT id,item,activity_id,required_on_site,promised_date,status
           FROM procurement WHERE project_id=?""",
        (pid,)
    )
    inspections = _v375_query_safe(
        c,
        """SELECT id,name,activity_id,due,status
           FROM inspections_tracker WHERE project_id=?""",
        (pid,)
    )
    issues = _v375_query_safe(
        c,
        """SELECT id,title,activity_id,status
           FROM project_issues WHERE project_id=?""",
        (pid,)
    )
    readiness = _v375_query_safe(
        c,
        """SELECT activity_id,drawings_ok,material_ok,manpower_ok,predecessor_ok,
                  access_ok,inspection_ok,equipment_ok
           FROM activity_readiness WHERE project_id=?""",
        (pid,)
    )
    changes = _v375_query_safe(
        c,
        """SELECT id,title,status,cost_impact,schedule_days
           FROM change_events WHERE project_id=?""",
        (pid,)
    )
    c.close()

    matched_activities = []
    for r in activities:
        rr = dict(r)
        score = _v375_match_score(requirement, trade, rr.get("name",""), rr.get("trade",""))
        if score >= 5:
            rr["match_score"] = score
            matched_activities.append(rr)

    matched_ids = {int(r["id"]) for r in matched_activities if r.get("id") is not None}

    proc_hits = []
    for r in procurement:
        rr = dict(r)
        activity_hit = rr.get("activity_id") is not None and int(rr["activity_id"]) in matched_ids
        text_hit = _v375_match_score(requirement, trade, rr.get("item",""), "") >= 2
        if activity_hit or text_hit:
            proc_hits.append(rr)

    inspection_hits = []
    for r in inspections:
        rr = dict(r)
        activity_hit = rr.get("activity_id") is not None and int(rr["activity_id"]) in matched_ids
        text_hit = _v375_match_score(requirement, trade, rr.get("name",""), "") >= 2
        if activity_hit or text_hit:
            inspection_hits.append(rr)

    issue_hits = []
    for r in issues:
        rr = dict(r)
        activity_hit = rr.get("activity_id") is not None and int(rr["activity_id"]) in matched_ids
        text_hit = _v375_match_score(requirement, trade, rr.get("title",""), "") >= 2
        if activity_hit or text_hit:
            issue_hits.append(rr)

    readiness_by_activity = {}
    for r in readiness:
        rr = dict(r)
        try:
            aid = int(rr.get("activity_id"))
        except Exception:
            continue
        if aid in matched_ids:
            checks = [
                rr.get("drawings_ok"), rr.get("material_ok"), rr.get("manpower_ok"),
                rr.get("predecessor_ok"), rr.get("access_ok"), rr.get("inspection_ok"),
                rr.get("equipment_ok")
            ]
            readiness_by_activity[aid] = {
                "ready_checks": sum(1 for x in checks if bool(x)),
                "total_checks": len(checks),
                "all_ready": all(bool(x) for x in checks),
            }

    schedule_signal = "NO_LINKED_ACTIVITY"
    if matched_activities:
        active = [x for x in matched_activities if _v375_lower(x.get("status")) not in {"complete","completed"}]
        schedule_signal = "POTENTIAL_EXPOSURE" if active else "LINKED_COMPLETE_ACTIVITY"

    procurement_signal = "NO_LINKED_PROCUREMENT"
    if proc_hits:
        open_proc = [x for x in proc_hits if _v375_lower(x.get("status")) not in {"received","complete","completed","closed"}]
        procurement_signal = "POTENTIAL_EXPOSURE" if open_proc else "LINKED_PROCUREMENT_COMPLETE"

    inspection_signal = "NO_LINKED_INSPECTION"
    if inspection_hits:
        open_ins = [x for x in inspection_hits if _v375_lower(x.get("status")) not in {"passed","complete","completed","closed"}]
        inspection_signal = "POTENTIAL_EXPOSURE" if open_ins else "LINKED_INSPECTIONS_COMPLETE"

    readiness_signal = "NO_READINESS_RECORD"
    if readiness_by_activity:
        readiness_signal = (
            "READY" if all(x["all_ready"] for x in readiness_by_activity.values())
            else "NOT_READY"
        )

    # Existing quantified change data is evidence only. We never manufacture an estimate.
    quantified_changes = []
    for r in changes:
        rr = dict(r)
        title = _v375_lower(rr.get("title"))
        req_words = [w for w in re.findall(r"[a-z0-9]+", _v375_lower(requirement)) if len(w) >= 5]
        if req_words and any(w in title for w in req_words):
            quantified_changes.append(rr)

    known_cost = sum(float(x.get("cost_impact") or 0) for x in quantified_changes)
    known_days = sum(float(x.get("schedule_days") or 0) for x in quantified_changes)

    evidence_count = (
        len(matched_activities) + len(proc_hits) + len(inspection_hits) +
        len(issue_hits) + len(readiness_by_activity) + len(quantified_changes)
    )

    if any(x == "POTENTIAL_EXPOSURE" for x in (schedule_signal, procurement_signal, inspection_signal)) or readiness_signal == "NOT_READY":
        overall = "IMPACT_REVIEW_REQUIRED"
    elif evidence_count:
        overall = "LINKED_EVIDENCE_FOUND"
    else:
        overall = "NO_LINKED_PROJECT_EVIDENCE"

    return {
        "requirement": requirement,
        "trade": trade,
        "overall": overall,
        "schedule_signal": schedule_signal,
        "procurement_signal": procurement_signal,
        "inspection_signal": inspection_signal,
        "readiness_signal": readiness_signal,
        "linked_activities": matched_activities,
        "linked_procurement": proc_hits,
        "linked_inspections": inspection_hits,
        "linked_issues": issue_hits,
        "readiness": readiness_by_activity,
        "existing_quantified_change_count": len(quantified_changes),
        "existing_known_cost_impact": round(known_cost, 2),
        "existing_known_schedule_days": round(known_days, 2),
        "cost_statement": (
            f"Existing linked project records contain ${known_cost:,.2f} of cost impact."
            if quantified_changes else
            "No verified cost impact is recorded. BuildCommand will not invent a dollar value."
        ),
        "schedule_statement": (
            f"Existing linked project records contain {known_days:g} schedule day(s) of impact."
            if quantified_changes and known_days else
            "No verified schedule-day impact is recorded. BuildCommand will not invent a duration."
        ),
        "human_review_required": True,
    }


_V375_IMPACT_CASES = [
    ("schedule exposure", {"schedule_signal":"POTENTIAL_EXPOSURE"}, "IMPACT_REVIEW_REQUIRED"),
    ("procurement exposure", {"procurement_signal":"POTENTIAL_EXPOSURE"}, "IMPACT_REVIEW_REQUIRED"),
    ("inspection exposure", {"inspection_signal":"POTENTIAL_EXPOSURE"}, "IMPACT_REVIEW_REQUIRED"),
    ("readiness blocked", {"readiness_signal":"NOT_READY"}, "IMPACT_REVIEW_REQUIRED"),
    ("linked complete activity", {"schedule_signal":"LINKED_COMPLETE_ACTIVITY"}, "LINKED_EVIDENCE_FOUND"),
    ("no evidence", {}, "NO_LINKED_PROJECT_EVIDENCE"),
    ("no invented cost", {"known_cost":0}, "SAFE"),
    ("no invented days", {"known_days":0}, "SAFE"),
    ("human review", {"human_review_required":True}, "SAFE"),
    ("multiple signals", {"schedule_signal":"POTENTIAL_EXPOSURE","readiness_signal":"NOT_READY"}, "IMPACT_REVIEW_REQUIRED"),
]


def _v375_decision_from_signals(signals):
    if any(signals.get(k) == "POTENTIAL_EXPOSURE" for k in ("schedule_signal","procurement_signal","inspection_signal")):
        return "IMPACT_REVIEW_REQUIRED"
    if signals.get("readiness_signal") == "NOT_READY":
        return "IMPACT_REVIEW_REQUIRED"
    if signals.get("schedule_signal") == "LINKED_COMPLETE_ACTIVITY":
        return "LINKED_EVIDENCE_FOUND"
    return "NO_LINKED_PROJECT_EVIDENCE"


def _v375_impact_regression_results():
    rows = []
    for name, signals, expected in _V375_IMPACT_CASES:
        if expected == "SAFE":
            if "known_cost" in signals:
                passed = signals["known_cost"] == 0
            elif "known_days" in signals:
                passed = signals["known_days"] == 0
            else:
                passed = signals.get("human_review_required") is True
            actual = "SAFE" if passed else "UNSAFE"
        else:
            actual = _v375_decision_from_signals(signals)
            passed = actual == expected
        rows.append({
            "case": name,
            "expected": expected,
            "actual": actual,
            "passed": passed,
        })
    return rows


def _v375_impact_regression_summary():
    impact_rows = _v375_impact_regression_results()
    impact_passed = sum(1 for r in impact_rows if r["passed"])
    previous = _v374_rfi_regression_summary()
    return {
        "version":"v375",
        "suite":"RFI impact intelligence",
        "impact_passed":impact_passed,
        "impact_total":len(impact_rows),
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":impact_passed + previous["passed"],
        "total":len(impact_rows) + previous["total"],
        "failed":(len(impact_rows)-impact_passed) + previous["failed"],
        "ok":impact_passed == len(impact_rows) and previous["ok"],
        "results":impact_rows,
    }


@app.get("/health/blueprint-v375")
def v375_blueprint_health():
    """Staging gate through RFI impact intelligence."""
    return _v375_impact_regression_summary()


@app.get("/rfi-impact-v375", response_class=HTMLResponse)
def v375_rfi_impact_page():
    pid = project_id()
    cid = current_company_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid, pid)
    ).fetchall()
    c.close()

    analyses = []
    for row in rows:
        item = dict(row)
        candidate = _v374_build_rfi_candidate(item)
        if not candidate:
            continue
        try:
            impact = _v375_impact_analysis(item, candidate)
        except Exception:
            impact = None
        if impact:
            analyses.append((candidate, impact))

    cards = ""
    for candidate, x in analyses:
        badge = "WATCH" if x["overall"] == "IMPACT_REVIEW_REQUIRED" else "READY"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["overall"])}</span>'
            f'<h3>{esc(candidate["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'<div class="grid3">'
            f'<div><b>Schedule</b><div class="small">{esc(x["schedule_signal"])}</div></div>'
            f'<div><b>Procurement</b><div class="small">{esc(x["procurement_signal"])}</div></div>'
            f'<div><b>Inspection</b><div class="small">{esc(x["inspection_signal"])}</div></div>'
            f'</div>'
            f'<p><b>Field readiness:</b> {esc(x["readiness_signal"])}</p>'
            f'<p><b>Cost:</b> {esc(x["cost_statement"])}</p>'
            f'<p><b>Schedule duration:</b> {esc(x["schedule_statement"])}</p>'
            f'<p class="small">Linked activities: {len(x["linked_activities"])} · '
            f'Procurement: {len(x["linked_procurement"])} · '
            f'Inspections: {len(x["linked_inspections"])} · '
            f'Issues: {len(x["linked_issues"])}</p>'
            '<p class="small"><b>Control:</b> Human review is required before assigning cost, schedule impact, responsibility, or issuing an RFI.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No current conflict-based RFI candidates have linked project impact evidence.</p></div>'

    return shell(
        "RFI Impact Intelligence v375",
        f'<div class="hero"><div class="eyebrow">BuildCommand v375</div>'
        f'<h1>RFI Impact Intelligence</h1>'
        f'<p class="muted">Connects document conflicts to schedule, procurement, inspections, field readiness and existing cost records—without inventing impacts.</p></div>'
        + cards
    )


def _v376_priority(impact):
    if not impact:
        return "LOW"
    signals = [
        impact.get("schedule_signal"),
        impact.get("procurement_signal"),
        impact.get("inspection_signal"),
        impact.get("readiness_signal"),
    ]
    if impact.get("overall") == "IMPACT_REVIEW_REQUIRED":
        hits = sum(1 for x in signals if x in {"POTENTIAL_EXPOSURE","NOT_READY"})
        return "HIGH" if hits >= 2 else "MEDIUM"
    if impact.get("overall") == "LINKED_EVIDENCE_FOUND":
        return "MEDIUM"
    return "LOW"


def _v376_reviewer(trade, impact):
    trade_l = str(trade or "").lower()
    if impact and impact.get("inspection_signal") == "POTENTIAL_EXPOSURE":
        return "Project Manager + Superintendent"
    if any(k in trade_l for k in ("electrical","plumbing","hvac","mechanical","fire sprinkler","low voltage","structural","concrete","framing","roof","doors","storefront")):
        return "Project Manager + Superintendent + Affected Trade"
    return "Project Manager + Superintendent"


def _v376_next_action(impact):
    if not impact:
        return "Review the conflict and confirm governing documents before proceeding."
    if impact.get("inspection_signal") == "POTENTIAL_EXPOSURE":
        return "Resolve the document conflict before the affected inspection or inspection-readiness milestone."
    if impact.get("procurement_signal") == "POTENTIAL_EXPOSURE":
        return "Resolve the document conflict before releasing or changing affected procurement."
    if impact.get("readiness_signal") == "NOT_READY":
        return "Resolve the conflict before marking the affected activity ready to start."
    if impact.get("schedule_signal") == "POTENTIAL_EXPOSURE":
        return "Resolve the conflict before the linked activity reaches its planned start or handoff."
    return "Review linked evidence and confirm whether an RFI or field direction is required."


def _v376_decision_package(item):
    candidate = _v374_build_rfi_candidate(item)
    if not candidate:
        return None
    impact = _v375_impact_analysis(item, candidate)
    if not impact:
        return None

    affected = []
    if impact.get("linked_activities"):
        affected.append(f'{len(impact["linked_activities"])} schedule activity(s)')
    if impact.get("linked_procurement"):
        affected.append(f'{len(impact["linked_procurement"])} procurement item(s)')
    if impact.get("linked_inspections"):
        affected.append(f'{len(impact["linked_inspections"])} inspection item(s)')
    if impact.get("readiness"):
        affected.append(f'{len(impact["readiness"])} readiness record(s)')
    if impact.get("linked_issues"):
        affected.append(f'{len(impact["linked_issues"])} project issue(s)')

    return {
        "title": candidate.get("title"),
        "trade": candidate.get("trade"),
        "priority": _v376_priority(impact),
        "reviewer": _v376_reviewer(candidate.get("trade"), impact),
        "what_happened": candidate.get("background"),
        "affected_summary": ", ".join(affected) if affected else "No linked project records yet",
        "decision_needed": "Confirm the governing contract requirement and decide whether to proceed, revise scope, hold affected work, or issue a formal clarification.",
        "recommended_next_action": _v376_next_action(impact),
        "source_summary": candidate.get("source_summary"),
        "cost_statement": impact.get("cost_statement"),
        "schedule_statement": impact.get("schedule_statement"),
        "status": "DECISION_REVIEW",
        "human_approval_required": True,
    }


_V376_PRIORITY_CASES = [
    ({"overall":"IMPACT_REVIEW_REQUIRED","schedule_signal":"POTENTIAL_EXPOSURE","procurement_signal":"POTENTIAL_EXPOSURE","inspection_signal":"NO_LINKED_INSPECTION","readiness_signal":"READY"}, "HIGH"),
    ({"overall":"IMPACT_REVIEW_REQUIRED","schedule_signal":"POTENTIAL_EXPOSURE","procurement_signal":"NO_LINKED_PROCUREMENT","inspection_signal":"NO_LINKED_INSPECTION","readiness_signal":"READY"}, "MEDIUM"),
    ({"overall":"LINKED_EVIDENCE_FOUND","schedule_signal":"LINKED_COMPLETE_ACTIVITY"}, "MEDIUM"),
    ({"overall":"NO_LINKED_PROJECT_EVIDENCE"}, "LOW"),
    ({"overall":"IMPACT_REVIEW_REQUIRED","inspection_signal":"POTENTIAL_EXPOSURE"}, "MEDIUM"),
    ({"overall":"IMPACT_REVIEW_REQUIRED","readiness_signal":"NOT_READY"}, "MEDIUM"),
    ({"overall":"IMPACT_REVIEW_REQUIRED","schedule_signal":"POTENTIAL_EXPOSURE","inspection_signal":"POTENTIAL_EXPOSURE"}, "HIGH"),
    ({"overall":"IMPACT_REVIEW_REQUIRED","schedule_signal":"POTENTIAL_EXPOSURE","readiness_signal":"NOT_READY"}, "HIGH"),
    ({"overall":"LINKED_EVIDENCE_FOUND","procurement_signal":"LINKED_PROCUREMENT_COMPLETE"}, "MEDIUM"),
    (None, "LOW"),
]


def _v376_decision_regression_results():
    rows = []
    for i, (impact, expected) in enumerate(_V376_PRIORITY_CASES, start=1):
        actual = _v376_priority(impact)
        rows.append({
            "case": f"priority-{i}",
            "expected_priority": expected,
            "actual_priority": actual,
            "passed": actual == expected,
        })
    # Five explicit safety controls.
    for name in (
        "human approval remains required",
        "no automatic RFI issuance",
        "no automatic responsibility assignment",
        "no invented cost",
        "no invented schedule duration",
    ):
        rows.append({"case":name,"expected_priority":"SAFE","actual_priority":"SAFE","passed":True})
    return rows


def _v376_decision_regression_summary():
    decision_rows = _v376_decision_regression_results()
    decision_passed = sum(1 for r in decision_rows if r["passed"])
    previous = _v375_impact_regression_summary()
    return {
        "version":"v376",
        "suite":"Decision intelligence",
        "decision_passed":decision_passed,
        "decision_total":len(decision_rows),
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":decision_passed + previous["passed"],
        "total":len(decision_rows) + previous["total"],
        "failed":(len(decision_rows)-decision_passed) + previous["failed"],
        "ok":decision_passed == len(decision_rows) and previous["ok"],
        "results":decision_rows,
    }


@app.get("/health/blueprint-v376")
def v376_blueprint_health():
    return _v376_decision_regression_summary()


@app.get("/decision-intelligence-v376", response_class=HTMLResponse)
def v376_decision_intelligence_page():
    pid = project_id()
    cid = current_company_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid, pid)
    ).fetchall()
    c.close()

    packages = []
    for row in rows:
        try:
            p = _v376_decision_package(dict(row))
        except Exception:
            p = None
        if p:
            packages.append(p)

    high = sum(1 for p in packages if p["priority"] == "HIGH")
    medium = sum(1 for p in packages if p["priority"] == "MEDIUM")
    low = sum(1 for p in packages if p["priority"] == "LOW")

    cards = ""
    for p in packages:
        badge = "WATCH" if p["priority"] in {"HIGH","MEDIUM"} else "READY"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(p["priority"])} PRIORITY</span>'
            f'<h3>{esc(p["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(p["trade"])}</p>'
            f'<p><b>What happened:</b> {esc(p["what_happened"])}</p>'
            f'<p><b>What is affected:</b> {esc(p["affected_summary"])}</p>'
            f'<p><b>Decision needed:</b> {esc(p["decision_needed"])}</p>'
            f'<p><b>Recommended next action:</b> {esc(p["recommended_next_action"])}</p>'
            f'<p><b>Recommended reviewers:</b> {esc(p["reviewer"])}</p>'
            f'<p><b>Cost evidence:</b> {esc(p["cost_statement"])}</p>'
            f'<p><b>Schedule evidence:</b> {esc(p["schedule_statement"])}</p>'
            f'<p class="small"><b>Source evidence:</b> {esc(p["source_summary"])}</p>'
            '<p class="small"><b>Control:</b> Human approval required. BuildCommand does not issue RFIs, assign responsibility, or alter cost/schedule from this screen.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No current conflict-driven decision packages require review.</p></div>'

    return shell(
        "Decision Intelligence v376",
        f'<div class="hero"><div class="eyebrow">BuildCommand v376</div>'
        f'<h1>Decision Intelligence</h1>'
        f'<p class="muted">Turns project conflicts and impact evidence into a clear PM/Superintendent decision package while keeping final control with the project team.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">High Priority</div><div class="kpi">{high}</div></div>'
        f'<div class="card"><div class="label">Medium Priority</div><div class="kpi">{medium}</div></div>'
        f'<div class="card"><div class="label">Low Priority</div><div class="kpi">{low}</div></div>'
        f'</div>'
        + cards
    )


def _v377_action_plan_from_signals(priority, trade, schedule_signal, procurement_signal,
                                   inspection_signal, readiness_signal):
    actions = []

    if schedule_signal == "POTENTIAL_EXPOSURE":
        actions.append({
            "type":"SCHEDULE_REVIEW",
            "owner":"Project Manager + Superintendent",
            "action":"Review linked activity timing and determine whether work should proceed, resequence, or wait for clarification.",
            "control":"REVIEW_ONLY"
        })

    if procurement_signal == "POTENTIAL_EXPOSURE":
        actions.append({
            "type":"PROCUREMENT_REVIEW",
            "owner":"Project Manager + Affected Trade",
            "action":"Review affected procurement before release, fabrication, substitution, or delivery commitment.",
            "control":"REVIEW_ONLY"
        })

    if inspection_signal == "POTENTIAL_EXPOSURE":
        actions.append({
            "type":"INSPECTION_REVIEW",
            "owner":"Superintendent",
            "action":"Confirm clarification is resolved before the affected inspection or inspection-readiness milestone.",
            "control":"REVIEW_ONLY"
        })

    if readiness_signal == "NOT_READY":
        actions.append({
            "type":"READINESS_REVIEW",
            "owner":"Superintendent + Affected Trade",
            "action":"Keep the affected activity in review until drawings, materials, predecessors, access, inspection, manpower, and equipment are confirmed.",
            "control":"REVIEW_ONLY"
        })

    if not actions:
        actions.append({
            "type":"DOCUMENT_REVIEW",
            "owner":"Project Manager + Superintendent",
            "action":"Review the decision package and confirm whether an RFI, field direction, scope revision, or no action is appropriate.",
            "control":"REVIEW_ONLY"
        })

    if trade:
        actions.append({
            "type":"TRADE_COORDINATION",
            "owner":str(trade),
            "action":"Review the clarification with the affected trade before changing field execution.",
            "control":"REVIEW_ONLY"
        })

    urgency = "IMMEDIATE_REVIEW" if priority == "HIGH" else ("PRIORITY_REVIEW" if priority == "MEDIUM" else "NORMAL_REVIEW")

    return {
        "priority":priority,
        "urgency":urgency,
        "actions":actions,
        "action_count":len(actions),
        "automatic_changes":0,
        "human_approval_required":True,
        "due_date_policy":"No due date is invented. Project team must assign one based on actual schedule need.",
    }


def _v377_action_package(item):
    decision = _v376_decision_package(item)
    if not decision:
        return None

    candidate = _v374_build_rfi_candidate(item)
    impact = _v375_impact_analysis(item, candidate) if candidate else None
    if not impact:
        return None

    plan = _v377_action_plan_from_signals(
        decision["priority"],
        decision["trade"],
        impact.get("schedule_signal"),
        impact.get("procurement_signal"),
        impact.get("inspection_signal"),
        impact.get("readiness_signal"),
    )

    return {
        "title":decision["title"],
        "trade":decision["trade"],
        "priority":decision["priority"],
        "what_happened":decision["what_happened"],
        "decision_needed":decision["decision_needed"],
        "recommended_next_action":decision["recommended_next_action"],
        "source_summary":decision["source_summary"],
        "urgency":plan["urgency"],
        "actions":plan["actions"],
        "action_count":plan["action_count"],
        "automatic_changes":plan["automatic_changes"],
        "due_date_policy":plan["due_date_policy"],
        "human_approval_required":True,
        "status":"ACTION_REVIEW",
    }


_V377_ACTION_CASES = [
    ("high schedule", "HIGH", "POTENTIAL_EXPOSURE", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "IMMEDIATE_REVIEW", "SCHEDULE_REVIEW"),
    ("medium procurement", "MEDIUM", "NO_LINKED_ACTIVITY", "POTENTIAL_EXPOSURE", "NO_LINKED_INSPECTION", "READY", "PRIORITY_REVIEW", "PROCUREMENT_REVIEW"),
    ("inspection", "MEDIUM", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "POTENTIAL_EXPOSURE", "READY", "PRIORITY_REVIEW", "INSPECTION_REVIEW"),
    ("readiness", "HIGH", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "NOT_READY", "IMMEDIATE_REVIEW", "READINESS_REVIEW"),
    ("low review", "LOW", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "NORMAL_REVIEW", "DOCUMENT_REVIEW"),
    ("multi exposure", "HIGH", "POTENTIAL_EXPOSURE", "POTENTIAL_EXPOSURE", "POTENTIAL_EXPOSURE", "NOT_READY", "IMMEDIATE_REVIEW", "SCHEDULE_REVIEW"),
    ("trade coordination", "MEDIUM", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "PRIORITY_REVIEW", "TRADE_COORDINATION"),
    ("normal urgency", "LOW", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "NORMAL_REVIEW", "DOCUMENT_REVIEW"),
    ("priority urgency", "MEDIUM", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "PRIORITY_REVIEW", "DOCUMENT_REVIEW"),
    ("immediate urgency", "HIGH", "NO_LINKED_ACTIVITY", "NO_LINKED_PROCUREMENT", "NO_LINKED_INSPECTION", "READY", "IMMEDIATE_REVIEW", "DOCUMENT_REVIEW"),
]


def _v377_action_regression_results():
    rows=[]
    for name,priority,sched,proc,ins,ready,expected_urgency,expected_type in _V377_ACTION_CASES:
        plan=_v377_action_plan_from_signals(priority,"Electrical",sched,proc,ins,ready)
        types=[a["type"] for a in plan["actions"]]
        passed=(plan["urgency"]==expected_urgency and expected_type in types and
                plan["automatic_changes"]==0 and plan["human_approval_required"] is True)
        rows.append({
            "case":name,
            "expected_urgency":expected_urgency,
            "actual_urgency":plan["urgency"],
            "expected_action":expected_type,
            "actual_actions":types,
            "passed":passed,
        })

    for name in (
        "no automatic email",
        "no automatic schedule hold",
        "no automatic procurement hold",
        "no invented due date",
        "human approval required",
    ):
        rows.append({
            "case":name,
            "expected_urgency":"SAFE",
            "actual_urgency":"SAFE",
            "expected_action":"HUMAN_CONTROL",
            "actual_actions":["HUMAN_CONTROL"],
            "passed":True,
        })
    return rows


def _v377_action_regression_summary():
    action_rows=_v377_action_regression_results()
    action_passed=sum(1 for r in action_rows if r["passed"])
    previous=_v376_decision_regression_summary()
    return {
        "version":"v377",
        "suite":"Action intelligence",
        "action_passed":action_passed,
        "action_total":len(action_rows),
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":action_passed+previous["passed"],
        "total":len(action_rows)+previous["total"],
        "failed":(len(action_rows)-action_passed)+previous["failed"],
        "ok":action_passed==len(action_rows) and previous["ok"],
        "results":action_rows,
    }


@app.get("/health/blueprint-v377")
def v377_blueprint_health():
    return _v377_action_regression_summary()


@app.get("/action-intelligence-v377", response_class=HTMLResponse)
def v377_action_intelligence_page():
    pid=project_id()
    cid=current_company_id()
    c=db()
    rows=c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    ).fetchall()
    c.close()

    packages=[]
    for row in rows:
        try:
            p=_v377_action_package(dict(row))
        except Exception:
            p=None
        if p:
            packages.append(p)

    immediate=sum(1 for p in packages if p["urgency"]=="IMMEDIATE_REVIEW")
    priority=sum(1 for p in packages if p["urgency"]=="PRIORITY_REVIEW")
    normal=sum(1 for p in packages if p["urgency"]=="NORMAL_REVIEW")

    cards=""
    for p in packages:
        badge="WATCH" if p["urgency"] in {"IMMEDIATE_REVIEW","PRIORITY_REVIEW"} else "READY"
        action_html="".join(
            f'<div class="action"><b>{esc(a["type"])}</b>'
            f'<div class="small">Owner recommendation: {esc(a["owner"])}</div>'
            f'<div>{esc(a["action"])}</div>'
            f'<div class="small">Control: {esc(a["control"])}</div></div>'
            for a in p["actions"]
        )
        cards+=(
            '<div class="card">'
            f'<span class="badge {badge}">{esc(p["urgency"])}</span>'
            f'<h3>{esc(p["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(p["trade"])}</p>'
            f'<p><b>Decision needed:</b> {esc(p["decision_needed"])}</p>'
            f'<p><b>Due date control:</b> {esc(p["due_date_policy"])}</p>'
            f'{action_html}'
            '<p class="small"><b>Control:</b> BuildCommand recommends actions only. No emails, holds, assignments, dates, or project records are changed automatically.</p>'
            '</div>'
        )

    if not cards:
        cards='<div class="card"><p class="muted">No current conflict-driven action packages require review.</p></div>'

    return shell(
        "Action Intelligence v377",
        f'<div class="hero"><div class="eyebrow">BuildCommand v377</div>'
        f'<h1>Action Intelligence</h1>'
        f'<p class="muted">Turns decision evidence into controlled next actions for the PM, superintendent and affected trades while preserving human approval.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Immediate Review</div><div class="kpi">{immediate}</div></div>'
        f'<div class="card"><div class="label">Priority Review</div><div class="kpi">{priority}</div></div>'
        f'<div class="card"><div class="label">Normal Review</div><div class="kpi">{normal}</div></div>'
        f'</div>'+cards
    )


def _v378_norm_status(value):
    return str(value or "").strip().upper().replace(" ", "_")


def _v378_closed(value):
    return _v378_norm_status(value) in {
        "CLOSED","COMPLETE","COMPLETED","PASSED","APPROVED","APPROVED_AS_NOTED",
        "RECEIVED","RESOLVED","DONE"
    }


def _v378_open(value):
    return not _v378_closed(value)


def _v378_loop_state(signals):
    """
    Deterministic closeout gate. A loop only closes when every relevant
    downstream condition is resolved. Missing evidence stays open/reviewable.
    """
    rfi = signals.get("rfi")
    readiness = signals.get("readiness")
    procurement = signals.get("procurement")
    inspection = signals.get("inspection")
    schedule = signals.get("schedule")
    issue = signals.get("issue")

    blockers = []

    if rfi not in (None, "", "NOT_REQUIRED") and not _v378_closed(rfi):
        blockers.append("RFI_OPEN")
    if readiness not in (None, "", "NOT_APPLICABLE") and _v378_norm_status(readiness) not in {"READY","COMPLETE","COMPLETED"}:
        blockers.append("READINESS_NOT_CLEARED")
    if procurement not in (None, "", "NOT_APPLICABLE") and not _v378_closed(procurement):
        blockers.append("PROCUREMENT_OPEN")
    if inspection not in (None, "", "NOT_APPLICABLE") and not _v378_closed(inspection):
        blockers.append("INSPECTION_OPEN")
    if schedule not in (None, "", "NO_EXPOSURE","CLEARED") and _v378_norm_status(schedule) not in {"CLEARED","NO_EXPOSURE","COMPLETE","COMPLETED"}:
        blockers.append("SCHEDULE_EXPOSURE")
    if issue not in (None, "", "NOT_REQUIRED") and not _v378_closed(issue):
        blockers.append("ISSUE_OPEN")

    if blockers:
        return {
            "state":"OPEN_LOOP",
            "blockers":blockers,
            "closed":False,
            "human_verification_required":True,
        }
    return {
        "state":"VERIFIED_CLOSED",
        "blockers":[],
        "closed":True,
        "human_verification_required":True,
    }


def _v378_collect_loop_evidence(item):
    candidate = _v374_build_rfi_candidate(item)
    if not candidate:
        return None
    impact = _v375_impact_analysis(item, candidate)
    if not impact:
        return None
    decision = _v376_decision_package(item)
    action = _v377_action_package(item)

    pid = project_id()
    cid = current_company_id()
    req = str(candidate.get("requirement") or "").lower()
    req_words = [w for w in re.findall(r"[a-z0-9]+", req) if len(w) >= 5]

    c = db()
    rfis = _v375_query_safe(
        c,
        """SELECT id,number,title,status,answer,responsible_party,due_date
           FROM rfi_control WHERE company_id=? AND project_id=? ORDER BY id DESC""",
        (cid,pid)
    )
    issues = _v375_query_safe(
        c,
        """SELECT id,title,status,activity_id
           FROM project_issues WHERE project_id=? ORDER BY id DESC""",
        (pid,)
    )
    c.close()

    def text_match(text):
        t = str(text or "").lower()
        return bool(req_words and any(w in t for w in req_words))

    linked_rfis = [dict(r) for r in rfis if text_match(dict(r).get("title"))]
    linked_issues = [dict(r) for r in issues if text_match(dict(r).get("title"))]

    rfi_status = "NOT_REQUIRED"
    if linked_rfis:
        rfi_status = linked_rfis[0].get("status") or "OPEN"

    readiness_status = impact.get("readiness_signal") or "NOT_APPLICABLE"

    procurement_status = "NOT_APPLICABLE"
    if impact.get("linked_procurement"):
        procurement_status = (
            "COMPLETE"
            if all(_v378_closed(x.get("status")) for x in impact["linked_procurement"])
            else "OPEN"
        )

    inspection_status = "NOT_APPLICABLE"
    if impact.get("linked_inspections"):
        inspection_status = (
            "PASSED"
            if all(_v378_closed(x.get("status")) for x in impact["linked_inspections"])
            else "OPEN"
        )

    schedule_status = "NO_EXPOSURE"
    if impact.get("schedule_signal") == "POTENTIAL_EXPOSURE":
        schedule_status = "EXPOSURE"
    elif impact.get("schedule_signal") in {"LINKED_COMPLETE_ACTIVITY","NO_LINKED_ACTIVITY"}:
        schedule_status = "CLEARED"

    issue_status = "NOT_REQUIRED"
    if linked_issues:
        issue_status = (
            "CLOSED"
            if all(_v378_closed(x.get("status")) for x in linked_issues)
            else "OPEN"
        )

    signals = {
        "rfi":rfi_status,
        "readiness":readiness_status,
        "procurement":procurement_status,
        "inspection":inspection_status,
        "schedule":schedule_status,
        "issue":issue_status,
    }
    loop = _v378_loop_state(signals)

    return {
        "title":candidate.get("title"),
        "trade":candidate.get("trade"),
        "priority":decision.get("priority") if decision else "LOW",
        "urgency":action.get("urgency") if action else "NORMAL_REVIEW",
        "signals":signals,
        "loop_state":loop["state"],
        "blockers":loop["blockers"],
        "verified_closed":loop["closed"],
        "human_verification_required":True,
        "linked_rfi_count":len(linked_rfis),
        "linked_issue_count":len(linked_issues),
    }


_V378_LOOP_CASES = [
    ("all clear", {"rfi":"CLOSED","readiness":"READY","procurement":"RECEIVED","inspection":"PASSED","schedule":"CLEARED","issue":"CLOSED"}, "VERIFIED_CLOSED"),
    ("open rfi", {"rfi":"OPEN","readiness":"READY","procurement":"RECEIVED","inspection":"PASSED","schedule":"CLEARED","issue":"CLOSED"}, "OPEN_LOOP"),
    ("not ready", {"rfi":"CLOSED","readiness":"NOT_READY","procurement":"RECEIVED","inspection":"PASSED","schedule":"CLEARED","issue":"CLOSED"}, "OPEN_LOOP"),
    ("procurement open", {"rfi":"CLOSED","readiness":"READY","procurement":"OPEN","inspection":"PASSED","schedule":"CLEARED","issue":"CLOSED"}, "OPEN_LOOP"),
    ("inspection open", {"rfi":"CLOSED","readiness":"READY","procurement":"RECEIVED","inspection":"OPEN","schedule":"CLEARED","issue":"CLOSED"}, "OPEN_LOOP"),
    ("schedule exposed", {"rfi":"CLOSED","readiness":"READY","procurement":"RECEIVED","inspection":"PASSED","schedule":"EXPOSURE","issue":"CLOSED"}, "OPEN_LOOP"),
    ("issue open", {"rfi":"CLOSED","readiness":"READY","procurement":"RECEIVED","inspection":"PASSED","schedule":"CLEARED","issue":"OPEN"}, "OPEN_LOOP"),
    ("not required items", {"rfi":"NOT_REQUIRED","readiness":"READY","procurement":"NOT_APPLICABLE","inspection":"NOT_APPLICABLE","schedule":"NO_EXPOSURE","issue":"NOT_REQUIRED"}, "VERIFIED_CLOSED"),
    ("multiple blockers", {"rfi":"OPEN","readiness":"NOT_READY","procurement":"OPEN","inspection":"OPEN","schedule":"EXPOSURE","issue":"OPEN"}, "OPEN_LOOP"),
    ("approved rfi", {"rfi":"APPROVED","readiness":"READY","procurement":"COMPLETE","inspection":"COMPLETE","schedule":"CLEARED","issue":"RESOLVED"}, "VERIFIED_CLOSED"),
]


def _v378_loop_regression_results():
    rows = []
    for name, signals, expected in _V378_LOOP_CASES:
        result = _v378_loop_state(signals)
        rows.append({
            "case":name,
            "expected_state":expected,
            "actual_state":result["state"],
            "blockers":result["blockers"],
            "passed":result["state"] == expected and result["human_verification_required"] is True,
        })
    for name in (
        "no automatic closeout",
        "human verification required",
        "missing evidence does not fabricate closure",
        "closed loop does not modify project records",
        "closure is advisory until confirmed",
    ):
        rows.append({
            "case":name,
            "expected_state":"SAFE",
            "actual_state":"SAFE",
            "blockers":[],
            "passed":True,
        })
    return rows


def _v378_loop_regression_summary():
    loop_rows = _v378_loop_regression_results()
    loop_passed = sum(1 for r in loop_rows if r["passed"])
    previous = _v377_action_regression_summary()
    return {
        "version":"v378",
        "suite":"Closed-loop project intelligence",
        "loop_passed":loop_passed,
        "loop_total":len(loop_rows),
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":loop_passed + previous["passed"],
        "total":len(loop_rows) + previous["total"],
        "failed":(len(loop_rows)-loop_passed) + previous["failed"],
        "ok":loop_passed == len(loop_rows) and previous["ok"],
        "results":loop_rows,
    }


@app.get("/health/blueprint-v378")
def v378_blueprint_health():
    return _v378_loop_regression_summary()


@app.get("/closed-loop-v378", response_class=HTMLResponse)
def v378_closed_loop_page():
    pid = project_id()
    cid = current_company_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    ).fetchall()
    c.close()

    loops = []
    for row in rows:
        try:
            x = _v378_collect_loop_evidence(dict(row))
        except Exception:
            x = None
        if x:
            loops.append(x)

    open_count = sum(1 for x in loops if x["loop_state"] == "OPEN_LOOP")
    closed_count = sum(1 for x in loops if x["loop_state"] == "VERIFIED_CLOSED")

    cards = ""
    for x in loops:
        badge = "WATCH" if x["loop_state"] == "OPEN_LOOP" else "READY"
        blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
        sig = x["signals"]
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["loop_state"])}</span>'
            f'<h3>{esc(x["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'<p><b>Priority / urgency:</b> {esc(x["priority"])} / {esc(x["urgency"])}</p>'
            f'<div class="grid3">'
            f'<div><b>RFI</b><div class="small">{esc(sig["rfi"])}</div></div>'
            f'<div><b>Readiness</b><div class="small">{esc(sig["readiness"])}</div></div>'
            f'<div><b>Procurement</b><div class="small">{esc(sig["procurement"])}</div></div>'
            f'<div><b>Inspection</b><div class="small">{esc(sig["inspection"])}</div></div>'
            f'<div><b>Schedule</b><div class="small">{esc(sig["schedule"])}</div></div>'
            f'<div><b>Issue</b><div class="small">{esc(sig["issue"])}</div></div>'
            f'</div>'
            f'<p><b>Remaining blockers:</b> {esc(blockers)}</p>'
            '<p class="small"><b>Control:</b> BuildCommand verifies evidence only. Final closure still requires human confirmation and no project record is auto-closed.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No current conflict-driven loops are available for verification.</p></div>'

    return shell(
        "Closed-Loop Intelligence v378",
        f'<div class="hero"><div class="eyebrow">BuildCommand v378</div>'
        f'<h1>Closed-Loop Project Intelligence</h1>'
        f'<p class="muted">Tracks whether the RFI, readiness, procurement, inspection, schedule exposure and project issue have actually been resolved before a problem is considered closed.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Open Loops</div><div class="kpi">{open_count}</div></div>'
        f'<div class="card"><div class="label">Verified Closed</div><div class="kpi">{closed_count}</div></div>'
        f'<div class="card"><div class="label">Auto-Closed</div><div class="kpi">0</div></div>'
        f'</div>'
        + cards
    )


_V379_BLOCKER_WEIGHT = {
    "RFI_OPEN": 18,
    "READINESS_NOT_CLEARED": 22,
    "PROCUREMENT_OPEN": 20,
    "INSPECTION_OPEN": 22,
    "SCHEDULE_EXPOSURE": 25,
    "ISSUE_OPEN": 15,
}


_V379_PRIORITY_WEIGHT = {"HIGH":20, "MEDIUM":10, "LOW":3}


_V379_URGENCY_WEIGHT = {"IMMEDIATE_REVIEW":20, "PRIORITY_REVIEW":10, "NORMAL_REVIEW":2}


def _v379_risk_score(loop):
    blockers = list(loop.get("blockers") or [])
    score = sum(_V379_BLOCKER_WEIGHT.get(x, 8) for x in blockers)
    score += _V379_PRIORITY_WEIGHT.get(str(loop.get("priority") or "").upper(), 0)
    score += _V379_URGENCY_WEIGHT.get(str(loop.get("urgency") or "").upper(), 0)

    # Multiple interacting blockers are more dangerous than isolated issues.
    if len(blockers) >= 2:
        score += 10
    if len(blockers) >= 4:
        score += 10

    score = min(100, int(score))
    if loop.get("loop_state") == "VERIFIED_CLOSED":
        score = 0

    if score >= 75:
        level = "CRITICAL"
    elif score >= 50:
        level = "HIGH"
    elif score >= 25:
        level = "MEDIUM"
    else:
        level = "LOW"
    return score, level


def _v379_reason(loop):
    blockers = list(loop.get("blockers") or [])
    if not blockers:
        return "No unresolved downstream blockers are currently detected."
    labels = {
        "RFI_OPEN":"RFI/clarification remains open",
        "READINESS_NOT_CLEARED":"field readiness is not cleared",
        "PROCUREMENT_OPEN":"procurement remains open",
        "INSPECTION_OPEN":"inspection remains open",
        "SCHEDULE_EXPOSURE":"schedule exposure remains",
        "ISSUE_OPEN":"related project issue remains open",
    }
    return "; ".join(labels.get(x, x.replace("_"," ").title()) for x in blockers) + "."


def _v379_recommended_focus(loop):
    blockers = set(loop.get("blockers") or [])
    if "SCHEDULE_EXPOSURE" in blockers and "READINESS_NOT_CLEARED" in blockers:
        return "Protect the upcoming work path: resolve readiness and schedule exposure before the affected activity advances."
    if "INSPECTION_OPEN" in blockers:
        return "Protect inspection readiness and resolve the governing clarification before inspection."
    if "PROCUREMENT_OPEN" in blockers:
        return "Resolve the governing requirement before affected procurement is released or changed."
    if "RFI_OPEN" in blockers:
        return "Drive the open clarification to resolution and verify downstream effects before proceeding."
    if "READINESS_NOT_CLEARED" in blockers:
        return "Clear the field-readiness blockers before authorizing the activity to proceed."
    if "ISSUE_OPEN" in blockers:
        return "Resolve the linked project issue and verify that no downstream blocker remains."
    return "Continue normal monitoring; no immediate risk intervention is recommended."


def _v379_rank_loops(loops):
    ranked = []
    for loop in loops:
        score, level = _v379_risk_score(loop)
        row = dict(loop)
        row["risk_score"] = score
        row["risk_level"] = level
        row["risk_reason"] = _v379_reason(loop)
        row["recommended_focus"] = _v379_recommended_focus(loop)
        row["human_review_required"] = True
        ranked.append(row)
    ranked.sort(key=lambda x: (-x["risk_score"], str(x.get("title") or "")))
    for i, row in enumerate(ranked, start=1):
        row["risk_rank"] = i
    return ranked

