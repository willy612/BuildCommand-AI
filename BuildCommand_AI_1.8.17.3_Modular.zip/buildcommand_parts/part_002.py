# BuildCommand AI 1.8.17.3 modular source fragment 002
# Generated from verified 1.8.17.2; execute only through full_app.py.

def _v49_assemblies(pid):
    rows=_v49_scope_rows(pid)
    out=[]
    patterns=[
      ("WALL",("wall type","partition","stud wall","gypsum board wall","shaft wall")),
      ("CEILING",("ceiling","act ceiling","acoustical ceiling","hard lid")),
      ("FLOOR",("flooring","tile","lvt","vct","carpet","resilient flooring")),
      ("ROOF",("roof","roofing","roof curb","roof penetration")),
      ("DOOR",("door","frame","hardware","storefront entrance")),
      ("PLUMBING FIXTURE",("water closet","urinal","lavatory","mop sink","floor drain")),
      ("EQUIPMENT",("water heater","rooftop unit","exhaust fan","air handler","panelboard","transformer"))
    ]
    seen=set()
    for r in rows:
        low=str(r["requirement"] or "").lower()
        for typ,terms in patterns:
            if any(term in low for term in terms):
                key=(typ,re.sub(r'\s+',' ',low[:140]))
                if key in seen:
                    continue
                seen.add(key)
                rel=set()
                if r["related_trade"]:
                    rel.add(str(r["related_trade"]))
                for dep_r,rels in _v46_dependencies(pid):
                    if dep_r["id"]==r["id"]:
                        rel.update(rels)
                prereq=[]
                if typ=="WALL":
                    prereq=["layout complete","framing/backing complete","MEP rough complete","required rough inspection passed"]
                elif typ=="CEILING":
                    prereq=["above-ceiling MEP complete","coordination complete","inspection/testing complete"]
                elif typ=="FLOOR":
                    prereq=["substrate ready","moisture/flatness requirements verified","overhead damaging work complete"]
                elif typ=="ROOF":
                    prereq=["penetrations/curbs coordinated","equipment/support locations confirmed"]
                elif typ=="DOOR":
                    prereq=["rough opening verified","frame/blocking ready","hardware/electrical interfaces coordinated"]
                elif typ=="PLUMBING FIXTURE":
                    prereq=["rough plumbing complete","wall/floor finishes ready","fixture available"]
                else:
                    prereq=["approved submittal","support ready","material onsite","power/controls/piping interfaces coordinated"]
                source=" · ".join(x for x in [r["source_sheet"],r["source_detail"],r["source_spec"]] if x)
                out.append((typ,r,sorted(rel),prereq,source))
    return out[:250]


def _v49_system_trace(pid):
    rows=_v49_scope_rows(pid)
    systems={
        "Electrical":[],"Plumbing":[],"HVAC / Mechanical":[],"Fire Sprinkler":[],
        "Low Voltage":[],"Fire Alarm":[],"Roofing":[],"Doors / Frames / Hardware":[]
    }
    for r in rows:
        tr=str(r["trade"] or "")
        if tr in systems:
            systems[tr].append(r)
    return systems


def _v49_penetrations(pid):
    rows=_v49_scope_rows(pid)
    out=[]
    for r in rows:
        low=str(r["requirement"] or "").lower()
        if any(x in low for x in ["penetration","sleeve","core drill","opening","roof curb","rough opening"]):
            out.append(r)
    return out[:150]


def _v49_install_prereqs(pid):
    seq=_v45_sequence_analysis(pid)
    out=[]
    for x in seq:
        a=x["activity"]
        gates=_v45_gate_requirements(x["stage"])
        out.append((a,x["readiness"],x["risk"],gates,x["blocking_reason"]))
    return out[:150]


def _v49_hold_points(pid):
    inspections=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? ORDER BY scheduled_date,id",(pid,))
    seq=_v45_sequence_analysis(pid)
    out=[]
    for i in inspections:
        act=None
        if i["activity_id"] is not None:
            act=next((x["activity"] for x in seq if x["activity"]["id"]==i["activity_id"]),None)
        out.append((i,act))
    return out[:150]


def _v49_commissioning(pid):
    eq=_v46_equipment(pid)
    out=[]
    for e in eq:
        testing=[]
        closeout=[]
        name=e["name"].lower()
        if any(x in name for x in ["rtu","air handler","exhaust fan","vav"]):
            testing=["startup","controls verification","test and balance as applicable"]
            closeout=["O&M","warranty","startup record"]
        elif "water heater" in name:
            testing=["startup","temperature/operation verification","leak check"]
            closeout=["O&M","warranty"]
        elif any(x in name for x in ["panelboard","transformer"]):
            testing=["energization verification","labeling/identification"]
            closeout=["O&M if required","test records if required"]
        else:
            testing=["startup / functional verification as applicable"]
            closeout=["O&M / warranty as applicable"]
        out.append((e,testing,closeout))
    return out[:100]


def _v49_work_packages(pid):
    rooms=_v49_rooms(pid)
    assemblies=_v49_assemblies(pid)
    packages=[]
    for room in rooms:
        by_trade={}
        for r in room["items"]:
            by_trade.setdefault(r["trade"],[]).append(r)
        for tr,items in by_trade.items():
            scope="; ".join(str(x["requirement"]) for x in items[:8])
            packages.append({
                "title":f"Room {room['room']} - {tr}",
                "location":f"Room {room['room']}",
                "trade":tr,"scope":scope,
                "prereq":"Verify predecessor work, access, approved documents and material readiness.",
                "inspection":"Verify required inspection/hold points before concealment or finish work.",
                "materials":"Confirm project-specific material availability."
            })
    if not packages:
        # Fallback assembly-based packages when room numbers are not explicit.
        for typ,r,rels,prereq,source in assemblies[:80]:
            packages.append({
                "title":f"{typ} - {r['trade']}",
                "location":source or "Project",
                "trade":r["trade"],"scope":r["requirement"],
                "prereq":"; ".join(prereq),
                "inspection":"Verify applicable inspections/testing before downstream work.",
                "materials":"Confirm approved material/submittal and onsite readiness."
            })
    return packages[:200]


@app.get("/field-context",response_class=HTMLResponse)
def v49_field_context_home():
    pid=project_id(); _v49_ensure_tables()
    rooms=_v49_rooms(pid); assemblies=_v49_assemblies(pid); pens=_v49_penetrations(pid)
    prereqs=_v49_install_prereqs(pid); holds=_v49_hold_points(pid); comm=_v49_commissioning(pid)
    packages=_v49_work_packages(pid); systems=_v49_system_trace(pid)
    system_count=sum(1 for _,rows in systems.items() if rows)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v49 - Field Context & Assembly Intelligence</div><h1>Understand the project where the work actually happens.</h1><p class="muted">{len(rooms)} room context(s) · {len(assemblies)} assembly signals · {system_count} traced systems · {len(pens)} penetration/opening items · {len(holds)} inspection hold points · {len(comm)} commissioning chains · {len(packages)} field work packages.</p></div><div class="grid3">'
    cards=[
      ("Room Intelligence","Organize project scope by room/location context.","/field-context/rooms"),
      ("Assembly Intelligence","Understand wall, ceiling, floor, roof, door and equipment assemblies.","/field-context/assemblies"),
      ("System Trace Intelligence","Trace scope by Electrical, Plumbing, HVAC, Fire Protection and other systems.","/field-context/systems"),
      ("Penetration & Opening Brain","Find sleeves, penetrations, rough openings and roof/opening coordination.","/field-context/penetrations"),
      ("Installation Prerequisites","Show what must be ready before activities can start.","/field-context/prerequisites"),
      ("Inspection Hold Points","Connect inspections/testing to the work they gate.","/field-context/hold-points"),
      ("Equipment-to-Location Intelligence","Map equipment scope to room/source context and trade interfaces.","/field-context/equipment-locations"),
      ("Commissioning Chain","Follow install → power → controls → startup → testing → closeout.","/field-context/commissioning"),
      ("Field Work Packages","Turn project intelligence into location/trade execution packages.","/field-context/work-packages"),
      ("Field Context Command","One field-focused view of rooms, assemblies, gates and work packages.","/field-context/command")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Field Context Intelligence",body)


@app.get("/field-context/rooms",response_class=HTMLResponse)
def v49_rooms_page():
    rows=_v49_rooms(project_id())
    h=""
    for room in rows:
        h+=f'<div class="card"><h3>Room {esc(room["room"])}</h3><p class="small">{len(room["items"])} scope item(s) · {len(room["trades"])} trade(s)</p>'
        for r in room["items"][:20]:
            h+=f'<div class="action"><b>{esc(r["trade"])}</b> - {esc(r["requirement"])}</div>'
        h+='</div>'
    return shell("Room Intelligence",'<div class="hero"><h1>Room Intelligence</h1><p class="muted">Location context is inferred only where explicit room identifiers exist in the analyzed text.</p></div>'+(h or '<div class="card">No explicit room identifiers detected in current scope.</div>'))


@app.get("/field-context/assemblies",response_class=HTMLResponse)
def v49_assemblies_page():
    rows=_v49_assemblies(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(typ)}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Related: {esc(", ".join(rels) or "None")} · Source {esc(source)}</div><p><b>Prerequisites:</b> {esc("; ".join(pre))}</p></div>' for typ,r,rels,pre,source in rows)
    return shell("Assembly Intelligence",'<div class="hero"><h1>Assembly Intelligence</h1><p class="muted">Breaks project scope into buildable assemblies with related trades and prerequisite logic.</p></div><div class="card">'+(h or '<p class="muted">No assembly signals detected.</p>')+'</div>')


@app.get("/field-context/systems",response_class=HTMLResponse)
def v49_systems_page():
    systems=_v49_system_trace(project_id())
    body='<div class="hero"><h1>System Trace Intelligence</h1><p class="muted">Trace the project by system instead of reading isolated scope items.</p></div>'
    for name,rows in systems.items():
        if not rows: continue
        body+=f'<div class="card"><h2>{esc(name)}</h2>'
        body+="".join(f'<div class="action">{esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} {esc(r["source_detail"])}</div></div>' for r in rows[:40])
        body+='</div>'
    return shell("System Trace Intelligence",body)


@app.get("/field-context/penetrations",response_class=HTMLResponse)
def v49_penetrations_page():
    rows=_v49_penetrations(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">COORDINATE</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} {esc(r["source_detail"])}</div></div>' for r in rows)
    return shell("Penetration & Opening Brain",'<div class="hero"><h1>Penetration & Opening Brain</h1><p class="muted">Finds opening/penetration scope requiring coordination across structure, MEP, roofing, framing or finishes.</p></div><div class="card">'+(h or '<p class="muted">No penetration/opening scope detected.</p>')+'</div>')


@app.get("/field-context/prerequisites",response_class=HTMLResponse)
def v49_prereq_page():
    rows=_v49_install_prereqs(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if ready=="READY" else "WATCH"}">{esc(ready)}</span> <b>{esc(a["name"])}</b><div class="small">{esc(a["trade"])} · Risk {esc(risk)}</div><p><b>Expected gates:</b> {esc("; ".join(gates))}</p><p>{esc(blocking)}</p></div>' for a,ready,risk,gates,blocking in rows)
    return shell("Installation Prerequisites",'<div class="hero"><h1>Installation Prerequisite Intelligence</h1><p class="muted">Makes sequence/readiness logic understandable at the installation level.</p></div><div class="card">'+(h or '<p class="muted">No scheduled activities available.</p>')+'</div>')


@app.get("/field-context/hold-points",response_class=HTMLResponse)
def v49_hold_page():
    rows=_v49_hold_points(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if str(i["result"] or "").upper()=="PASSED" else "WATCH"}">{esc(i["result"])}</span> <b>{esc(i["inspection_type"])}</b><div class="small">Activity: {esc(a["name"] if a else "Unlinked")} · {esc(i["scheduled_date"])} · {esc(i["authority"])}</div></div>' for i,a in rows)
    return shell("Inspection Hold Points",'<div class="hero"><h1>Inspection Hold Points</h1><p class="muted">Do not let downstream work bury required inspection/testing gates.</p></div><div class="card">'+(h or '<p class="muted">No inspection hold points loaded.</p>')+'</div>')


@app.get("/field-context/equipment-locations",response_class=HTMLResponse)
def v49_equipment_locations():
    rows=_v46_equipment(project_id())
    h=""
    for e in rows:
        room=_v49_room_key(e["name"])
        h+=f'<div class="action"><b>{esc(e["name"])}</b><div class="small">Location context: {esc("Room "+room if room else e["source"] or "Not explicit")} · Install {esc(e["primary"])} · Power {esc(e["power"] or "N/A")} · Controls {esc(e["controls"] or "N/A")}</div></div>'
    return shell("Equipment Location Intelligence",'<div class="hero"><h1>Equipment-to-Location Intelligence</h1><p class="muted">Connects equipment responsibilities to explicit room/source context where available.</p></div><div class="card">'+(h or '<p class="muted">No equipment intelligence detected.</p>')+'</div>')


@app.get("/field-context/commissioning",response_class=HTMLResponse)
def v49_commissioning_page():
    rows=_v49_commissioning(project_id())
    h="".join(f'<div class="card"><h3>{esc(e["name"])}</h3><p><b>Install:</b> {esc(e["primary"])} · <b>Power:</b> {esc(e["power"] or "N/A")} · <b>Controls:</b> {esc(e["controls"] or "N/A")} · <b>Startup:</b> {esc(e["startup"])}</p><p><b>Testing:</b> {esc("; ".join(testing))}</p><p><b>Closeout:</b> {esc("; ".join(closeout))}</p></div>' for e,testing,closeout in rows)
    return shell("Commissioning Chain",'<div class="hero"><h1>Commissioning Chain Intelligence</h1><p class="muted">Follows equipment from installation through operational verification and turnover.</p></div>'+(h or '<div class="card">No commissioning chains detected.</div>'))


@app.get("/field-context/work-packages",response_class=HTMLResponse)
def v49_packages_page():
    rows=_v49_work_packages(project_id())
    h="".join(f'<div class="card"><span class="badge">DRAFT PACKAGE</span><h3>{esc(p["title"])}</h3><p><b>Location:</b> {esc(p["location"])}</p><p><b>Scope:</b> {esc(p["scope"])}</p><p><b>Prerequisites:</b> {esc(p["prereq"])}</p><p><b>Inspection:</b> {esc(p["inspection"])}</p><p><b>Materials:</b> {esc(p["materials"])}</p></div>' for p in rows)
    return shell("Field Work Packages",'<div class="hero"><h1>Field Work Package Intelligence</h1><p class="muted">Draft execution packages only; superintendent review is required before release to the field.</p></div>'+(h or '<div class="card">No work-package candidates detected.</div>'))


@app.get("/field-context/command",response_class=HTMLResponse)
def v49_command_page():
    pid=project_id()
    rooms=_v49_rooms(pid); assemblies=_v49_assemblies(pid); pens=_v49_penetrations(pid)
    prereqs=[x for x in _v49_install_prereqs(pid) if x[1]!="READY"]
    holds=[x for x in _v49_hold_points(pid) if str(x[0]["result"] or "").upper()!="PASSED"]
    packages=_v49_work_packages(pid)
    body=f'<div class="hero"><div class="eyebrow">Field Context Command</div><h1>What needs coordination before work moves?</h1><p class="muted">{len(rooms)} room contexts · {len(assemblies)} assemblies · {len(pens)} penetration/opening items · {len(prereqs)} not-ready activities · {len(holds)} open hold points · {len(packages)} draft work packages.</p></div>'
    body+='<div class="grid3">'
    body+=_v37_link_card("Not-Ready Work","Installation prerequisites and blocking reasons.","/field-context/prerequisites","Review")
    body+=_v37_link_card("Hold Points","Inspections/testing that gate downstream work.","/field-context/hold-points","Review")
    body+=_v37_link_card("Work Packages","Location/trade execution packages from current intelligence.","/field-context/work-packages","Review")
    body+='</div>'
    return shell("Field Context Command",body)


def _v50_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS master_reasoning_runs(
        id {pk},company_id BIGINT,project_id BIGINT,run_time TEXT,
        health_score {num} DEFAULT 100,risk_score {num} DEFAULT 0,
        quality_score {num} DEFAULT 100,summary TEXT,status TEXT DEFAULT 'COMPLETE',
        created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS master_reasoning_findings(
        id {pk},company_id BIGINT,project_id BIGINT,run_id BIGINT,
        finding_type TEXT,title TEXT,severity TEXT,trade TEXT,location TEXT,
        reason TEXT,source_ref TEXT,downstream_impact TEXT,recommended_action TEXT,
        confidence TEXT DEFAULT 'MEDIUM',human_review INTEGER DEFAULT 1,created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS master_reasoning_links(
        id {pk},company_id BIGINT,project_id BIGINT,run_id BIGINT,
        from_type TEXT,from_key TEXT,to_type TEXT,to_key TEXT,
        relationship TEXT,reason TEXT,created TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v50_collect_findings_uncached(pid):
    findings=[]

    # 1) Blueprint / scope quality
    for r,verify,agreement,source_level,calibrated,score,contradiction,reason in _v48_self_audit(pid):
        if agreement=="DISAGREE" or calibrated=="LOW" or source_level=="LOW":
            sev="HIGH" if agreement=="DISAGREE" else "MEDIUM"
            findings.append({
                "type":"SCOPE QUALITY","title":r["requirement"],"severity":sev,
                "trade":r["trade"],"location":_v49_room_key(r["requirement"]),
                "reason":reason,
                "source": " · ".join(x for x in [r["source_sheet"],r["source_detail"],r["source_spec"]] if x),
                "impact":"Bad ownership/source quality can contaminate estimating, bidding, schedule and field execution.",
                "action":f"Review saved trade ownership versus second opinion: {verify}.",
                "confidence":calibrated
            })

    # 2) Constructability
    for r in _v452_constructability(pid):
        findings.append({
            "type":"CONSTRUCTABILITY","title":r["title"],"severity":r["severity"],
            "trade":r["trade"],"location":_v49_room_key(r["description"]),
            "reason":r["description"],"source":r["source"],
            "impact":"Potential field coordination, access, clearance or installation problem.",
            "action":r["action"],"confidence":"MEDIUM"
        })

    # 3) Sequence
    for x in _v45_sequence_analysis(pid):
        if x["risk"] in {"CRITICAL","HIGH"}:
            a=x["activity"]
            findings.append({
                "type":"SEQUENCE","title":a["name"],"severity":x["risk"],
                "trade":a["trade"],"location":"",
                "reason":x["blocking_reason"] or "High sequence exposure.",
                "source":f'Schedule {a["start"]} to {a["finish"]}',
                "impact":x["downstream"],
                "action":x["recommendation"],"confidence":"HIGH"
            })

    # 4) Procurement
    for r,level,exposure,reason,action in _v452_procurement_analysis(pid):
        if level in {"CRITICAL","HIGH","TODAY"}:
            findings.append({
                "type":"PROCUREMENT","title":r["item"],"severity":"CRITICAL" if level=="TODAY" else level,
                "trade":"","location":"","reason":reason,
                "source":f'Need {r["required_on_site"]} · Promised {r["promised_date"]}',
                "impact":"Late material can delay installation and downstream activities.",
                "action":action,"confidence":"HIGH"
            })

    # 5) Decision deadlines
    for typ,title,due,severity,cost,days,source in _v47_decision_deadlines(pid):
        if severity in {"CRITICAL","HIGH"}:
            findings.append({
                "type":"DECISION","title":title,"severity":severity,"trade":"","location":"",
                "reason":f"{typ} decision due {due}.",
                "source":source,
                "impact":f"Potential ${cost:,.0f} cost exposure and {days:g} schedule day(s).",
                "action":"Escalate and obtain decision before downstream commitment.",
                "confidence":"HIGH"
            })

    # 6) Inspection hold points
    for i,a in _v49_hold_points(pid):
        if str(i["result"] or "").upper()!="PASSED":
            findings.append({
                "type":"INSPECTION","title":i["inspection_type"],"severity":"HIGH",
                "trade":a["trade"] if a else "","location":"",
                "reason":f'Inspection gate is {i["result"] or "PENDING"}.',
                "source":f'{i["scheduled_date"]} · {i["authority"]}',
                "impact":"Downstream concealment/finish work should not proceed past an unmet hold point.",
                "action":"Verify readiness and pass required inspection before releasing downstream work.",
                "confidence":"HIGH"
            })

    # 7) Cost risk
    for level,kind,title,reason,source in _v46_cost_risk(pid):
        if level in {"HIGH","CRITICAL"}:
            findings.append({
                "type":"COST RISK","title":title,"severity":level,
                "trade":"","location":"","reason":reason,"source":source,
                "impact":"Potential added cost or commercial exposure.",
                "action":"Review contract scope, source documents and change documentation.",
                "confidence":"MEDIUM"
            })

    # 8) Field prerequisites
    for a,ready,risk,gates,blocking in _v49_install_prereqs(pid):
        if ready!="READY" and risk in {"CRITICAL","HIGH"}:
            findings.append({
                "type":"MAKE READY","title":a["name"],"severity":risk,
                "trade":a["trade"],"location":"",
                "reason":blocking or "Installation prerequisites are incomplete.",
                "source":"; ".join(gates),
                "impact":"Activity may start unprepared or force downstream rework.",
                "action":"Close make-ready gaps before releasing crew.",
                "confidence":"HIGH"
            })

    # 9) Closeout
    for r,level in _v47_closeout_prediction(pid):
        if level in {"CRITICAL","HIGH"}:
            findings.append({
                "type":"CLOSEOUT","title":r["item"],"severity":level,
                "trade":r["responsible_party"],"location":"",
                "reason":f'Status {r["status"]} · Due {r["due_date"]}',
                "source":r["category"],
                "impact":"Late turnover requirement can delay substantial/final completion.",
                "action":"Assign owner and recover closeout requirement before project end.",
                "confidence":"HIGH"
            })

    # 10) Cross-trade dependencies / handoffs
    for r,rels in _v46_dependencies(pid):
        if rels:
            findings.append({
                "type":"HANDOFF","title":r["requirement"],"severity":"REVIEW",
                "trade":r["trade"],"location":_v49_room_key(r["requirement"]),
                "reason":f'Primary trade depends on {", ".join(rels)}.',
                "source":" · ".join(x for x in [r["source_sheet"],r["source_detail"],r["source_spec"]] if x),
                "impact":"Missed handoff can create scope gaps, rework or delay.",
                "action":"Confirm responsibility boundary and readiness between trades.",
                "confidence":"MEDIUM"
            })

    rank={"CRITICAL":0,"HIGH":1,"MEDIUM":2,"REVIEW":3,"LOW":4}
    findings.sort(key=lambda x:(rank.get(x["severity"],9),x["type"],x["title"]))
    return findings[:500]


def _v50_collect_findings(pid):
    return _v56_master_findings(pid)


def _v50_score(pid):
    return _v56_master_score(pid)


def _v50_run(pid):
    _v50_ensure_tables()
    findings=_v50_collect_findings(pid)
    score=_v50_score(pid)
    now=datetime.utcnow().isoformat()
    summary=f'{score["count"]} connected findings · health {score["health"]}/100 · risk {score["risk"]}/100 · quality {score["quality"]}/100.'
    c=db()
    c.execute("""INSERT INTO master_reasoning_runs(company_id,project_id,run_time,health_score,risk_score,quality_score,summary,status,created)
                 VALUES(?,?,?,?,?,?,?,?,?)""",
              (current_company_id(),pid,now,score["health"],score["risk"],score["quality"],summary,"COMPLETE",now))
    run_id=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    for f in findings:
        c.execute("""INSERT INTO master_reasoning_findings(
            company_id,project_id,run_id,finding_type,title,severity,trade,location,reason,
            source_ref,downstream_impact,recommended_action,confidence,human_review,created
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (current_company_id(),pid,run_id,f["type"],f["title"],f["severity"],f["trade"],f["location"],
         f["reason"],f["source"],f["impact"],f["action"],f["confidence"],1,now))
    c.commit(); c.close()
    return run_id,findings,score


def _v50_top_priorities(pid,limit=10):
    return _v56_top_priorities(pid,limit)


def _v50_trade_brief(pid,trade):
    findings=[f for f in _v50_collect_findings(pid) if str(f["trade"] or "").lower()==str(trade or "").lower()]
    scopes=[r for r in _v452_scope_rows(pid) if str(r["trade"] or "").lower()==str(trade or "").lower()]
    return findings,scopes


def _v50_location_brief(pid,room):
    findings=[f for f in _v50_collect_findings(pid) if str(f["location"] or "")==str(room or "")]
    rooms=[r for r in _v49_rooms(pid) if r["room"]==room]
    return findings,rooms


def _v50_reasoning_chain(pid,title):
    q=str(title or "").lower()
    chain=[]
    for f in _v50_collect_findings(pid):
        text=(f["title"]+" "+f["reason"]+" "+f["trade"]).lower()
        tokens=[w for w in re.findall(r'[a-z0-9]+',q) if len(w)>3]
        if tokens and any(tok in text for tok in tokens):
            chain.append(f)
    return chain[:30]


@app.get("/master-reasoning",response_class=HTMLResponse)
def v50_master_reasoning_home():
    pid=project_id()
    run_id,findings,score=_v50_run(pid)
    top=_v50_top_priorities(pid,10)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v50 - Master Construction Reasoning Engine</div><h1>One brain. One project judgment.</h1><p class="muted">Health {score["health"]}/100 · Risk {score["risk"]}/100 · Intelligence quality {score["quality"]}/100 · {score["count"]} connected findings.</p></div>'
    body+='<div class="grid3">'
    cards=[
      ("Master Project Brief","The 10 most important connected project findings.","/master-reasoning/brief"),
      ("Reasoning Findings","All connected findings from Blueprint, sequence, risk, field and quality intelligence.","/master-reasoning/findings"),
      ("Trade Command","See connected intelligence by subcontractor/trade.","/master-reasoning/trades"),
      ("Location Command","See connected intelligence by room/location where explicit context exists.","/master-reasoning/locations"),
      ("Reasoning Chain","Trace why BuildCommand thinks an issue matters.","/master-reasoning/chain"),
      ("Quality Gate","See which findings should be trusted versus reviewed.","/master-reasoning/quality-gate"),
      ("Field Release Gate","Check whether high-risk work should be released to the field.","/master-reasoning/release-gate"),
      ("Commercial Exposure","Combine cost, decision and change signals.","/master-reasoning/commercial"),
      ("Schedule Exposure","Combine sequence, procurement, inspection and decision risks.","/master-reasoning/schedule"),
      ("Executive Judgment","One concise project health and leadership view.","/master-reasoning/executive")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div><div class="card"><h2>Top 10</h2>'
    body+="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div class="small">{esc(f["reason"])}</div></div>' for f in top)
    body+='</div>'
    return shell("Master Construction Reasoning",body)


@app.get("/master-reasoning/brief",response_class=HTMLResponse)
def v50_brief_page():
    rows=_v50_top_priorities(project_id(),10)
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])} - {esc(f["title"])}</b><p>{esc(f["reason"])}</p><p><b>Impact:</b> {esc(f["impact"])}</p><p><b>Recommended:</b> {esc(f["action"])}</p><div class="small">{esc(f["trade"])} {("· Room "+esc(f["location"])) if f["location"] else ""} · {esc(f["source"])}</div></div>' for f in rows)
    return shell("Master Project Brief",'<div class="hero"><h1>Master Project Brief</h1><p class="muted">The highest-priority connected project findings from across BuildCommand.</p></div><div class="card">'+(h or '<p class="muted">No major findings detected.</p>')+'</div>')


@app.get("/master-reasoning/findings",response_class=HTMLResponse)
def v50_findings_page():
    rows=_v50_collect_findings(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div>{esc(f["reason"])}</div><div class="small">Trade {esc(f["trade"])} · Confidence {esc(f["confidence"])} · {esc(f["source"])}</div></div>' for f in rows)
    return shell("Reasoning Findings",'<div class="hero"><h1>Connected Reasoning Findings</h1><p class="muted">This is the combined output of the major BuildCommand intelligence layers.</p></div><div class="card">'+(h or '<p class="muted">No findings.</p>')+'</div>')


@app.get("/master-reasoning/trades",response_class=HTMLResponse)
def v50_trade_page(trade:str=''):
    pid=project_id()
    trades=sorted(set(str(r["trade"] or "") for r in _v452_scope_rows(pid) if r["trade"]))
    options="".join(f'<option value="{esc(tr)}" {"selected" if tr==trade else ""}>{esc(tr)}</option>' for tr in trades)
    body='<div class="hero"><h1>Trade Command</h1><p class="muted">Connected scope, risk and handoff intelligence by trade.</p></div><div class="card"><form method="get"><select name="trade">'+options+'</select><button type="submit">Open Trade</button></form></div>'
    if trade:
        findings,scopes=_v50_trade_brief(pid,trade)
        body+=f'<div class="card"><h2>{esc(trade)}</h2><p>{len(scopes)} scope item(s) · {len(findings)} connected finding(s)</p>'
        body+="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> {esc(f["title"])}<div class="small">{esc(f["reason"])}</div></div>' for f in findings)
        body+='</div>'
    return shell("Trade Command",body)


@app.get("/master-reasoning/locations",response_class=HTMLResponse)
def v50_location_page(room:str=''):
    pid=project_id()
    rooms=sorted(r["room"] for r in _v49_rooms(pid))
    options="".join(f'<option value="{esc(r)}" {"selected" if r==room else ""}>Room {esc(r)}</option>' for r in rooms)
    body='<div class="hero"><h1>Location Command</h1><p class="muted">Connected intelligence by explicit room/location context.</p></div><div class="card"><form method="get"><select name="room">'+options+'</select><button type="submit">Open Location</button></form></div>'
    if room:
        findings,roomdata=_v50_location_brief(pid,room)
        body+=f'<div class="card"><h2>Room {esc(room)}</h2><p>{len(findings)} connected finding(s)</p>'
        body+="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div class="small">{esc(f["reason"])}</div></div>' for f in findings)
        body+='</div>'
    return shell("Location Command",body)


@app.get("/master-reasoning/chain",response_class=HTMLResponse)
def v50_chain_page(q:str=''):
    rows=_v50_reasoning_chain(project_id(),q) if q else []
    body='<div class="hero"><h1>Reasoning Chain</h1><p class="muted">Trace the connected evidence behind a project issue or subject.</p></div><div class="card"><form method="get"><input name="q" value="'+esc(q)+'" placeholder="Example: water heater, storefront, ceiling"><button type="submit">Trace</button></form></div>'
    if q:
        body+='<div class="card">'+("".join(f'<div class="action"><span class="badge">{esc(f["type"])}</span> <b>{esc(f["title"])}</b><p>{esc(f["reason"])}</p><div class="small">{esc(f["source"])}</div></div>' for f in rows) or '<p class="muted">No connected reasoning chain found.</p>')+'</div>'
    return shell("Reasoning Chain",body)


@app.get("/master-reasoning/quality-gate",response_class=HTMLResponse)
def v50_quality_gate():
    rows=_v50_collect_findings(project_id())
    review=[f for f in rows if f["confidence"]=="LOW" or f["severity"]=="REVIEW"]
    h="".join(f'<div class="action"><span class="badge WATCH">HUMAN REVIEW</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div class="small">Confidence {esc(f["confidence"])} · {esc(f["reason"])}</div></div>' for f in review)
    return shell("Quality Gate",'<div class="hero"><h1>Master Quality Gate</h1><p class="muted">Low-confidence and review-only findings should not silently drive consequential project action.</p></div><div class="card">'+(h or '<p class="muted">No current quality-gate exceptions.</p>')+'</div>')


@app.get("/master-reasoning/release-gate",response_class=HTMLResponse)
def v50_release_gate():
    rows=[f for f in _v50_collect_findings(project_id()) if f["type"] in {"SEQUENCE","MAKE READY","INSPECTION","PROCUREMENT"} and f["severity"] in {"CRITICAL","HIGH"}]
    h="".join(f'<div class="action"><span class="badge WATCH">HOLD / REVIEW</span> <b>{esc(f["title"])}</b><div>{esc(f["reason"])}</div><p><b>Before release:</b> {esc(f["action"])}</p></div>' for f in rows)
    return shell("Field Release Gate",'<div class="hero"><h1>Field Release Gate</h1><p class="muted">High-risk prerequisites, inspections, sequence and procurement conditions should be reviewed before releasing work.</p></div><div class="card">'+(h or '<p class="muted">No high-risk field release blockers detected.</p>')+'</div>')


@app.get("/master-reasoning/commercial",response_class=HTMLResponse)
def v50_commercial():
    rows=[f for f in _v50_collect_findings(project_id()) if f["type"] in {"COST RISK","DECISION"}]
    changes=_v39_changes(project_id())
    total=sum(float(r["estimated_cost"] or 0) for r in changes)
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["title"])}</b><div class="small">{esc(f["reason"])}</div></div>' for f in rows)
    return shell("Commercial Exposure",f'<div class="hero"><h1>Commercial Exposure</h1><p class="muted">${total:,.0f} known open change exposure plus {len(rows)} connected cost/decision risk signal(s).</p></div><div class="card">'+(h or '<p class="muted">No major commercial exposure signals.</p>')+'</div>')


@app.get("/master-reasoning/schedule",response_class=HTMLResponse)
def v50_schedule():
    rows=[f for f in _v50_collect_findings(project_id()) if f["type"] in {"SEQUENCE","PROCUREMENT","DECISION","INSPECTION","MAKE READY"}]
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div class="small">{esc(f["reason"])}</div></div>' for f in rows)
    return shell("Schedule Exposure",'<div class="hero"><h1>Schedule Exposure</h1><p class="muted">One connected schedule-risk view across readiness, procurement, inspections and decisions.</p></div><div class="card">'+(h or '<p class="muted">No major schedule exposure signals.</p>')+'</div>')


@app.get("/master-reasoning/executive",response_class=HTMLResponse)
def v50_executive():
    pid=project_id()
    score=_v50_score(pid)
    top=_v50_top_priorities(pid,5)
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["type"])}</b> - {esc(f["title"])}<div class="small">{esc(f["impact"])}</div></div>' for f in top)
    return shell("Executive Judgment",f'<div class="hero"><h1>Executive Project Judgment</h1><p class="muted">Health {score["health"]}/100 · Risk {score["risk"]}/100 · Intelligence quality {score["quality"]}/100.</p></div><div class="card"><h2>Top Leadership Attention</h2>{h or "<p class=muted>No major leadership issues detected.</p>"}</div>')


def _v51_reasoning_units(pid):
    """
    Convert master findings into cause -> dependency -> consequence -> owner -> action units.
    """
    findings=_v50_collect_findings(pid)
    deps=_v46_dependencies(pid)
    dep_map={}
    for r,rels in deps:
        dep_map[str(r["requirement"] or "").strip().lower()]=rels

    units=[]
    for f in findings:
        key=str(f["title"] or "").strip().lower()
        rels=dep_map.get(key,[])
        owner=f["trade"] or (rels[0] if rels else "")
        cause=f["reason"]
        dependency=", ".join(rels) if rels else "No explicit cross-trade dependency detected."
        consequence=f["impact"]
        action=f["action"]
        units.append({
            "severity":f["severity"],"type":f["type"],"title":f["title"],
            "cause":cause,"dependency":dependency,"consequence":consequence,
            "owner":owner,"action":action,"source":f["source"],
            "confidence":f["confidence"]
        })
    return units[:500]


def _v51_alternatives(unit):
    """
    Transparent option generation. These are review alternatives, not automatic directives.
    """
    typ=unit["type"]
    opts=[]
    if typ in {"SEQUENCE","MAKE READY"}:
        opts=[
            ("Hold downstream work","Protect sequence and avoid rework until prerequisites are complete."),
            ("Resequence unaffected work","Move crews to independent work while the blocker is resolved."),
            ("Recover prerequisite","Add manpower/material/coordination to clear the blocker faster.")
        ]
    elif typ=="PROCUREMENT":
        opts=[
            ("Expedite current source","Confirm fabrication/shipping recovery with current vendor."),
            ("Evaluate approved alternate","Use only if contract/submittal requirements allow an alternate."),
            ("Resequence installation","Move unaffected work ahead while protecting downstream milestones.")
        ]
    elif typ=="INSPECTION":
        opts=[
            ("Hold concealment","Do not cover work before required inspection/testing."),
            ("Resolve deficiencies first","Correct known issues before requesting inspection."),
            ("Coordinate inspection timing","Align inspector availability with field readiness.")
        ]
    elif typ in {"COST RISK","DECISION"}:
        opts=[
            ("Clarify contract responsibility","Review drawings/specs/subcontract scope before authorizing extra work."),
            ("Issue/advance RFI","Seek documented clarification where design intent is ambiguous."),
            ("Track potential change","Preserve cost/schedule documentation pending entitlement review.")
        ]
    elif typ=="CONSTRUCTABILITY":
        opts=[
            ("Coordinate affected trades","Resolve interfaces before installation."),
            ("Request design clarification","Use RFI if drawings/specs do not establish a buildable solution."),
            ("Field-verify existing conditions","Confirm dimensions/access before committing material or labor.")
        ]
    else:
        opts=[
            ("Review source documents","Confirm the governing requirement before action."),
            ("Coordinate responsible trade","Verify ownership and handoff."),
            ("Document decision","Record the approved resolution and downstream impact.")
        ]
    return opts


def _v51_uncertainty(unit):
    conf=str(unit["confidence"] or "MEDIUM").upper()
    missing_source=not bool(str(unit["source"] or "").strip())
    if conf=="LOW" or missing_source:
        return ("LOW","Project evidence is incomplete or weak; human review is required before relying on this conclusion.")
    if unit["severity"]=="REVIEW":
        return ("MEDIUM","This is a coordination/review signal rather than a confirmed project condition.")
    return ("HIGH","Current project data provides a reasonably strong basis for this reasoning path.")


def _v51_reasoning_score(unit):
    score=50
    sev={"CRITICAL":25,"HIGH":18,"MEDIUM":10,"REVIEW":3}.get(unit["severity"],0)
    score+=sev
    if unit["source"]: score+=10
    if unit["dependency"] and "No explicit" not in unit["dependency"]: score+=5
    if str(unit["confidence"]).upper()=="HIGH": score+=10
    elif str(unit["confidence"]).upper()=="LOW": score-=20
    return max(0,min(100,score))


def _v51_top_units(pid,limit=20):
    units=_v51_reasoning_units(pid)
    for u in units:
        u["reasoning_score"]=_v51_reasoning_score(u)
        u["certainty"],u["certainty_note"]=_v51_uncertainty(u)
    units.sort(key=lambda x:(-x["reasoning_score"],x["type"],x["title"]))
    return units[:limit]


@app.get("/reasoning-2",response_class=HTMLResponse)
def v51_reasoning_home():
    pid=project_id()
    units=_v51_top_units(pid,25)
    low=sum(1 for u in units if u["certainty"]=="LOW")
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v51 - Real Construction Reasoning 2.0</div><h1>Explain the problem, the dependency, and what to do next.</h1><p class="muted">{len(units)} prioritized reasoning paths · {low} low-certainty path(s) requiring stronger human review.</p></div><div class="grid3">'
    cards=[
      ("Cause → Consequence","See the full reasoning chain for the highest-risk project findings.","/reasoning-2/chains"),
      ("Alternative Resolutions","Compare practical response options before choosing a path.","/reasoning-2/alternatives"),
      ("Responsible Trade Logic","See who owns the action versus who is only affected.","/reasoning-2/ownership"),
      ("Uncertainty Engine","Show when BuildCommand should not make a confident call.","/reasoning-2/uncertainty"),
      ("Reasoning Score","Rank findings by evidence strength and project consequence.","/reasoning-2/scores"),
      ("What Happens Next","Show downstream consequences if a blocker stays unresolved.","/reasoning-2/downstream"),
      ("Best Next Action","Prioritize the next recommended move for each major issue.","/reasoning-2/actions"),
      ("Decision Comparison","Compare hold / resequence / clarify / recover alternatives.","/reasoning-2/compare"),
      ("Explain This Finding","Search a topic and trace BuildCommand's reasoning path.","/reasoning-2/explain"),
      ("Reasoning Command","One concise project view of what matters, why, and what to do.","/reasoning-2/command")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Real Construction Reasoning 2.0",body)


@app.get("/reasoning-2/chains",response_class=HTMLResponse)
def v51_chains():
    units=_v51_top_units(project_id(),100)
    h="".join(
        f'<div class="card"><span class="badge WATCH">{esc(u["severity"])}</span><h3>{esc(u["title"])}</h3>'
        f'<p><b>Cause:</b> {esc(u["cause"])}</p>'
        f'<p><b>Dependency:</b> {esc(u["dependency"])}</p>'
        f'<p><b>Consequence:</b> {esc(u["consequence"])}</p>'
        f'<p><b>Responsible:</b> {esc(u["owner"] or "Needs ownership review")}</p>'
        f'<p><b>Recommended:</b> {esc(u["action"])}</p>'
        f'<div class="small">Reasoning score {u["reasoning_score"]}/100 · Certainty {esc(u["certainty"])} · {esc(u["source"])}</div></div>'
        for u in units
    )
    return shell("Cause to Consequence",'<div class="hero"><h1>Cause → Dependency → Consequence</h1><p class="muted">The master brain now explains why each major finding matters.</p></div>'+h)


@app.get("/reasoning-2/alternatives",response_class=HTMLResponse)
def v51_alternatives_page():
    units=_v51_top_units(project_id(),30)
    body='<div class="hero"><h1>Alternative Resolution Intelligence</h1><p class="muted">Options are decision support, not automatic field directives.</p></div>'
    for u in units:
        body+=f'<div class="card"><h3>{esc(u["title"])}</h3><p>{esc(u["cause"])}</p>'
        for title,why in _v51_alternatives(u):
            body+=f'<div class="action"><b>{esc(title)}</b><div class="small">{esc(why)}</div></div>'
        body+='</div>'
    return shell("Alternative Resolutions",body)


@app.get("/reasoning-2/ownership",response_class=HTMLResponse)
def v51_ownership():
    units=_v51_top_units(project_id(),100)
    h="".join(
        f'<div class="action"><b>{esc(u["owner"] or "Ownership review needed")}</b> - {esc(u["title"])}'
        f'<div class="small">Affected dependency: {esc(u["dependency"])}</div></div>'
        for u in units
    )
    return shell("Responsible Trade Logic",'<div class="hero"><h1>Responsible Trade Logic</h1><p class="muted">Primary ownership is separated from downstream affected trades.</p></div><div class="card">'+h+'</div>')


@app.get("/reasoning-2/uncertainty",response_class=HTMLResponse)
def v51_uncertainty_page():
    units=_v51_top_units(project_id(),150)
    h="".join(
        f'<div class="action"><span class="badge {"WATCH" if u["certainty"]!="HIGH" else "READY"}">{esc(u["certainty"])}</span> '
        f'<b>{esc(u["title"])}</b><div class="small">{esc(u["certainty_note"])}</div></div>'
        for u in units
    )
    return shell("Uncertainty Engine",'<div class="hero"><h1>Uncertainty Engine</h1><p class="muted">BuildCommand should expose weak evidence instead of sounding certain when the project documents do not support certainty.</p></div><div class="card">'+h+'</div>')


@app.get("/reasoning-2/scores",response_class=HTMLResponse)
def v51_scores():
    units=_v51_top_units(project_id(),150)
    h="".join(
        f'<div class="action"><span class="badge">{u["reasoning_score"]}</span> <b>{esc(u["title"])}</b>'
        f'<div class="small">{esc(u["type"])} · {esc(u["severity"])} · Certainty {esc(u["certainty"])}</div></div>'
        for u in units
    )
    return shell("Reasoning Score",'<div class="hero"><h1>Reasoning Strength Score</h1><p class="muted">Ranks findings using consequence, source evidence, dependency context and confidence.</p></div><div class="card">'+h+'</div>')


@app.get("/reasoning-2/downstream",response_class=HTMLResponse)
def v51_downstream_page():
    units=_v51_top_units(project_id(),100)
    h="".join(
        f'<div class="action"><b>{esc(u["title"])}</b><p>{esc(u["consequence"])}</p>'
        f'<div class="small">If unresolved: downstream work may remain exposed. Dependency: {esc(u["dependency"])}</div></div>'
        for u in units
    )
    return shell("What Happens Next",'<div class="hero"><h1>What Happens Next?</h1><p class="muted">Focuses the team on downstream consequence, not only the immediate problem.</p></div><div class="card">'+h+'</div>')


@app.get("/reasoning-2/actions",response_class=HTMLResponse)
def v51_actions_page():
    units=_v51_top_units(project_id(),50)
    h="".join(
        f'<div class="action"><span class="badge WATCH">{esc(u["severity"])}</span> <b>{esc(u["action"])}</b>'
        f'<div class="small">Because: {esc(u["cause"])} · Owner: {esc(u["owner"] or "Review")}</div></div>'
        for u in units
    )
    return shell("Best Next Action",'<div class="hero"><h1>Best Next Action</h1><p class="muted">Recommended actions are tied to the reason they matter.</p></div><div class="card">'+h+'</div>')


@app.get("/reasoning-2/compare",response_class=HTMLResponse)
def v51_compare_page():
    units=_v51_top_units(project_id(),20)
    body='<div class="hero"><h1>Decision Comparison</h1><p class="muted">Compare practical response paths before committing the project.</p></div>'
    for u in units:
        body+=f'<div class="card"><h3>{esc(u["title"])}</h3>'
        for idx,(title,why) in enumerate(_v51_alternatives(u),1):
            body+=f'<div class="action"><b>Option {idx}: {esc(title)}</b><div class="small">{esc(why)}</div></div>'
        body+=f'<p><b>Current recommended action:</b> {esc(u["action"])}</p></div>'
    return shell("Decision Comparison",body)


@app.get("/reasoning-2/explain",response_class=HTMLResponse)
def v51_explain_page(q:str=''):
    units=_v51_top_units(project_id(),200)
    matches=[]
    if q:
        tokens=[w for w in re.findall(r'[a-z0-9]+',q.lower()) if len(w)>3]
        for u in units:
            text=(u["title"]+" "+u["cause"]+" "+u["dependency"]+" "+u["owner"]).lower()
            if tokens and any(tok in text for tok in tokens):
                matches.append(u)
    body='<div class="hero"><h1>Explain This Finding</h1><p class="muted">Search a project subject and see the reasoning path behind BuildCommand\'s conclusion.</p></div><div class="card"><form method="get"><input name="q" value="'+esc(q)+'" placeholder="Example: storefront, water heater, ceiling"><button type="submit">Explain</button></form></div>'
    if q:
        body+='<div class="card">'+("".join(
            f'<div class="action"><b>{esc(u["title"])}</b><p><b>Cause:</b> {esc(u["cause"])}</p><p><b>Dependency:</b> {esc(u["dependency"])}</p><p><b>Consequence:</b> {esc(u["consequence"])}</p><p><b>Action:</b> {esc(u["action"])}</p></div>'
            for u in matches[:30]
        ) or '<p class="muted">No reasoning path matched that subject.</p>')+'</div>'
    return shell("Explain This Finding",body)


@app.get("/reasoning-2/command",response_class=HTMLResponse)
def v51_command_page():
    units=_v51_top_units(project_id(),10)
    body='<div class="hero"><div class="eyebrow">Reasoning Command</div><h1>What matters, why, and what should happen next?</h1><p class="muted">Top connected reasoning paths from the current project.</p></div><div class="card">'
    for u in units:
        body+=f'<div class="action"><span class="badge WATCH">{esc(u["severity"])}</span> <b>{esc(u["title"])}</b><p>{esc(u["cause"])}</p><p><b>Next:</b> {esc(u["action"])}</p><div class="small">Owner {esc(u["owner"] or "Review")} · Score {u["reasoning_score"]}/100 · Certainty {esc(u["certainty"])}</div></div>'
    body+='</div>'
    return shell("Reasoning Command",body)


def _v54_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS project_memory(
        id {pk},company_id BIGINT,project_id BIGINT,memory_type TEXT,subject TEXT,
        lesson TEXT,approved_result TEXT,source_ref TEXT,scope_level TEXT DEFAULT 'PROJECT ONLY',
        approval_status TEXT DEFAULT 'APPROVED',approved_by TEXT,confidence TEXT DEFAULT 'HIGH',
        created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS project_pattern_memory(
        id {pk},company_id BIGINT,pattern_type TEXT,pattern_key TEXT,pattern_summary TEXT,
        occurrence_count INTEGER DEFAULT 1,latest_project_id BIGINT,last_seen TEXT,
        approved_only INTEGER DEFAULT 1,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS learning_application_log(
        id {pk},company_id BIGINT,project_id BIGINT,memory_id BIGINT,applied_to_type TEXT,
        applied_to_key TEXT,application_result TEXT,confidence TEXT DEFAULT 'MEDIUM',
        created TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v54_memory_rows(pid=None):
    _v54_ensure_tables()
    if pid:
        return _v39_rows("""
            SELECT * FROM project_memory
            WHERE company_id=? AND project_id=? AND approval_status='APPROVED'
            ORDER BY id DESC
        """,(current_company_id(),pid))
    return _v39_rows("""
        SELECT * FROM project_memory
        WHERE company_id=? AND approval_status='APPROVED'
        ORDER BY id DESC LIMIT 500
    """,(current_company_id(),))


def _v54_seed_from_existing(pid):
    """
    Import already-approved learning and answered project decisions into project memory
    without changing their original source tables.
    """
    _v54_ensure_tables()
    existing=_v39_rows("SELECT subject,lesson,source_ref FROM project_memory WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    seen={(str(r["subject"] or ""),str(r["lesson"] or ""),str(r["source_ref"] or "")) for r in existing}
    c=db()
    now=datetime.utcnow().isoformat()

    # Approved learning rules
    for r in _v48_learning_rules(pid):
        key=(str(r["subject"] or ""),str(r["learned_rule"] or ""),str(r["source_ref"] or ""))
        if key in seen: continue
        c.execute("""INSERT INTO project_memory(
            company_id,project_id,memory_type,subject,lesson,approved_result,source_ref,
            scope_level,approval_status,approved_by,confidence,created,updated
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
            current_company_id(),pid,"APPROVED LEARNING",r["subject"],r["learned_rule"],r["learned_rule"],
            r["source_ref"],r["scope_level"],"APPROVED",r["approved_by"],r["confidence"],now,now
        ))
        seen.add(key)

    # Answered / closed RFIs
    try:
        for r in _v42_rfis(pid):
            status=str(r["status"] or "").upper()
            if status not in {"ANSWERED","CLOSED","COMPLETE"} or not str(r["answer"] or "").strip():
                continue
            subject=f'RFI {r["number"] or r["id"]}: {r["title"]}'
            lesson=str(r["answer"] or "").strip()
            key=(subject,lesson,str(r["source_ref"] or ""))
            if key in seen: continue
            c.execute("""INSERT INTO project_memory(
                company_id,project_id,memory_type,subject,lesson,approved_result,source_ref,
                scope_level,approval_status,approved_by,confidence,created,updated
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
                current_company_id(),pid,"RFI ANSWER",subject,lesson,lesson,r["source_ref"] or "",
                "PROJECT ONLY","APPROVED","PROJECT TEAM","HIGH",now,now
            ))
            seen.add(key)
    except Exception:
        pass

    # Completed lessons learned
    try:
        lessons=_v39_rows("""
            SELECT * FROM lessons_learned
            WHERE company_id=? AND project_id=? AND approval_status='APPROVED'
            ORDER BY id DESC
        """,(current_company_id(),pid))
        for r in lessons:
            subject=f'{r["category"]}: {r["title"]}'
            lesson=str(r["lesson"] or "")
            key=(subject,lesson,str(r["source_ref"] or ""))
            if key in seen: continue
            c.execute("""INSERT INTO project_memory(
                company_id,project_id,memory_type,subject,lesson,approved_result,source_ref,
                scope_level,approval_status,approved_by,confidence,created,updated
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
                current_company_id(),pid,"LESSON LEARNED",subject,lesson,r["recommendation"] or lesson,
                r["source_ref"] or "",r["scope_level"] or "PROJECT ONLY","APPROVED",
                r["approved_by"] or "PROJECT TEAM","HIGH",now,now
            ))
            seen.add(key)
    except Exception:
        pass

    c.commit(); c.close()


def _v54_rebuild_patterns():
    _v54_ensure_tables()
    rows=_v54_memory_rows()
    patterns={}
    for r in rows:
        if str(r["scope_level"] or "")=="PROJECT ONLY":
            continue
        typ=str(r["memory_type"] or "OTHER")
        key=re.sub(r'\s+',' ',str(r["subject"] or "").lower()).strip()[:180]
        if not key: continue
        p=patterns.setdefault((typ,key),{"summary":r["lesson"],"count":0,"latest":r["project_id"]})
        p["count"]+=1
        p["latest"]=r["project_id"]

    c=db()
    c.execute("DELETE FROM project_pattern_memory WHERE company_id=?",(current_company_id(),))
    now=datetime.utcnow().isoformat()
    for (typ,key),p in patterns.items():
        c.execute("""INSERT INTO project_pattern_memory(
            company_id,pattern_type,pattern_key,pattern_summary,occurrence_count,
            latest_project_id,last_seen,approved_only,created,updated
        ) VALUES(?,?,?,?,?,?,?,?,?,?)""",(
            current_company_id(),typ,key,p["summary"],p["count"],p["latest"],now,1,now,now
        ))
    c.commit(); c.close()


def _v54_company_patterns():
    _v54_rebuild_patterns()
    return _v39_rows("""
        SELECT * FROM project_pattern_memory
        WHERE company_id=?
        ORDER BY occurrence_count DESC,id DESC LIMIT 250
    """,(current_company_id(),))


def _v54_apply_memory_to_scope(pid):
    """
    Preview how approved company memory would influence current scope.
    Does not silently overwrite saved scope.
    """
    memories=[r for r in _v54_memory_rows() if str(r["scope_level"] or "")=="COMPANY STANDARD"]
    scopes=_v452_scope_rows(pid)
    proposals=[]
    for r in scopes:
        low=str(r["requirement"] or "").lower()
        for m in memories:
            subject=str(m["subject"] or "").lower().strip()
            if subject and subject in low:
                proposals.append((r,m))
    return proposals[:200]


def _v54_memory_quality():
    rows=_v54_memory_rows()
    project=sum(1 for r in rows if r["scope_level"]=="PROJECT ONLY")
    company=sum(1 for r in rows if r["scope_level"]=="COMPANY STANDARD")
    globaln=sum(1 for r in rows if r["scope_level"]=="GLOBAL BUILDCOMMAND RULE")
    return {"total":len(rows),"project":project,"company":company,"global":globaln}


@app.get("/project-memory",response_class=HTMLResponse)
def v54_memory_home():
    pid=project_id()
    _v54_seed_from_existing(pid)
    q=_v54_memory_quality()
    patterns=_v54_company_patterns()
    proposals=_v54_apply_memory_to_scope(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v54 - Project Memory & Continuous Learning</div><h1>Do not make the same construction mistake twice.</h1><p class="muted">{q["total"]} approved memory item(s) · {q["project"]} project-only · {q["company"]} company standards · {q["global"]} global rules · {len(patterns)} reusable pattern(s) · {len(proposals)} current-project memory match(es).</p></div><div class="grid3">'
    cards=[
      ("Approved Project Memory","See approved corrections, RFI answers and lessons from this project.","/project-memory/current"),
      ("Company Standards Memory","Approved reusable construction rules across projects.","/project-memory/company"),
      ("Recurring Pattern Brain","Find repeated approved lessons across completed work.","/project-memory/patterns"),
      ("Memory-to-Scope Preview","See where approved company memory would influence current scope.","/project-memory/apply"),
      ("RFI Answer Memory","Reuse approved clarifications instead of rediscovering the same question.","/project-memory/rfis"),
      ("Lessons-Learned Memory","Carry approved lessons into future project intelligence.","/project-memory/lessons"),
      ("Trade Correction Memory","See approved ownership corrections that should affect Blueprint Brain.","/project-memory/trade-corrections"),
      ("Memory Quality","Understand what is project-specific versus reusable.","/project-memory/quality"),
      ("Project-to-Project Learning","Compare current project needs against approved company patterns.","/project-memory/cross-project"),
      ("Continuous Learning Command","One view of what BuildCommand has learned and where it can help next.","/project-memory/command")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Project Memory",body)


@app.get("/project-memory/current",response_class=HTMLResponse)
def v54_current_memory():
    pid=project_id(); _v54_seed_from_existing(pid)
    rows=_v54_memory_rows(pid)
    h="".join(f'<div class="action"><span class="badge READY">{esc(r["memory_type"])}</span> <b>{esc(r["subject"])}</b><div>{esc(r["lesson"])}</div><div class="small">{esc(r["scope_level"])} · {esc(r["source_ref"])} · Approved by {esc(r["approved_by"])}</div></div>' for r in rows)
    return shell("Approved Project Memory",'<div class="hero"><h1>Approved Project Memory</h1><p class="muted">Only approved decisions become durable project memory.</p></div><div class="card">'+(h or '<p class="muted">No approved project memory yet.</p>')+'</div>')


@app.get("/project-memory/company",response_class=HTMLResponse)
def v54_company_memory():
    rows=[r for r in _v54_memory_rows() if r["scope_level"]=="COMPANY STANDARD"]
    h="".join(f'<div class="action"><span class="badge READY">COMPANY STANDARD</span> <b>{esc(r["subject"])}</b><div>{esc(r["lesson"])}</div><div class="small">{esc(r["memory_type"])} · {esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Company Standards Memory",'<div class="hero"><h1>Company Standards Memory</h1><p class="muted">Approved reusable rules can influence future projects; project-only memory cannot silently promote itself.</p></div><div class="card">'+(h or '<p class="muted">No company-standard memory yet.</p>')+'</div>')


@app.get("/project-memory/patterns",response_class=HTMLResponse)
def v54_patterns_page():
    rows=_v54_company_patterns()
    h="".join(f'<div class="action"><span class="badge">{r["occurrence_count"]}x</span> <b>{esc(r["pattern_type"])}</b> - {esc(r["pattern_key"])}<div>{esc(r["pattern_summary"])}</div></div>' for r in rows)
    return shell("Recurring Pattern Brain",'<div class="hero"><h1>Recurring Pattern Brain</h1><p class="muted">Repeated approved lessons become visible patterns; they are not automatically promoted to global truth.</p></div><div class="card">'+(h or '<p class="muted">No recurring approved patterns yet.</p>')+'</div>')


@app.get("/project-memory/apply",response_class=HTMLResponse)
def v54_apply_page():
    rows=_v54_apply_memory_to_scope(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">MEMORY MATCH</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Approved company memory: {esc(m["subject"])} → {esc(m["lesson"])}</div></div>' for r,m in rows)
    return shell("Memory-to-Scope Preview",'<div class="hero"><h1>Memory-to-Scope Preview</h1><p class="muted">Shows where approved company memory matches current scope. Preview only—no silent overwrite.</p></div><div class="card">'+(h or '<p class="muted">No current scope matches approved company memory.</p>')+'</div>')


@app.get("/project-memory/rfis",response_class=HTMLResponse)
def v54_rfi_memory():
    rows=[r for r in _v54_memory_rows() if r["memory_type"]=="RFI ANSWER"]
    h="".join(f'<div class="action"><b>{esc(r["subject"])}</b><div>{esc(r["lesson"])}</div><div class="small">{esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("RFI Answer Memory",'<div class="hero"><h1>RFI Answer Memory</h1><p class="muted">Approved clarifications remain searchable project knowledge instead of disappearing in old RFIs.</p></div><div class="card">'+(h or '<p class="muted">No approved RFI-answer memory yet.</p>')+'</div>')


@app.get("/project-memory/lessons",response_class=HTMLResponse)
def v54_lessons_memory():
    rows=[r for r in _v54_memory_rows() if r["memory_type"]=="LESSON LEARNED"]
    h="".join(f'<div class="action"><b>{esc(r["subject"])}</b><div>{esc(r["lesson"])}</div><div class="small">{esc(r["scope_level"])} · {esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Lessons-Learned Memory",'<div class="hero"><h1>Lessons-Learned Memory</h1><p class="muted">Approved project lessons can become company intelligence when deliberately promoted.</p></div><div class="card">'+(h or '<p class="muted">No approved lessons-learned memory yet.</p>')+'</div>')


@app.get("/project-memory/trade-corrections",response_class=HTMLResponse)
def v54_trade_memory():
    rows=[r for r in _v54_memory_rows() if r["memory_type"]=="APPROVED LEARNING" and ("trade" in str(r["subject"] or "").lower() or "->" in str(r["lesson"] or ""))]
    h="".join(f'<div class="action"><span class="badge READY">{esc(r["scope_level"])}</span> <b>{esc(r["subject"])}</b><div>{esc(r["lesson"])}</div></div>' for r in rows)
    return shell("Trade Correction Memory",'<div class="hero"><h1>Trade Correction Memory</h1><p class="muted">Human-approved ownership corrections should influence future Blueprint Brain decisions.</p></div><div class="card">'+(h or '<p class="muted">No approved trade-correction memory found.</p>')+'</div>')


@app.get("/project-memory/quality",response_class=HTMLResponse)
def v54_memory_quality_page():
    q=_v54_memory_quality()
    return shell("Memory Quality",f'<div class="hero"><h1>Memory Quality</h1><p class="muted">{q["total"]} approved memories available.</p></div><div class="grid3"><div class="card"><div class="label">Project Only</div><div class="kpi">{q["project"]}</div></div><div class="card"><div class="label">Company Standards</div><div class="kpi">{q["company"]}</div></div><div class="card"><div class="label">Global Rules</div><div class="kpi">{q["global"]}</div></div></div>')


@app.get("/project-memory/cross-project",response_class=HTMLResponse)
def v54_cross_project():
    patterns=_v54_company_patterns()
    h="".join(f'<div class="action"><span class="badge">{r["occurrence_count"]}x</span> <b>{esc(r["pattern_key"])}</b><div>{esc(r["pattern_summary"])}</div><div class="small">Latest project {esc(r["latest_project_id"])}</div></div>' for r in patterns)
    return shell("Project-to-Project Learning",'<div class="hero"><h1>Project-to-Project Learning</h1><p class="muted">Approved company-level patterns help the next project start smarter.</p></div><div class="card">'+(h or '<p class="muted">No reusable cross-project patterns yet.</p>')+'</div>')


@app.get("/project-memory/command",response_class=HTMLResponse)
def v54_command():
    pid=project_id(); _v54_seed_from_existing(pid)
    q=_v54_memory_quality(); proposals=_v54_apply_memory_to_scope(pid); patterns=_v54_company_patterns()[:10]
    body=f'<div class="hero"><div class="eyebrow">Continuous Learning Command</div><h1>What has BuildCommand learned?</h1><p class="muted">{q["total"]} approved memories · {q["company"]} company standards · {len(proposals)} current scope matches · {len(patterns)} recurring patterns.</p></div>'
    body+='<div class="grid3">'
    body+=_v37_link_card("Current Project Memory","Approved corrections, RFIs and lessons.","/project-memory/current","Open")
    body+=_v37_link_card("Memory Matches","Where prior approved knowledge applies now.","/project-memory/apply","Review")
    body+=_v37_link_card("Recurring Patterns","Approved patterns across projects.","/project-memory/patterns","Review")
    body+='</div>'
    return shell("Continuous Learning Command",body)


def _v55_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS drawing_revision_runs(
        id {pk},company_id BIGINT,project_id BIGINT,new_attachment_id BIGINT,
        prior_attachment_id BIGINT,revision_group TEXT,status TEXT DEFAULT 'REVIEW',
        summary TEXT,affected_trades TEXT,cost_risk TEXT DEFAULT 'REVIEW',
        schedule_risk TEXT DEFAULT 'REVIEW',created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS drawing_revision_findings(
        id {pk},company_id BIGINT,project_id BIGINT,run_id BIGINT,
        finding_type TEXT,subject TEXT,trade TEXT,source_new TEXT,source_prior TEXT,
        change_summary TEXT,cost_exposure {num} DEFAULT 0,schedule_days {num} DEFAULT 0,
        severity TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'OPEN',
        recommended_action TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS revision_downstream_links(
        id {pk},company_id BIGINT,project_id BIGINT,run_id BIGINT,
        finding_id BIGINT,related_type TEXT,related_key TEXT,related_title TEXT,
        relationship TEXT,reason TEXT,created TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v55_doc_group(name):
    n=str(name or "")
    n=re.sub(r'(?i)\b(rev(?:ision)?|addendum|bulletin|asi|sk)[\s_-]*[A-Z0-9.-]+\b','',n)
    n=re.sub(r'(?i)\b\d{4}[-_]\d{2}[-_]\d{2}\b','',n)
    return re.sub(r'[^a-z0-9]+',' ',n.lower()).strip()


def _v55_revision_pairs(pid):
    docs=_v46_docs(pid)
    groups={}
    for d in docs:
        groups.setdefault(_v55_doc_group(d["original_name"]),[]).append(d)
    out=[]
    for group,items in groups.items():
        if not group or len(items)<2:
            continue
        items=sorted(items,key=lambda x:x["id"],reverse=True)
        out.append((items[0],items[1],group))
    return out[:100]


def _v55_scope_by_run(pid):
    rows=_v452_scope_rows(pid)
    runs={}
    for r in rows:
        runs.setdefault(int(r["run_id"]),[]).append(r)
    return runs


def _v55_scope_delta(pid):
    runs=_v55_scope_by_run(pid)
    run_ids=sorted(runs.keys(),reverse=True)
    if len(run_ids)<2:
        return [],[],[]
    new_rows=runs[run_ids[0]]
    old_rows=runs[run_ids[1]]

    def key(r):
        return re.sub(r'\s+',' ',str(r["requirement"] or "").lower()).strip()

    new_map={key(r):r for r in new_rows if key(r)}
    old_map={key(r):r for r in old_rows if key(r)}

    added=[new_map[k] for k in new_map.keys()-old_map.keys()]
    removed=[old_map[k] for k in old_map.keys()-new_map.keys()]
    changed=[]
    common=new_map.keys() & old_map.keys()
    for k in common:
        nr,orow=new_map[k],old_map[k]
        if str(nr["trade"])!=str(orow["trade"]) or str(nr["source_sheet"])!=str(orow["source_sheet"]) or str(nr["source_spec"])!=str(orow["source_spec"]):
            changed.append((orow,nr))
    return added[:200],removed[:200],changed[:200]


def _v55_affected_trades(pid):
    added,removed,changed=_v55_scope_delta(pid)
    trades=set()
    for r in added+removed:
        if r["trade"]: trades.add(str(r["trade"]))
    for old,new in changed:
        if old["trade"]: trades.add(str(old["trade"]))
        if new["trade"]: trades.add(str(new["trade"]))
    return sorted(trades)


def _v55_cost_schedule_exposure(pid):
    added,removed,changed=_v55_scope_delta(pid)
    estimate=_v39_rows("SELECT * FROM estimator_items WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    est_by_scope={}
    for e in estimate:
        sid=e["blueprint_scope_item_id"]
        if sid is not None:
            total=(float(e["quantity"] or 0)*float(e["material_unit_cost"] or 0)
                   +float(e["quantity"] or 0)*float(e["labor_unit_cost"] or 0)
                   +float(e["subcontract_quote"] or 0)+float(e["allowance"] or 0))
            est_by_scope[int(sid)]=total
    added_cost=sum(est_by_scope.get(int(r["id"]),0) for r in added)
    removed_cost=sum(est_by_scope.get(int(r["id"]),0) for r in removed)
    schedule_days=min(30,len(added)*0.5+len(changed)*0.25)
    return added_cost,removed_cost,schedule_days


def _v55_downstream(pid):
    affected=_v55_affected_trades(pid)
    rfis=_v42_rfis(pid)
    subs=_v39_rows("SELECT * FROM submittals WHERE project_id=?",(pid,))
    acts=_v39_rows("SELECT * FROM activities WHERE project_id=?",(pid,))
    links=[]
    for tr in affected:
        for a in acts:
            if str(a["trade"] or "").lower()==tr.lower():
                links.append(("ACTIVITY",a["id"],a["name"],tr))
        for s in subs:
            if tr.lower() in str(s["responsible_party"] or "").lower() or tr.lower() in str(s["title"] or "").lower():
                links.append(("SUBMITTAL",s["id"],s["title"],tr))
        for r in rfis:
            blob=(str(r["title"] or "")+" "+str(r["question"] or "")).lower()
            if tr.lower() in blob:
                links.append(("RFI",r["id"],r["title"],tr))
    return links[:200]


def _v55_summary(pid):
    def build():
        pairs=_v55_revision_pairs(pid)
        added,removed,changed=_v55_scope_delta(pid)
        trades=_v55_affected_trades(pid)
        add_cost,remove_cost,days=_v55_cost_schedule_exposure(pid)
        links=_v55_downstream(pid)
        return {
            "pairs":pairs,"added":added,"removed":removed,"changed":changed,"trades":trades,
            "added_cost":add_cost,"removed_cost":remove_cost,"days":days,"links":links
        }
    return _v56_cached("revision_summary",pid,build)


@app.get("/revision-intelligence",response_class=HTMLResponse)
def v55_revision_home():
    pid=project_id(); _v55_ensure_tables()
    s=_v55_summary(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v55 - Drawing Revision & Change Intelligence</div><h1>Know what changed before it hits the field.</h1><p class="muted">{len(s["pairs"])} likely revision pair(s) · {len(s["added"])} added scope item(s) · {len(s["removed"])} removed item(s) · {len(s["changed"])} changed ownership/source item(s) · {len(s["trades"])} affected trade(s).</p></div><div class="grid3">'
    cards=[
      ("Revision Pairing","Find likely prior/new versions of project documents.","/revision-intelligence/pairs"),
      ("Added Scope","See requirements appearing in the latest analyzed run.","/revision-intelligence/added"),
      ("Removed Scope","See requirements no longer present in the latest analyzed run.","/revision-intelligence/removed"),
      ("Changed Scope","See ownership/source changes between recent analyses.","/revision-intelligence/changed"),
      ("Affected Trades","See which subcontractor scopes may need review.","/revision-intelligence/trades"),
      ("Cost Exposure","Estimate known priced exposure tied to changed scope.","/revision-intelligence/cost"),
      ("Schedule Exposure","Show likely schedule review pressure from revision volume.","/revision-intelligence/schedule"),
      ("RFI / Submittal Impact","Connect affected trades to downstream control items.","/revision-intelligence/downstream"),
      ("Revision Action List","Prioritize what the project team should review next.","/revision-intelligence/actions"),
      ("Revision Command","One concise revision/change intelligence view.","/revision-intelligence/command")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Revision Intelligence",body)


@app.get("/revision-intelligence/pairs",response_class=HTMLResponse)
def v55_pairs_page():
    rows=_v55_revision_pairs(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">COMPARE</span> <b>{esc(new["original_name"])}</b><div class="small">Prior candidate: {esc(old["original_name"])} · Group {esc(group)}</div></div>' for new,old,group in rows)
    return shell("Revision Pairing",'<div class="hero"><h1>Revision Pairing</h1><p class="muted">Filename-based candidate pairing only; human review still confirms the actual revision relationship.</p></div><div class="card">'+(h or '<p class="muted">No likely revision pairs detected.</p>')+'</div>')


@app.get("/revision-intelligence/added",response_class=HTMLResponse)
def v55_added_page():
    rows=_v55_scope_delta(project_id())[0]
    h="".join(f'<div class="action"><span class="badge WATCH">ADDED</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} · {esc(r["source_spec"])}</div></div>' for r in rows)
    return shell("Added Scope",'<div class="hero"><h1>Added Scope Intelligence</h1><p class="muted">Requirements present in the latest Blueprint Brain run but not the immediately prior run.</p></div><div class="card">'+(h or '<p class="muted">No added scope detected.</p>')+'</div>')


@app.get("/revision-intelligence/removed",response_class=HTMLResponse)
def v55_removed_page():
    rows=_v55_scope_delta(project_id())[1]
    h="".join(f'<div class="action"><span class="badge WATCH">REMOVED</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} · {esc(r["source_spec"])}</div></div>' for r in rows)
    return shell("Removed Scope",'<div class="hero"><h1>Removed Scope Intelligence</h1><p class="muted">Requirements present in the prior Blueprint Brain run but not the latest run.</p></div><div class="card">'+(h or '<p class="muted">No removed scope detected.</p>')+'</div>')


@app.get("/revision-intelligence/changed",response_class=HTMLResponse)
def v55_changed_page():
    rows=_v55_scope_delta(project_id())[2]
    h="".join(f'<div class="action"><span class="badge WATCH">CHANGED</span> <b>{esc(old["trade"])} → {esc(new["trade"])}</b> - {esc(new["requirement"])}<div class="small">Old {esc(old["source_sheet"])} / New {esc(new["source_sheet"])}</div></div>' for old,new in rows)
    return shell("Changed Scope",'<div class="hero"><h1>Changed Scope Intelligence</h1><p class="muted">Highlights ownership/source changes between the two most recent Blueprint Brain runs.</p></div><div class="card">'+(h or '<p class="muted">No changed scope signals detected.</p>')+'</div>')


@app.get("/revision-intelligence/trades",response_class=HTMLResponse)
def v55_trades_page():
    trades=_v55_affected_trades(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">REVIEW</span> <b>{esc(tr)}</b><div class="small">Scope/bid/schedule review recommended due to detected revision changes.</div></div>' for tr in trades)
    return shell("Affected Trades",'<div class="hero"><h1>Affected Trades</h1><p class="muted">Trade list derived from added, removed and changed Blueprint Brain scope.</p></div><div class="card">'+(h or '<p class="muted">No affected trades detected.</p>')+'</div>')


@app.get("/revision-intelligence/cost",response_class=HTMLResponse)
def v55_cost_page():
    add,remove,days=_v55_cost_schedule_exposure(project_id())
    return shell("Revision Cost Exposure",f'<div class="hero"><h1>Revision Cost Exposure</h1><p class="muted">Known estimator-linked scope only. Added ${add:,.0f} · Removed ${remove:,.0f} · Net ${add-remove:,.0f}.</p></div><div class="card"><p>Unpriced scope remains review exposure and is not fabricated into a dollar value.</p></div>')


@app.get("/revision-intelligence/schedule",response_class=HTMLResponse)
def v55_schedule_page():
    s=_v55_summary(project_id())
    return shell("Revision Schedule Exposure",f'<div class="hero"><h1>Revision Schedule Exposure</h1><p class="muted">{len(s["added"])} added + {len(s["changed"])} changed scope signals suggest approximately {s["days"]:.1f} review-day(s) of schedule pressure proxy.</p></div><div class="card"><p>This is a transparent review proxy, not CPM-calculated delay entitlement.</p></div>')


@app.get("/revision-intelligence/downstream",response_class=HTMLResponse)
def v55_downstream_page():
    rows=_v55_downstream(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(kind)}</span> <b>{esc(title)}</b><div class="small">Affected trade: {esc(trade)}</div></div>' for kind,key,title,trade in rows)
    return shell("Revision Downstream Impact",'<div class="hero"><h1>RFI / Submittal / Schedule Impact</h1><p class="muted">Connect revision-affected trades to downstream project controls that deserve review.</p></div><div class="card">'+(h or '<p class="muted">No downstream linked items detected.</p>')+'</div>')


@app.get("/revision-intelligence/actions",response_class=HTMLResponse)
def v55_actions_page():
    s=_v55_summary(project_id())
    actions=[]
    if s["added"]: actions.append(("HIGH","Review added scope",f'{len(s["added"])} new requirement(s) detected.'))
    if s["removed"]: actions.append(("HIGH","Review deleted scope",f'{len(s["removed"])} prior requirement(s) no longer detected.'))
    if s["changed"]: actions.append(("HIGH","Review changed ownership/source",f'{len(s["changed"])} changed item(s) detected.'))
    if s["trades"]: actions.append(("HIGH","Notify affected trades",", ".join(s["trades"])))
    if s["links"]: actions.append(("REVIEW","Review downstream controls",f'{len(s["links"])} RFI/submittal/activity link(s) may be affected.'))
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(title)}</b><div class="small">{esc(detail)}</div></div>' for level,title,detail in actions)
    return shell("Revision Action List",'<div class="hero"><h1>Revision Action List</h1><p class="muted">Human review remains required before scope, cost, or schedule commitments change.</p></div><div class="card">'+(h or '<p class="muted">No revision actions detected.</p>')+'</div>')


@app.get("/revision-intelligence/command",response_class=HTMLResponse)
def v55_command_page():
    s=_v55_summary(project_id())
    net=s["added_cost"]-s["removed_cost"]
    body=f'<div class="hero"><div class="eyebrow">Revision Command</div><h1>What changed and what should the team do?</h1><p class="muted">{len(s["added"])} added · {len(s["removed"])} removed · {len(s["changed"])} changed · {len(s["trades"])} affected trades · ${net:,.0f} known net estimator-linked exposure.</p></div><div class="grid3">'
    body+=_v37_link_card("Review Added Scope","Latest-run additions.","/revision-intelligence/added","Review")
    body+=_v37_link_card("Affected Trades","Who needs scope review.","/revision-intelligence/trades","Review")
    body+=_v37_link_card("Action List","What the team should review next.","/revision-intelligence/actions","Open")
    body+='</div>'
    return shell("Revision Command",body)


_V56_CACHE={}


_V56_PERF={}


_V56_TTL={
    "snapshot":15,
    "sequence":30,
    "self_audit":60,
    "master_findings":45,
    "master_score":45,
    "top_priorities":45,
    "decisions":30,
    "materials":30,
    "hold_points":30,
    "agenda":30,
    "revision_summary":60,
}


def _v56_now_ts():
    return datetime.utcnow().timestamp()


def _v56_cache_get(name,pid):
    key=(name,current_company_id(),pid)
    row=_V56_CACHE.get(key)
    if not row:
        return None
    ttl=_V56_TTL.get(name,30)
    if _v56_now_ts()-row["ts"]>ttl:
        _V56_CACHE.pop(key,None)
        return None
    return row["value"]


def _v56_cache_set(name,pid,value):
    _V56_CACHE[(name,current_company_id(),pid)]={"ts":_v56_now_ts(),"value":value}
    return value


def _v56_cached(name,pid,builder):
    hit=_v56_cache_get(name,pid)
    if hit is not None:
        return hit
    return _v56_cache_set(name,pid,builder())


def _v56_clear_project_cache(pid=None):
    cid=current_company_id()
    keys=list(_V56_CACHE.keys())
    for k in keys:
        if k[1]==cid and (pid is None or k[2]==pid):
            _V56_CACHE.pop(k,None)


def _v56_perf_start(label):
    return (label,_v56_now_ts())


def _v56_perf_end(token):
    label,start=token
    elapsed=max(0,_v56_now_ts()-start)
    row=_V56_PERF.setdefault(label,{"count":0,"total":0.0,"max":0.0,"last":0.0})
    row["count"]+=1
    row["total"]+=elapsed
    row["max"]=max(row["max"],elapsed)
    row["last"]=elapsed
    return elapsed


def _v56_ensure_indexes():
    """
    Safe, idempotent indexes for the most common project-scoped reads.
    """
    c=db()
    indexes=[
        ("idx_activities_project_start","activities","project_id,start"),
        ("idx_readiness_project_activity","activity_readiness","project_id,activity_id"),
        ("idx_inspections_project_activity","inspections_tracker","project_id,activity_id"),
        ("idx_procurement_project_activity","procurement","project_id,activity_id"),
        ("idx_submittals_project_activity","submittals","project_id,activity_id"),
        ("idx_issues_project_activity_status","project_issues","project_id,activity_id,status"),
        ("idx_scope_company_project_run","blueprint_scope_items","company_id,project_id,run_id"),
        ("idx_scope_company_project_trade","blueprint_scope_items","company_id,project_id,trade"),
        ("idx_scope_trade_scope","blueprint_scope_items","trade_scope_id"),
        ("idx_trade_scopes_company_project_run","blueprint_trade_scopes","company_id,project_id,run_id"),
        ("idx_attachments_company_project","attachments","company_id,project_id"),
        ("idx_estimator_company_project_scope","estimator_items","company_id,project_id,blueprint_scope_item_id"),
        ("idx_changes_project_status","change_events","project_id,status"),
        ("idx_closeout_company_project","closeout_items","company_id,project_id"),
        ("idx_learning_company_project_approval","learning_rules","company_id,project_id,approval_status"),
        ("idx_memory_company_project_approval","project_memory","company_id,project_id,approval_status"),
    ]
    for name,table,cols in indexes:
        try:
            c.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {table}({cols})")
        except Exception:
            try: c.rollback()
            except Exception: pass
    try: c.commit()
    except Exception: pass
    c.close()


_V56_INDEXES_READY=False


def _v56_indexes_once():
    global _V56_INDEXES_READY
    if not _V56_INDEXES_READY:
        try:
            _v56_ensure_indexes()
        finally:
            _V56_INDEXES_READY=True


def _v56_sequence(pid):
    return _v56_cached("sequence",pid,lambda:_v45_sequence_analysis_uncached(pid))


def _v56_self_audit(pid):
    return _v56_cached("self_audit",pid,lambda:_v48_self_audit_uncached(pid))


def _v56_master_findings(pid):
    return _v56_cached("master_findings",pid,lambda:_v50_collect_findings_uncached(pid))


def _v56_master_score(pid):
    def build():
        findings=_v56_master_findings(pid)
        weights={"CRITICAL":12,"HIGH":7,"MEDIUM":3,"REVIEW":1,"LOW":0}
        risk=min(100,sum(weights.get(f["severity"],1) for f in findings))
        quality=_v48_quality_score(pid)["score"]
        health=max(0,round((100-risk)*0.65 + quality*0.35))
        return {"health":health,"risk":risk,"quality":quality,"count":len(findings)}
    return _v56_cached("master_score",pid,build)


def _v56_top_priorities(pid,limit=10):
    cached=_v56_cache_get("top_priorities",pid)
    if cached is None:
        findings=_v56_master_findings(pid)
        priority=[f for f in findings if f["severity"] in {"CRITICAL","HIGH","MEDIUM"}]
        if len(priority)<50:
            priority.extend([f for f in findings if f["severity"]=="REVIEW"][:50-len(priority)])
        cached=_v56_cache_set("top_priorities",pid,priority[:50])
    return cached[:limit]


def _v56_dashboard_bundle(pid):
    """
    Compute the home screen once and share the same cached module results.
    """
    token=_v56_perf_start("home_dashboard_bundle")
    try:
        _v56_indexes_once()
        s=_v56_cached("snapshot",pid,lambda:_v37_snapshot(pid))
        score=_v56_master_score(pid)
        top=_v56_top_priorities(pid,8)
        decisions=_v56_cached("decisions",pid,lambda:_v47_decision_deadlines(pid)[:8])
        materials=_v56_cached("materials",pid,lambda:[x for x in _v47_material_readiness(pid) if x[2] in {"CRITICAL","HIGH","TODAY"}][:8])
        holds=_v56_cached("hold_points",pid,lambda:[x for x in _v49_hold_points(pid) if str(x[0]["result"] or "").upper()!="PASSED"][:8])
        agenda=_v56_cached("agenda",pid,lambda:_v47_coordination_agenda(pid)[:8])
        sequence=[x for x in _v56_sequence(pid) if x["risk"] in {"CRITICAL","HIGH"}][:8]
        return {
            "snapshot":s,"score":score,"top":top,"decisions":decisions,
            "materials":materials,"holds":holds,"agenda":agenda,"sequence":sequence
        }
    finally:
        _v56_perf_end(token)


@app.get("/performance",response_class=HTMLResponse)
def v56_performance_page():
    _v56_indexes_once()
    cache_count=len(_V56_CACHE)
    rows=[]
    for name,r in sorted(_V56_PERF.items(), key=lambda kv:kv[1]["last"], reverse=True):
        avg=(r["total"]/r["count"]) if r["count"] else 0
        rows.append((name,r["count"],r["last"],avg,r["max"]))
    h="".join(
        f'<div class="action"><b>{esc(name)}</b>'
        f'<div class="small">runs {count} · last {last*1000:.0f} ms · avg {avg*1000:.0f} ms · max {maxv*1000:.0f} ms</div></div>'
        for name,count,last,avg,maxv in rows
    )
    return shell("Performance Monitor",
        f'<div class="hero"><div class="eyebrow">v56 Performance</div><h1>BuildCommand Performance Monitor</h1>'
        f'<p class="muted">{cache_count} cached project intelligence snapshot(s). Heavy intelligence is reused until its short TTL expires.</p></div>'
        f'<div class="card">{h or "<p class=muted>No timing samples yet. Open the dashboard, then return here.</p>"}</div>')


@app.post("/performance/clear-cache")
def v56_clear_cache():
    _v56_clear_project_cache(project_id())
    return RedirectResponse("/performance",status_code=303)


_V57_EVENTS=[]


_V57_DIRTY={}


_V57_DEPENDENCIES={
    "DRAWING_UPLOAD":{"snapshot","master_findings","master_score","top_priorities","revision_summary","self_audit"},
    "BLUEPRINT_ANALYSIS":{"snapshot","master_findings","master_score","top_priorities","revision_summary","self_audit"},
    "SCOPE_CHANGE":{"snapshot","master_findings","master_score","top_priorities","revision_summary","self_audit"},
    "RFI_CHANGE":{"snapshot","master_findings","master_score","top_priorities","decisions","agenda","self_audit"},
    "SUBMITTAL_CHANGE":{"snapshot","master_findings","master_score","top_priorities","decisions","agenda","sequence"},
    "INSPECTION_CHANGE":{"snapshot","master_findings","master_score","top_priorities","hold_points","agenda","sequence"},
    "PROCUREMENT_CHANGE":{"snapshot","master_findings","master_score","top_priorities","materials","agenda","sequence"},
    "SCHEDULE_CHANGE":{"snapshot","master_findings","master_score","top_priorities","sequence","agenda","decisions"},
    "ISSUE_CHANGE":{"snapshot","master_findings","master_score","top_priorities","agenda","sequence"},
    "LEARNING_CHANGE":{"master_findings","master_score","top_priorities","self_audit","revision_summary"},
    "PROJECT_CHANGE":{"snapshot","master_findings","master_score","top_priorities","sequence","agenda","decisions","materials","hold_points"},
}


def _v57_emit(pid,event_type,subject="",source="SYSTEM"):
    event_type=str(event_type or "PROJECT_CHANGE").upper()
    affected=set(_V57_DEPENDENCIES.get(event_type,_V57_DEPENDENCIES["PROJECT_CHANGE"]))
    cid=current_company_id()
    dirty=_V57_DIRTY.setdefault((cid,pid),set())
    dirty.update(affected)

    # Invalidate only the affected v56 cache keys.
    for name in affected:
        _V56_CACHE.pop((name,cid,pid),None)

    event={
        "ts":datetime.utcnow().isoformat(),
        "company_id":cid,"project_id":pid,"event_type":event_type,
        "subject":subject,"source":source,"affected":sorted(affected)
    }
    _V57_EVENTS.append(event)
    if len(_V57_EVENTS)>500:
        del _V57_EVENTS[:-500]
    return event


def _v57_dirty(pid):
    return sorted(_V57_DIRTY.get((current_company_id(),pid),set()))


def _v57_mark_clean(pid,names):
    dirty=_V57_DIRTY.setdefault((current_company_id(),pid),set())
    for n in names: dirty.discard(n)


def _v57_refresh(pid,names=None):
    names=set(names or _v57_dirty(pid))
    token=_v56_perf_start("event_driven_refresh")
    refreshed=[]
    try:
        if "snapshot" in names:
            _v56_cached("snapshot",pid,lambda:_v37_snapshot(pid)); refreshed.append("snapshot")
        if "sequence" in names:
            _v56_sequence(pid); refreshed.append("sequence")
        if "self_audit" in names:
            _v56_self_audit(pid); refreshed.append("self_audit")
        if "master_findings" in names:
            _v56_master_findings(pid); refreshed.append("master_findings")
        if "master_score" in names:
            _v56_master_score(pid); refreshed.append("master_score")
        if "top_priorities" in names:
            _v56_top_priorities(pid,50); refreshed.append("top_priorities")
        if "decisions" in names:
            _v56_cached("decisions",pid,lambda:_v47_decision_deadlines(pid)[:8]); refreshed.append("decisions")
        if "materials" in names:
            _v56_cached("materials",pid,lambda:[x for x in _v47_material_readiness(pid) if x[2] in {"CRITICAL","HIGH","TODAY"}][:8]); refreshed.append("materials")
        if "hold_points" in names:
            _v56_cached("hold_points",pid,lambda:[x for x in _v49_hold_points(pid) if str(x[0]["result"] or "").upper()!="PASSED"][:8]); refreshed.append("hold_points")
        if "agenda" in names:
            _v56_cached("agenda",pid,lambda:_v47_coordination_agenda(pid)[:8]); refreshed.append("agenda")
        if "revision_summary" in names:
            _v55_summary(pid); refreshed.append("revision_summary")
        _v57_mark_clean(pid,refreshed)
        return refreshed
    finally:
        _v56_perf_end(token)


def _v57_recent_events(pid,limit=50):
    cid=current_company_id()
    return [e for e in reversed(_V57_EVENTS) if e["company_id"]==cid and e["project_id"]==pid][:limit]


@app.get("/event-intelligence",response_class=HTMLResponse)
def v57_event_home():
    pid=project_id()
    dirty=_v57_dirty(pid)
    events=_v57_recent_events(pid,20)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v57 - Event-Driven Intelligence</div><h1>Update only what changed.</h1><p class="muted">{len(dirty)} intelligence area(s) currently marked for refresh · {len(events)} recent project event(s).</p></div><div class="grid3">'
    cards=[
      ("Event Command","See project changes and affected intelligence.","/event-intelligence/command"),
      ("Dirty Intelligence","See exactly what needs recalculation.","/event-intelligence/dirty"),
      ("Dependency Map","See which project changes affect which brain modules.","/event-intelligence/dependencies"),
      ("Recent Events","Audit recent intelligence-triggering project changes.","/event-intelligence/events"),
      ("Refresh Changed Intelligence","Recalculate only dirty modules.","/event-intelligence/refresh"),
      ("Performance Monitor","Measure event-driven refresh speed.","/performance"),
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Event-Driven Intelligence",body)


@app.get("/event-intelligence/command",response_class=HTMLResponse)
def v57_event_command():
    pid=project_id(); dirty=_v57_dirty(pid); events=_v57_recent_events(pid,10)
    ehtml="".join(
        f'<div class="action"><span class="badge WATCH">{esc(e["event_type"])}</span> <b>{esc(e["subject"] or "Project change")}</b>'
        f'<div class="small">{esc(e["ts"])} · refreshes {esc(", ".join(e["affected"]))}</div></div>'
        for e in events
    ) or '<p class="muted">No project change events recorded in this process yet.</p>'
    dhtml="".join(f'<span class="badge WATCH" style="margin:4px">{esc(x)}</span>' for x in dirty) or '<span class="badge READY">CLEAN</span>'
    body=f'<div class="hero"><div class="eyebrow">Event Command</div><h1>What changed, and what brain work does it require?</h1><p class="muted">Dirty intelligence: {len(dirty)} module(s).</p></div><div class="card"><h2>Needs Refresh</h2>{dhtml}</div><div class="card"><h2>Recent Events</h2>{ehtml}</div>'
    return shell("Event Command",body)


@app.get("/event-intelligence/dirty",response_class=HTMLResponse)
def v57_dirty_page():
    dirty=_v57_dirty(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">DIRTY</span> <b>{esc(x)}</b><div class="small">This module was invalidated by a relevant project change.</div></div>' for x in dirty)
    return shell("Dirty Intelligence",'<div class="hero"><h1>Dirty Intelligence</h1><p class="muted">Only these modules need recalculation.</p></div><div class="card">'+(h or '<p class="muted">All tracked intelligence is clean.</p>')+'</div>')


@app.get("/event-intelligence/dependencies",response_class=HTMLResponse)
def v57_dependencies_page():
    h=""
    for event,names in _V57_DEPENDENCIES.items():
        h+=f'<div class="action"><b>{esc(event)}</b><div class="small">{esc(", ".join(sorted(names)))}</div></div>'
    return shell("Intelligence Dependency Map",'<div class="hero"><h1>Intelligence Dependency Map</h1><p class="muted">A drawing change should not force unrelated procurement or field calculations unless they actually depend on it.</p></div><div class="card">'+h+'</div>')


@app.get("/event-intelligence/events",response_class=HTMLResponse)
def v57_events_page():
    rows=_v57_recent_events(project_id(),100)
    h="".join(f'<div class="action"><span class="badge">{esc(e["event_type"])}</span> <b>{esc(e["subject"] or "Project change")}</b><div class="small">{esc(e["ts"])} · source {esc(e["source"])} · affected {esc(", ".join(e["affected"]))}</div></div>' for e in rows)
    return shell("Recent Intelligence Events",'<div class="hero"><h1>Recent Intelligence Events</h1><p class="muted">Transparent audit trail for cache invalidation and targeted refresh.</p></div><div class="card">'+(h or '<p class="muted">No events recorded yet.</p>')+'</div>')


@app.get("/event-intelligence/refresh",response_class=HTMLResponse)
def v57_refresh_page():
    pid=project_id()
    dirty=_v57_dirty(pid)
    if not dirty:
        return shell("Refresh Changed Intelligence",'<div class="hero"><h1>Nothing needs refreshing.</h1><p class="muted">Tracked intelligence is currently clean.</p></div>')
    h="".join(f'<li>{esc(x)}</li>' for x in dirty)
    return shell("Refresh Changed Intelligence",f'<div class="hero"><h1>Refresh only changed intelligence</h1><p class="muted">{len(dirty)} module(s) are dirty.</p></div><div class="card"><ul>{h}</ul><form method="post" action="/event-intelligence/refresh"><button type="submit">Refresh Changed Intelligence</button></form></div>')


@app.post("/event-intelligence/refresh")
def v57_refresh_post():
    _v57_refresh(project_id())
    return RedirectResponse("/event-intelligence/command",status_code=303)


@app.post("/event-intelligence/test-event")
def v57_test_event(event_type:str=Form("PROJECT_CHANGE"),subject:str=Form("Manual project update")):
    _v57_emit(project_id(),event_type,subject,"MANUAL")
    return RedirectResponse("/event-intelligence/command",status_code=303)


def _v58_days_until(value):
    if not value: return None
    try:
        d=datetime.fromisoformat(str(value)[:10]).date()
        return (d-date.today()).days
    except Exception:
        return None


def _v58_proactive_findings(pid):
    findings=[]

    # Start with master reasoning priorities.
    try:
        for f in _v56_top_priorities(pid,30):
            findings.append({
                "severity":f["severity"],"category":f["type"],"title":f["title"],
                "why":f["reason"],"action":f["action"],"source":"MASTER REASONING"
            })
    except Exception:
        pass

    # Upcoming activities and readiness.
    try:
        for x in _v56_sequence(pid):
            a=x["activity"]
            days=_v58_days_until(a["start"])
            if days is None or days < 0 or days > 14: continue
            if x["risk"] in {"CRITICAL","HIGH","MEDIUM"}:
                findings.append({
                    "severity":x["risk"],"category":"UPCOMING WORK",
                    "title":f'{a["name"]} starts in {days} day(s)',
                    "why":x["blocking_reason"] or "Upcoming activity has readiness/sequence exposure.",
                    "action":"Clear predecessor, readiness, material, inspection, and coordination blockers before mobilization.",
                    "source":"SEQUENCE INTELLIGENCE"
                })
    except Exception:
        pass

    # Material risk.
    try:
        for r,act,level,exposure,reason,action in _v47_material_readiness(pid):
            if level not in {"CRITICAL","HIGH","TODAY"}: continue
            findings.append({
                "severity":"CRITICAL" if level=="CRITICAL" else "HIGH",
                "category":"MATERIAL",
                "title":f'{r["item"]} threatens upcoming work',
                "why":reason,
                "action":action,
                "source":"PROCUREMENT"
            })
    except Exception:
        pass

    # Inspection hold points.
    try:
        for i,a in _v49_hold_points(pid):
            if str(i["result"] or "").upper()=="PASSED": continue
            findings.append({
                "severity":"HIGH","category":"INSPECTION",
                "title":f'{i["inspection_type"]} is an open hold point',
                "why":f'Scheduled {i["scheduled_date"] or "date not set"}; related activity {a["name"] if a else "not linked"}.',
                "action":"Confirm prerequisite work is complete and inspection is scheduled/passed before covering or proceeding.",
                "source":"INSPECTIONS"
            })
    except Exception:
        pass

    # Decisions / RFIs / submittals.
    try:
        for typ,title,due,severity,cost,days,source in _v47_decision_deadlines(pid)[:30]:
            findings.append({
                "severity":severity,"category":"DECISION",
                "title":title,
                "why":f'{typ} due {due}; ${cost:,.0f} known exposure; {days:g} schedule day(s) exposure.',
                "action":"Drive the responsible party to resolution before downstream work is affected.",
                "source":source or typ
            })
    except Exception:
        pass

    # Deduplicate and rank.
    rank={"CRITICAL":0,"HIGH":1,"MEDIUM":2,"REVIEW":3,"LOW":4}
    seen=set(); clean=[]
    for f in findings:
        k=(str(f["category"]).lower(),str(f["title"]).lower())
        if k in seen: continue
        seen.add(k); clean.append(f)
    clean.sort(key=lambda x:rank.get(x["severity"],3))
    return clean[:100]


def _v58_now_today_week(pid):
    rows=_v58_proactive_findings(pid)
    now=[]; today=[]; week=[]; upcoming=[]
    for f in rows:
        sev=f["severity"]
        if sev=="CRITICAL":
            now.append(f)
        elif sev=="HIGH":
            today.append(f)
        elif sev=="MEDIUM":
            week.append(f)
        else:
            upcoming.append(f)
    return now[:12],today[:15],week[:15],upcoming[:15]


def _v58_trade_alerts(pid):
    rows=_v58_proactive_findings(pid)
    alerts={}
    known_trades=[str(x["trade"] or "") for x in _v39_rows("SELECT DISTINCT trade FROM activities WHERE project_id=?",(pid,)) if x["trade"]]
    for f in rows:
        blob=(f["title"]+" "+f["why"]+" "+f["action"]).lower()
        for tr in known_trades:
            if tr.lower() in blob:
                alerts.setdefault(tr,[]).append(f)
    return alerts


def _v58_super_brief(pid):
    now,today,week,upcoming=_v58_now_today_week(pid)
    return {
        "now":now,"today":today,"week":week,"upcoming":upcoming,
        "total":len(now)+len(today)+len(week)+len(upcoming)
    }


@app.get("/proactive-superintendent",response_class=HTMLResponse)
def v58_home():
    pid=project_id(); b=_v58_super_brief(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v58 - Proactive Superintendent AI</div><h1>BuildCommand should tell you before you have to ask.</h1><p class="muted">{len(b["now"])} do-now · {len(b["today"])} today · {len(b["week"])} this-week · {len(b["upcoming"])} upcoming intelligence item(s).</p></div><div class="grid3">'
    cards=[
      ("Superintendent Command","Prioritized proactive construction intelligence.","/proactive-superintendent/command"),
      ("Do Now","Critical items needing immediate attention.","/proactive-superintendent/now"),
      ("Today","High-priority actions for today.","/proactive-superintendent/today"),
      ("This Week","Medium-term coordination and readiness actions.","/proactive-superintendent/week"),
      ("Upcoming Risk","Watch items before they become field problems.","/proactive-superintendent/upcoming"),
      ("Trade Alerts","Group proactive intelligence by affected trade.","/proactive-superintendent/trades"),
      ("Inspection Readiness","Surface open hold points before work gets covered.","/proactive-superintendent/inspections"),
      ("Material Alerts","Catch procurement exposure before installation dates.","/proactive-superintendent/materials"),
      ("Decision Alerts","Push RFIs/submittals/decisions before downstream impact.","/proactive-superintendent/decisions"),
      ("Event Intelligence","See what project changes triggered intelligence refresh.","/event-intelligence","Open"),
    ]
    for n,d,h in cards: body+=_v37_link_card(n,d,h,"Open")
    body+='</div>'
    return shell("Proactive Superintendent AI",body)


def _v58_render(title,subtitle,rows):
    h="".join(
        f'<div class="action bc-priority"><span class="badge WATCH">{esc(f["severity"])}</span> '
        f'<b>{esc(f["category"])} - {esc(f["title"])}</b>'
        f'<div class="small">{esc(f["why"])}</div><p><b>Recommended next action:</b> {esc(f["action"])}</p>'
        f'<div class="small">Source: {esc(f["source"])}</div></div>'
        for f in rows
    ) or '<p class="muted">No items in this priority group.</p>'
    return shell(title,f'<div class="hero"><h1>{esc(title)}</h1><p class="muted">{esc(subtitle)}</p></div><div class="card">{h}</div>')


@app.get("/proactive-superintendent/now",response_class=HTMLResponse)
def v58_now_page():
    return _v58_render("Do Now","Critical project conditions BuildCommand believes deserve immediate superintendent attention.",_v58_now_today_week(project_id())[0])


@app.get("/proactive-superintendent/today",response_class=HTMLResponse)
def v58_today_page():
    return _v58_render("Today","High-priority project actions to drive today.",_v58_now_today_week(project_id())[1])


@app.get("/proactive-superintendent/week",response_class=HTMLResponse)
def v58_week_page():
    return _v58_render("This Week","Coordination, readiness and decision items to clear this week.",_v58_now_today_week(project_id())[2])


@app.get("/proactive-superintendent/upcoming",response_class=HTMLResponse)
def v58_upcoming_page():
    return _v58_render("Upcoming Risk","Watch these conditions before they become field blockers.",_v58_now_today_week(project_id())[3])


@app.get("/proactive-superintendent/inspections",response_class=HTMLResponse)
def v58_inspections_page():
    rows=[f for f in _v58_proactive_findings(project_id()) if f["category"]=="INSPECTION"]
    return _v58_render("Inspection Readiness","Open hold points that can stop covering, startup, energization or downstream work.",rows)


@app.get("/proactive-superintendent/materials",response_class=HTMLResponse)
def v58_materials_page():
    rows=[f for f in _v58_proactive_findings(project_id()) if f["category"]=="MATERIAL"]
    return _v58_render("Material Alerts","Procurement conditions that threaten upcoming installation work.",rows)


@app.get("/proactive-superintendent/decisions",response_class=HTMLResponse)
def v58_decisions_page():
    rows=[f for f in _v58_proactive_findings(project_id()) if f["category"]=="DECISION"]
    return _v58_render("Decision Alerts","RFIs, submittals and project decisions that need to move before downstream impact.",rows)


@app.get("/proactive-superintendent/trades",response_class=HTMLResponse)
def v58_trades_page():
    alerts=_v58_trade_alerts(project_id())
    h=""
    for tr,rows in alerts.items():
        h+=f'<div class="card"><h2>{esc(tr)}</h2>'
        h+="".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["title"])}</b><div class="small">{esc(f["action"])}</div></div>' for f in rows[:10])
        h+='</div>'
    return shell("Trade Alerts",'<div class="hero"><h1>Trade Alerts</h1><p class="muted">Proactive project intelligence grouped by affected trade.</p></div>'+(h or '<div class="card"><p class="muted">No trade-specific alerts detected.</p></div>'))


@app.get("/proactive-superintendent/command",response_class=HTMLResponse)
def v58_command():
    pid=project_id(); b=_v58_super_brief(pid)
    def compact(rows):
        return "".join(f'<div class="action"><span class="badge WATCH">{esc(f["severity"])}</span> <b>{esc(f["title"])}</b><div class="small">{esc(f["action"])}</div></div>' for f in rows[:8]) or '<p class="muted">Clear.</p>'
    body=f'<div class="hero"><div class="eyebrow">SUPERINTENDENT COMMAND</div><h1>What should I deal with next?</h1><p class="muted">{b["total"]} proactive intelligence item(s) prioritized from project controls and construction reasoning.</p></div>'
    body+='<div class="grid2"><div class="card"><h2>DO NOW</h2>'+compact(b["now"])+'</div><div class="card"><h2>DO TODAY</h2>'+compact(b["today"])+'</div></div>'
    body+='<div class="grid2"><div class="card"><h2>THIS WEEK</h2>'+compact(b["week"])+'</div><div class="card"><h2>UPCOMING RISK</h2>'+compact(b["upcoming"])+'</div></div>'
    return shell("Superintendent Command",body)


def _v59_lookahead(pid,weeks=3):
    horizon=date.today()+timedelta(days=weeks*7)
    rows=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,))
    out=[]
    seq={int(x["activity"]["id"]):x for x in _v56_sequence(pid)}
    for a in rows:
        try: sd=datetime.fromisoformat(str(a["start"])[:10]).date()
        except Exception: continue
        if not (date.today()<=sd<=horizon): continue
        x=seq.get(int(a["id"]),{})
        risk=x.get("risk","LOW")
        state="READY" if risk=="LOW" else ("NOT READY" if risk in {"CRITICAL","HIGH"} else "AT RISK")
        out.append((a,state,risk,x.get("blocking_reason","")))
    return out


def _v60_trade_readiness(pid):
    out=[]
    for a,state,risk,reason in _v59_lookahead(pid,6):
        checks=[]
        checks.append(("Sequence",state=="READY",reason or "Sequence clear"))
        try:
            proc=[x for x in _v47_material_readiness(pid) if x[1] and int(x[1]["id"])==int(a["id"])]
            checks.append(("Materials",not any(x[2] in {"CRITICAL","HIGH","TODAY"} for x in proc),"Material readiness"))
        except Exception: pass
        try:
            holds=[x for x in _v49_hold_points(pid) if x[1] and int(x[1]["id"])==int(a["id"]) and str(x[0]["result"] or "").upper()!="PASSED"]
            checks.append(("Inspections",not holds,"Inspection hold points"))
        except Exception: pass
        failed=[c[0] for c in checks if not c[1]]
        readiness="READY" if not failed else ("NOT READY" if len(failed)>1 else "AT RISK")
        out.append((a,readiness,failed,checks))
    return out


def _v61_handoffs(pid):
    rows=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,))
    out=[]
    for i in range(len(rows)-1):
        a,b=rows[i],rows[i+1]
        if str(a["trade"] or "")!=str(b["trade"] or ""):
            out.append((a,b,"Verify predecessor completion, inspection, access, layout and turnover before successor mobilizes."))
    return out[:100]


def _v62_daily_brief(pid):
    b=_v58_super_brief(pid)
    today=str(date.today())
    acts=_v39_rows("SELECT * FROM activities WHERE project_id=? AND start<=? AND finish>=? ORDER BY start",(pid,today,today))
    try: inspections=[x for x in _v49_hold_points(pid) if str(x[0]["scheduled_date"] or "")[:10]==today]
    except Exception: inspections=[]
    try: mats=[x for x in _v47_material_readiness(pid) if str(x[0]["promised_date"] or "")[:10]==today]
    except Exception: mats=[]
    return {"priorities":b,"activities":acts,"inspections":inspections,"materials":mats}


def _v63_rfi_candidates(pid):
    candidates=[]
    try:
        for f in _v50_collect_findings(pid):
            blob=(str(f["type"])+" "+str(f["title"])+" "+str(f["reason"])).lower()
            if any(k in blob for k in ["conflict","contradiction","missing","unclear","coordination","constructability"]):
                candidates.append({
                    "severity":f["severity"],"title":f["title"],"reason":f["reason"],
                    "question":f'Please clarify the contract requirement regarding: {f["title"]}.',
                    "action":f["action"],"source":f.get("source","")
                })
    except Exception: pass
    return candidates[:100]


def _v64_longlead(pid):
    rows=_v39_rows("SELECT * FROM procurement WHERE project_id=? ORDER BY required_on_site",(pid,))
    out=[]
    for r in rows:
        try:
            need=datetime.fromisoformat(str(r["required_on_site"])[:10]).date()
            promised=datetime.fromisoformat(str(r["promised_date"])[:10]).date() if r["promised_date"] else None
        except Exception: continue
        exposure=(promised-need).days if promised else None
        level="HIGH" if exposure is None or exposure>0 else ("MEDIUM" if exposure==0 else "LOW")
        release_by=need-timedelta(days=42)
        out.append((r,level,release_by,exposure))
    return out


def _v65_qc_points(pid):
    rows=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,))
    rules=[
      ("concrete","Pre-pour: reinforcing, embeds, forms, elevations, underground signoff and required inspection/testing."),
      ("drywall","Before close-in: framing, above-wall MEP rough, fire/smoke assemblies, backing and inspections."),
      ("ceiling","Before ceiling close: above-ceiling MEP, fire sprinkler, controls, inspections and access coordination."),
      ("roof","Before concealment: substrate, flashing, penetrations, curbs and manufacturer-required conditions."),
      ("electrical","Verify rough inspection, labeling, terminations, testing and energization prerequisites."),
      ("plumbing","Verify pressure/testing, supports, slopes, cleanouts, insulation and inspection prerequisites."),
    ]
    out=[]
    for a in rows:
        blob=(str(a["name"])+" "+str(a["trade"] or "")).lower()
        for key,check in rules:
            if key in blob: out.append((a,key.upper(),check))
    return out[:200]


def _v66_scope_gaps(pid):
    scopes=_v452_scope_rows(pid)
    gaps=[]; seen={}
    for r in scopes:
        req=re.sub(r'\s+',' ',str(r["requirement"] or "").lower()).strip()
        if not str(r["trade"] or "").strip():
            gaps.append(("UNOWNED",r,"No trade owner assigned."))
        if req:
            if req in seen and str(seen[req]["trade"])!=str(r["trade"]):
                gaps.append(("DUPLICATE",r,f'Also assigned to {seen[req]["trade"]}.'))
            else: seen[req]=r
        if any(k in str(r["trade"] or "").lower() for k in ["general","other","unknown","tbd"]):
            gaps.append(("AMBIGUOUS",r,"Trade ownership should be confirmed before buyout."))
    return gaps[:200]


def _v67_change_intelligence(pid):
    s=_v55_summary(pid)
    return {
      "added":s["added"],"removed":s["removed"],"changed":s["changed"],
      "known_net":s["added_cost"]-s["removed_cost"],"schedule_proxy":s["days"],
      "affected_trades":s["trades"],"downstream":s["links"]
    }


def _v68_autopilot(pid):
    proactive=_v58_super_brief(pid)
    readiness=_v60_trade_readiness(pid)
    not_ready=[x for x in readiness if x[1]=="NOT READY"]
    at_risk=[x for x in readiness if x[1]=="AT RISK"]
    changes=_v67_change_intelligence(pid)
    return {
      "now":proactive["now"],"today":proactive["today"],"week":proactive["week"],
      "upcoming":proactive["upcoming"],"not_ready":not_ready,"at_risk":at_risk,
      "cost":changes["known_net"],"schedule":changes["schedule_proxy"]
    }


@app.get("/lookahead-intelligence",response_class=HTMLResponse)
def v59_home():
    pid=project_id()
    body='<div class="hero"><div class="eyebrow">v59 Look-Ahead Planning Intelligence</div><h1>Is upcoming work actually ready?</h1><p class="muted">2-, 3-, and 6-week schedule windows connected to construction readiness.</p></div><div class="grid3">'
    for weeks in (2,3,6):
        rows=_v59_lookahead(pid,weeks)
        bad=sum(1 for x in rows if x[1]!="READY")
        body+=_v37_link_card(f"{weeks}-Week Look-Ahead",f"{len(rows)} activity(s) · {bad} at risk/not ready.",f"/lookahead-intelligence/{weeks}","Open")
    body+='</div>'
    return shell("Look-Ahead Intelligence",body)


@app.get("/lookahead-intelligence/{weeks}",response_class=HTMLResponse)
def v59_window(weeks:int):
    weeks=max(1,min(weeks,12)); rows=_v59_lookahead(project_id(),weeks)
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(state)}</span> <b>{esc(a["name"])}</b><div class="small">{esc(a["trade"])} · {esc(a["start"])} → {esc(a["finish"])} · {esc(reason)}</div></div>' for a,state,risk,reason in rows)
    return shell(f"{weeks}-Week Look-Ahead",f'<div class="hero"><h1>{weeks}-Week Look-Ahead</h1></div><div class="card">{h or "<p class=muted>No activities in this window.</p>"}</div>')


@app.get("/trade-readiness",response_class=HTMLResponse)
def v60_home():
    rows=_v60_trade_readiness(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(state)}</span> <b>{esc(a["trade"])} - {esc(a["name"])}</b><div class="small">Failed checks: {esc(", ".join(failed) if failed else "None")}</div></div>' for a,state,failed,checks in rows)
    return shell("Trade Readiness Brain",'<div class="hero"><div class="eyebrow">v60</div><h1>Trade Readiness Brain</h1><p class="muted">READY / AT RISK / NOT READY before mobilization.</p></div><div class="card">'+(h or '<p class="muted">No upcoming activities.</p>')+'</div>')


@app.get("/trade-coordination",response_class=HTMLResponse)
def v61_home():
    rows=_v61_handoffs(project_id())
    h="".join(f'<div class="action"><span class="badge">HANDOFF</span> <b>{esc(a["trade"])} → {esc(b["trade"])}</b><div>{esc(a["name"])} → {esc(b["name"])}</div><div class="small">{esc(note)}</div></div>' for a,b,note in rows)
    return shell("Trade Coordination Engine",'<div class="hero"><div class="eyebrow">v61</div><h1>Automatic Trade Coordination Engine</h1></div><div class="card">'+(h or '<p class="muted">No trade handoffs detected.</p>')+'</div>')


@app.get("/daily-superintendent",response_class=HTMLResponse)
def v62_home():
    d=_v62_daily_brief(project_id()); b=d["priorities"]
    def ph(rows): return "".join(f'<div class="action"><span class="badge WATCH">{esc(x["severity"])}</span> <b>{esc(x["title"])}</b><div class="small">{esc(x["action"])}</div></div>' for x in rows[:8]) or '<p class="muted">Clear.</p>'
    acts="".join(f'<div class="action"><b>{esc(a["trade"])} - {esc(a["name"])}</b></div>' for a in d["activities"]) or '<p class="muted">No scheduled activities today.</p>'
    body='<div class="hero"><div class="eyebrow">v62 Daily Superintendent Command AI</div><h1>Today’s superintendent briefing.</h1></div><div class="grid2"><div class="card"><h2>DO NOW</h2>'+ph(b["now"])+'</div><div class="card"><h2>TODAY</h2>'+ph(b["today"])+'</div></div><div class="card"><h2>Scheduled Work Today</h2>'+acts+'</div>'
    return shell("Daily Superintendent Command",body)


@app.get("/smart-rfi",response_class=HTMLResponse)
def v63_home():
    rows=_v63_rfi_candidates(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["severity"])}</span> <b>{esc(r["title"])}</b><div>{esc(r["question"])}</div><div class="small">Why: {esc(r["reason"])} · Suggested action: {esc(r["action"])}</div></div>' for r in rows)
    return shell("Smart RFI Generator",'<div class="hero"><div class="eyebrow">v63</div><h1>Smart RFI Generator & Conflict Detection</h1><p class="muted">Draft candidates only. Human approval remains required before sending.</p></div><div class="card">'+(h or '<p class="muted">No RFI candidates detected.</p>')+'</div>')


@app.get("/longlead-intelligence",response_class=HTMLResponse)
def v64_home():
    rows=_v64_longlead(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(r["item"])}</b><div class="small">Required {esc(r["required_on_site"])} · target release by {release_by} · promised {esc(r["promised_date"] or "not set")} · exposure {esc(exposure if exposure is not None else "unknown")} day(s)</div></div>' for r,level,release_by,exposure in rows)
    return shell("Long-Lead Prediction",'<div class="hero"><div class="eyebrow">v64</div><h1>Procurement & Long-Lead Prediction Brain</h1></div><div class="card">'+(h or '<p class="muted">No procurement records.</p>')+'</div>')


@app.get("/quality-intelligence",response_class=HTMLResponse)
def v65_home():
    rows=_v65_qc_points(project_id())
    h="".join(f'<div class="action"><span class="badge">QC</span> <b>{esc(a["name"])}</b><div class="small">{esc(kind)} · {esc(check)}</div></div>' for a,kind,check in rows)
    return shell("Inspection & QC Intelligence",'<div class="hero"><div class="eyebrow">v65</div><h1>Inspection & Quality Control Intelligence</h1></div><div class="card">'+(h or '<p class="muted">No QC checkpoints generated.</p>')+'</div>')


@app.get("/scope-gap-intelligence",response_class=HTMLResponse)
def v66_home():
    rows=_v66_scope_gaps(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(r["trade"] or "UNASSIGNED")}</b> - {esc(r["requirement"])}<div class="small">{esc(reason)}</div></div>' for kind,r,reason in rows)
    return shell("Scope Gap & Buyout Intelligence",'<div class="hero"><div class="eyebrow">v66</div><h1>Scope Gap & Buyout Intelligence</h1><p class="muted">Find unowned, duplicate and ambiguous scope before buyout.</p></div><div class="card">'+(h or '<p class="muted">No obvious scope gaps detected.</p>')+'</div>')


@app.get("/change-order-intelligence",response_class=HTMLResponse)
def v67_home():
    s=_v67_change_intelligence(project_id())
    body=f'<div class="hero"><div class="eyebrow">v67</div><h1>Change Order Intelligence</h1><p class="muted">{len(s["added"])} added · {len(s["removed"])} removed · {len(s["changed"])} changed · ${s["known_net"]:,.0f} known estimator-linked net exposure · {s["schedule_proxy"]:.1f} schedule review-day proxy.</p></div><div class="card"><p>BuildCommand does not invent entitlement or unpriced costs. Human contract review remains required.</p></div>'
    return shell("Change Order Intelligence",body)


@app.get("/autopilot",response_class=HTMLResponse)
def v68_home():
    a=_v68_autopilot(project_id())
    def ph(rows): return "".join(f'<div class="action"><span class="badge WATCH">{esc(x["severity"])}</span> <b>{esc(x["title"])}</b><div class="small">{esc(x["action"])}</div></div>' for x in rows[:8]) or '<p class="muted">Clear.</p>'
    nr="".join(f'<div class="action"><span class="badge WATCH">{esc(state)}</span> <b>{esc(act["trade"])} - {esc(act["name"])}</b><div class="small">{esc(", ".join(failed))}</div></div>' for act,state,failed,checks in a["not_ready"][:10]) or '<p class="muted">No not-ready trades.</p>'
    body=f'<div class="hero"><div class="eyebrow">v68 PROJECT AUTOPILOT</div><h1>One command center for what the project needs next.</h1><p class="muted">Known change exposure ${a["cost"]:,.0f} · schedule review proxy {a["schedule"]:.1f} day(s).</p></div>'
    body+='<div class="grid2"><div class="card"><h2>DO NOW</h2>'+ph(a["now"])+'</div><div class="card"><h2>DO TODAY</h2>'+ph(a["today"])+'</div></div>'
    body+='<div class="grid2"><div class="card"><h2>THIS WEEK</h2>'+ph(a["week"])+'</div><div class="card"><h2>NOT READY</h2>'+nr+'</div></div>'
    body+='<div class="grid3">'+_v37_link_card("Look-Ahead","2/3/6-week readiness.","/lookahead-intelligence","Open")+_v37_link_card("Trade Readiness","Mobilization readiness.","/trade-readiness","Open")+_v37_link_card("Smart RFI","Conflict-driven RFI candidates.","/smart-rfi","Open")+'</div>'
    return shell("Project Autopilot",body)


_V168_FEATURES=[(69, 'Sheet Classification Brain', 'DRAWING'), (70, 'Drawing Discipline Detection', 'DRAWING'), (71, 'Sheet Number Intelligence', 'DRAWING'), (72, 'Drawing Index Reconciliation', 'DRAWING'), (73, 'Detail Bubble Recognition', 'DRAWING'), (74, 'Detail-to-Sheet Linking', 'DRAWING'), (75, 'Section Callout Intelligence', 'DRAWING'), (76, 'Elevation Callout Intelligence', 'DRAWING'), (77, 'Keynote Recognition', 'DRAWING'), (78, 'Keynote-to-Legend Linking', 'DRAWING'), (79, 'General Notes Intelligence', 'DRAWING'), (80, 'Plan Note Intelligence', 'DRAWING'), (81, 'Drawing Legend Brain', 'DRAWING'), (82, 'Symbol Recognition Intelligence', 'DRAWING'), (83, 'Abbreviation Intelligence', 'DRAWING'), (84, 'Drawing Scale Intelligence', 'DRAWING'), (85, 'Dimension Relationship Brain', 'DRAWING'), (86, 'Grid-Line Intelligence', 'DRAWING'), (87, 'Room/Area Recognition', 'DRAWING'), (88, 'Drawing Cross-Reference Brain', 'DRAWING'), (89, 'Door Schedule Brain', 'SCHEDULE_SPEC'), (90, 'Hardware Schedule Brain', 'SCHEDULE_SPEC'), (91, 'Finish Schedule Brain', 'SCHEDULE_SPEC'), (92, 'Room Finish Intelligence', 'SCHEDULE_SPEC'), (93, 'Equipment Schedule Brain', 'SCHEDULE_SPEC'), (94, 'Plumbing Fixture Schedule Brain', 'SCHEDULE_SPEC'), (95, 'Mechanical Equipment Schedule Brain', 'SCHEDULE_SPEC'), (96, 'Electrical Panel Schedule Brain', 'SCHEDULE_SPEC'), (97, 'Lighting Fixture Schedule Brain', 'SCHEDULE_SPEC'), (98, 'Structural Schedule Intelligence', 'SCHEDULE_SPEC'), (99, 'Specification Division Recognition', 'SCHEDULE_SPEC'), (100, 'Spec Section Classification', 'SCHEDULE_SPEC'), (101, 'Drawing-to-Spec Linking', 'SCHEDULE_SPEC'), (102, 'Product Requirement Extraction', 'SCHEDULE_SPEC'), (103, 'Manufacturer Requirement Extraction', 'SCHEDULE_SPEC'), (104, 'Testing Requirement Extraction', 'SCHEDULE_SPEC'), (105, 'Warranty Requirement Extraction', 'SCHEDULE_SPEC'), (106, 'Submittal Requirement Extraction', 'SCHEDULE_SPEC'), (107, 'Closeout Requirement Extraction', 'SCHEDULE_SPEC'), (108, 'Specification Conflict Detection', 'SCHEDULE_SPEC'), (109, 'Wall Assembly Intelligence', 'ASSEMBLY'), (110, 'Rated Wall Intelligence', 'ASSEMBLY'), (111, 'Shaft-Wall Intelligence', 'ASSEMBLY'), (112, 'Ceiling Assembly Intelligence', 'ASSEMBLY'), (113, 'Floor Assembly Intelligence', 'ASSEMBLY'), (114, 'Roof Assembly Intelligence', 'ASSEMBLY'), (115, 'Waterproofing Assembly Brain', 'ASSEMBLY'), (116, 'Exterior Wall Assembly Brain', 'ASSEMBLY'), (117, 'Storefront Assembly Intelligence', 'ASSEMBLY'), (118, 'Door/Frame Assembly Intelligence', 'ASSEMBLY'), (119, 'Foundation Assembly Intelligence', 'ASSEMBLY'), (120, 'Slab Assembly Intelligence', 'ASSEMBLY'), (121, 'Structural Steel Assembly Brain', 'ASSEMBLY'), (122, 'CMU Assembly Intelligence', 'ASSEMBLY'), (123, 'Concrete Assembly Intelligence', 'ASSEMBLY'), (124, 'Underground Utility Assembly Brain', 'ASSEMBLY'), (125, 'Plumbing System Assembly Brain', 'ASSEMBLY'), (126, 'HVAC System Assembly Brain', 'ASSEMBLY'), (127, 'Electrical System Assembly Brain', 'ASSEMBLY'), (128, 'Fire Protection Assembly Brain', 'ASSEMBLY'), (129, 'Architectural/Structural Coordination', 'COORDINATION'), (130, 'Architectural/Mechanical Coordination', 'COORDINATION'), (131, 'Architectural/Electrical Coordination', 'COORDINATION'), (132, 'Architectural/Plumbing Coordination', 'COORDINATION'), (133, 'Structural/MEP Coordination', 'COORDINATION'), (134, 'HVAC/Electrical Coordination', 'COORDINATION'), (135, 'HVAC/Plumbing Coordination', 'COORDINATION'), (136, 'Electrical/Plumbing Coordination', 'COORDINATION'), (137, 'Fire Sprinkler/Ceiling Coordination', 'COORDINATION'), (138, 'Lighting/Ceiling Coordination', 'COORDINATION'), (139, 'Access Panel Coordination', 'COORDINATION'), (140, 'Equipment Clearance Intelligence', 'COORDINATION'), (141, 'ADA Clearance Intelligence', 'COORDINATION'), (142, 'Maintenance Clearance Intelligence', 'COORDINATION'), (143, 'Penetration Coordination Brain', 'COORDINATION'), (144, 'Sleeve Coordination Intelligence', 'COORDINATION'), (145, 'Embed Coordination Intelligence', 'COORDINATION'), (146, 'Opening Coordination Intelligence', 'COORDINATION'), (147, 'Above-Ceiling Coordination Brain', 'COORDINATION'), (148, 'Underground Coordination Brain', 'COORDINATION'), (149, 'Constructability Intelligence', 'REASONING'), (150, 'Missing Information Detection', 'REASONING'), (151, 'Contradiction Intelligence', 'REASONING'), (152, 'Ambiguous Requirement Detection', 'REASONING'), (153, 'Impossible Condition Detection', 'REASONING'), (154, 'Incomplete Detail Detection', 'REASONING'), (155, 'Scope Ownership Brain 2.0', 'REASONING'), (156, 'Trade Boundary Intelligence', 'REASONING'), (157, 'Demolition Ownership Intelligence', 'REASONING'), (158, 'Temporary Work Intelligence', 'REASONING'), (159, 'Inspection Requirement Brain', 'REASONING'), (160, 'Testing Requirement Brain', 'REASONING'), (161, 'Permit Requirement Intelligence', 'REASONING'), (162, 'Sequence Requirement Brain', 'REASONING'), (163, 'Prerequisite Intelligence', 'REASONING'), (164, 'Means-and-Methods Awareness', 'REASONING'), (165, 'Confidence Calibration Brain', 'REASONING'), (166, 'Human Correction Learning 2.0', 'REASONING'), (167, 'Cross-Project Construction Memory', 'REASONING'), (168, 'Unified Construction Knowledge Brain 2.0', 'UNIFIED')]


def _v168_rows(pid):
    try: return _v452_scope_rows(pid)
    except Exception: return []


def _v168_text(pid):
    rows=_v168_rows(pid)
    return "\n".join(
        " ".join(str(x or "") for x in [r["trade"],r["requirement"],r["source_sheet"],r["source_spec"]])
        for r in rows
    ).lower()


def _v168_metrics(pid):
    rows=_v168_rows(pid); text=_v168_text(pid)
    patterns={
      "DRAWING":["sheet ","detail","section","elevation","keynote","legend","scale","grid","room"],
      "SCHEDULE_SPEC":["schedule","spec","manufacturer","testing","warranty","submittal","closeout"],
      "ASSEMBLY":["wall","ceiling","floor","roof","waterproof","storefront","foundation","slab","steel","cmu","concrete","plumbing","hvac","electrical","sprinkler"],
      "COORDINATION":["coordinate","clearance","penetration","sleeve","embed","opening","above ceiling","underground"],
      "REASONING":["conflict","missing","verify","confirm","inspection","testing","permit","sequence","prerequisite","demolition"]
    }
    counts={k:sum(text.count(p) for p in ps) for k,ps in patterns.items()}
    return {"scope_rows":len(rows),"signals":counts}


def _v168_feature_status(pid,feature):
    v,name,group=feature
    m=_v168_metrics(pid); n=m["scope_rows"]; sig=m["signals"].get(group,0)
    if group=="UNIFIED":
        active=sum(1 for x in m["signals"].values() if x>0)
        return "ACTIVE" if n and active>=3 else "LEARNING"
    return "ACTIVE" if n and sig>0 else ("LEARNING" if n else "WAITING FOR PROJECT DATA")


def _v168_ownership_rules():
    return [
      ("Concrete","slab cutting, trenching and restoration","Concrete"),
      ("Bathroom Accessories","grab bars, toilet partitions, urinal screens, toilet room accessories","Bathroom Accessories"),
      ("Demolition","existing fixture/equipment removal and demolition work","Demolition"),
      ("Low Voltage","accessible door operators, card access, cameras and electronic access","Low Voltage"),
      ("Flooring/Tile","flooring, tile, rubber base and tile backsplash","Flooring/Tile"),
      ("Storefront/Glazing","exterior storefront and glazing systems","Storefront/Glazing"),
      ("HVAC","mechanical/HVAC equipment and duct systems","HVAC"),
      ("Roofing","roof patching, flashing and roofing restoration","Roofing"),
      ("Paint","prime/refinish patched surfaces and finish painting","Paint"),
      ("Doors","interior doors, frames, hardware and hollow-metal framed interior windows","Doors"),
    ]


def _v168_reasoning_signals(pid):
    rows=_v168_rows(pid); out=[]
    seen={}
    for r in rows:
        req=str(r["requirement"] or "")
        low=req.lower(); trade=str(r["trade"] or "")
        if not req.strip():
            out.append(("MISSING","HIGH",trade,"Empty scope requirement","Review source document and regenerate requirement."))
        if any(k in low for k in ["verify","confirm","coordinate","as required","if required"]):
            out.append(("AMBIGUOUS","MEDIUM",trade,req,"Confirm contract requirement, responsible trade, and prerequisite before execution."))
        if any(k in low for k in ["inspection","test","testing"]):
            out.append(("QC","REVIEW",trade,req,"Link requirement to inspection/testing readiness and schedule hold point."))
        key=re.sub(r'\s+',' ',low).strip()
        if key:
            if key in seen and str(seen[key]["trade"])!=trade:
                out.append(("TRADE BOUNDARY","HIGH",trade,req,f'Requirement also appears under {seen[key]["trade"]}; resolve ownership.'))
            else: seen[key]=r
    return out[:300]


def _v168_assembly_links(pid):
    rows=_v168_rows(pid); out=[]
    maps=[
      ("WALL",["wall","partition","gypsum","stud"]),
      ("CEILING",["ceiling","grid","acoustical"]),
      ("ROOF",["roof","flashing","curb"]),
      ("CONCRETE",["concrete","slab","footing","foundation"]),
      ("PLUMBING",["plumbing","water closet","lavatory","drain","water heater"]),
      ("HVAC",["hvac","mechanical","duct","exhaust fan","rtu"]),
      ("ELECTRICAL",["electrical","panel","lighting","receptacle","power"]),
      ("FIRE PROTECTION",["sprinkler","fire protection"]),
    ]
    for r in rows:
        low=str(r["requirement"] or "").lower()
        linked=[name for name,keys in maps if any(k in low for k in keys)]
        if linked: out.append((r,linked))
    return out[:300]


def _v168_knowledge_summary(pid):
    m=_v168_metrics(pid)
    active=sum(1 for f in _V168_FEATURES if _v168_feature_status(pid,f)=="ACTIVE")
    reasoning=_v168_reasoning_signals(pid)
    assemblies=_v168_assembly_links(pid)
    return {"metrics":m,"active":active,"reasoning":reasoning,"assemblies":assemblies}


@app.get("/knowledge-brain-2",response_class=HTMLResponse)
def v168_home():
    pid=project_id(); s=_v168_knowledge_summary(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v168</div><h1>Unified Construction Knowledge Brain 2.0</h1><p class="muted">{s["active"]} / 100 capabilities active against current project intelligence · {s["metrics"]["scope_rows"]} scope knowledge row(s).</p></div><div class="grid3">'
    cards=[
      ("100-Capability Map","See all v69-v168 construction knowledge capabilities.","/knowledge-brain-2/capabilities"),
      ("Drawing Intelligence","Sheet, detail, note, symbol and cross-reference understanding.","/knowledge-brain-2/group/DRAWING"),
      ("Schedule & Spec Intelligence","Schedules, specifications, products, testing and closeout.","/knowledge-brain-2/group/SCHEDULE_SPEC"),
      ("Assembly Brain","Construction systems and assembly relationships.","/knowledge-brain-2/assemblies"),
      ("Cross-Trade Coordination","Interfaces, penetrations, clearances and handoffs.","/knowledge-brain-2/group/COORDINATION"),
      ("Construction Reasoning","Missing, ambiguous, conflicting and ownership conditions.","/knowledge-brain-2/reasoning"),
      ("Scope Ownership 2.0","Approved construction trade-boundary knowledge.","/knowledge-brain-2/ownership"),
      ("Blueprint Brain","Use the existing blueprint analysis engine.","/blueprint-brain"),
      ("Project Autopilot","Feed construction knowledge into operations.","/autopilot"),
    ]
    for n,d,h in cards: body+=_v37_link_card(n,d,h,"Open")
    body+='</div>'
    return shell("Knowledge Brain 2.0",body)


@app.get("/knowledge-brain-2/capabilities",response_class=HTMLResponse)
def v168_capabilities():
    pid=project_id()
    h=""
    for v,name,group in _V168_FEATURES:
        status=_v168_feature_status(pid,(v,name,group))
        h+=f'<div class="action"><span class="badge">{esc(status)}</span> <b>v{v} - {esc(name)}</b><div class="small">{esc(group.replace("_"," "))}</div></div>'
    return shell("100 Construction Knowledge Capabilities",'<div class="hero"><h1>v69-v168 Capability Map</h1><p class="muted">These capabilities share the same project knowledge instead of becoming 100 disconnected pages.</p></div><div class="card">'+h+'</div>')


@app.get("/knowledge-brain-2/group/{group}",response_class=HTMLResponse)
def v168_group(group:str):
    group=group.upper()
    rows=[f for f in _V168_FEATURES if f[2]==group]
    h="".join(f'<div class="action"><span class="badge">{esc(_v168_feature_status(project_id(),f))}</span> <b>v{f[0]} - {esc(f[1])}</b></div>' for f in rows)
    return shell("Construction Knowledge Group",f'<div class="hero"><h1>{esc(group.replace("_"," "))}</h1><p class="muted">{len(rows)} integrated capability(s).</p></div><div class="card">{h or "<p class=muted>No capabilities.</p>"}</div>')


@app.get("/knowledge-brain-2/reasoning",response_class=HTMLResponse)
def v168_reasoning():
    rows=_v168_reasoning_signals(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(sev)}</span> <b>{esc(kind)} · {esc(trade)}</b><div>{esc(req)}</div><div class="small">{esc(action)}</div></div>' for kind,sev,trade,req,action in rows)
    return shell("Construction Reasoning 2.0",'<div class="hero"><h1>Construction Reasoning & Learning</h1><p class="muted">Find ambiguous requirements, trade-boundary conflicts and quality/inspection signals.</p></div><div class="card">'+(h or '<p class="muted">No reasoning exceptions detected.</p>')+'</div>')


@app.get("/knowledge-brain-2/assemblies",response_class=HTMLResponse)
def v168_assemblies():
    rows=_v168_assembly_links(project_id())
    h="".join(f'<div class="action"><span class="badge">ASSEMBLY</span> <b>{esc(", ".join(linked))}</b><div>{esc(r["requirement"])}</div><div class="small">{esc(r["trade"])} · {esc(r["source_sheet"])}</div></div>' for r,linked in rows)
    return shell("Assembly Intelligence",'<div class="hero"><h1>Construction Assembly Brain</h1><p class="muted">Connect scope requirements to the physical systems being built.</p></div><div class="card">'+(h or '<p class="muted">No assembly links detected.</p>')+'</div>')


@app.get("/knowledge-brain-2/ownership",response_class=HTMLResponse)
def v168_ownership():
    rules=_v168_ownership_rules()
    h="".join(f'<div class="action"><span class="badge READY">RULE</span> <b>{esc(owner)}</b><div>{esc(scope)}</div><div class="small">Normalized owner: {esc(normalized)}</div></div>' for owner,scope,normalized in rules)
    return shell("Scope Ownership Brain 2.0",'<div class="hero"><h1>Scope Ownership Brain 2.0</h1><p class="muted">Construction trade-boundary rules carried into the shared knowledge brain.</p></div><div class="card">'+h+'</div>')


@app.get("/api/dashboard/command")
def v169_dashboard_command_api():
    """
    Heavy dashboard intelligence is isolated from first paint and shares v56 caches.
    """
    pid=project_id()
    token=_v56_perf_start("dashboard_lazy_api")
    try:
        d=_v56_dashboard_bundle(pid)
        score=d["score"]; top=d["top"]; decisions=d["decisions"]
        materials=d["materials"]; holds=d["holds"]; agenda=d["agenda"]; sequence=d["sequence"]

        priorities_html="".join(
            f'<div class="action bc-priority"><span class="badge WATCH">{_v37_esc(f["severity"])}</span> '
            f'<b>{_v37_esc(f["type"])}</b> - {_v37_esc(f["title"])}'
            f'<div class="small">{_v37_esc(f["reason"])}</div>'
            f'<p><b>Next:</b> {_v37_esc(f["action"])}</p></div>'
            for f in top
        ) or '<p class="muted">No major project priorities detected.</p>'

        blockers_html="".join(
            f'<div class="action"><span class="badge WATCH">{_v37_esc(x["risk"])}</span> '
            f'<b>{_v37_esc(x["activity"]["name"])}</b>'
            f'<div class="small">{_v37_esc(x["activity"]["trade"])} · {_v37_esc(x["blocking_reason"] or "Sequence risk")}</div></div>'
            for x in sequence
        ) or '<p class="muted">No high sequence blockers.</p>'

        inspections_html="".join(
            f'<div class="action"><span class="badge WATCH">{_v37_esc(i["result"])}</span> '
            f'<b>{_v37_esc(i["inspection_type"])}</b>'
            f'<div class="small">{_v37_esc(i["scheduled_date"])} · {_v37_esc(i["authority"])}'
            f' · Activity {_v37_esc(a["name"] if a else "Unlinked")}</div></div>'
            for i,a in holds
        ) or '<p class="muted">No open inspection hold points.</p>'

        materials_html="".join(
            f'<div class="action"><span class="badge WATCH">{_v37_esc(level)}</span> '
            f'<b>{_v37_esc(r["item"])}</b>'
            f'<div class="small">Need {_v37_esc(r["required_on_site"])} · Promised {_v37_esc(r["promised_date"])}'
            f' · {exposure} day(s) exposure</div></div>'
            for r,act,level,exposure,reason,action in materials
        ) or '<p class="muted">No critical/high material risks.</p>'

        decisions_html="".join(
            f'<div class="action"><span class="badge WATCH">{_v37_esc(severity)}</span> '
            f'<b>{_v37_esc(typ)} - {_v37_esc(title)}</b>'
            f'<div class="small">Due {_v37_esc(due)} · ${cost:,.0f} exposure · {days:g} schedule day(s)</div></div>'
            for typ,title,due,severity,cost,days,source in decisions
        ) or '<p class="muted">No urgent decision deadlines.</p>'

        agenda_html="".join(
            f'<div class="action"><span class="badge">{_v37_esc(kind)}</span> '
            f'<b>{_v37_esc(title)}</b><div class="small">{_v37_esc(detail)}</div></div>'
            for kind,title,detail in agenda
        ) or '<p class="muted">No current coordination agenda items.</p>'

        return JSONResponse({
            "health":score["health"],"risk":score["risk"],"quality":score["quality"],
            "priorities_html":priorities_html,"blockers_html":blockers_html,
            "inspections_html":inspections_html,"materials_html":materials_html,
            "decisions_html":decisions_html,"agenda_html":agenda_html
        })
    finally:
        _v56_perf_end(token)


_V269_CAPABILITIES=[(171, 'Customizable Dashboard', 'UI_WORKFLOW'), (172, 'Saved Dashboard Layouts', 'UI_WORKFLOW'), (173, 'Compact Navigation Mode', 'UI_WORKFLOW'), (174, 'Mobile Field Layout', 'UI_WORKFLOW'), (175, 'Quick Action Bar', 'UI_WORKFLOW'), (176, 'Global Command Search', 'UI_WORKFLOW'), (177, 'Recent Work History', 'UI_WORKFLOW'), (178, 'Favorite Tools', 'UI_WORKFLOW'), (179, 'Role-Based Home Screens', 'UI_WORKFLOW'), (180, 'Notification Center', 'UI_WORKFLOW'), (181, 'Smart Alert Prioritization', 'UI_WORKFLOW'), (182, 'Read/Unread Intelligence Alerts', 'UI_WORKFLOW'), (183, 'Project Context Header', 'UI_WORKFLOW'), (184, 'Command Breadcrumbs', 'UI_WORKFLOW'), (185, 'Side-by-Side Intelligence View', 'UI_WORKFLOW'), (186, 'Sheet + Scope Split View', 'UI_WORKFLOW'), (187, 'Full-Screen Blueprint Review Workspace', 'UI_WORKFLOW'), (188, 'Universal Filter & Sort System', 'UI_WORKFLOW'), (189, 'UI Performance Optimization 2.0', 'UI_WORKFLOW'), (190, 'Drawing Index Intelligence 2.0', 'BLUEPRINT'), (191, 'Sheet Revision Recognition', 'BLUEPRINT'), (192, 'Detail Callout Linking 2.0', 'BLUEPRINT'), (193, 'Section/Elevation Relationship Brain', 'BLUEPRINT'), (194, 'Keynote Intelligence 2.0', 'BLUEPRINT'), (195, 'Drawing Legend Intelligence 2.0', 'BLUEPRINT'), (196, 'Symbol Intelligence 2.0', 'BLUEPRINT'), (197, 'Room Recognition 2.0', 'BLUEPRINT'), (198, 'Area/Zone Intelligence', 'BLUEPRINT'), (199, 'Building-Level Intelligence', 'BLUEPRINT'), (200, 'Door Schedule Intelligence 2.0', 'BLUEPRINT'), (201, 'Finish Schedule Intelligence 2.0', 'BLUEPRINT'), (202, 'Equipment Schedule Intelligence 2.0', 'BLUEPRINT'), (203, 'Plumbing Fixture Schedule Intelligence 2.0', 'BLUEPRINT'), (204, 'Mechanical Schedule Intelligence 2.0', 'BLUEPRINT'), (205, 'Electrical Panel Intelligence 2.0', 'BLUEPRINT'), (206, 'Lighting Fixture Intelligence 2.0', 'BLUEPRINT'), (207, 'Structural Schedule Intelligence 2.0', 'BLUEPRINT'), (208, 'Specification Cross-Reference Brain', 'BLUEPRINT'), (209, 'Drawing/Spec Conflict Intelligence 2.0', 'BLUEPRINT'), (210, 'Daily Field Plan AI', 'FIELD'), (211, 'Crew Planning Intelligence', 'FIELD'), (212, 'Manpower Forecast 2.0', 'FIELD'), (213, 'Crew Stacking Conflict Detection', 'FIELD'), (214, 'Work Area Availability Brain', 'FIELD'), (215, 'Site Logistics Intelligence', 'FIELD'), (216, 'Delivery Coordination Brain', 'FIELD'), (217, 'Material Staging Intelligence', 'FIELD'), (218, 'Shutdown Planning Intelligence', 'FIELD'), (219, 'Temporary Protection Intelligence', 'FIELD'), (220, 'Trade Mobilization Planner', 'FIELD'), (221, 'Daily Production Tracking', 'FIELD'), (222, 'Production Rate Intelligence', 'FIELD'), (223, 'Planned-vs-Actual Field Production', 'FIELD'), (224, 'Daily Delay Cause Tracking', 'FIELD'), (225, 'Superintendent Recovery Suggestions', 'FIELD'), (226, 'Field Constraint Log Intelligence', 'FIELD'), (227, 'Weather Impact Integration', 'FIELD'), (228, 'Daily Field Risk Forecast', 'FIELD'), (229, 'Superintendent Command 3.0', 'FIELD'), (230, 'RFI Intelligence 3.0', 'PM'), (231, 'RFI Aging & Risk Prediction', 'PM'), (232, 'RFI-to-Schedule Impact Linking', 'PM'), (233, 'RFI-to-Cost Exposure Linking', 'PM'), (234, 'Submittal Intelligence 3.0', 'PM'), (235, 'Submittal Required-Date Prediction', 'PM'), (236, 'Submittal Approval Risk', 'PM'), (237, 'Procurement Chain Intelligence 3.0', 'PM'), (238, 'Vendor Commitment Tracking', 'PM'), (239, 'Long-Lead Recovery Scenarios', 'PM'), (240, 'Meeting Intelligence', 'PM'), (241, 'Automatic Meeting Agenda', 'PM'), (242, 'Meeting Decision Tracker', 'PM'), (243, 'Meeting Action Item Intelligence', 'PM'), (244, 'Owner Decision Intelligence 2.0', 'PM'), (245, 'Architect/Engineer Response Tracking', 'PM'), (246, 'Correspondence Intelligence', 'PM'), (247, 'Contract Notice Intelligence', 'PM'), (248, 'PM Command Center', 'PM'), (249, 'Project Management Autopilot', 'PM'), (250, 'Bid Package Generator 2.0', 'PRECON'), (251, 'Scope Coverage Matrix', 'PRECON'), (252, 'Bidder Scope Comparison', 'PRECON'), (253, 'Exclusion Intelligence', 'PRECON'), (254, 'Allowance Intelligence', 'PRECON'), (255, 'Alternate Intelligence', 'PRECON'), (256, 'Bid Leveling 2.0', 'PRECON'), (257, 'Proposal Normalization Brain', 'PRECON'), (258, 'Missing Scope Detection 3.0', 'PRECON'), (259, 'Duplicate Scope Detection 3.0', 'PRECON'), (260, 'Buyout Recommendation Engine', 'PRECON'), (261, 'Subcontractor Risk Scoring', 'PRECON'), (262, 'Historical Cost Intelligence 2.0', 'PRECON'), (263, 'Quantity Confidence Engine', 'PRECON'), (264, 'Estimate Revision Comparison', 'PRECON'), (265, 'Budget-to-Buyout Intelligence', 'PRECON'), (266, 'Preconstruction Risk Register', 'PRECON'), (267, 'Preconstruction Command Center', 'PRECON'), (268, 'Estimator/PM Handoff Intelligence', 'PRECON'), (269, 'Unified Preconstruction Operating Brain 3.0', 'PRECON')]


def _v269_table_exists(name):
    try:
        c=db()
        if DB_KIND=="postgres":
            return bool(c.execute("SELECT to_regclass(?)",(name,)).fetchone()[0])
        return bool(c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(name,)).fetchone())
    except Exception: return False


def _v269_count(table,pid):
    try:
        if not _v269_table_exists(table): return 0
        return int(db().execute(f"SELECT COUNT(*) FROM {table} WHERE project_id=?",(pid,)).fetchone()[0])
    except Exception: return 0


def _v269_context(pid):
    s=_v56_cached("snapshot",pid,lambda:_v37_snapshot(pid))
    return {
      "snapshot":s,
      "activities":_v269_count("activities",pid),
      "issues":_v269_count("issues",pid),
      "rfis":_v269_count("rfis",pid),
      "submittals":_v269_count("submittals",pid),
      "procurement":_v269_count("procurement",pid),
      "inspections":_v269_count("inspections",pid),
      "scope":len(_v452_scope_rows(pid)) if callable(globals().get("_v452_scope_rows")) else 0
    }


def _v269_cap_status(pid,cap):
    v,name,group=cap; c=_v269_context(pid)
    if group=="UI_WORKFLOW": return "ACTIVE"
    if group=="BLUEPRINT": return "ACTIVE" if c["scope"] else "WAITING FOR DOCUMENT DATA"
    if group=="FIELD": return "ACTIVE" if c["activities"] else "WAITING FOR SCHEDULE DATA"
    if group=="PM": return "ACTIVE" if (c["rfis"]+c["submittals"]+c["procurement"]+c["issues"]) else "WAITING FOR PM DATA"
    if group=="PRECON": return "ACTIVE" if c["scope"] else "WAITING FOR SCOPE DATA"
    return "LEARNING"


def _v269_search(pid,q):
    q=str(q or "").strip().lower()
    if not q:return []
    results=[]
    for v,name,group in _V269_CAPABILITIES:
        if q in name.lower() or q in group.lower():
            results.append(("TOOL",name,f"/platform-269/group/{group}",f"v{v} · {group}"))
    for r in _v452_scope_rows(pid)[:1000]:
        blob=" ".join(str(r[x] or "") for x in ["trade","requirement","source_sheet","source_spec"]).lower()
        if q in blob:
            results.append(("SCOPE",str(r["trade"] or "Scope"),"/blueprint-brain",str(r["requirement"] or "")[:180]))
        if len(results)>=100: break
    return results[:100]


def _v269_field_command(pid):
    try: brief=_v62_daily_brief(pid)
    except Exception: brief={"priorities":{"now":[],"today":[],"week":[]},"activities":[],"inspections":[],"materials":[]}
    try: readiness=_v60_trade_readiness(pid)
    except Exception: readiness=[]
    return brief,readiness


def _v269_pm_command(pid):
    try: decisions=_v47_decision_deadlines(pid)[:30]
    except Exception: decisions=[]
    try: agenda=_v47_coordination_agenda(pid)[:30]
    except Exception: agenda=[]
    return decisions,agenda


def _v269_precon_command(pid):
    try: gaps=_v66_scope_gaps(pid)
    except Exception: gaps=[]
    rows=_v452_scope_rows(pid)
    by_trade={}
    for r in rows:
        tr=str(r["trade"] or "UNASSIGNED")
        by_trade[tr]=by_trade.get(tr,0)+1
    return gaps,sorted(by_trade.items(),key=lambda x:(-x[1],x[0]))


@app.get("/platform-269",response_class=HTMLResponse)
def v269_platform():
    pid=project_id(); c=_v269_context(pid)
    active=sum(1 for x in _V269_CAPABILITIES if _v269_cap_status(pid,x)=="ACTIVE")
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v269</div><h1>Unified Construction Operating Platform</h1><p class="muted">{active} / 99 new capabilities active against current project data. v170 layout + v171-v269 intelligence phase.</p></div><div class="grid3">'
    cards=[
      ("Command Search","Search tools and project scope from one place.","/platform-269/search"),
      ("UI & Workflow","Dashboard, navigation, alerts and workflow capabilities.","/platform-269/group/UI_WORKFLOW"),
      ("Blueprint Workspace","Advanced drawing/specification intelligence.","/platform-269/group/BLUEPRINT"),
      ("Field Command","Superintendent operations and readiness.","/field-command-3"),
      ("PM Command","RFI, submittal, procurement and decision intelligence.","/pm-command"),
      ("Preconstruction Command","Scope coverage, gaps, buyout and risk.","/precon-command"),
      ("100-Phase Capability Map","See v170-v269 platform capabilities.","/platform-269/capabilities"),
      ("Project Autopilot","Existing project operating intelligence.","/autopilot"),
      ("Knowledge Brain 2.0","Construction knowledge foundation.","/knowledge-brain-2"),
    ]
    for n,d,h in cards: body+=_v37_link_card(n,d,h,"Open")
    body+='</div>'
    return shell("Unified Operating Platform",body)


@app.get("/platform-269/capabilities",response_class=HTMLResponse)
def v269_caps():
    pid=project_id()
    h='<div class="action"><span class="badge READY">ACTIVE</span> <b>v170 - Professional Command Center Layout</b><div class="small">UI WORKFLOW</div></div>'
    for cap in _V269_CAPABILITIES:
        v,name,group=cap; status=_v269_cap_status(pid,cap)
        h+=f'<div class="action"><span class="badge">{esc(status)}</span> <b>v{v} - {esc(name)}</b><div class="small">{esc(group.replace("_"," "))}</div></div>'
    return shell("v170-v269 Capability Map",'<div class="hero"><h1>100-Version Platform Phase</h1><p class="muted">One shared operating architecture instead of 100 independent pages.</p></div><div class="card">'+h+'</div>')


@app.get("/platform-269/group/{group}",response_class=HTMLResponse)
def v269_group(group:str):
    group=group.upper(); pid=project_id()
    rows=[x for x in _V269_CAPABILITIES if x[2]==group]
    h="".join(f'<div class="action"><span class="badge">{esc(_v269_cap_status(pid,x))}</span> <b>v{x[0]} - {esc(x[1])}</b></div>' for x in rows)
    return shell(group.replace("_"," "),f'<div class="hero"><h1>{esc(group.replace("_"," "))}</h1><p class="muted">{len(rows)} integrated capabilities.</p></div><div class="card">{h}</div>')


@app.get("/platform-269/search",response_class=HTMLResponse)
def v269_search_page(q:str=""):
    rows=_v269_search(project_id(),q)
    form=f'<form method="get"><input name="q" value="{esc(q)}" placeholder="Search BuildCommand tools, trades, scope, sheets..." style="width:min(760px,90%);padding:12px"><button type="submit">Search</button></form>'
    h="".join(f'<div class="action"><span class="badge">{esc(kind)}</span> <a href="{href}"><b>{esc(title)}</b></a><div class="small">{esc(detail)}</div></div>' for kind,title,href,detail in rows)
    return shell("Command Search",'<div class="hero"><h1>Global Command Search</h1><p class="muted">Search the platform and current project knowledge.</p>'+form+'</div><div class="card">'+(h or '<p class="muted">Enter a search above.</p>')+'</div>')


@app.get("/field-command-3",response_class=HTMLResponse)
def v269_field():
    brief,ready=_v269_field_command(project_id())
    p=brief["priorities"]
    def ph(rows):return "".join(f'<div class="action"><span class="badge WATCH">{esc(x["severity"])}</span> <b>{esc(x["title"])}</b><div class="small">{esc(x["action"])}</div></div>' for x in rows[:8]) or '<p class="muted">Clear.</p>'
    nr="".join(f'<div class="action"><span class="badge WATCH">{esc(state)}</span> <b>{esc(a["trade"])} - {esc(a["name"])}</b><div class="small">{esc(", ".join(failed))}</div></div>' for a,state,failed,checks in ready if state!="READY") or '<p class="muted">Upcoming trades ready.</p>'
    body='<div class="hero"><div class="eyebrow">v229 Superintendent Command 3.0</div><h1>Field Command</h1></div><div class="grid2"><div class="card"><h2>DO NOW</h2>'+ph(p["now"])+'</div><div class="card"><h2>TODAY</h2>'+ph(p["today"])+'</div></div><div class="card"><h2>Trade Readiness</h2>'+nr+'</div>'
    return shell("Field Command",body)


@app.get("/pm-command",response_class=HTMLResponse)
def v269_pm():
    decisions,agenda=_v269_pm_command(project_id())
    dh="".join(f'<div class="action"><span class="badge WATCH">{esc(sev)}</span> <b>{esc(typ)} - {esc(title)}</b><div class="small">Due {esc(due)} · ${cost:,.0f} known exposure · {days:g} schedule day(s)</div></div>' for typ,title,due,sev,cost,days,source in decisions) or '<p class="muted">No urgent decisions.</p>'
    ah="".join(f'<div class="action"><span class="badge">{esc(kind)}</span> <b>{esc(title)}</b><div class="small">{esc(detail)}</div></div>' for kind,title,detail in agenda) or '<p class="muted">No coordination agenda items.</p>'
    return shell("PM Command",'<div class="hero"><div class="eyebrow">v248-v249</div><h1>Project Management Command</h1></div><div class="grid2"><div class="card"><h2>Decisions</h2>'+dh+'</div><div class="card"><h2>Coordination</h2>'+ah+'</div></div>')


@app.get("/precon-command",response_class=HTMLResponse)
def v269_precon():
    gaps,trades=_v269_precon_command(project_id())
    gh="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(r["trade"] or "UNASSIGNED")}</b><div>{esc(r["requirement"])}</div><div class="small">{esc(reason)}</div></div>' for kind,r,reason in gaps[:40]) or '<p class="muted">No obvious scope gaps.</p>'
    th="".join(f'<div class="action"><b>{esc(trade)}</b><div class="small">{count} scope requirement(s)</div></div>' for trade,count in trades[:40])
    return shell("Preconstruction Command",'<div class="hero"><div class="eyebrow">v267-v269</div><h1>Preconstruction Command</h1><p class="muted">Scope coverage, ownership and buyout risk in one workspace.</p></div><div class="grid2"><div class="card"><h2>Scope Risk</h2>'+gh+'</div><div class="card"><h2>Coverage by Trade</h2>'+th+'</div></div>')


_V369_CAPABILITIES=[(270, 'Daily Workface Planning', 'FIELD_EXECUTION'), (271, 'Crew Availability Intelligence', 'FIELD_EXECUTION'), (272, 'Trade Stacking Forecast', 'FIELD_EXECUTION'), (273, 'Work Area Conflict Detection', 'FIELD_EXECUTION'), (274, 'Material Staging Planner', 'FIELD_EXECUTION'), (275, 'Delivery Window Intelligence', 'FIELD_EXECUTION'), (276, 'Access Route Intelligence', 'FIELD_EXECUTION'), (277, 'Temporary Protection Planner', 'FIELD_EXECUTION'), (278, 'Shutdown Coordination Brain', 'FIELD_EXECUTION'), (279, 'Site Logistics Command', 'FIELD_EXECUTION'), (280, 'Production Quantity Tracking', 'FIELD_EXECUTION'), (281, 'Planned vs Actual Production', 'FIELD_EXECUTION'), (282, 'Daily Delay Cause Intelligence', 'FIELD_EXECUTION'), (283, 'Recovery Action Recommender', 'FIELD_EXECUTION'), (284, 'Constraint Removal Planner', 'FIELD_EXECUTION'), (285, 'Field Issue Escalation Brain', 'FIELD_EXECUTION'), (286, 'Weather Exposure Planning', 'FIELD_EXECUTION'), (287, 'Trade Mobilization Forecast', 'FIELD_EXECUTION'), (288, 'Foreman Coordination Intelligence', 'FIELD_EXECUTION'), (289, 'Field Execution Command 4.0', 'FIELD_EXECUTION'), (290, 'RFI Aging Intelligence 4.0', 'PM_CONTROL'), (291, 'RFI Impact Propagation', 'PM_CONTROL'), (292, 'Submittal Aging Intelligence', 'PM_CONTROL'), (293, 'Submittal Required-Date Engine', 'PM_CONTROL'), (294, 'Procurement Commitment Tracking', 'PM_CONTROL'), (295, 'Vendor Response Risk', 'PM_CONTROL'), (296, 'Owner Decision Aging', 'PM_CONTROL'), (297, 'Architect Response Tracking', 'PM_CONTROL'), (298, 'Meeting Agenda Intelligence 2.0', 'PM_CONTROL'), (299, 'Meeting Decision Register', 'PM_CONTROL'), (300, 'Meeting Action Follow-Up', 'PM_CONTROL'), (301, 'Correspondence Intelligence 2.0', 'PM_CONTROL'), (302, 'Contract Notice Trigger Brain', 'PM_CONTROL'), (303, 'Potential Change Register 2.0', 'PM_CONTROL'), (304, 'Change Documentation Completeness', 'PM_CONTROL'), (305, 'PM Risk Register', 'PM_CONTROL'), (306, 'Responsibility Escalation Engine', 'PM_CONTROL'), (307, 'Communication Gap Detection', 'PM_CONTROL'), (308, 'Project Controls Integration', 'PM_CONTROL'), (309, 'PM Command 4.0', 'PM_CONTROL'), (310, 'CPM Relationship Readiness', 'SCHEDULE'), (311, 'Predecessor Quality Audit', 'SCHEDULE'), (312, 'Successor Exposure Intelligence', 'SCHEDULE'), (313, 'Float Consumption Predictor', 'SCHEDULE'), (314, 'Near-Critical Path Intelligence', 'SCHEDULE'), (315, 'Constraint Date Intelligence', 'SCHEDULE'), (316, 'Milestone Risk Forecast', 'SCHEDULE'), (317, 'Look-Ahead Reliability Score', 'SCHEDULE'), (318, 'Production-to-Schedule Feedback', 'SCHEDULE'), (319, 'Procurement-to-Schedule Link', 'SCHEDULE'), (320, 'RFI-to-Schedule Link 2.0', 'SCHEDULE'), (321, 'Inspection-to-Schedule Link', 'SCHEDULE'), (322, 'Weather-to-Schedule Link', 'SCHEDULE'), (323, 'Crew Capacity Schedule Risk', 'SCHEDULE'), (324, 'Area Turnover Sequence Brain', 'SCHEDULE'), (325, 'Recovery Scenario Generator', 'SCHEDULE'), (326, 'Resequencing Opportunity Brain', 'SCHEDULE'), (327, 'Delay Cause Classification', 'SCHEDULE'), (328, 'Schedule Confidence Engine', 'SCHEDULE'), (329, 'Schedule Command 4.0', 'SCHEDULE'), (330, 'Commitment Intelligence', 'COST'), (331, 'Pending Change Exposure', 'COST'), (332, 'Known vs Unpriced Cost Separation', 'COST'), (333, 'Cost-to-Complete Forecast', 'COST'), (334, 'Estimate-at-Completion Predictor', 'COST'), (335, 'Allowance Burn Intelligence', 'COST'), (336, 'Contingency Consumption Brain', 'COST'), (337, 'Buyout Variance Intelligence', 'COST'), (338, 'Production Cost Variance', 'COST'), (339, 'Schedule Cost Exposure', 'COST'), (340, 'RFI Cost Exposure 2.0', 'COST'), (341, 'Procurement Cost Risk', 'COST'), (342, 'Labor Productivity Cost Signal', 'COST'), (343, 'Subcontractor Cost Risk', 'COST'), (344, 'Forecast Confidence Engine', 'COST'), (345, 'Cash Exposure Snapshot', 'COST'), (346, 'Commercial Risk Register', 'COST'), (347, 'Budget Trend Intelligence', 'COST'), (348, 'Executive Cost Forecast', 'COST'), (349, 'Cost Command 4.0', 'COST'), (350, 'Activity Safety Readiness', 'SAFETY_QUALITY_COMPANY'), (351, 'JHA Requirement Intelligence', 'SAFETY_QUALITY_COMPANY'), (352, 'Permit-to-Work Intelligence', 'SAFETY_QUALITY_COMPANY'), (353, 'High-Risk Activity Detection', 'SAFETY_QUALITY_COMPANY'), (354, 'Quality Hold Point Intelligence 2.0', 'SAFETY_QUALITY_COMPANY'), (355, 'Preinstallation Conference Intelligence', 'SAFETY_QUALITY_COMPANY'), (356, 'Mockup Requirement Brain', 'SAFETY_QUALITY_COMPANY'), (357, 'Manufacturer Inspection Requirement', 'SAFETY_QUALITY_COMPANY'), (358, 'Testing Witness Requirement', 'SAFETY_QUALITY_COMPANY'), (359, 'Deficiency Recurrence Intelligence', 'SAFETY_QUALITY_COMPANY'), (360, 'Punch Trend Intelligence', 'SAFETY_QUALITY_COMPANY'), (361, 'Commissioning Readiness 2.0', 'SAFETY_QUALITY_COMPANY'), (362, 'Closeout Quality Intelligence', 'SAFETY_QUALITY_COMPANY'), (363, 'Subcontractor Quality Score', 'SAFETY_QUALITY_COMPANY'), (364, 'Subcontractor Safety Score', 'SAFETY_QUALITY_COMPANY'), (365, 'Project Lessons Pattern Brain', 'SAFETY_QUALITY_COMPANY'), (366, 'Company Benchmark Intelligence', 'SAFETY_QUALITY_COMPANY'), (367, 'Cross-Project Risk Pattern', 'SAFETY_QUALITY_COMPANY'), (368, 'Portfolio Health Intelligence', 'SAFETY_QUALITY_COMPANY'), (369, 'Safety Quality Company Command', 'SAFETY_QUALITY_COMPANY')]


def _v369_context(pid):
    try: snap=_v56_cached("snapshot",pid,lambda:_v37_snapshot(pid))
    except Exception: snap={}
    def cnt(table):
        try:
            c=db()
            row=c.execute(f"SELECT COUNT(*) FROM {table} WHERE project_id=?",(pid,)).fetchone()
            c.close()
            return int(row[0] if row else 0)
        except Exception:
            return 0
    return {
      "snapshot":snap,
      "activities":cnt("activities"),
      "issues":cnt("issues"),
      "rfis":cnt("rfis"),
      "submittals":cnt("submittals"),
      "procurement":cnt("procurement"),
      "inspections":cnt("inspections"),
      "changes":cnt("change_events"),
      "scope":len(_v452_scope_rows(pid)) if callable(globals().get("_v452_scope_rows")) else 0
    }


def _v369_status(pid,cap):
    _,_,group=cap
    c=_v369_context(pid)
    if group=="FIELD_EXECUTION":
        return "ACTIVE" if c["activities"] else "WAITING FOR SCHEDULE DATA"
    if group=="PM_CONTROL":
        return "ACTIVE" if (c["rfis"]+c["submittals"]+c["issues"]+c["procurement"]) else "WAITING FOR PM DATA"
    if group=="SCHEDULE":
        return "ACTIVE" if c["activities"] else "WAITING FOR SCHEDULE DATA"
    if group=="COST":
        return "ACTIVE" if (c["changes"] or c["scope"]) else "WAITING FOR COMMERCIAL DATA"
    if group=="SAFETY_QUALITY_COMPANY":
        return "ACTIVE" if (c["activities"] or c["inspections"] or c["scope"]) else "WAITING FOR PROJECT DATA"
    return "LEARNING"


def _v369_field(pid):
    try: brief=_v62_daily_brief(pid)
    except Exception: brief={"priorities":{"now":[],"today":[],"week":[]},"activities":[]}
    try: ready=_v60_trade_readiness(pid)
    except Exception: ready=[]
    try: handoffs=_v61_handoffs(pid)
    except Exception: handoffs=[]
    return brief,ready,handoffs


def _v369_pm(pid):
    try: decisions=_v47_decision_deadlines(pid)[:40]
    except Exception: decisions=[]
    try: agenda=_v47_coordination_agenda(pid)[:40]
    except Exception: agenda=[]
    try: changes=_v39_rows("SELECT * FROM change_events WHERE project_id=? ORDER BY id DESC LIMIT 40",(pid,))
    except Exception: changes=[]
    return decisions,agenda,changes


def _v369_schedule(pid):
    try: seq=_v56_sequence(pid)
    except Exception: seq=[]
    high=[x for x in seq if x.get("risk") in {"CRITICAL","HIGH"}]
    try: look=_v59_lookahead(pid,6)
    except Exception: look=[]
    return high,look


def _v369_cost(pid):
    try: changes=_v39_changes(pid)
    except Exception: changes=[]
    known=sum(float(r["estimated_cost"] or 0) for r in changes)
    try:
        rev=_v55_summary(pid)
        revnet=float(rev.get("added_cost",0))-float(rev.get("removed_cost",0))
    except Exception:
        revnet=0
    return {"known_change":known,"revision_net":revnet,"total_known":known+revnet}


def _v369_quality(pid):
    try: qc=_v65_qc_points(pid)
    except Exception: qc=[]
    try: holds=[x for x in _v49_hold_points(pid) if str(x[0]["result"] or "").upper()!="PASSED"]
    except Exception: holds=[]
    return qc,holds


@app.get("/platform-369",response_class=HTMLResponse)
def v369_platform():
    pid=project_id()
    active=sum(1 for x in _V369_CAPABILITIES if _v369_status(pid,x)=="ACTIVE")
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v369</div><h1>Execution & Control Intelligence Platform</h1><p class="muted">{active} / 100 new capabilities active against current project data.</p></div><div class="grid3">'
    cards=[
      ("Field Execution Command","Production, crews, logistics, constraints and recovery.","/field-execution-4"),
      ("PM Command 4.0","RFI, submittal, decisions, meetings and change controls.","/pm-command-4"),
      ("Schedule Command 4.0","Sequence, near-critical exposure, float and recovery intelligence.","/schedule-command-4"),
      ("Cost Command 4.0","Known exposure, changes, forecast and commercial risk.","/cost-command-4"),
      ("Safety / Quality / Company","Safety readiness, QC, commissioning and company patterns.","/sqc-command"),
      ("Capability Map","See all v270-v369 capabilities.","/platform-369/capabilities"),
      ("Project Autopilot","Continue using the operating command center.","/autopilot"),
      ("Unified Platform v269","Prior platform phase.","/platform-269"),
      ("Knowledge Brain 2.0","Construction knowledge foundation.","/knowledge-brain-2"),
    ]
    for n,d,h in cards:
        body+=_v37_link_card(n,d,h,"Open")
    body+='</div>'
    return shell("Execution & Control Platform",body)


@app.get("/platform-369/capabilities",response_class=HTMLResponse)
def v369_caps():
    pid=project_id()
    h="".join(
        f'<div class="action"><span class="badge">{esc(_v369_status(pid,x))}</span> '
        f'<b>v{x[0]} - {esc(x[1])}</b><div class="small">{esc(x[2].replace("_"," "))}</div></div>'
        for x in _V369_CAPABILITIES
    )
    return shell("v270-v369 Capability Map",'<div class="hero"><h1>Next 100 Capability Map</h1><p class="muted">Shared workspaces, not 100 separate top-level pages.</p></div><div class="card">'+h+'</div>')


@app.get("/field-execution-4",response_class=HTMLResponse)
def v369_field_page():
    brief,ready,handoffs=_v369_field(project_id())
    p=brief["priorities"]
    def ph(rows): return "".join(
        f'<div class="action"><span class="badge WATCH">{esc(x["severity"])}</span> '
        f'<b>{esc(x["title"])}</b><div class="small">{esc(x["action"])}</div></div>' for x in rows[:10]
    ) or '<p class="muted">Clear.</p>'
    rh="".join(
        f'<div class="action"><span class="badge WATCH">{esc(state)}</span> '
        f'<b>{esc(a["trade"])} - {esc(a["name"])}</b><div class="small">{esc(", ".join(failed))}</div></div>'
        for a,state,failed,checks in ready if state!="READY"
    ) or '<p class="muted">Upcoming trades ready.</p>'
    hh="".join(
        f'<div class="action"><span class="badge">HANDOFF</span> <b>{esc(a["trade"])} → {esc(b["trade"])}</b>'
        f'<div class="small">{esc(a["name"])} → {esc(b["name"])}</div></div>' for a,b,note in handoffs[:12]
    ) or '<p class="muted">No immediate handoffs.</p>'
    body='<div class="hero"><div class="eyebrow">v289 Field Execution Command 4.0</div><h1>Field Execution Command</h1></div>'
    body+='<div class="grid2"><div class="card"><h2>DO NOW</h2>'+ph(p["now"])+'</div><div class="card"><h2>TODAY</h2>'+ph(p["today"])+'</div></div>'
    body+='<div class="grid2"><div class="card"><h2>Trade Readiness</h2>'+rh+'</div><div class="card"><h2>Upcoming Handoffs</h2>'+hh+'</div></div>'
    return shell("Field Execution Command",body)


@app.get("/pm-command-4",response_class=HTMLResponse)
def v369_pm_page():
    decisions,agenda,changes=_v369_pm(project_id())
    dh="".join(
        f'<div class="action"><span class="badge WATCH">{esc(sev)}</span> <b>{esc(typ)} - {esc(title)}</b>'
        f'<div class="small">Due {esc(due)} · ${cost:,.0f} known exposure · {days:g} day(s)</div></div>'
        for typ,title,due,sev,cost,days,source in decisions
    ) or '<p class="muted">No urgent decisions.</p>'
    ah="".join(
        f'<div class="action"><span class="badge">{esc(kind)}</span> <b>{esc(title)}</b><div class="small">{esc(detail)}</div></div>'
        for kind,title,detail in agenda
    ) or '<p class="muted">No current agenda items.</p>'
    ch="".join(
        f'<div class="action"><b>{esc(r["title"])}</b><div class="small">${float(r["estimated_cost"] or 0):,.0f} · {float(r["schedule_days"] or 0):g} day(s)</div></div>'
        for r in changes[:20]
    ) or '<p class="muted">No change events.</p>'
    return shell("PM Command 4.0",'<div class="hero"><div class="eyebrow">v309</div><h1>PM Command 4.0</h1></div><div class="grid3"><div class="card"><h2>Decisions</h2>'+dh+'</div><div class="card"><h2>Coordination</h2>'+ah+'</div><div class="card"><h2>Changes</h2>'+ch+'</div></div>')


@app.get("/schedule-command-4",response_class=HTMLResponse)
def v369_schedule_page():
    high,look=_v369_schedule(project_id())
    hh="".join(
        f'<div class="action"><span class="badge WATCH">{esc(x["risk"])}</span> <b>{esc(x["activity"]["name"])}</b>'
        f'<div class="small">{esc(x["activity"]["trade"])} · {esc(x["blocking_reason"])}</div></div>' for x in high[:30]
    ) or '<p class="muted">No high sequence risks.</p>'
    lh="".join(
        f'<div class="action"><span class="badge WATCH">{esc(state)}</span> <b>{esc(a["name"])}</b>'
        f'<div class="small">{esc(a["trade"])} · {esc(a["start"])} → {esc(a["finish"])}</div></div>' for a,state,risk,reason in look[:30]
    ) or '<p class="muted">No look-ahead activities.</p>'
    return shell("Schedule Command 4.0",'<div class="hero"><div class="eyebrow">v329</div><h1>Schedule Command 4.0</h1><p class="muted">Sequence exposure plus six-week readiness.</p></div><div class="grid2"><div class="card"><h2>High-Risk Sequence</h2>'+hh+'</div><div class="card"><h2>6-Week Look-Ahead</h2>'+lh+'</div></div>')


@app.get("/cost-command-4",response_class=HTMLResponse)
def v369_cost_page():
    c=_v369_cost(project_id())
    return shell("Cost Command 4.0",f'<div class="hero"><div class="eyebrow">v349</div><h1>Cost Command 4.0</h1><p class="muted">Known values only; unpriced exposure remains explicitly unpriced.</p></div><div class="grid3"><div class="card"><div class="label">Known Change Exposure</div><div class="kpi">${c["known_change"]:,.0f}</div></div><div class="card"><div class="label">Revision Net</div><div class="kpi">${c["revision_net"]:,.0f}</div></div><div class="card"><div class="label">Total Known</div><div class="kpi">${c["total_known"]:,.0f}</div></div></div>')


@app.get("/sqc-command",response_class=HTMLResponse)
def v369_sqc_page():
    qc,holds=_v369_quality(project_id())
    qh="".join(
        f'<div class="action"><span class="badge">QC</span> <b>{esc(a["name"])}</b><div class="small">{esc(kind)} · {esc(check)}</div></div>'
        for a,kind,check in qc[:30]
    ) or '<p class="muted">No QC checkpoints generated.</p>'
    hh="".join(
        f'<div class="action"><span class="badge WATCH">{esc(i["result"])}</span> <b>{esc(i["inspection_type"])}</b>'
        f'<div class="small">{esc(i["scheduled_date"])} · {esc(i["authority"])}</div></div>' for i,a in holds[:30]
    ) or '<p class="muted">No open inspection hold points.</p>'
    return shell("Safety Quality Company Command",'<div class="hero"><div class="eyebrow">v369</div><h1>Safety / Quality / Company Command</h1></div><div class="grid2"><div class="card"><h2>Quality Checkpoints</h2>'+qh+'</div><div class="card"><h2>Open Hold Points</h2>'+hh+'</div></div>')


@app.get("/build",response_class=HTMLResponse)
def unified_build():
    s=_v37_snapshot(project_id())
    body=(
      '<div class="hero"><div class="eyebrow">BUILD</div><h1>Understand the project.</h1><p class="muted">One place for plans, specs and scope intelligence.</p></div>'
      f'<div class="card"><div class="label">Source-backed Scope Items</div><div class="kpi">{s["scope"]}</div></div>'
      '<div class="grid2">'
      +_v37_link_card("Analyze Project","Upload once. BuildCommand runs plan intelligence, estimator sync, takeoff splitting and quantity review automatically.","/build/analyze-project","Analyze")
      +_v37_link_card("Review Project Scope","Review unified source-backed construction intelligence.","/brain","Review")
      +_v37_link_card("Blueprint Brain","Open source-backed trade scopes and run the final trade cleanup.","/blueprint-brain","Open")
      +'</div><details class="card"><summary><b>More Build tools</b></summary><p><a href="/sequence-intelligence">Sequence Intelligence</a> · <a href="/blueprint-brain">Blueprint Brain</a> · <a href="/preconstruction">Preconstruction & Bid Intelligence</a> · <a href="/documents">Documents</a> · <a href="/document-ai">Deep Document AI</a></p></details>'
    )
    return shell("Build",body)


@app.get("/estimate",response_class=HTMLResponse)
def unified_estimate():
    s=_v37_snapshot(project_id())
    body=(
      '<div class="hero"><div class="eyebrow">ESTIMATE</div><h1>Scope to price.</h1><p class="muted">The takeoff brains work underneath; review what needs estimator judgment.</p></div>'
      f'<div class="grid2"><div class="card"><div class="label">Estimator Items</div><div class="kpi">{s["estimate"]}</div></div>'
      f'<div class="card"><div class="label">Need Review</div><div class="kpi">{s["review"]}</div></div></div>'
      '<div class="grid2">'
      +_v37_link_card("Estimator Workspace","Scope, quantity, unit, labor, material, subcontract quote and markup.","/brain/estimator","Open Estimate")
      +_v37_link_card("Takeoff Review","Review AI quantity proposals and verification items.","/brain/takeoff","Review")
      +'</div><details class="card"><summary><b>Advanced estimating tools</b></summary><p><a href="/brain/takeoff/components">Takeoff Components</a> · <a href="/cost-intelligence">Cost Intelligence</a></p></details>'
    )
    return shell("Estimate",body)


@app.get("/manage",response_class=HTMLResponse)
def unified_manage():
    s=_v37_snapshot(project_id())
    attention=s["issues"]+s["submittals"]+s["actions"]+s["inspections"]
    body=(
      '<div class="hero"><div class="eyebrow">MANAGE</div><h1>Run the job.</h1><p class="muted">Schedule, field, RFIs, submittals, inspections and subcontractors.</p></div>'
      f'<div class="grid4"><div class="card"><div class="label">Need Attention</div><div class="kpi">{attention}</div></div>'
      f'<div class="card"><div class="label">Issues</div><div class="kpi">{s["issues"]}</div></div>'
      f'<div class="card"><div class="label">Submittals</div><div class="kpi">{s["submittals"]}</div></div>'
      f'<div class="card"><div class="label">Inspections</div><div class="kpi">{s["inspections"]}</div></div></div>'
      '<div class="grid3">'
      +_v37_link_card("Today","Superintendent Field Command: readiness, crews, deliveries, inspections and decisions.","/field-command")
      +_v37_link_card("Schedule","Schedule and production planning.","/schedule")
      +_v37_link_card("Things That Need You","One queue for human decisions.","/actions")
      +_v37_link_card("RFIs / Issues","Questions, conflicts and issues.","/issues")
      +_v37_link_card("Submittals","Submittal workflow.","/submittals")
      +_v37_link_card("Field","Field execution and reporting.","/field")
      +'</div><details class="card"><summary><b>More management tools</b></summary><p><a href="/sequence-intelligence">Sequence Intelligence</a> · <a href="/learning">Learning Intelligence</a> · <a href="/project-control">Project Control</a> · <a href="/intelligence">Intelligence Center</a> · <a href="/inspections">Inspections</a> · <a href="/safety">Safety</a> · <a href="/subcontractors">Subcontractors</a> · <a href="/procurement">Procurement</a> · <a href="/punch">Punch</a></p></details>'
    )
    return shell("Manage",body)


@app.get("/ask-buildcommand",response_class=HTMLResponse)
def unified_ask_buildcommand():
    body=(
      '<div class="hero"><div class="eyebrow">ASK BUILDCOMMAND</div><h1>Ask the project.</h1><p class="muted">Use natural language instead of hunting through menus.</p></div>'
      '<div class="grid2">'
      +_v37_link_card("Project Command","Ask about scope, schedule, risks, trades and project status.","/ai-command","Ask")
      +_v37_link_card("Search Everything","Find information across the project.","/global-search","Search")
      +'</div><div class="card"><h2>Try asking</h2><div class="action">What am I missing in electrical?</div><div class="action">What needs my attention today?</div><div class="action">Show me everything affecting doors.</div><div class="action">What could delay this week?</div></div>'
    )
    return shell("Ask BuildCommand",body)


@app.get("/legacy-dashboard",response_class=HTMLResponse)
def home():
    pid = project_id()
    ensure_today_morning_brief(pid)
    c = db()
    today = date.today().isoformat()

    project = c.execute(
        "SELECT * FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        "SELECT * FROM activities WHERE project_id=? ORDER BY start",
        (pid,)
    ).fetchall()

    risks = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM risks r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY r.score DESC
        """,
        (pid,)
    ).fetchall()

    make_ready_items = c.execute(
        """
        SELECT m.*, a.external_id, a.name activity
        FROM make_ready m
        JOIN activities a ON a.id=m.activity_id
        WHERE m.project_id=? AND m.status='OPEN'
        ORDER BY m.due
        """,
        (pid,)
    ).fetchall()

    actions = c.execute(
        """
        SELECT *
        FROM action_items
        WHERE project_id=? AND status='OPEN'
        ORDER BY due, id
        """,
        (pid,)
    ).fetchall()

    issues = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM project_issues i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=? AND i.status!='CLOSED'
        ORDER BY i.due, i.id
        """,
        (pid,)
    ).fetchall()

    procurement_rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM procurement p
        LEFT JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=? AND p.status!='DELIVERED'
        ORDER BY p.required_on_site, p.id
        """,
        (pid,)
    ).fetchall()

    inspection_rows = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM inspections_tracker i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=? AND i.result!='PASSED'
        ORDER BY i.scheduled_date, i.id
        """,
        (pid,)
    ).fetchall()

    submittal_rows = c.execute(
        """
        SELECT s.*, a.external_id, a.name activity
        FROM submittals s
        LEFT JOIN activities a ON a.id=s.activity_id
        WHERE s.project_id=? AND s.status NOT IN ('APPROVED','APPROVED_AS_NOTED')
        ORDER BY s.due_date, s.id
        """,
        (pid,)
    ).fetchall()

    safety_rows = c.execute(
        """
        SELECT *
        FROM safety_items
        WHERE project_id=? AND status!='CLOSED'
        ORDER BY id DESC
        """,
        (pid,)
    ).fetchall()

    change_rows = c.execute(
        """
        SELECT *
        FROM change_events
        WHERE project_id=? AND status NOT IN ('APPROVED','REJECTED')
        ORDER BY id DESC
        """,
        (pid,)
    ).fetchall()

    latest_report = c.execute(
        """
        SELECT *
        FROM daily_reports
        WHERE project_id=?
        ORDER BY report_date DESC,id DESC
        LIMIT 1
        """,
        (pid,)
    ).fetchone()

    c.close()

    critical_risks = [r for r in risks if r["band"] == "CRITICAL"]
    high_risks = [r for r in risks if r["band"] == "HIGH"]

    overdue_actions = [
        a for a in actions
        if a["due"] and a["due"] < today
    ]

    overdue_issues = [
        i for i in issues
        if i["due"] and i["due"] < today
    ]

    procurement_critical = []
    for p in procurement_rows:
        badge, risk_text = procurement_risk(
            p["required_on_site"],
            p["promised_date"],
            p["status"]
        )
        if badge == "CRITICAL":
            procurement_critical.append((p, risk_text))

    failed_inspections = [
        i for i in inspection_rows
        if i["result"] == "FAILED"
    ]

    overdue_inspections = [
        i for i in inspection_rows
        if i["scheduled_date"]
        and i["scheduled_date"] < today
        and i["result"] in ["PENDING", "SCHEDULED"]
    ]

    rejected_submittals = [
        s for s in submittal_rows
        if s["status"] == "REJECTED"
    ]

    overdue_submittals = [
        s for s in submittal_rows
        if s["due_date"]
        and s["due_date"] < today
        and s["status"] in ["PENDING", "SUBMITTED"]
    ]

    critical_safety = [
        s for s in safety_rows
        if s["severity"] == "CRITICAL"
    ]

    open_change_cost = sum((r["estimated_cost"] or 0) for r in change_rows)
    open_change_days = sum((r["schedule_days"] or 0) for r in change_rows)

    attention_score = min(
        100,
        len(critical_risks) * 20
        + len(high_risks) * 10
        + len(overdue_actions) * 8
        + len(overdue_issues) * 8
        + len(procurement_critical) * 12
        + len(failed_inspections) * 15
        + len(overdue_inspections) * 8
        + len(rejected_submittals) * 10
        + len(overdue_submittals) * 6
        + len(critical_safety) * 20
    )

    if attention_score >= 70:
        overall_badge = "CRITICAL"
        overall_text = "Immediate Attention"
    elif attention_score >= 40:
        overall_badge = "HIGH"
        overall_text = "Needs Attention"
    elif attention_score >= 15:
        overall_badge = "WATCH"
        overall_text = "Watch"
    else:
        overall_badge = "READY"
        overall_text = "Stable"

    priority_items = []

    for s in critical_safety[:2]:
        priority_items.append(
            ("CRITICAL", "Safety", s["title"], f'{s["location"] or "No location"}')
        )

    for r in critical_risks[:3]:
        priority_items.append(
            ("CRITICAL", "Risk", r["activity"], r["explanation"])
        )

    for i in failed_inspections[:2]:
        priority_items.append(
            ("CRITICAL", "Inspection", i["inspection_type"], i["notes"] or "Failed inspection")
        )

    for p, risk_text in procurement_critical[:2]:
        priority_items.append(
            ("CRITICAL", "Procurement", p["item"], risk_text)
        )

    for a in overdue_actions[:3]:
        priority_items.append(
            (
                a["priority"] if a["priority"] in ["CRITICAL","HIGH","WATCH","LOW"] else "HIGH",
                "Action",
                a["title"],
                f'Owner: {a["owner"] or "Unassigned"} · Due {a["due"]}'
            )
        )

    for i in overdue_issues[:2]:
        priority_items.append(
            (
                i["priority"] if i["priority"] in ["CRITICAL","HIGH","WATCH","LOW"] else "HIGH",
                i["issue_type"],
                i["title"],
                f'Owner: {i["owner"] or "Unassigned"} · Due {i["due"]}'
            )
        )

    for s in rejected_submittals[:2]:
        priority_items.append(
            ("HIGH", "Submittal", s["title"], "Rejected / revise and resubmit")
        )

    for m in make_ready_items[:3]:
        priority_items.append(
            (
                m["priority"] if m["priority"] in ["CRITICAL","HIGH","WATCH","LOW"] else "HIGH",
                "Make Ready",
                m["title"],
                f'Due {m["due"]}'
            )
        )

    if not priority_items:
        priority_items.append(
            ("READY", "Command", "No urgent issues detected", "Review today’s plan and upcoming work.")
        )

    priority_html = "".join(
        f"""
        <div class="action">
            <span class="badge {badge}">{esc(category)}</span>
            <b>{esc(title)}</b>
            <div class="small">{esc(detail)}</div>
        </div>
        """
        for badge, category, title, detail in priority_items[:10]
    )

    latest_report_html = (
        f"""
        <div class="small">Latest Daily Report: {esc(latest_report["report_date"])}</div>
        <p><b>Manpower:</b> {latest_report["manpower"] or 0}</p>
        <p><b>Work Completed:</b> {esc(latest_report["work_completed"]) or "—"}</p>
        <p><b>Delays:</b> {esc(latest_report["delays"]) or "—"}</p>
        <p><b>Tomorrow:</b> {esc(latest_report["tomorrow_plan"]) or "—"}</p>
        """
        if latest_report
        else '<div class="muted">No daily report submitted yet.</div>'
    )

    project_name = esc(project["name"]) if project else "Current Project"
    project_number = esc(project["number"]) if project else ""

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;gap:18px;align-items:flex-start;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Morning Command Center</div>
                <h1>What needs attention today?</h1>
                <div class="muted">
                    {project_number} - {project_name}
                </div>
            </div>

            <div style="text-align:right;">
                <span class="badge {overall_badge}">{overall_text}</span>
                <div class="kpi" style="margin-top:8px;">{attention_score}</div>
                <div class="small">Project attention score</div>
            </div>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Critical Risks</div>
            <div class="kpi">{len(critical_risks)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue Actions</div>
            <div class="kpi">{len(overdue_actions)}</div>
        </div>

        <div class="card">
            <div class="label">Open Make-Ready</div>
            <div class="kpi">{len(make_ready_items)}</div>
        </div>

        <div class="card">
            <div class="label">Failed Inspections</div>
            <div class="kpi">{len(failed_inspections)}</div>
        </div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Handle First</h2>
            {priority_html}
        </div>

        <div class="card">
            <h2>Latest Field Signal</h2>
            {latest_report_html}

            <div style="margin-top:14px;">
                <a href="/assistant"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Ask BuildCommand AI →
                </a>
            </div>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Procurement Critical</div>
            <div class="kpi">{len(procurement_critical)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue RFIs / Issues</div>
            <div class="kpi">{len(overdue_issues)}</div>
        </div>

        <div class="card">
            <div class="label">Submittal Problems</div>
            <div class="kpi">{len(rejected_submittals) + len(overdue_submittals)}</div>
        </div>

        <div class="card">
            <div class="label">Critical Safety</div>
            <div class="kpi">{len(critical_safety)}</div>
        </div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Change Exposure</h2>

            <div class="grid2">
                <div>
                    <div class="label">Potential Cost</div>
                    <div class="kpi">${open_change_cost:,.0f}</div>
                </div>

                <div>
                    <div class="label">Potential Days</div>
                    <div class="kpi">{open_change_days:.1f}</div>
                </div>
            </div>

            <div style="margin-top:12px;">
                <a href="/changes"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Review Change Events →
                </a>
            </div>
        </div>

        <div class="card">
            <h2>Quick Command</h2>

            <div class="action">
                <a href="/daily-report" style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Daily Report →
                </a>
            </div>

            <div class="action">
                <a href="/schedule-health" style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Schedule Health →
                </a>
            </div>

            <div class="action">
                <a href="/readiness" style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Lookahead Readiness →
                </a>
            </div>

            <div class="action">
                <a href="/actions" style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Action Center →
                </a>
            </div>
        </div>
    </div>
    """

    return shell("Daily Command", body)


@app.get("/schedule",response_class=HTMLResponse)
def schedule():
    pid=project_id(); c=db(); rows=c.execute("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,)).fetchall(); c.close()
    tr="".join(
        f'<tr>'
        f'<td>{esc(r["external_id"])}</td>'
        f'<td><b>{esc(r["name"])}</b></td>'
        f'<td>{esc(r["trade"])}</td>'
        f'<td>{r["start"]}</td>'
        f'<td>{r["finish"]}</td>'
        f'<td>{r["pct"]:.0f}%</td>'
        f'<td>{esc(r["status"])}</td>'
        f'<td><a href="/activities/{r["id"]}/edit" style="color:#f0b44d;text-decoration:none;font-weight:700;">Edit</a></td>'
        f'</tr>'
        for r in rows
    )
    return shell("Schedule",f'<div class="hero"><div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;"><div><div class="eyebrow">Schedule + Lookahead</div><h1>Field execution plan</h1></div><a href="/activities/new" style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">+ Add Activity</a></div></div><div class="card"><table><tr><th>ID</th><th>Activity</th><th>Trade</th><th>Start</th><th>Finish</th><th>%</th><th>Status</th><th>Action</th></tr>{tr}</table></div>')


@app.get("/make-ready",response_class=HTMLResponse)
def make_ready():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT m.*, a.external_id, a.name activity
        FROM make_ready m
        JOIN activities a ON a.id=m.activity_id
        WHERE m.project_id=? AND m.status='OPEN'
        ORDER BY
            CASE m.priority
                WHEN 'CRITICAL' THEN 1
                WHEN 'HIGH' THEN 2
                WHEN 'WATCH' THEN 3
                ELSE 4
            END,
            m.due
        """,
        (pid,)
    ).fetchall()

    closed = c.execute(
        """
        SELECT m.*, a.external_id, a.name activity
        FROM make_ready m
        JOIN activities a ON a.id=m.activity_id
        WHERE m.project_id=? AND m.status='COMPLETE'
        ORDER BY m.id DESC
        LIMIT 10
        """,
        (pid,)
    ).fetchall()

    c.close()

    open_html = "".join(
        f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {r["priority"]}">{r["priority"]}</span>
                    <b>{esc(r["external_id"])} - {esc(r["activity"])}</b>
                </div>

                <form method="post" action="/make-ready/{r["id"]}/close">
                    <button type="submit">Mark Cleared</button>
                </form>
            </div>

            <h3>{esc(r["title"])}</h3>
            <p>{esc(r["reason"])}</p>
            <div class="small">Clear by {esc(r["due"])}</div>
        </div>
        """
        for r in rows
    ) or '<div class="card"><div class="muted">No open make-ready items. Nice work.</div></div>'

    closed_html = "".join(
        f"""
        <div class="action">
            <span class="badge COMPLETE">CLEARED</span>
            <b>{esc(r["external_id"])} - {esc(r["activity"])}</b>
            <div>{esc(r["title"])}</div>
        </div>
        """
        for r in closed
    ) or '<div class="muted">No recently cleared items.</div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Predictive Make-Ready</div>
                <h1>Clear tomorrow's blockers before they hit the field.</h1>
            </div>

            <a href="/make-ready/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Make-Ready
            </a>
        </div>
    </div>

    <div class="grid2">
        <div>
            <h2>Open Blockers</h2>
            {open_html}
        </div>

        <div class="card">
            <h2>Recently Cleared</h2>
            {closed_html}
        </div>
    </div>
    """

    return shell("Make Ready", body)


@app.get("/field",response_class=HTMLResponse)
def field():
    pid=project_id(); c=db(); acts=c.execute("SELECT id,external_id,name FROM activities WHERE project_id=?",(pid,)).fetchall(); updates=c.execute("SELECT f.*,a.name activity FROM field_updates f JOIN activities a ON a.id=f.activity_id WHERE f.project_id=? ORDER BY f.id DESC LIMIT 15",(pid,)).fetchall(); c.close()
    opts="".join(f'<option value="{a["id"]}">{a["external_id"]} - {esc(a["name"])}</option>' for a in acts)
    recent="".join(f'<div class="action"><b>{u["update_type"]} - {esc(u["activity"])}</b><div>{esc(u["text"])}</div><div class="small">{u["created"]}</div></div>' for u in updates) or '<div class="muted">No updates yet.</div>'
    body=f'<div class="hero"><div class="eyebrow">Field Execution</div><h1>Capture what changed today.</h1></div><div class="grid2"><div class="card"><form method="post" action="/field/add"><select name="activity_id">{opts}</select><br><br><select name="update_type"><option>PROGRESS</option><option>BLOCKER</option><option>QUALITY</option><option>INSPECTION</option><option>DELIVERY</option></select><br><br><textarea name="text" placeholder="What changed in the field?"></textarea><br><br><button>Save field update</button></form></div><div class="card"><h2>Recent field updates</h2>{recent}</div></div>'
    return shell("Field",body)


@app.post("/field/add")
def add_field(activity_id:int=Form(...),update_type:str=Form(...),text:str=Form(...)):
    pid=project_id(); c=db(); c.execute("INSERT INTO field_updates(project_id,activity_id,update_type,text,created) VALUES(?,?,?,?,?)",(pid,activity_id,update_type,text,date.today().isoformat())); c.commit(); c.close()
    return RedirectResponse("/field",303)


@app.get("/subcontractors",response_class=HTMLResponse)
def subcontractors():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT *
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    updates = c.execute(
        """
        SELECT u.*, s.name AS sub_name, s.trade AS sub_trade
        FROM subcontractor_updates u
        JOIN subs s ON s.id=u.sub_id
        WHERE u.project_id=?
        ORDER BY u.update_date DESC, u.id DESC
        LIMIT 25
        """,
        (pid,)
    ).fetchall()

    c.close()

    latest_by_sub = {}
    for u in updates:
        if u["sub_id"] not in latest_by_sub:
            latest_by_sub[u["sub_id"]] = u

    cards = ""

    for r in rows:
        latest = latest_by_sub.get(r["id"])

        if latest:
            status = latest["status"] or "WATCH"
            status_badge = status if status in ["CRITICAL", "HIGH", "WATCH", "READY", "LOW"] else "OPEN"
            detail = (
                f'<div class="small">Latest Update: {esc(latest["update_date"])}</div>'
                f'<p><b>Manpower:</b> {latest["manpower"] or 0}</p>'
                f'<p><b>Commitment:</b> {esc(latest["commitment"]) or "—"}</p>'
                f'<p><b>Issue:</b> {esc(latest["issue"]) or "—"}</p>'
                f'<span class="badge {status_badge}">{esc(status)}</span>'
            )
        else:
            detail = '<div class="muted">No field update recorded yet.</div>'

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
                <div>
                    <h3 style="margin-top:0;">{esc(r["name"])}</h3>
                    <div class="muted">{esc(r["trade"])}</div>
                </div>

                <a href="/subcontractors/{r["id"]}/update"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Log Update
                </a>
            </div>

            <div style="margin-top:14px;">
                {detail}
            </div>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No subcontractors added yet.</div></div>'

    recent_html = ""

    for u in updates[:12]:
        status = u["status"] or "WATCH"
        badge = status if status in ["CRITICAL", "HIGH", "WATCH", "READY", "LOW"] else "OPEN"

        recent_html += (
            f'<div class="action">'
            f'<span class="badge {badge}">{esc(status)}</span> '
            f'<b>{esc(u["sub_name"])}</b> · {esc(u["sub_trade"])}'
            f'<div class="small">{esc(u["update_date"])} · Manpower {u["manpower"] or 0}</div>'
            f'<div>{esc(u["commitment"]) or "No commitment entered."}</div>'
            f'<div class="small">{esc(u["issue"]) or "No issue entered."}</div>'
            f'</div>'
        )

    if not recent_html:
        recent_html = '<div class="muted">No subcontractor updates yet.</div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Subcontractor Intelligence</div>
                <h1>Know who is committed, who is staffed, and who needs attention.</h1>
            </div>

            <a href="/subcontractors/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Subcontractor
            </a>
        </div>
    </div>

    <div class="grid3">
        {cards}
    </div>

    <div class="card">
        <h2>Recent Trade Partner Updates</h2>
        {recent_html}
    </div>
    """

    return shell("Subcontractors", body)


@app.get("/subcontractors/{sub_id}/update", response_class=HTMLResponse)
def subcontractor_update_form(sub_id: int):
    pid = project_id()
    c = db()

    sub = c.execute(
        """
        SELECT *
        FROM subs
        WHERE id=? AND project_id=?
        """,
        (sub_id, pid)
    ).fetchone()

    c.close()

    if not sub:
        return RedirectResponse(url="/subcontractors", status_code=303)

    body = f"""
    <div class="hero">
        <div class="eyebrow">Subcontractor Intelligence</div>
        <h1>Log Trade Partner Update</h1>
        <div class="muted">{esc(sub["name"])} · {esc(sub["trade"])}</div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/subcontractors/{sub_id}/update">
            <label>Update Date</label>
            <input type="date" name="update_date" value="{date.today().isoformat()}" required>

            <label>Manpower</label>
            <input type="number" name="manpower" min="0" value="0">

            <label>Commitment</label>
            <textarea name="commitment" placeholder="Example: Complete level 2 overhead rough-in by Friday."></textarea>

            <label>Issue / Constraint</label>
            <textarea name="issue" placeholder="Example: Waiting on sleeves and access above ceiling."></textarea>

            <label>Status</label>
            <select name="status">
                <option value="READY">Ready / On Track</option>
                <option value="WATCH">Watch</option>
                <option value="HIGH">High Concern</option>
                <option value="CRITICAL">Critical</option>
                <option value="LOW">Low Concern</option>
            </select>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Update</button>
                <a href="/subcontractors"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Subcontractor Update", body)


@app.post("/subcontractors/{sub_id}/update")
def save_subcontractor_update(
    sub_id: int,
    update_date: str = Form(...),
    manpower: int = Form(0),
    commitment: str = Form(""),
    issue: str = Form(""),
    status: str = Form("WATCH")
):
    pid = project_id()
    c = db()

    sub = c.execute(
        "SELECT id FROM subs WHERE id=? AND project_id=?",
        (sub_id, pid)
    ).fetchone()

    if sub:
        c.execute(
            """
            INSERT INTO subcontractor_updates(
                project_id,
                sub_id,
                update_date,
                manpower,
                commitment,
                issue,
                status,
                created
            )
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (
                pid,
                sub_id,
                update_date,
                manpower,
                commitment.strip(),
                issue.strip(),
                status,
                date.today().isoformat()
            )
        )
        c.commit()

    c.close()
    return RedirectResponse(url="/subcontractors", status_code=303)


@app.get("/production",response_class=HTMLResponse)
def production():
    pid = project_id()
    c = db()

    acts = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    rows = c.execute(
        """
        SELECT p.*,a.external_id,a.name activity
        FROM production p
        JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=?
        ORDER BY p.work_date DESC,p.id DESC
        LIMIT 30
        """,
        (pid,)
    ).fetchall()

    c.close()

    opts = "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in acts
    )

    total_qty = sum((r["qty"] or 0) for r in rows)
    total_plan = sum((r["planned_qty"] or 0) for r in rows)

    overall_pct = 0
    if total_plan > 0:
        overall_pct = (total_qty / total_plan) * 100

    behind_count = 0
    onplan_count = 0

    tr = ""

    for r in rows:
        qty = r["qty"] or 0
        plan = r["planned_qty"] or 0

        if plan > 0:
            pct = (qty / plan) * 100
            variance = qty - plan

            if pct < 90:
                status = "BEHIND"
                badge = "CRITICAL"
                behind_count += 1
            elif pct < 100:
                status = "WATCH"
                badge = "WATCH"
            else:
                status = "ON PLAN"
                badge = "READY"
                onplan_count += 1
        else:
            pct = 0
            variance = qty
            status = "NO PLAN"
            badge = "OPEN"

        tr += f"""
        <tr>
            <td>{esc(r["work_date"])}</td>
            <td><b>{esc(r["external_id"])} - {esc(r["activity"])}</b></td>
            <td>{r["crew"] or 0}</td>
            <td>{qty:g}</td>
            <td>{plan:g}</td>
            <td>{esc(r["unit"])}</td>
            <td>{pct:.0f}%</td>
            <td>{variance:+g}</td>
            <td><span class="badge {badge}">{status}</span></td>
        </tr>
        """

    if not tr:
        tr = '<tr><td colspan="9" class="muted">No production records yet.</td></tr>'

    if not opts:
        form_html = """
        <div class="muted">
            Add a schedule activity before recording production.
        </div>
        <div style="margin-top:12px;">
            <a href="/activities/new"
               style="color:#f0b44d;text-decoration:none;font-weight:700;">
                + Add Activity
            </a>
        </div>
        """
    else:
        form_html = f"""
        <form method="post" action="/production/add">
            <label>Activity</label>
            <select name="activity_id" required>{opts}</select>

            <label>Crew Size</label>
            <input name="crew" type="number" min="0" placeholder="Example: 6">

            <label>Installed Quantity</label>
            <input name="qty" type="number" step="0.1" placeholder="Example: 420">

            <label>Planned Quantity</label>
            <input name="planned_qty" type="number" step="0.1" placeholder="Example: 500">

            <label>Unit</label>
            <input name="unit" placeholder="LF / SF / CY / EA">

            <button type="submit">Record Production</button>
        </form>
        """

    body = f"""
    <div class="hero">
        <div class="eyebrow">Production Intelligence</div>
        <h1>Measure the job before the schedule update does.</h1>
        <div class="muted">
            Track actual production against plan and flag underperformance early.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Production Records</div>
            <div class="kpi">{len(rows)}</div>
        </div>

        <div class="card">
            <div class="label">Overall To Plan</div>
            <div class="kpi">{overall_pct:.0f}%</div>
        </div>

        <div class="card">
            <div class="label">Behind Plan</div>
            <div class="kpi">{behind_count}</div>
        </div>

        <div class="card">
            <div class="label">On / Above Plan</div>
            <div class="kpi">{onplan_count}</div>
        </div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Record Production</h2>
            {form_html}
        </div>

        <div class="card">
            <h2>How BuildCommand Reads It</h2>
            <p>
                Below 90% of planned production is flagged as <b>Behind</b>.
                Between 90% and 99% is flagged as <b>Watch</b>.
                At or above plan is shown as <b>On Plan</b>.
            </p>
            <div class="small">
                These records can be used by the AI Assistant when evaluating field performance and schedule risk.
            </div>
        </div>
    </div>

    <div class="card">
        <h2>Production History</h2>

        <table>
            <tr>
                <th>Date</th>
                <th>Activity</th>
                <th>Crew</th>
                <th>Actual</th>
                <th>Plan</th>
                <th>Unit</th>
                <th>% Plan</th>
                <th>Variance</th>
                <th>Status</th>
            </tr>

            {tr}
        </table>
    </div>
    """

    return shell("Production", body)


@app.post("/production/add")
def add_prod(activity_id:int=Form(...),crew:int=Form(0),qty:float=Form(0),planned_qty:float=Form(0),unit:str=Form("")):
    pid=project_id(); c=db(); c.execute("INSERT INTO production(project_id,activity_id,work_date,crew,qty,planned_qty,unit) VALUES(?,?,?,?,?,?,?)",(pid,activity_id,date.today().isoformat(),crew,qty,planned_qty,unit)); c.commit(); c.close()
    return RedirectResponse("/production",303)


@app.get("/risk",response_class=HTMLResponse)
def risk():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM risks r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY r.score DESC
        """,
        (pid,)
    ).fetchall()

    c.close()

    html = "".join(
        f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {r["band"]}">{r["band"]}</span>
                    <b>{esc(r["external_id"])} - {esc(r["activity"])}</b>
                </div>

                <a href="/risk/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <h3>{r["score"]:.0f}/100</h3>
            <p>{esc(r["explanation"])}</p>
        </div>
        """
        for r in rows
    ) or '<div class="card"><div class="muted">No risks entered for this project yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Predictive Risk</div>
                <h1>What is most likely to hurt the job next?</h1>
                <div class="muted">
                    Track field and schedule risk with an explainable score.
                </div>
            </div>

            <a href="/risk/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Risk
            </a>
        </div>
    </div>

    {html}
    """

    return shell("Predictive Risk", body)


@app.get("/risk/new", response_class=HTMLResponse)
def new_risk_form():
    pid = project_id()
    c = db()

    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    options = "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    if not options:
        body = """
        <div class="hero">
            <div class="eyebrow">Predictive Risk</div>
            <h1>Add Risk</h1>
        </div>

        <div class="card">
            <p>This project has no schedule activities yet. Add an activity first.</p>
            <a href="/activities/new"
               style="color:#f0b44d;font-weight:700;text-decoration:none;">
                + Add Activity
            </a>
        </div>
        """
        return shell("Add Risk", body)

    body = f"""
    <div class="hero">
        <div class="eyebrow">Predictive Risk</div>
        <h1>Add Risk</h1>
        <div class="muted">{project_label}</div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/risk/new">

            <label>Activity</label>
            <select name="activity_id" required>
                {options}
            </select>

            <div class="grid2">
                <div>
                    <label>Risk Score</label>
                    <input
                        type="number"
                        name="score"
                        min="0"
                        max="100"
                        step="1"
                        value="50"
                        required
                    >
                </div>

                <div>
                    <label>Risk Band</label>
                    <select name="band">
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="WATCH">Watch</option>
                        <option value="LOW">Low</option>
                    </select>
                </div>
            </div>

            <label>Why Is This a Risk?</label>
            <textarea
                name="explanation"
                placeholder="Example: Material release is late and threatens the rough-in start."
                required
            ></textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Risk</button>

                <a href="/risk"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Add Risk", body)


@app.post("/risk/new")
def create_risk(
    activity_id: int = Form(...),
    score: float = Form(...),
    band: str = Form(...),
    explanation: str = Form(...)
):
    pid = project_id()
    score = max(0.0, min(100.0, score))

    c = db()

    activity = c.execute(
        "SELECT id FROM activities WHERE id=? AND project_id=?",
        (activity_id, pid)
    ).fetchone()

    if activity:
        c.execute(
            """
            INSERT INTO risks(
                project_id,
                activity_id,
                score,
                band,
                explanation
            )
            VALUES(?,?,?,?,?)
            """,
            (
                pid,
                activity_id,
                score,
                band,
                explanation.strip()
            )
        )
        c.commit()

    c.close()

    return RedirectResponse(url="/risk", status_code=303)


@app.get("/risk/{risk_id}/edit", response_class=HTMLResponse)
def edit_risk_form(risk_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM risks r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.id=? AND r.project_id=?
        """,
        (risk_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/risk", status_code=303)

    bands = ["CRITICAL", "HIGH", "WATCH", "LOW"]
    band_options = "".join(
        f'<option value="{b}" {"selected" if item["band"] == b else ""}>{b.title()}</option>'
        for b in bands
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Predictive Risk</div>
        <h1>Edit Risk</h1>
        <div class="muted">
            {esc(item["external_id"])} - {esc(item["activity"])}
        </div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/risk/{risk_id}/edit">

            <div class="grid2">
                <div>
                    <label>Risk Score</label>
                    <input
                        type="number"
                        name="score"
                        min="0"
                        max="100"
                        step="1"
                        value="{item["score"]:.0f}"
                        required
                    >
                </div>

                <div>
                    <label>Risk Band</label>
                    <select name="band">
                        {band_options}
                    </select>
                </div>
            </div>

            <label>Explanation</label>
            <textarea name="explanation" required>{esc(item["explanation"])}</textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Changes</button>

                <a href="/risk"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>

        <form method="post"
              action="/risk/{risk_id}/delete"
              style="margin-top:22px;padding-top:18px;border-top:1px solid #213042;">
            <button type="submit"
                    style="background:#492324;color:#ffb0b0;">
                Delete Risk
            </button>
        </form>
    </div>
    """

    return shell("Edit Risk", body)


@app.post("/risk/{risk_id}/edit")
def edit_risk(
    risk_id: int,
    score: float = Form(...),
    band: str = Form(...),
    explanation: str = Form(...)
):
    pid = project_id()
    score = max(0.0, min(100.0, score))

    c = db()
    c.execute(
        """
        UPDATE risks
        SET score=?, band=?, explanation=?
        WHERE id=? AND project_id=?
        """,
        (
            score,
            band,
            explanation.strip(),
            risk_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/risk", status_code=303)


@app.post("/risk/{risk_id}/delete")
def delete_risk(risk_id: int):
    pid = project_id()

    c = db()
    c.execute(
        "DELETE FROM risks WHERE id=? AND project_id=?",
        (risk_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/risk", status_code=303)


@app.get("/recovery",response_class=HTMLResponse)
def recovery():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM recovery r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY
            CASE r.status
                WHEN 'APPROVED' THEN 1
                WHEN 'PROPOSED' THEN 2
                WHEN 'REJECTED' THEN 3
                ELSE 4
            END,
            r.days_recovered DESC,
            r.est_cost ASC
        """,
        (pid,)
    ).fetchall()

    acts = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    opts = "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in acts
    )

    total_scenarios = len(rows)
    approved = sum(1 for r in rows if r["status"] == "APPROVED")
    proposed = sum(1 for r in rows if r["status"] == "PROPOSED")

    best_value = None
    best_value_score = None

    scenario_cards = ""

    for r in rows:
        days = r["days_recovered"] or 0
        cost = r["est_cost"] or 0

        if days > 0:
            cost_per_day = cost / days
            value_text = f'${cost_per_day:,.0f} / recovered day'

            if best_value_score is None or cost_per_day < best_value_score:
                best_value_score = cost_per_day
                best_value = r["id"]
        else:
            cost_per_day = None
            value_text = "No recovered days entered"

        status_badge = (
            "READY" if r["status"] == "APPROVED"
            else "HIGH" if r["status"] == "REJECTED"
            else "OPEN"
        )

        best_badge = (
            '<span class="badge READY">BEST VALUE</span>'
            if best_value == r["id"]
            else ""
        )

        scenario_cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {status_badge}">{esc(r["status"])}</span>
                    {best_badge}
                    <h3 style="margin:10px 0 4px;">{esc(r["scenario"]).replace("_"," ").title()}</h3>
                    <div class="muted">{esc(r["external_id"])} - {esc(r["activity"])}</div>
                </div>

                <form method="post" action="/recovery/{r["id"]}/delete">
                    <button type="submit" style="background:#492324;color:#ffb0b0;">
                        Delete
                    </button>
                </form>
            </div>

            <div class="grid3" style="margin-top:14px;">
                <div>
                    <div class="label">Days Recovered</div>
                    <div class="kpi">{days:.1f}</div>
                </div>

                <div>
                    <div class="label">Estimated Cost</div>
                    <div class="kpi">${cost:,.0f}</div>
                </div>

                <div>
                    <div class="label">Cost / Day</div>
                    <div style="font-size:20px;font-weight:800;">{value_text}</div>
                </div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px;">
                <form method="post" action="/recovery/{r["id"]}/approve">
                    <button type="submit">Approve</button>
                </form>

                <form method="post" action="/recovery/{r["id"]}/reject">
                    <button type="submit" style="background:#43381b;color:#ffd779;">
                        Reject
                    </button>
                </form>
            </div>
        </div>
        """

    if not scenario_cards:
        scenario_cards = '<div class="card"><div class="muted">No recovery scenarios saved yet.</div></div>'

    if opts:
        form = f"""
        <div class="card">
            <h2>Test Recovery Idea</h2>

            <form method="post" action="/recovery/add">
                <label>Activity</label>
                <select name="activity_id" required>
                    {opts}
                </select>

                <label>Scenario</label>
                <select name="scenario">
                    <option value="ADD_CREW">Add Crew</option>
                    <option value="OVERTIME">Overtime</option>
                    <option value="WORK_SATURDAY">Work Saturday</option>
                    <option value="RESEQUENCE">Resequence Work</option>
                    <option value="CLEAR_CONSTRAINT">Clear Constraint</option>
                    <option value="SECOND_SHIFT">Second Shift</option>
                </select>

                <label>Modeled Days Recovered</label>
                <input
                    name="days_recovered"
                    type="number"
                    step="0.1"
                    min="0"
                    placeholder="Example: 2.5"
                >

                <label>Estimated Cost</label>
                <input
                    name="est_cost"
                    type="number"
                    step="100"
                    min="0"
                    placeholder="Example: 7500"
                >

                <button type="submit">Save Recovery Scenario</button>
            </form>
        </div>
        """
    else:
        form = """
        <div class="card">
            <h2>Test Recovery Idea</h2>
            <p>Add a schedule activity before creating a recovery scenario.</p>
            <a href="/activities/new"
               style="color:#f0b44d;text-decoration:none;font-weight:700;">
                + Add Activity
            </a>
        </div>
        """

    body = f"""
    <div class="hero">
        <div class="eyebrow">Recovery Intelligence</div>
        <h1>Compare recovery before spending money.</h1>
        <div class="muted">
            Model time recovered, cost, and decision status before committing resources.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Scenarios</div>
            <div class="kpi">{total_scenarios}</div>
        </div>

        <div class="card">
            <div class="label">Proposed</div>
            <div class="kpi">{proposed}</div>
        </div>

        <div class="card">
            <div class="label">Approved</div>
            <div class="kpi">{approved}</div>
        </div>

        <div class="card">
            <div class="label">Best Cost / Day</div>
            <div class="kpi">
                {"$"+format(best_value_score,",.0f") if best_value_score is not None else "—"}
            </div>
        </div>
    </div>

    <div class="grid2">
        {form}

        <div class="card">
            <h2>How To Use Recovery Intelligence</h2>
            <p>
                Compare options by how many schedule days they recover and what each recovered day costs.
                Approve the option you intend to execute and reject scenarios you no longer want considered.
            </p>
            <div class="small">
                BuildCommand AI can use these recovery scenarios when evaluating project risk and next actions.
            </div>
        </div>
    </div>

    <div>
        <h2>Recovery Scenarios</h2>
        {scenario_cards}
    </div>
    """

    return shell("Recovery", body)


@app.post("/recovery/add")
def add_recovery(
    activity_id: int = Form(...),
    scenario: str = Form(...),
    days_recovered: float = Form(0),
    est_cost: float = Form(0)
):
    pid = project_id()

    days_recovered = max(0.0, days_recovered)
    est_cost = max(0.0, est_cost)

    c = db()

    activity = c.execute(
        "SELECT id FROM activities WHERE id=? AND project_id=?",
        (activity_id, pid)
    ).fetchone()

    if activity:
        c.execute(
            """
            INSERT INTO recovery(
                project_id,
                activity_id,
                scenario,
                days_recovered,
                est_cost,
                status
            )
            VALUES(?,?,?,?,?,?)
            """,
            (
                pid,
                activity_id,
                scenario,
                days_recovered,
                est_cost,
                "PROPOSED"
            )
        )
        c.commit()

    c.close()

    return RedirectResponse("/recovery", 303)


@app.post("/recovery/{scenario_id}/approve")
def approve_recovery(scenario_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE recovery
        SET status='APPROVED'
        WHERE id=? AND project_id=?
        """,
        (scenario_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse("/recovery", 303)


@app.post("/recovery/{scenario_id}/reject")
def reject_recovery(scenario_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE recovery
        SET status='REJECTED'
        WHERE id=? AND project_id=?
        """,
        (scenario_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse("/recovery", 303)


@app.post("/recovery/{scenario_id}/delete")
def delete_recovery(scenario_id: int):
    pid = project_id()

    c = db()
    c.execute(
        "DELETE FROM recovery WHERE id=? AND project_id=?",
        (scenario_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse("/recovery", 303)


@app.get("/memory",response_class=HTMLResponse)
def memory():
    pid=project_id(); c=db(); rows=c.execute("SELECT * FROM memory WHERE project_id=? ORDER BY confidence DESC",(pid,)).fetchall(); c.close()
    html="".join(f'<div class="card"><h3>{esc(r["category"])}</h3><p>{esc(r["insight"])}</p><div class="small">Confidence {r["confidence"]:.0%}</div></div>' for r in rows)
    return shell("Company Memory",'<div class="hero"><div class="eyebrow">Company Construction Memory</div><h1>Every project makes the next one smarter.</h1></div>'+html)


@app.get("/playbooks",response_class=HTMLResponse)
def playbooks():
    body='<div class="hero"><div class="eyebrow">Company Playbooks</div><h1>Turn repeated evidence into how your company runs work.</h1></div><div class="card"><h3>MEP Start Readiness</h3><p>Confirm manpower, material, predecessor completion, access, and inspection prerequisites. Escalate unresolved items before start.</p><div class="small">Evidence-backed company operating routine.</div></div><div class="card"><h3>Schedule Drift Response</h3><p>Verify field status, identify the controlling constraint, compare the field plan with the master schedule, test recovery, and document the agreed plan.</p></div>'
    return shell("Playbooks",body)


@app.get("/portfolio",response_class=HTMLResponse)
def portfolio():
    current_pid = project_id()
    c = db()

    projects = c.execute(
        """
        SELECT *
        FROM projects
        WHERE company_id=?
        ORDER BY
            CASE status
                WHEN 'ACTIVE' THEN 1
                WHEN 'PLANNING' THEN 2
                WHEN 'ON_HOLD' THEN 3
                WHEN 'COMPLETE' THEN 4
                ELSE 5
            END,
            name
        """,
        (current_company_id(),)
    ).fetchall()

    cards = []
    portfolio_scores = []

    for p in projects:
        pid = p["id"]

        risks = c.execute(
            "SELECT * FROM risks WHERE project_id=?",
            (pid,)
        ).fetchall()

        mr = c.execute(
            """
            SELECT COUNT(*) n
            FROM make_ready
            WHERE project_id=? AND status='OPEN'
            """,
            (pid,)
        ).fetchone()["n"]

        activities = c.execute(
            """
            SELECT COUNT(*) n
            FROM activities
            WHERE project_id=?
            """,
            (pid,)
        ).fetchone()["n"]

        active_activities = c.execute(
            """
            SELECT COUNT(*) n
            FROM activities
            WHERE project_id=? AND status='IN_PROGRESS'
            """,
            (pid,)
        ).fetchone()["n"]

        report = c.execute(
            """
            SELECT report_date, manpower, delays
            FROM daily_reports
            WHERE project_id=?
            ORDER BY report_date DESC, id DESC
            LIMIT 1
            """,
            (pid,)
        ).fetchone()

        crit = sum(r["band"] == "CRITICAL" for r in risks)
        high = sum(r["band"] == "HIGH" for r in risks)
        watch = sum(r["band"] == "WATCH" for r in risks)

        score = min(
            100,
            crit * 30 +
            high * 15 +
            watch * 5 +
            mr * 5
        )

        portfolio_scores.append(score)

        if score >= 70:
            attention_band = "CRITICAL"
            attention_text = "Immediate Attention"
        elif score >= 40:
            attention_band = "HIGH"
            attention_text = "Needs Attention"
        elif score >= 15:
            attention_band = "WATCH"
            attention_text = "Watch"
        else:
            attention_band = "READY"
            attention_text = "Stable"

        selected_badge = (
            '<span class="badge READY">CURRENT</span>'
            if pid == current_pid
            else ""
        )

        latest_report = esc(report["report_date"]) if report else "No report"
        latest_manpower = report["manpower"] if report else 0
        latest_delay = esc(report["delays"]) if report and report["delays"] else "No delay noted"

        card = f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <div class="eyebrow">{esc(p["number"])}</div>
                    <h2 style="margin:5px 0;">{esc(p["name"])}</h2>
                    <div class="muted">{esc(p["status"]).replace("_"," ").title()}</div>
                </div>

                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    {selected_badge}
                    <span class="badge {attention_band}">{attention_text}</span>
                </div>
            </div>

            <div class="grid4" style="margin-top:16px;">
                <div>
                    <div class="label">Attention</div>
                    <div class="kpi">{score}</div>
                </div>
                <div>
                    <div class="label">Critical</div>
                    <div class="kpi">{crit}</div>
                </div>
                <div>
                    <div class="label">High</div>
                    <div class="kpi">{high}</div>
                </div>
                <div>
                    <div class="label">Make Ready</div>
                    <div class="kpi">{mr}</div>
                </div>
            </div>

            <div style="margin-top:16px;">
                <div class="small">
                    Activities: {activities} · Active: {active_activities}
                </div>
                <div class="small">
                    Latest report: {latest_report} · Manpower: {latest_manpower or 0}
                </div>
                <div class="small">
                    Latest delay signal: {latest_delay}
                </div>
            </div>

            <form method="post" action="/projects/select" style="margin-top:16px;">
                <input type="hidden" name="project_id" value="{pid}">
                <button type="submit">Open Project</button>
            </form>
        </div>
        """

        cards.append((score, card))

    c.close()

    cards.sort(key=lambda x: x[0], reverse=True)
    cards_html = "".join(card for _, card in cards)

    total_projects = len(projects)
    active_projects = sum(p["status"] == "ACTIVE" for p in projects)
    high_attention = sum(score >= 40 for score in portfolio_scores)
    avg_score = (
        sum(portfolio_scores) / len(portfolio_scores)
        if portfolio_scores
        else 0
    )

    if not cards_html:
        cards_html = '<div class="card"><div class="muted">No projects created yet.</div></div>'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Executive Intelligence</div>
        <h1>Which projects need intervention?</h1>
        <div class="muted">
            Portfolio-wide risk, make-ready, field reporting, and schedule attention in one view.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Projects</div>
            <div class="kpi">{total_projects}</div>
        </div>

        <div class="card">
            <div class="label">Active Projects</div>
            <div class="kpi">{active_projects}</div>
        </div>

        <div class="card">
            <div class="label">Need Attention</div>
            <div class="kpi">{high_attention}</div>
        </div>

        <div class="card">
            <div class="label">Avg Attention</div>
            <div class="kpi">{avg_score:.0f}</div>
        </div>
    </div>

    <div class="grid2">
        {cards_html}
    </div>
    """

    return shell("Portfolio", body)


@app.get("/activities/new", response_class=HTMLResponse)
def new_activity_form():
    pid = project_id()
    c = db()
    project = c.execute("SELECT name,number FROM projects WHERE id=?", (pid,)).fetchone()
    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Schedule</div>
        <h1>Add Activity</h1>
        <div class="muted">Add a schedule activity to {project_label}.</div>
    </div>
    <div class="card" style="max-width:760px;">
        <form method="post" action="/activities/new">
            <div class="grid2">
                <div><label>Activity ID</label><input type="text" name="external_id" placeholder="Example: A600" required></div>
                <div><label>Trade</label><input type="text" name="trade" placeholder="Example: Electrical" required></div>
            </div>
            <label>Activity Name</label>
            <input type="text" name="name" placeholder="Example: Electrical Rough-In" required>
            <div class="grid2">
                <div><label>Start Date</label><input type="date" name="start" required></div>
                <div><label>Finish Date</label><input type="date" name="finish" required></div>
            </div>
            <div class="grid2">
                <div><label>Percent Complete</label><input type="number" name="pct" min="0" max="100" step="1" value="0" required></div>
                <div>
                    <label>Status</label>
                    <select name="status">
                        <option value="NOT_STARTED">Not Started</option>
                        <option value="IN_PROGRESS">In Progress</option>
                        <option value="COMPLETE">Complete</option>
                        <option value="HOLD">Hold</option>
                    </select>
                </div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Activity</button>
                <a href="/schedule" style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">Cancel</a>
            </div>
        </form>
    </div>
    """
    return shell("Add Activity", body)


@app.post("/activities/new")
def create_activity(
    external_id: str = Form(...),
    name: str = Form(...),
    trade: str = Form(...),
    start: str = Form(...),
    finish: str = Form(...),
    pct: float = Form(0),
    status: str = Form("NOT_STARTED")
):
    pid = project_id()
    pct = max(0.0, min(100.0, pct))
    c = db()
    c.execute(
        """
        INSERT INTO activities(project_id,external_id,name,trade,start,finish,pct,status)
        VALUES(?,?,?,?,?,?,?,?)
        """,
        (pid, external_id.strip(), name.strip(), trade.strip(), start, finish, pct, status)
    )
    c.commit()
    c.close()
    return RedirectResponse(url="/schedule", status_code=303)

