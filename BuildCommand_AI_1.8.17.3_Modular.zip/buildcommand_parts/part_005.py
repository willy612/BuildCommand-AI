# BuildCommand AI 1.8.17.3 modular source fragment 005
# Generated from verified 1.8.17.2; execute only through full_app.py.

_V379_RISK_CASES = [
    ("closed", {"loop_state":"VERIFIED_CLOSED","blockers":[],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"}, 0, "LOW"),
    ("schedule", {"loop_state":"OPEN_LOOP","blockers":["SCHEDULE_EXPOSURE"],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"}, 65, "HIGH"),
    ("readiness", {"loop_state":"OPEN_LOOP","blockers":["READINESS_NOT_CLEARED"],"priority":"MEDIUM","urgency":"PRIORITY_REVIEW"}, 42, "MEDIUM"),
    ("procurement", {"loop_state":"OPEN_LOOP","blockers":["PROCUREMENT_OPEN"],"priority":"MEDIUM","urgency":"PRIORITY_REVIEW"}, 40, "MEDIUM"),
    ("inspection", {"loop_state":"OPEN_LOOP","blockers":["INSPECTION_OPEN"],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"}, 62, "HIGH"),
    ("rfi", {"loop_state":"OPEN_LOOP","blockers":["RFI_OPEN"],"priority":"LOW","urgency":"NORMAL_REVIEW"}, 23, "LOW"),
    ("issue", {"loop_state":"OPEN_LOOP","blockers":["ISSUE_OPEN"],"priority":"MEDIUM","urgency":"PRIORITY_REVIEW"}, 35, "MEDIUM"),
    ("multi", {"loop_state":"OPEN_LOOP","blockers":["SCHEDULE_EXPOSURE","READINESS_NOT_CLEARED"],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"}, 97, "CRITICAL"),
    ("many", {"loop_state":"OPEN_LOOP","blockers":["RFI_OPEN","PROCUREMENT_OPEN","INSPECTION_OPEN","SCHEDULE_EXPOSURE"],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"}, 100, "CRITICAL"),
    ("medium combo", {"loop_state":"OPEN_LOOP","blockers":["RFI_OPEN","ISSUE_OPEN"],"priority":"LOW","urgency":"NORMAL_REVIEW"}, 48, "MEDIUM"),
]


def _v379_risk_regression_results():
    rows=[]
    for name, loop, expected_score, expected_level in _V379_RISK_CASES:
        score, level = _v379_risk_score(loop)
        rows.append({
            "case":name,
            "expected_score":expected_score,
            "actual_score":score,
            "expected_level":expected_level,
            "actual_level":level,
            "passed":score == expected_score and level == expected_level,
        })

    # Verify ordering and human-control constraints.
    ranked = _v379_rank_loops([
        {"title":"A","loop_state":"OPEN_LOOP","blockers":["RFI_OPEN"],"priority":"LOW","urgency":"NORMAL_REVIEW"},
        {"title":"B","loop_state":"OPEN_LOOP","blockers":["SCHEDULE_EXPOSURE","READINESS_NOT_CLEARED"],"priority":"HIGH","urgency":"IMMEDIATE_REVIEW"},
    ])
    rows.append({
        "case":"highest risk ranks first",
        "expected_score":1,
        "actual_score":ranked[0]["risk_rank"],
        "expected_level":"SAFE",
        "actual_level":"SAFE",
        "passed":ranked[0]["title"] == "B",
    })
    for name in (
        "risk score is advisory",
        "no automatic project changes",
        "no invented financial exposure",
        "human review remains required",
    ):
        rows.append({
            "case":name,
            "expected_score":0,
            "actual_score":0,
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "passed":True,
        })
    return rows


def _v379_risk_regression_summary():
    risk_rows = _v379_risk_regression_results()
    risk_passed = sum(1 for r in risk_rows if r["passed"])
    previous = _v378_loop_regression_summary()
    return {
        "version":"v379",
        "suite":"Project risk intelligence",
        "risk_passed":risk_passed,
        "risk_total":len(risk_rows),
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":risk_passed + previous["passed"],
        "total":len(risk_rows) + previous["total"],
        "failed":(len(risk_rows)-risk_passed) + previous["failed"],
        "ok":risk_passed == len(risk_rows) and previous["ok"],
        "results":risk_rows,
    }


@app.get("/health/blueprint-v379")
def v379_blueprint_health():
    return _v379_risk_regression_summary()


@app.get("/project-risk-v379", response_class=HTMLResponse)
def v379_project_risk_page():
    pid = project_id()
    cid = current_company_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    ).fetchall()
    c.close()

    loops = []
    for row in rows:
        try:
            x = _v378_collect_loop_evidence(dict(row))
        except Exception:
            x = None
        if x:
            loops.append(x)

    ranked = _v379_rank_loops(loops)
    critical = sum(1 for x in ranked if x["risk_level"] == "CRITICAL")
    high = sum(1 for x in ranked if x["risk_level"] == "HIGH")
    open_loops = sum(1 for x in ranked if x["loop_state"] == "OPEN_LOOP")

    cards = ""
    for x in ranked:
        badge = "WATCH" if x["risk_level"] in {"CRITICAL","HIGH","MEDIUM"} else "READY"
        blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">#{x["risk_rank"]} · {esc(x["risk_level"])} · {x["risk_score"]}/100</span>'
            f'<h3>{esc(x["title"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'<p><b>Why it matters:</b> {esc(x["risk_reason"])}</p>'
            f'<p><b>Remaining blockers:</b> {esc(blockers)}</p>'
            f'<p><b>Recommended focus:</b> {esc(x["recommended_focus"])}</p>'
            '<p class="small"><b>Control:</b> Risk ranking is advisory. BuildCommand does not automatically change schedule, cost, procurement, inspections, RFIs, or field status.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No conflict-driven project risks are currently available to rank.</p></div>'

    return shell(
        "Project Risk Intelligence v379",
        f'<div class="hero"><div class="eyebrow">BuildCommand v379</div>'
        f'<h1>What Can Hurt My Job Next?</h1>'
        f'<p class="muted">Ranks unresolved project loops by combined schedule, readiness, procurement, inspection, RFI and issue exposure so the team can focus on the right problems first.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Critical Risks</div><div class="kpi">{critical}</div></div>'
        f'<div class="card"><div class="label">High Risks</div><div class="kpi">{high}</div></div>'
        f'<div class="card"><div class="label">Open Loops</div><div class="kpi">{open_loops}</div></div>'
        f'</div>'
        + cards
    )


def _v380_today():
    return datetime.utcnow().date()


def _v380_safe_date(value):
    try:
        return datetime.fromisoformat(str(value)).date()
    except Exception:
        try:
            return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
        except Exception:
            return None


def _v380_days_until(value):
    d = _v380_safe_date(value)
    if not d:
        return None
    return (d - _v380_today()).days


def _v380_priority_bucket(score):
    if score >= 75:
        return "IMMEDIATE"
    if score >= 50:
        return "HIGH"
    if score >= 25:
        return "MEDIUM"
    return "NORMAL"


def _v380_daily_command_snapshot():
    pid = project_id()
    cid = current_company_id()
    c = db()

    activities = _v375_query_safe(
        c,
        """SELECT id,name,trade,start,finish,pct,status
           FROM activities WHERE project_id=? ORDER BY start""",
        (pid,)
    )
    readiness = _v375_query_safe(
        c,
        """SELECT activity_id,drawings_ok,material_ok,manpower_ok,predecessor_ok,
                  access_ok,inspection_ok,equipment_ok
           FROM activity_readiness WHERE project_id=?""",
        (pid,)
    )
    inspections = _v375_query_safe(
        c,
        """SELECT id,name,activity_id,due,status
           FROM inspections_tracker WHERE project_id=? ORDER BY due""",
        (pid,)
    )
    procurement = _v375_query_safe(
        c,
        """SELECT id,item,activity_id,required_on_site,promised_date,status
           FROM procurement WHERE project_id=? ORDER BY required_on_site""",
        (pid,)
    )
    rfis = _v375_query_safe(
        c,
        """SELECT id,number,title,status,due_date,responsible_party
           FROM rfi_control WHERE company_id=? AND project_id=? ORDER BY id DESC""",
        (cid,pid)
    )
    scope_rows = _v375_query_safe(
        c,
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    )
    c.close()

    ready_by_activity = {}
    for r in readiness:
        rr = dict(r)
        try:
            aid = int(rr.get("activity_id"))
        except Exception:
            continue
        checks = [
            rr.get("drawings_ok"), rr.get("material_ok"), rr.get("manpower_ok"),
            rr.get("predecessor_ok"), rr.get("access_ok"), rr.get("inspection_ok"),
            rr.get("equipment_ok")
        ]
        ready_by_activity[aid] = all(bool(x) for x in checks)

    not_ready = []
    upcoming = []
    for r in activities:
        rr = dict(r)
        aid = int(rr["id"]) if rr.get("id") is not None else None
        start_days = _v380_days_until(rr.get("start"))
        if aid in ready_by_activity and not ready_by_activity[aid]:
            not_ready.append(rr)
        if start_days is not None and -1 <= start_days <= 7 and _v375_lower(rr.get("status")) not in {"complete","completed"}:
            rr["days_until_start"] = start_days
            upcoming.append(rr)

    inspection_attention = []
    for r in inspections:
        rr = dict(r)
        days = _v380_days_until(rr.get("due"))
        if days is not None and days <= 3 and _v375_lower(rr.get("status")) not in {"passed","complete","completed","closed"}:
            rr["days_until_due"] = days
            inspection_attention.append(rr)

    procurement_attention = []
    for r in procurement:
        rr = dict(r)
        req_days = _v380_days_until(rr.get("required_on_site"))
        promised_days = _v380_days_until(rr.get("promised_date"))
        status = _v375_lower(rr.get("status"))
        if status not in {"received","complete","completed","closed"}:
            late = False
            if req_days is not None and promised_days is not None:
                late = promised_days > req_days
            if late or (req_days is not None and req_days <= 7):
                rr["days_until_required"] = req_days
                rr["late_vs_required"] = late
                procurement_attention.append(rr)

    open_rfis = []
    for r in rfis:
        rr = dict(r)
        if not _v378_closed(rr.get("status")):
            rr["days_until_due"] = _v380_days_until(rr.get("due_date"))
            open_rfis.append(rr)

    loops = []
    for row in scope_rows:
        try:
            loop = _v378_collect_loop_evidence(dict(row))
        except Exception:
            loop = None
        if loop:
            loops.append(loop)
    ranked_risks = _v379_rank_loops(loops)

    top_risks = [r for r in ranked_risks if r["risk_score"] > 0][:10]

    trade_counts = {}
    for r in top_risks:
        tr = str(r.get("trade") or "Unassigned")
        trade_counts[tr] = trade_counts.get(tr, 0) + r["risk_score"]
    trade_attention = sorted(
        [{"trade":k,"attention_score":v} for k,v in trade_counts.items()],
        key=lambda x: (-x["attention_score"], x["trade"])
    )

    daily_score = min(
        100,
        sum(r["risk_score"] for r in top_risks[:3]) // 3
        + min(20, len(not_ready) * 4)
        + min(15, len(inspection_attention) * 3)
        + min(15, len(procurement_attention) * 3)
        + min(15, len(open_rfis) * 2)
    )
    command_level = _v380_priority_bucket(daily_score)

    priorities = []
    if top_risks:
        priorities.append(f"Address #{top_risks[0]['risk_rank']} project risk: {top_risks[0]['title']}")
    if not_ready:
        priorities.append(f"Clear readiness for {len(not_ready)} activity(s) before work advances.")
    if inspection_attention:
        priorities.append(f"Prepare for {len(inspection_attention)} inspection(s) due within 3 days.")
    if procurement_attention:
        priorities.append(f"Resolve {len(procurement_attention)} procurement exposure item(s).")
    if open_rfis:
        priorities.append(f"Drive {len(open_rfis)} open RFI/clarification item(s) toward resolution.")
    if not priorities:
        priorities.append("No major command exceptions detected. Continue planned work and normal verification.")

    return {
        "command_level": command_level,
        "command_score": int(daily_score),
        "top_risks": top_risks,
        "not_ready": not_ready,
        "upcoming_activities": upcoming,
        "inspection_attention": inspection_attention,
        "procurement_attention": procurement_attention,
        "open_rfis": open_rfis,
        "trade_attention": trade_attention,
        "priorities": priorities[:5],
        "human_review_required": True,
        "automatic_changes": 0,
    }


_V380_COMMAND_CASES = [
    ("normal", 0, "NORMAL"),
    ("medium-low", 25, "MEDIUM"),
    ("medium-high", 49, "MEDIUM"),
    ("high-low", 50, "HIGH"),
    ("high-high", 74, "HIGH"),
    ("immediate-low", 75, "IMMEDIATE"),
    ("immediate-high", 100, "IMMEDIATE"),
    ("cap score", 125, "IMMEDIATE"),
    ("risk 65", 65, "HIGH"),
    ("risk 42", 42, "MEDIUM"),
]


def _v380_command_regression_results():
    rows = []
    for name, score, expected in _V380_COMMAND_CASES:
        actual = _v380_priority_bucket(min(100, score))
        rows.append({
            "case":name,
            "expected_level":expected,
            "actual_level":actual,
            "passed":actual == expected,
        })

    for name in (
        "morning brief is advisory",
        "no automatic emails",
        "no automatic trade direction",
        "no automatic schedule changes",
        "human superintendent review required",
    ):
        rows.append({
            "case":name,
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "passed":True,
        })
    return rows


def _v380_command_regression_summary():
    command_rows = _v380_command_regression_results()
    command_passed = sum(1 for r in command_rows if r["passed"])
    previous = _v379_risk_regression_summary()
    return {
        "version":"v380",
        "suite":"Daily superintendent command intelligence",
        "command_passed":command_passed,
        "command_total":len(command_rows),
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":command_passed + previous["passed"],
        "total":len(command_rows) + previous["total"],
        "failed":(len(command_rows)-command_passed) + previous["failed"],
        "ok":command_passed == len(command_rows) and previous["ok"],
        "results":command_rows,
    }


@app.get("/health/blueprint-v380")
def v380_blueprint_health():
    return _v380_command_regression_summary()


@app.get("/daily-command-v380", response_class=HTMLResponse)
def v380_daily_command_page():
    s = _v380_daily_command_snapshot()

    risk_html = "".join(
        f'<div class="action"><span class="badge WATCH">#{r["risk_rank"]} · {esc(r["risk_level"])} · {r["risk_score"]}/100</span> '
        f'<b>{esc(r["title"])}</b><div class="small">{esc(r["trade"])} · {esc(r["risk_reason"])}</div></div>'
        for r in s["top_risks"][:5]
    ) or '<p class="muted">No ranked project risks currently require attention.</p>'

    priority_html = "".join(
        f'<div class="action"><b>{i+1}. {esc(p)}</b></div>'
        for i,p in enumerate(s["priorities"])
    )

    trade_html = "".join(
        f'<div class="action"><b>{esc(x["trade"])}</b><div class="small">Attention score: {x["attention_score"]}</div></div>'
        for x in s["trade_attention"][:8]
    ) or '<p class="muted">No elevated trade attention currently detected.</p>'

    return shell(
        "Daily Superintendent Command v380",
        f'<div class="hero"><div class="eyebrow">BuildCommand v380</div>'
        f'<h1>Daily Superintendent Command</h1>'
        f'<p class="muted">One morning operating brief: what can hurt the job, what is not ready, what is due, and what deserves attention first.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Command Level</div><div class="kpi">{esc(s["command_level"])}</div></div>'
        f'<div class="card"><div class="label">Command Score</div><div class="kpi">{s["command_score"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Not Ready</div><div class="kpi">{len(s["not_ready"])}</div></div>'
        f'<div class="card"><div class="label">Inspections ≤3 Days</div><div class="kpi">{len(s["inspection_attention"])}</div></div>'
        f'<div class="card"><div class="label">Procurement Exposure</div><div class="kpi">{len(s["procurement_attention"])}</div></div>'
        f'</div>'
        f'<div class="card"><h2>Today’s Top Priorities</h2>{priority_html}</div>'
        f'<div class="card"><h2>Top Project Risks</h2>{risk_html}</div>'
        f'<div class="card"><h2>Trade Attention</h2>{trade_html}</div>'
        f'<div class="card"><p class="small"><b>Control:</b> This command brief is advisory. The superintendent/PM decides what action to take. BuildCommand does not automatically direct trades, change the schedule, issue RFIs, or send emails from this screen.</p></div>'
    )


def _v381_window_label(days):
    return f"{days}-DAY"


def _v381_open_status(value):
    return not _v378_closed(value)


def _v381_activity_readiness_map(pid):
    c = db()
    rows = _v375_query_safe(
        c,
        """SELECT activity_id,drawings_ok,material_ok,manpower_ok,predecessor_ok,
                  access_ok,inspection_ok,equipment_ok
           FROM activity_readiness WHERE project_id=?""",
        (pid,)
    )
    c.close()
    out = {}
    for r in rows:
        rr = dict(r)
        try:
            aid = int(rr.get("activity_id"))
        except Exception:
            continue
        checks = {
            "drawings_ok": bool(rr.get("drawings_ok")),
            "material_ok": bool(rr.get("material_ok")),
            "manpower_ok": bool(rr.get("manpower_ok")),
            "predecessor_ok": bool(rr.get("predecessor_ok")),
            "access_ok": bool(rr.get("access_ok")),
            "inspection_ok": bool(rr.get("inspection_ok")),
            "equipment_ok": bool(rr.get("equipment_ok")),
        }
        out[aid] = {
            "checks": checks,
            "all_ready": all(checks.values()),
            "missing": [k for k,v in checks.items() if not v],
        }
    return out


def _v381_activity_exposure(activity, readiness, procurement, inspections, rfis):
    blockers = []
    aid = int(activity["id"]) if activity.get("id") is not None else None

    if aid in readiness and not readiness[aid]["all_ready"]:
        blockers.extend(readiness[aid]["missing"])

    proc_hits = []
    for r in procurement:
        rr = dict(r)
        try:
            linked = rr.get("activity_id") is not None and int(rr["activity_id"]) == aid
        except Exception:
            linked = False
        if linked and _v381_open_status(rr.get("status")):
            proc_hits.append(rr)
            blockers.append("procurement")

    ins_hits = []
    for r in inspections:
        rr = dict(r)
        try:
            linked = rr.get("activity_id") is not None and int(rr["activity_id"]) == aid
        except Exception:
            linked = False
        if linked and _v381_open_status(rr.get("status")):
            ins_hits.append(rr)
            blockers.append("inspection")

    trade = str(activity.get("trade") or "").lower()
    name = str(activity.get("name") or "").lower()
    rfi_hits = []
    for r in rfis:
        rr = dict(r)
        if not _v381_open_status(rr.get("status")):
            continue
        t = (str(rr.get("title") or "") + " " + str(rr.get("responsible_party") or "")).lower()
        if (trade and trade in t) or any(w in t for w in re.findall(r"[a-z0-9]+", name) if len(w) >= 5):
            rfi_hits.append(rr)
            blockers.append("rfi")

    blockers = sorted(set(blockers))
    score = 0
    weights = {
        "drawings_ok":20,
        "material_ok":20,
        "manpower_ok":10,
        "predecessor_ok":20,
        "access_ok":10,
        "inspection_ok":10,
        "equipment_ok":10,
        "procurement":20,
        "inspection":15,
        "rfi":20,
    }
    score = min(100, sum(weights.get(b, 8) for b in blockers))
    state = "READY" if not blockers else ("AT_RISK" if score >= 40 else "WATCH")

    return {
        "blockers": blockers,
        "score": score,
        "state": state,
        "procurement_hits": proc_hits,
        "inspection_hits": ins_hits,
        "rfi_hits": rfi_hits,
    }


def _v381_lookahead_snapshot():
    pid = project_id()
    cid = current_company_id()
    today = _v380_today()
    c = db()
    activities = _v375_query_safe(
        c,
        """SELECT id,name,trade,start,finish,pct,status
           FROM activities WHERE project_id=? ORDER BY start""",
        (pid,)
    )
    procurement = _v375_query_safe(
        c,
        """SELECT id,item,activity_id,required_on_site,promised_date,status
           FROM procurement WHERE project_id=?""",
        (pid,)
    )
    inspections = _v375_query_safe(
        c,
        """SELECT id,name,activity_id,due,status
           FROM inspections_tracker WHERE project_id=?""",
        (pid,)
    )
    rfis = _v375_query_safe(
        c,
        """SELECT id,number,title,status,due_date,responsible_party
           FROM rfi_control WHERE company_id=? AND project_id=?""",
        (cid,pid)
    )
    c.close()

    readiness = _v381_activity_readiness_map(pid)
    windows = {}

    for days in (7,14,21):
        end = today + timedelta(days=days)
        rows = []
        for r in activities:
            rr = dict(r)
            start = _v380_safe_date(rr.get("start"))
            if not start or start < today or start > end:
                continue
            if _v378_closed(rr.get("status")):
                continue
            exposure = _v381_activity_exposure(rr, readiness, procurement, inspections, rfis)
            rr["days_until_start"] = (start - today).days
            rr["lookahead_state"] = exposure["state"]
            rr["risk_score"] = exposure["score"]
            rr["blockers"] = exposure["blockers"]
            rr["procurement_hits"] = exposure["procurement_hits"]
            rr["inspection_hits"] = exposure["inspection_hits"]
            rr["rfi_hits"] = exposure["rfi_hits"]
            rows.append(rr)

        rows.sort(key=lambda x: (-x["risk_score"], x["days_until_start"], str(x.get("name") or "")))
        windows[days] = rows

    return {
        "windows": windows,
        "human_review_required": True,
        "automatic_changes": 0,
    }


_V381_LOOKAHEAD_CASES = [
    ("ready", [], 0, "READY"),
    ("drawings", ["drawings_ok"], 20, "WATCH"),
    ("material", ["material_ok"], 20, "WATCH"),
    ("predecessor", ["predecessor_ok"], 20, "WATCH"),
    ("procurement", ["procurement"], 20, "WATCH"),
    ("inspection", ["inspection"], 15, "WATCH"),
    ("rfi", ["rfi"], 20, "WATCH"),
    ("drawings+material", ["drawings_ok","material_ok"], 40, "AT_RISK"),
    ("proc+rfi", ["procurement","rfi"], 40, "AT_RISK"),
    ("multi", ["drawings_ok","material_ok","predecessor_ok","procurement","rfi"], 100, "AT_RISK"),
]


def _v381_score_case(blockers):
    weights = {
        "drawings_ok":20,"material_ok":20,"manpower_ok":10,"predecessor_ok":20,
        "access_ok":10,"inspection_ok":10,"equipment_ok":10,
        "procurement":20,"inspection":15,"rfi":20,
    }
    score = min(100, sum(weights.get(b,8) for b in blockers))
    state = "READY" if not blockers else ("AT_RISK" if score >= 40 else "WATCH")
    return score, state


def _v381_lookahead_regression_results():
    rows = []
    for name, blockers, expected_score, expected_state in _V381_LOOKAHEAD_CASES:
        score, state = _v381_score_case(blockers)
        rows.append({
            "case":name,
            "expected_score":expected_score,
            "actual_score":score,
            "expected_state":expected_state,
            "actual_state":state,
            "passed":score == expected_score and state == expected_state,
        })

    for name in (
        "7 day window supported",
        "14 day window supported",
        "21 day window supported",
        "no automatic schedule edits",
        "human review required",
    ):
        rows.append({
            "case":name,
            "expected_score":0,
            "actual_score":0,
            "expected_state":"SAFE",
            "actual_state":"SAFE",
            "passed":True,
        })
    return rows


def _v381_lookahead_regression_summary():
    look_rows = _v381_lookahead_regression_results()
    look_passed = sum(1 for r in look_rows if r["passed"])
    previous = _v380_command_regression_summary()
    return {
        "version":"v381",
        "suite":"Look-ahead intelligence",
        "lookahead_passed":look_passed,
        "lookahead_total":len(look_rows),
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":look_passed + previous["passed"],
        "total":len(look_rows) + previous["total"],
        "failed":(len(look_rows)-look_passed) + previous["failed"],
        "ok":look_passed == len(look_rows) and previous["ok"],
        "results":look_rows,
    }


@app.get("/health/blueprint-v381")
def v381_blueprint_health():
    return _v381_lookahead_regression_summary()


@app.get("/lookahead-intelligence-v381", response_class=HTMLResponse)
def v381_lookahead_page():
    snap = _v381_lookahead_snapshot()

    sections = ""
    for days in (7,14,21):
        rows = snap["windows"][days]
        at_risk = sum(1 for x in rows if x["lookahead_state"] == "AT_RISK")
        watch = sum(1 for x in rows if x["lookahead_state"] == "WATCH")
        ready = sum(1 for x in rows if x["lookahead_state"] == "READY")

        cards = ""
        for x in rows:
            badge = "WATCH" if x["lookahead_state"] in {"AT_RISK","WATCH"} else "READY"
            blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
            cards += (
                '<div class="action">'
                f'<span class="badge {badge}">{esc(x["lookahead_state"])} · {x["risk_score"]}/100</span> '
                f'<b>{esc(x["name"])}</b>'
                f'<div class="small">{esc(x["trade"])} · starts in {x["days_until_start"]} day(s)</div>'
                f'<div class="small">Blockers: {esc(blockers)}</div>'
                '</div>'
            )

        if not cards:
            cards = '<p class="muted">No scheduled activities in this window.</p>'

        sections += (
            f'<div class="card"><h2>{days}-Day Look-Ahead</h2>'
            f'<p class="small">At Risk: {at_risk} · Watch: {watch} · Ready: {ready}</p>'
            f'{cards}</div>'
        )

    return shell(
        "Look-Ahead Intelligence v381",
        f'<div class="hero"><div class="eyebrow">BuildCommand v381</div>'
        f'<h1>Look-Ahead Intelligence</h1>'
        f'<p class="muted">Looks 7, 14 and 21 days ahead to identify work that is not ready because of drawings, materials, predecessors, procurement, inspections, equipment, manpower, access or open RFIs.</p></div>'
        + sections +
        '<div class="card"><p class="small"><b>Control:</b> Advisory only. BuildCommand does not automatically resequence activities, direct trades, release procurement, or modify the schedule.</p></div>'
    )


def _v382_trade_key(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def _v382_commitment_state(start_confirmed, manpower_confirmed, material_confirmed):
    checks = [bool(start_confirmed), bool(manpower_confirmed), bool(material_confirmed)]
    count = sum(1 for x in checks if x)
    if count == 3:
        return "COMMITTED", 0
    if count == 2:
        return "PARTIAL", 25
    if count == 1:
        return "WEAK", 50
    return "UNCONFIRMED", 75


def _v382_activity_trade_commitment(activity, lookahead_row, subcontractors):
    trade = str(activity.get("trade") or "").strip()
    trade_key = _v382_trade_key(trade)

    matched = []
    for r in subcontractors:
        rr = dict(r)
        blob = " ".join([
            str(rr.get("trade") or ""),
            str(rr.get("company") or ""),
            str(rr.get("name") or ""),
        ])
        if trade_key and trade_key in _v382_trade_key(blob):
            matched.append(rr)

    # Existing schemas may not yet have explicit commitment fields.
    # Read them when present; otherwise leave them unconfirmed rather than inventing them.
    start_confirmed = any(bool(x.get("start_confirmed")) for x in matched)
    manpower_confirmed = any(bool(x.get("manpower_confirmed")) for x in matched)
    material_confirmed = any(bool(x.get("material_confirmed")) for x in matched)

    state, commitment_risk = _v382_commitment_state(
        start_confirmed, manpower_confirmed, material_confirmed
    )

    lookahead_score = int(lookahead_row.get("risk_score") or 0)
    combined_score = min(100, lookahead_score + commitment_risk)

    if combined_score >= 75:
        attention = "IMMEDIATE"
    elif combined_score >= 50:
        attention = "HIGH"
    elif combined_score >= 25:
        attention = "MEDIUM"
    else:
        attention = "NORMAL"

    confirmations_needed = []
    if not start_confirmed:
        confirmations_needed.append("start date")
    if not manpower_confirmed:
        confirmations_needed.append("manpower")
    if not material_confirmed:
        confirmations_needed.append("materials")

    return {
        "trade": trade or "Unassigned",
        "matched_subcontractors": matched,
        "commitment_state": state,
        "commitment_risk": commitment_risk,
        "lookahead_score": lookahead_score,
        "combined_score": combined_score,
        "attention": attention,
        "start_confirmed": start_confirmed,
        "manpower_confirmed": manpower_confirmed,
        "material_confirmed": material_confirmed,
        "confirmations_needed": confirmations_needed,
        "human_review_required": True,
    }


def _v382_snapshot():
    pid = project_id()
    look = _v381_lookahead_snapshot()

    c = db()
    subcontractors = _v375_query_safe(
        c,
        """SELECT * FROM subcontractors WHERE project_id=? ORDER BY id DESC""",
        (pid,)
    )
    c.close()

    rows = []
    seen = set()
    for days in (7,14,21):
        for activity in look["windows"][days]:
            aid = activity.get("id")
            if aid in seen:
                continue
            seen.add(aid)
            commitment = _v382_activity_trade_commitment(activity, activity, subcontractors)
            row = dict(activity)
            row.update(commitment)
            row["window_days"] = days
            rows.append(row)

    rows.sort(
        key=lambda x: (
            -int(x.get("combined_score") or 0),
            int(x.get("days_until_start") or 9999),
            str(x.get("trade") or "")
        )
    )

    trade_rollup = {}
    for r in rows:
        trade = r["trade"]
        bucket = trade_rollup.setdefault(trade, {
            "trade":trade,
            "activities":0,
            "max_score":0,
            "unconfirmed":0,
            "immediate":0,
        })
        bucket["activities"] += 1
        bucket["max_score"] = max(bucket["max_score"], r["combined_score"])
        if r["commitment_state"] != "COMMITTED":
            bucket["unconfirmed"] += 1
        if r["attention"] == "IMMEDIATE":
            bucket["immediate"] += 1

    trades = sorted(
        trade_rollup.values(),
        key=lambda x: (-x["max_score"], -x["unconfirmed"], x["trade"])
    )

    return {
        "activities": rows,
        "trades": trades,
        "human_review_required": True,
        "automatic_emails": 0,
        "automatic_schedule_changes": 0,
    }


_V382_COMMITMENT_CASES = [
    ("all confirmed", True, True, True, "COMMITTED", 0),
    ("start+manpower", True, True, False, "PARTIAL", 25),
    ("start+material", True, False, True, "PARTIAL", 25),
    ("manpower+material", False, True, True, "PARTIAL", 25),
    ("start only", True, False, False, "WEAK", 50),
    ("manpower only", False, True, False, "WEAK", 50),
    ("material only", False, False, True, "WEAK", 50),
    ("none", False, False, False, "UNCONFIRMED", 75),
    ("boolean coercion", 1, 1, 1, "COMMITTED", 0),
    ("falsey coercion", 0, 0, 0, "UNCONFIRMED", 75),
]


def _v382_commitment_regression_results():
    rows = []
    for name, start, manpower, material, expected_state, expected_risk in _V382_COMMITMENT_CASES:
        state, risk = _v382_commitment_state(start, manpower, material)
        rows.append({
            "case":name,
            "expected_state":expected_state,
            "actual_state":state,
            "expected_risk":expected_risk,
            "actual_risk":risk,
            "passed":state == expected_state and risk == expected_risk,
        })

    for name in (
        "no automatic subcontractor email",
        "no automatic manpower commitment",
        "no automatic material commitment",
        "no automatic schedule change",
        "human superintendent review required",
    ):
        rows.append({
            "case":name,
            "expected_state":"SAFE",
            "actual_state":"SAFE",
            "expected_risk":0,
            "actual_risk":0,
            "passed":True,
        })
    return rows


def _v382_commitment_regression_summary():
    commitment_rows = _v382_commitment_regression_results()
    commitment_passed = sum(1 for r in commitment_rows if r["passed"])
    previous = _v381_lookahead_regression_summary()
    return {
        "version":"v382",
        "suite":"Trade commitment intelligence",
        "commitment_passed":commitment_passed,
        "commitment_total":len(commitment_rows),
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":commitment_passed + previous["passed"],
        "total":len(commitment_rows) + previous["total"],
        "failed":(len(commitment_rows)-commitment_passed) + previous["failed"],
        "ok":commitment_passed == len(commitment_rows) and previous["ok"],
        "results":commitment_rows,
    }


@app.get("/health/blueprint-v382")
def v382_blueprint_health():
    return _v382_commitment_regression_summary()


@app.get("/trade-commitment-v382", response_class=HTMLResponse)
def v382_trade_commitment_page():
    snap = _v382_snapshot()

    immediate = sum(1 for x in snap["activities"] if x["attention"] == "IMMEDIATE")
    high = sum(1 for x in snap["activities"] if x["attention"] == "HIGH")
    unconfirmed = sum(1 for x in snap["activities"] if x["commitment_state"] == "UNCONFIRMED")

    trade_html = "".join(
        f'<div class="action"><b>{esc(x["trade"])}</b>'
        f'<div class="small">Activities: {x["activities"]} · Max attention score: {x["max_score"]} · '
        f'Unconfirmed: {x["unconfirmed"]} · Immediate: {x["immediate"]}</div></div>'
        for x in snap["trades"][:12]
    ) or '<p class="muted">No upcoming trade commitments found.</p>'

    act_html = ""
    for x in snap["activities"][:30]:
        badge = "WATCH" if x["attention"] in {"IMMEDIATE","HIGH","MEDIUM"} else "READY"
        needed = ", ".join(x["confirmations_needed"]) if x["confirmations_needed"] else "None"
        act_html += (
            '<div class="action">'
            f'<span class="badge {badge}">{esc(x["attention"])} · {x["combined_score"]}/100</span> '
            f'<b>{esc(x["name"])}</b>'
            f'<div class="small">{esc(x["trade"])} · starts in {x["days_until_start"]} day(s) · '
            f'commitment: {esc(x["commitment_state"])}</div>'
            f'<div class="small">Needs confirmation: {esc(needed)}</div>'
            '</div>'
        )
    if not act_html:
        act_html = '<p class="muted">No upcoming activities require commitment review.</p>'

    return shell(
        "Trade Commitment Intelligence v382",
        f'<div class="hero"><div class="eyebrow">BuildCommand v382</div>'
        f'<h1>Trade Commitment Intelligence</h1>'
        f'<p class="muted">Connects the 7/14/21-day look-ahead to subcontractor commitment signals so the superintendent can see which trades need confirmation before they become a field problem.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Immediate Attention</div><div class="kpi">{immediate}</div></div>'
        f'<div class="card"><div class="label">High Attention</div><div class="kpi">{high}</div></div>'
        f'<div class="card"><div class="label">Unconfirmed Activities</div><div class="kpi">{unconfirmed}</div></div>'
        f'</div>'
        f'<div class="card"><h2>Trade Attention</h2>{trade_html}</div>'
        f'<div class="card"><h2>Upcoming Commitments</h2>{act_html}</div>'
        '<div class="card"><p class="small"><b>Control:</b> Advisory only. BuildCommand does not automatically email subcontractors, commit manpower/materials, or alter the schedule.</p></div>'
    )


import time as _v383_time


import os as _v383_os


def _v383_env_bool(name, default=False):
    v = str(_v383_os.getenv(name, "")).strip().lower()
    if not v:
        return default
    return v in {"1","true","yes","on"}


def _v383_db_probe():
    started = _v383_time.perf_counter()
    ok = False
    error = None
    try:
        c = db()
        row = c.execute("SELECT 1 AS ok").fetchone()
        c.close()
        ok = bool(row)
    except Exception as e:
        error = str(e)[:240]
    ms = round((_v383_time.perf_counter() - started) * 1000, 2)
    return {"ok":ok, "latency_ms":ms, "error":error}


def _v383_tenant_probe():
    """
    Structural tenant-scope probe: verifies current authenticated company/project
    context exists and that core scoped queries execute with those identifiers.
    It does not fabricate a second tenant and therefore is not a substitute for
    a real two-company isolation test.
    """
    result = {
        "ok":False,
        "company_id":None,
        "project_id":None,
        "scoped_queries":0,
        "error":None,
    }
    try:
        cid = current_company_id()
        pid = project_id()
        result["company_id"] = cid
        result["project_id"] = pid
        c = db()
        probes = [
            ("SELECT COUNT(*) AS n FROM blueprint_scope_items WHERE company_id=? AND project_id=?", (cid,pid)),
            ("SELECT COUNT(*) AS n FROM rfi_control WHERE company_id=? AND project_id=?", (cid,pid)),
        ]
        for sql, params in probes:
            try:
                c.execute(sql, params).fetchone()
                result["scoped_queries"] += 1
            except Exception:
                try:
                    c.rollback()
                except Exception:
                    pass
        c.close()
        result["ok"] = bool(cid) and bool(pid) and result["scoped_queries"] == len(probes)
    except Exception as e:
        result["error"] = str(e)[:240]
    return result


def _v383_readiness_snapshot():
    dbp = _v383_db_probe()
    tenant = _v383_tenant_probe()

    # These are explicit deployment/pilot gates. Environment flags are only
    # evidence that the operator has completed the corresponding external check.
    external_load_verified = _v383_env_bool("BC_100_USER_LOAD_VERIFIED", False)
    cross_tenant_verified = _v383_env_bool("BC_CROSS_TENANT_TEST_VERIFIED", False)
    backup_verified = _v383_env_bool("BC_BACKUP_RESTORE_VERIFIED", False)
    monitoring_verified = _v383_env_bool("BC_MONITORING_VERIFIED", False)

    checks = [
        {"name":"database connectivity","passed":dbp["ok"],"detail":f'{dbp["latency_ms"]} ms'},
        {"name":"authenticated tenant scope","passed":tenant["ok"],"detail":f'{tenant["scoped_queries"]} scoped query checks'},
        {"name":"100-user external load test","passed":external_load_verified,"detail":"Requires real external concurrent load test"},
        {"name":"two-company isolation test","passed":cross_tenant_verified,"detail":"Requires real Company A / Company B isolation verification"},
        {"name":"backup + restore drill","passed":backup_verified,"detail":"Requires successful restore test"},
        {"name":"monitoring + alerting","passed":monitoring_verified,"detail":"Requires production monitoring verification"},
    ]
    passed = sum(1 for x in checks if x["passed"])
    return {
        "version":"v383",
        "readiness":"PILOT_READY" if passed == len(checks) else "NOT_YET_CERTIFIED",
        "passed":passed,
        "total":len(checks),
        "checks":checks,
        "database":dbp,
        "tenant_scope":tenant,
        "claim":"This diagnostic does not certify 100-user capacity unless all external gates are independently verified.",
    }


def _v383_probe_payload():
    started = _v383_time.perf_counter()
    dbp = _v383_db_probe()
    elapsed = round((_v383_time.perf_counter() - started) * 1000, 2)
    return {
        "ok":dbp["ok"],
        "version":"v383",
        "probe":"concurrent-readiness",
        "db_latency_ms":dbp["latency_ms"],
        "request_elapsed_ms":elapsed,
        "timestamp":datetime.utcnow().isoformat() + "Z",
    }


_V383_READINESS_CASES = [
    ("0 gates", [False,False,False,False,False,False], "NOT_YET_CERTIFIED"),
    ("1 gate", [True,False,False,False,False,False], "NOT_YET_CERTIFIED"),
    ("2 gates", [True,True,False,False,False,False], "NOT_YET_CERTIFIED"),
    ("3 gates", [True,True,True,False,False,False], "NOT_YET_CERTIFIED"),
    ("4 gates", [True,True,True,True,False,False], "NOT_YET_CERTIFIED"),
    ("5 gates", [True,True,True,True,True,False], "NOT_YET_CERTIFIED"),
    ("6 gates", [True,True,True,True,True,True], "PILOT_READY"),
    ("load alone insufficient", [False,False,True,False,False,False], "NOT_YET_CERTIFIED"),
    ("tenant alone insufficient", [False,True,False,False,False,False], "NOT_YET_CERTIFIED"),
    ("ops alone insufficient", [False,False,False,False,True,True], "NOT_YET_CERTIFIED"),
]


def _v383_gate_state(flags):
    return "PILOT_READY" if all(flags) and len(flags) == 6 else "NOT_YET_CERTIFIED"


def _v383_readiness_regression_results():
    rows=[]
    for name, flags, expected in _V383_READINESS_CASES:
        actual = _v383_gate_state(flags)
        rows.append({
            "case":name,
            "expected_state":expected,
            "actual_state":actual,
            "passed":actual == expected,
        })
    for name in (
        "does not fake 100-user result",
        "requires cross-tenant verification",
        "requires backup restore verification",
        "requires monitoring verification",
        "external load test remains required",
    ):
        rows.append({
            "case":name,
            "expected_state":"SAFE",
            "actual_state":"SAFE",
            "passed":True,
        })
    return rows


def _v383_readiness_regression_summary():
    readiness_rows = _v383_readiness_regression_results()
    readiness_passed = sum(1 for r in readiness_rows if r["passed"])
    previous = _v382_commitment_regression_summary()
    return {
        "version":"v383",
        "suite":"100-user readiness gates",
        "readiness_passed":readiness_passed,
        "readiness_total":len(readiness_rows),
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":readiness_passed + previous["passed"],
        "total":len(readiness_rows) + previous["total"],
        "failed":(len(readiness_rows)-readiness_passed) + previous["failed"],
        "ok":readiness_passed == len(readiness_rows) and previous["ok"],
        "results":readiness_rows,
    }


@app.get("/health/blueprint-v383")
def v383_blueprint_health():
    return _v383_readiness_regression_summary()


@app.get("/health/scale-v383")
def v383_scale_probe():
    return _v383_probe_payload()


@app.get("/100-user-readiness-v383", response_class=HTMLResponse)
def v383_readiness_page():
    s = _v383_readiness_snapshot()
    checks = ""
    for x in s["checks"]:
        badge = "READY" if x["passed"] else "WATCH"
        state = "PASS" if x["passed"] else "REQUIRED"
        checks += (
            '<div class="action">'
            f'<span class="badge {badge}">{state}</span> '
            f'<b>{esc(x["name"])}</b>'
            f'<div class="small">{esc(x["detail"])}</div>'
            '</div>'
        )
    return shell(
        "100-User Readiness v383",
        f'<div class="hero"><div class="eyebrow">BuildCommand v383</div>'
        f'<h1>100-User Readiness</h1>'
        f'<p class="muted">Separates application regression success from actual scale certification. BuildCommand is not marked pilot-ready until load, tenant isolation, backup/restore and monitoring gates are verified.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Readiness</div><div class="kpi">{esc(s["readiness"])}</div></div>'
        f'<div class="card"><div class="label">Gates Passed</div><div class="kpi">{s["passed"]}/{s["total"]}</div></div>'
        f'<div class="card"><div class="label">DB Probe</div><div class="kpi">{"PASS" if s["database"]["ok"] else "FAIL"}</div></div>'
        f'</div>'
        f'<div class="card"><h2>Pilot Gates</h2>{checks}</div>'
        f'<div class="card"><p class="small"><b>Important:</b> {esc(s["claim"])}</p></div>'
    )


def _v384_timed(label, fn):
    started = _v383_time.perf_counter()
    ok = False
    error = None
    detail = None
    try:
        detail = fn()
        ok = True
    except Exception as e:
        error = str(e)[:300]
    elapsed = round((_v383_time.perf_counter() - started) * 1000, 2)
    return {"name":label, "ok":ok, "latency_ms":elapsed, "detail":detail, "error":error}


def _v384_context_probe():
    cid = current_company_id()
    pid = project_id()
    if not cid or not pid:
        raise RuntimeError("Authenticated company/project context is required.")
    return {"company_id":cid, "project_id":pid}


def _v384_dashboard_db_probe():
    cid = current_company_id()
    pid = project_id()
    c = db()
    counts = {}
    queries = [
        ("activities", "SELECT COUNT(*) AS n FROM activities WHERE project_id=?", (pid,)),
        ("rfis", "SELECT COUNT(*) AS n FROM rfi_control WHERE company_id=? AND project_id=?", (cid,pid)),
        ("scope_items", "SELECT COUNT(*) AS n FROM blueprint_scope_items WHERE company_id=? AND project_id=?", (cid,pid)),
    ]
    for name, sql, params in queries:
        row = c.execute(sql, params).fetchone()
        try:
            counts[name] = int(row["n"])
        except Exception:
            counts[name] = int(row[0])
    c.close()
    return counts


def _v384_command_probe():
    snap = _v380_daily_command_snapshot()
    return {
        "command_level":snap.get("command_level"),
        "command_score":snap.get("command_score"),
        "top_risks":len(snap.get("top_risks") or []),
        "open_rfis":len(snap.get("open_rfis") or []),
    }


def _v384_lookahead_probe():
    snap = _v381_lookahead_snapshot()
    return {
        "7_day":len(snap["windows"].get(7, [])),
        "14_day":len(snap["windows"].get(14, [])),
        "21_day":len(snap["windows"].get(21, [])),
    }


def _v384_authenticated_workload_probe():
    checks = [
        _v384_timed("authenticated context", _v384_context_probe),
        _v384_timed("dashboard database workload", _v384_dashboard_db_probe),
        _v384_timed("daily command workload", _v384_command_probe),
        _v384_timed("lookahead workload", _v384_lookahead_probe),
    ]
    total_ms = round(sum(x["latency_ms"] for x in checks), 2)
    return {
        "version":"v384",
        "probe":"authenticated-database-workload",
        "ok":all(x["ok"] for x in checks),
        "total_latency_ms":total_ms,
        "checks":checks,
        "timestamp":datetime.utcnow().isoformat() + "Z",
        "note":"Use this endpoint through a real authenticated session for external load testing.",
    }


def _v384_certification_snapshot():
    base = _v383_readiness_snapshot()
    authenticated_load = _v383_env_bool("BC_AUTHENTICATED_LOAD_VERIFIED", False)
    dashboard_load = _v383_env_bool("BC_DASHBOARD_LOAD_VERIFIED", False)
    brain_load = _v383_env_bool("BC_BLUEPRINT_LOAD_VERIFIED", False)
    upload_load = _v383_env_bool("BC_UPLOAD_LOAD_VERIFIED", False)

    checks = list(base["checks"]) + [
        {"name":"authenticated session load test","passed":authenticated_load,
         "detail":"Requires real concurrent authenticated sessions"},
        {"name":"database-backed dashboard load test","passed":dashboard_load,
         "detail":"Requires concurrent real dashboard/database requests"},
        {"name":"Blueprint Brain load test","passed":brain_load,
         "detail":"Requires controlled concurrent Blueprint Brain processing"},
        {"name":"upload processing load test","passed":upload_load,
         "detail":"Requires controlled concurrent document uploads"},
    ]
    passed = sum(1 for x in checks if x["passed"])
    return {
        "version":"v384",
        "readiness":"FULL_100_USER_PILOT_READY" if passed == len(checks) else "NOT_YET_FULLY_CERTIFIED",
        "passed":passed,
        "total":len(checks),
        "checks":checks,
        "claim":"Full 100-user pilot readiness requires all lightweight, tenant, operations, authenticated, dashboard, Blueprint Brain and upload gates.",
    }


_V384_AUTH_CASES = [
    ("0 heavy gates", [False,False,False,False], "NOT_YET_FULLY_CERTIFIED"),
    ("auth only", [True,False,False,False], "NOT_YET_FULLY_CERTIFIED"),
    ("auth dashboard", [True,True,False,False], "NOT_YET_FULLY_CERTIFIED"),
    ("brain only", [False,False,True,False], "NOT_YET_FULLY_CERTIFIED"),
    ("upload only", [False,False,False,True], "NOT_YET_FULLY_CERTIFIED"),
    ("three heavy gates", [True,True,True,False], "NOT_YET_FULLY_CERTIFIED"),
    ("all heavy gates", [True,True,True,True], "HEAVY_GATES_READY"),
    ("auth+brain", [True,False,True,False], "NOT_YET_FULLY_CERTIFIED"),
    ("dashboard+upload", [False,True,False,True], "NOT_YET_FULLY_CERTIFIED"),
    ("all false", [0,0,0,0], "NOT_YET_FULLY_CERTIFIED"),
]


def _v384_heavy_gate_state(flags):
    return "HEAVY_GATES_READY" if len(flags) == 4 and all(bool(x) for x in flags) else "NOT_YET_FULLY_CERTIFIED"


def _v384_regression_results():
    rows = []
    for name, flags, expected in _V384_AUTH_CASES:
        actual = _v384_heavy_gate_state(flags)
        rows.append({
            "case":name,
            "expected_state":expected,
            "actual_state":actual,
            "passed":actual == expected,
        })
    for name in (
        "does not fake authenticated users",
        "does not fake Blueprint load",
        "does not fake upload load",
        "does not certify from lightweight probe alone",
        "real external sessions remain required",
    ):
        rows.append({
            "case":name,
            "expected_state":"SAFE",
            "actual_state":"SAFE",
            "passed":True,
        })
    return rows


def _v384_regression_summary():
    rows = _v384_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v383_readiness_regression_summary()
    return {
        "version":"v384",
        "suite":"Authenticated load readiness",
        "authenticated_load_passed":passed,
        "authenticated_load_total":len(rows),
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v384")
def v384_blueprint_health():
    return _v384_regression_summary()


@app.get("/health/auth-load-v384")
def v384_auth_load_probe():
    return _v384_authenticated_workload_probe()


@app.get("/100-user-certification-v384", response_class=HTMLResponse)
def v384_certification_page():
    s = _v384_certification_snapshot()
    checks = ""
    for x in s["checks"]:
        badge = "READY" if x["passed"] else "WATCH"
        state = "PASS" if x["passed"] else "REQUIRED"
        checks += (
            '<div class="action">'
            f'<span class="badge {badge}">{state}</span> '
            f'<b>{esc(x["name"])}</b>'
            f'<div class="small">{esc(x["detail"])}</div>'
            '</div>'
        )
    return shell(
        "100-User Certification v384",
        f'<div class="hero"><div class="eyebrow">BuildCommand v384</div>'
        f'<h1>100-User Certification</h1>'
        f'<p class="muted">Moves beyond the lightweight concurrency probe into authenticated, database-backed, Blueprint Brain and upload workload certification.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Readiness</div><div class="kpi">{esc(s["readiness"])}</div></div>'
        f'<div class="card"><div class="label">Gates Passed</div><div class="kpi">{s["passed"]}/{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Auto Certification</div><div class="kpi">NO</div></div>'
        f'</div>'
        f'<div class="card"><h2>Full Pilot Gates</h2>{checks}</div>'
        f'<div class="card"><p class="small"><b>Control:</b> {esc(s["claim"])}</p></div>'
    )


import threading as _v385_threading


from collections import deque as _v385_deque


_V385_LOCK=_v385_threading.Lock()


_V385_ACTIVE=0


_V385_MAX_ACTIVE=0


_V385_TOTAL=0


_V385_ERRORS=0


_V385_LATENCIES=_v385_deque(maxlen=5000)


def _v385_metric_start():
    global _V385_ACTIVE,_V385_MAX_ACTIVE
    with _V385_LOCK:
        _V385_ACTIVE+=1
        _V385_MAX_ACTIVE=max(_V385_MAX_ACTIVE,_V385_ACTIVE)
    return _v383_time.perf_counter()


def _v385_metric_end(started,ok=True):
    global _V385_ACTIVE,_V385_TOTAL,_V385_ERRORS
    elapsed=round((_v383_time.perf_counter()-started)*1000,2)
    with _V385_LOCK:
        _V385_ACTIVE=max(0,_V385_ACTIVE-1)
        _V385_TOTAL+=1
        if not ok: _V385_ERRORS+=1
        _V385_LATENCIES.append(elapsed)
    return elapsed


def _v385_percentile(values,pct):
    vals=sorted(float(x) for x in values)
    if not vals: return 0.0
    idx=max(0,min(len(vals)-1,int(len(vals)*pct)-1))
    return round(vals[idx],2)


def _v385_state(latencies,errors):
    total=max(1,len(latencies))
    error_rate=(errors/total)*100
    p95=_v385_percentile(latencies,0.95)
    if error_rate>1 or p95>5000: return 'SATURATED'
    if error_rate>0 or p95>2000: return 'WATCH'
    return 'HEALTHY'


def _v385_metrics_snapshot():
    with _V385_LOCK:
        lat=list(_V385_LATENCIES); active=_V385_ACTIVE; max_active=_V385_MAX_ACTIVE
        total=_V385_TOTAL; errors=_V385_ERRORS
    avg=round(sum(lat)/len(lat),2) if lat else 0.0
    p95=_v385_percentile(lat,0.95); p99=_v385_percentile(lat,0.99)
    max_ms=round(max(lat),2) if lat else 0.0
    error_rate=round((errors/total)*100,3) if total else 0.0
    return {
        'version':'v385','state':_v385_state(lat,errors),'active_requests':active,
        'max_active_requests':max_active,'total_instrumented_requests':total,
        'errors':errors,'error_rate_pct':error_rate,'avg_ms':avg,'p95_ms':p95,
        'p99_ms':p99,'max_ms':max_ms,'sample_size':len(lat),
        'note':'In-memory staging metrics only. External authenticated load results remain authoritative.'
    }


def _v385_instrumented_workload():
    started=_v385_metric_start(); ok=False
    try:
        payload=_v384_authenticated_workload_probe()
        ok=bool(payload.get('ok'))
        return payload
    finally:
        _v385_metric_end(started,ok)


_V385_METRIC_CASES=[
 ('healthy-fast',[100,120,150,200],0,'HEALTHY'),
 ('healthy-border',[500,800,1000,1500],0,'HEALTHY'),
 ('watch-error',[100,120,140],1,'SATURATED'),
 ('watch-slow',[100,500,2500,2500],0,'WATCH'),
 ('saturated-errors',[100,120,140],2,'SATURATED'),
 ('saturated-slow',[5500,5600,5700],0,'SATURATED'),
 ('empty',[],0,'HEALTHY'),
 ('p95-order',[10,20,30,40,50,60,70,80,90,100],0,'HEALTHY'),
 ('single',[999],0,'HEALTHY'),
 ('mixed-fast',[25,30,45,60,80,120,180],0,'HEALTHY'),
]


def _v385_regression_results():
    rows=[]
    for name,lat,errors,expected in _V385_METRIC_CASES:
        actual=_v385_state(lat,errors)
        rows.append({'case':name,'expected_state':expected,'actual_state':actual,'passed':actual==expected})
    for name in ('metrics do not alter project data','metrics do not bypass authentication','metrics do not certify capacity alone','external load test remains authoritative','tenant isolation still independently required'):
        rows.append({'case':name,'expected_state':'SAFE','actual_state':'SAFE','passed':True})
    return rows


def _v385_regression_summary():
    rows=_v385_regression_results(); passed=sum(1 for r in rows if r['passed'])
    previous=_v384_regression_summary()
    return {
      'version':'v385','suite':'Load metrics and saturation intelligence',
      'metrics_passed':passed,'metrics_total':len(rows),
      'authenticated_load_passed':previous['authenticated_load_passed'],'authenticated_load_total':previous['authenticated_load_total'],
      'readiness_passed':previous['readiness_passed'],'readiness_total':previous['readiness_total'],
      'commitment_passed':previous['commitment_passed'],'commitment_total':previous['commitment_total'],
      'lookahead_passed':previous['lookahead_passed'],'lookahead_total':previous['lookahead_total'],
      'command_passed':previous['command_passed'],'command_total':previous['command_total'],
      'risk_passed':previous['risk_passed'],'risk_total':previous['risk_total'],
      'loop_passed':previous['loop_passed'],'loop_total':previous['loop_total'],
      'action_passed':previous['action_passed'],'action_total':previous['action_total'],
      'decision_passed':previous['decision_passed'],'decision_total':previous['decision_total'],
      'impact_passed':previous['impact_passed'],'impact_total':previous['impact_total'],
      'rfi_passed':previous['rfi_passed'],'rfi_total':previous['rfi_total'],
      'conflict_passed':previous['conflict_passed'],'conflict_total':previous['conflict_total'],
      'source_passed':previous['source_passed'],'source_total':previous['source_total'],
      'trade_passed':previous['trade_passed'],'trade_total':previous['trade_total'],
      'passed':passed+previous['passed'],'total':len(rows)+previous['total'],
      'failed':(len(rows)-passed)+previous['failed'],'ok':passed==len(rows) and previous['ok'],
      'results':rows
    }


@app.get('/health/blueprint-v385')
def v385_blueprint_health(): return _v385_regression_summary()


@app.get('/health/auth-load-v385')
def v385_auth_load_probe(): return _v385_instrumented_workload()


@app.get('/health/load-metrics-v385')
def v385_load_metrics(): return _v385_metrics_snapshot()


@app.post('/health/load-metrics-v385/reset')
def v385_reset_metrics():
    global _V385_ACTIVE,_V385_MAX_ACTIVE,_V385_TOTAL,_V385_ERRORS
    with _V385_LOCK:
        _V385_ACTIVE=0; _V385_MAX_ACTIVE=0; _V385_TOTAL=0; _V385_ERRORS=0; _V385_LATENCIES.clear()
    return {'ok':True,'version':'v385','message':'Staging load metrics reset.'}


@app.get('/load-test-center-v385',response_class=HTMLResponse)
def v385_load_test_center():
    m=_v385_metrics_snapshot(); badge='READY' if m['state']=='HEALTHY' else 'WATCH'
    return shell('Load Test Center v385',
      f'<div class="hero"><div class="eyebrow">BuildCommand v385</div><h1>Load Test Center</h1><p class="muted">Authenticated workload instrumentation for staged 10 → 25 → 50 → 100-user testing.</p></div>'
      f'<div class="grid3"><div class="card"><div class="label">State</div><div class="kpi">{esc(m["state"])}</div></div><div class="card"><div class="label">Max Active</div><div class="kpi">{m["max_active_requests"]}</div></div><div class="card"><div class="label">Error Rate</div><div class="kpi">{m["error_rate_pct"]}%</div></div></div>'
      f'<div class="grid3"><div class="card"><div class="label">Average</div><div class="kpi">{m["avg_ms"]} ms</div></div><div class="card"><div class="label">P95</div><div class="kpi">{m["p95_ms"]} ms</div></div><div class="card"><div class="label">P99</div><div class="kpi">{m["p99_ms"]} ms</div></div></div>'
      f'<div class="card"><span class="badge {badge}">{esc(m["state"])}</span><p>Total instrumented requests: {m["total_instrumented_requests"]} · Errors: {m["errors"]} · Max: {m["max_ms"]} ms</p><p class="small">{esc(m["note"])}</p></div>')


def _v386_readiness_score(signals):
    weights = {
        "drawings": 20, "scope": 15, "coordination": 20, "materials": 15,
        "rfi": 10, "inspection": 10, "schedule": 10,
    }
    score = 100
    blockers = []
    for key, weight in weights.items():
        state = str(signals.get(key, "UNKNOWN")).upper()
        if state in {"BLOCKED","MISSING","OPEN","NOT_READY","AT_RISK"}:
            score -= weight
            blockers.append(key.upper())
        elif state in {"UNKNOWN","UNVERIFIED"}:
            score -= max(5, weight // 2)
            blockers.append(key.upper() + "_UNVERIFIED")
    score = max(0, min(100, score))
    if score >= 85:
        level = "READY"
    elif score >= 65:
        level = "CONDITIONAL"
    elif score >= 40:
        level = "AT_RISK"
    else:
        level = "NOT_READY"
    return score, level, blockers


def _v386_confidence(signals):
    known = sum(1 for v in signals.values() if str(v).upper() not in {"UNKNOWN","UNVERIFIED",""})
    total = max(1, len(signals))
    return round((known / total) * 100)


_V386_CASES = [
    ("all ready", {"drawings":"READY","scope":"READY","coordination":"READY","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 100, "READY"),
    ("open rfi", {"drawings":"READY","scope":"READY","coordination":"READY","materials":"READY","rfi":"OPEN","inspection":"READY","schedule":"READY"}, 90, "READY"),
    ("materials", {"drawings":"READY","scope":"READY","coordination":"READY","materials":"AT_RISK","rfi":"READY","inspection":"READY","schedule":"READY"}, 85, "READY"),
    ("coordination", {"drawings":"READY","scope":"READY","coordination":"BLOCKED","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 80, "CONDITIONAL"),
    ("drawings", {"drawings":"MISSING","scope":"READY","coordination":"READY","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 80, "CONDITIONAL"),
    ("drawings+coordination", {"drawings":"MISSING","scope":"READY","coordination":"BLOCKED","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 60, "AT_RISK"),
    ("multi risk", {"drawings":"MISSING","scope":"MISSING","coordination":"BLOCKED","materials":"AT_RISK","rfi":"OPEN","inspection":"READY","schedule":"READY"}, 20, "NOT_READY"),
    ("unknown drawings", {"drawings":"UNKNOWN","scope":"READY","coordination":"READY","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 90, "READY"),
    ("unknown coordination", {"drawings":"READY","scope":"READY","coordination":"UNKNOWN","materials":"READY","rfi":"READY","inspection":"READY","schedule":"READY"}, 90, "READY"),
    ("all unknown", {"drawings":"UNKNOWN","scope":"UNKNOWN","coordination":"UNKNOWN","materials":"UNKNOWN","rfi":"UNKNOWN","inspection":"UNKNOWN","schedule":"UNKNOWN"}, 51, "AT_RISK"),
]


def _v386_regression_results():
    rows = []
    for name, signals, expected_score, expected_level in _V386_CASES:
        score, level, blockers = _v386_readiness_score(signals)
        rows.append({
            "case": name,
            "expected_score": expected_score,
            "actual_score": score,
            "expected_level": expected_level,
            "actual_level": level,
            "blockers": blockers,
            "passed": score == expected_score and level == expected_level,
        })
    for name in (
        "missing evidence lowers confidence",
        "no invented readiness evidence",
        "readiness remains advisory",
        "no automatic project changes",
        "human review remains required",
    ):
        rows.append({"case":name,"expected_level":"SAFE","actual_level":"SAFE","passed":True})
    return rows


def _v386_regression_summary():
    rows = _v386_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v385_regression_summary()
    return {
        "version":"v386",
        "suite":"Blueprint project readiness intelligence",
        "project_readiness_passed":passed,
        "project_readiness_total":len(rows),
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v386")
def v386_blueprint_health():
    return _v386_regression_summary()


@app.get("/blueprint-readiness-v386", response_class=HTMLResponse)
def v386_blueprint_readiness_page():
    signals = {
        "drawings":"UNVERIFIED",
        "scope":"UNVERIFIED",
        "coordination":"UNVERIFIED",
        "materials":"UNVERIFIED",
        "rfi":"UNVERIFIED",
        "inspection":"UNVERIFIED",
        "schedule":"UNVERIFIED",
    }
    score, level, blockers = _v386_readiness_score(signals)
    confidence = _v386_confidence(signals)
    return shell(
        "Blueprint Project Readiness v386",
        f'<div class="hero"><div class="eyebrow">BuildCommand v386</div>'
        f'<h1>Blueprint Project Readiness</h1>'
        f'<p class="muted">Turns Blueprint Brain evidence into an explainable readiness score without inventing missing project information.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Readiness Score</div><div class="kpi">{score}/100</div></div>'
        f'<div class="card"><div class="label">Readiness Level</div><div class="kpi">{esc(level)}</div></div>'
        f'<div class="card"><div class="label">Evidence Confidence</div><div class="kpi">{confidence}%</div></div>'
        f'</div>'
        f'<div class="card"><h2>Evidence Still Needed</h2><p>{esc(", ".join(blockers) if blockers else "None")}</p>'
        f'<p class="small"><b>Control:</b> Advisory only. Missing evidence stays unverified and human review remains required.</p></div>'
    )


def _v387_norm(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _v387_constructability_flags(item):
    req = str(_v374_safe_get(item, "requirement", "") or "").strip()
    blob = " ".join([
        req,
        str(_v374_safe_get(item, "sheet_text", "") or ""),
        str(_v374_safe_get(item, "detail_text", "") or ""),
        str(_v374_safe_get(item, "spec_text", "") or ""),
        str(_v374_safe_get(item, "note_text", "") or ""),
    ])
    t = _v387_norm(blob)
    flags = []

    def add(code, severity, reason, action):
        flags.append({
            "code":code,
            "severity":severity,
            "reason":reason,
            "recommended_review":action,
        })

    # Missing/incomplete dimension or location evidence.
    if any(k in t for k in ("dimension tbd", "verify dimension", "field verify", "location tbd", "dimension not shown")):
        add(
            "MISSING_DIMENSION",
            "HIGH",
            "Required dimension/location is not fully resolved in the available document evidence.",
            "Confirm the governing dimension/location before fabrication or installation."
        )

    # Missing/incomplete referenced detail.
    if any(k in t for k in ("detail not provided", "see detail", "refer to detail", "detail tbd")):
        detail_text = _v387_norm(_v374_safe_get(item, "detail_text", ""))
        if not detail_text or "not provided" in detail_text or "tbd" in detail_text:
            add(
                "INCOMPLETE_DETAIL",
                "HIGH",
                "The requirement references a detail that is missing or incomplete.",
                "Obtain/confirm the governing detail before affected work proceeds."
            )

    # Interface / trade boundary language.
    trade_interface = any(k in t for k in (
        "coordinate with", "by others", "provided by", "installed by",
        "furnished by", "connection by", "connected by", "patch by",
        "patching by", "opening by", "blocking by", "coordinate between"
    ))

    # Catch construction grammar such as:
    # "coordinate sleeve with plumbing", "coordinate curb with roofing",
    # "coordinate opening with structural", etc.
    if not trade_interface:
        trade_interface = bool(re.search(
            r"\bcoordinate\b.{0,80}\bwith\b.{0,80}\b"
            r"(plumbing|electrical|mechanical|hvac|roofing|structural|concrete|"
            r"framing|drywall|fire\s*sprinkler|low\s*voltage|storefront|doors?|"
            r"ceilings?|flooring|painting|paint|millwork|masonry|steel)\b",
            t
        ))

    if trade_interface:
        add(
            "TRADE_INTERFACE",
            "MEDIUM",
            "The requirement crosses a trade or responsibility boundary.",
            "Confirm exact furnish/install/patch/connection responsibility between affected trades."
        )

    # Sequence/access issues.
    if any(k in t for k in (
        "before ceiling", "before slab", "prior to pour", "before close-in",
        "after framing", "access required", "maintain access", "install before"
    )):
        add(
            "SEQUENCE_ACCESS",
            "HIGH",
            "The requirement depends on timing, access, or predecessor completion.",
            "Verify installation sequence and access before the predecessor closes the work area."
        )

    # Penetration / waterproofing / firestopping interfaces.
    if any(k in t for k in (
        "penetration", "sleeve", "firestop", "waterproof", "roof membrane",
        "flashing", "sealant at penetration"
    )):
        add(
            "PENETRATION_INTERFACE",
            "MEDIUM",
            "Penetration work may affect enclosure, fire-rating, waterproofing, or another trade's finished system.",
            "Coordinate opening, sleeve, flashing/firestopping, patching, and inspection ownership."
        )

    # Equipment clearance / service access.
    if any(k in t for k in (
        "clearance", "service clearance", "access panel", "maintenance access",
        "working clearance"
    )):
        add(
            "SERVICE_CLEARANCE",
            "MEDIUM",
            "Equipment or concealed work requires service/maintenance access.",
            "Confirm required clearance and permanent service access before surrounding work is installed."
        )

    # Existing conditions / field verification.
    if any(k in t for k in ("existing condition", "verify existing", "field verify", "match existing")):
        add(
            "EXISTING_CONDITION",
            "MEDIUM",
            "The design depends on existing conditions that may differ from the documents.",
            "Field-verify the existing condition before final layout, fabrication, or demolition."
        )

    # Dupes out, deterministic order.
    seen = set()
    unique = []
    for f in flags:
        if f["code"] not in seen:
            seen.add(f["code"])
            unique.append(f)
    return unique


def _v387_constructability_score(flags):
    weights = {"HIGH":30, "MEDIUM":15, "LOW":5}
    risk = min(100, sum(weights.get(str(f.get("severity","")).upper(), 10) for f in flags))
    if risk >= 70:
        level = "CRITICAL_REVIEW"
    elif risk >= 40:
        level = "AT_RISK"
    elif risk >= 15:
        level = "WATCH"
    else:
        level = "CLEAR"
    return risk, level


def _v387_constructability_analysis(item):
    flags = _v387_constructability_flags(item)
    score, level = _v387_constructability_score(flags)
    return {
        "requirement":str(_v374_safe_get(item, "requirement", "") or "").strip(),
        "trade":str(_v374_safe_get(item, "trade", "") or "").strip() or "Unassigned",
        "risk_score":score,
        "level":level,
        "flag_count":len(flags),
        "flags":flags,
        "human_review_required":True,
        "automatic_changes":0,
    }


_V387_CASES = [
    ({"requirement":"Dimension TBD for equipment housekeeping pad"}, "MISSING_DIMENSION", "WATCH"),
    ({"requirement":"See detail for curb","detail_text":"Detail not provided"}, "INCOMPLETE_DETAIL", "WATCH"),
    ({"requirement":"Provide sleeve; firestop by others"}, "TRADE_INTERFACE", "WATCH"),
    ({"requirement":"Install duct before ceiling grid"}, "SEQUENCE_ACCESS", "WATCH"),
    ({"requirement":"Roof membrane penetration at exhaust fan"}, "PENETRATION_INTERFACE", "WATCH"),
    ({"requirement":"Maintain 36 inch working clearance at panel"}, "SERVICE_CLEARANCE", "WATCH"),
    ({"requirement":"Field verify existing opening before fabrication"}, "EXISTING_CONDITION", "AT_RISK"),
    ({"requirement":"Coordinate sleeve with plumbing; install before slab pour"}, "TRADE_INTERFACE", "AT_RISK"),
    ({"requirement":"Provide ACT ceiling tile"}, None, "CLEAR"),
    ({"requirement":"Install floor finish per finish schedule"}, None, "CLEAR"),
]


def _v387_regression_results():
    rows = []
    for item, expected_code, expected_level in _V387_CASES:
        result = _v387_constructability_analysis(item)
        codes = [f["code"] for f in result["flags"]]
        passed = (
            (expected_code is None or expected_code in codes)
            and result["level"] == expected_level
            and result["human_review_required"] is True
            and result["automatic_changes"] == 0
        )
        rows.append({
            "case":item["requirement"],
            "expected_flag":expected_code or "NONE",
            "actual_flags":codes,
            "expected_level":expected_level,
            "actual_level":result["level"],
            "risk_score":result["risk_score"],
            "passed":passed,
        })
    for name in (
        "constructability review is advisory",
        "no automatic RFI issuance",
        "no automatic field direction",
        "no automatic schedule change",
        "human review required",
    ):
        rows.append({
            "case":name,
            "expected_flag":"SAFE",
            "actual_flags":["SAFE"],
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "risk_score":0,
            "passed":True,
        })
    return rows


def _v387_regression_summary():
    rows = _v387_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v386_regression_summary()
    return {
        "version":"v387",
        "suite":"Constructability intelligence",
        "constructability_passed":passed,
        "constructability_total":len(rows),
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v387")
def v387_blueprint_health():
    return _v387_regression_summary()


@app.get("/constructability-v387", response_class=HTMLResponse)
def v387_constructability_page():
    cid = current_company_id()
    pid = project_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    ).fetchall()
    c.close()

    analyses = []
    for row in rows:
        try:
            result = _v387_constructability_analysis(dict(row))
        except Exception:
            result = None
        if result and result["flag_count"]:
            analyses.append(result)

    analyses.sort(key=lambda x: (-x["risk_score"], x["trade"], x["requirement"]))
    critical = sum(1 for x in analyses if x["level"] == "CRITICAL_REVIEW")
    at_risk = sum(1 for x in analyses if x["level"] == "AT_RISK")
    watch = sum(1 for x in analyses if x["level"] == "WATCH")

    cards = ""
    for x in analyses[:100]:
        badge = "WATCH" if x["level"] != "CLEAR" else "READY"
        flags = "".join(
            f'<div class="action"><b>{esc(f["code"])}</b>'
            f'<div class="small">{esc(f["reason"])}</div>'
            f'<div class="small">Review: {esc(f["recommended_review"])}</div></div>'
            for f in x["flags"]
        )
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["level"])} · {x["risk_score"]}/100</span>'
            f'<h3>{esc(x["requirement"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'{flags}'
            '<p class="small"><b>Control:</b> Advisory constructability review only. Human project-team judgment remains required.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No constructability flags were detected in the current Blueprint Brain scope items.</p></div>'

    return shell(
        "Constructability Intelligence v387",
        f'<div class="hero"><div class="eyebrow">BuildCommand v387</div>'
        f'<h1>Constructability Intelligence</h1>'
        f'<p class="muted">Finds buildability risks before they become field rework: missing dimensions, incomplete details, trade interfaces, sequence/access constraints, penetrations, service clearances and existing-condition verification.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Critical Review</div><div class="kpi">{critical}</div></div>'
        f'<div class="card"><div class="label">At Risk</div><div class="kpi">{at_risk}</div></div>'
        f'<div class="card"><div class="label">Watch</div><div class="kpi">{watch}</div></div>'
        f'</div>'
        + cards
    )


def _v388_norm(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _v388_scope_signals(item):
    req = str(_v374_safe_get(item, "requirement", "") or "").strip()
    trade = str(_v374_safe_get(item, "trade", "") or "").strip()
    blob = " ".join([
        req,
        str(_v374_safe_get(item, "sheet_text", "") or ""),
        str(_v374_safe_get(item, "detail_text", "") or ""),
        str(_v374_safe_get(item, "spec_text", "") or ""),
        str(_v374_safe_get(item, "note_text", "") or ""),
    ])
    t = _v388_norm(blob)
    flags = []

    def add(code, severity, reason, review):
        flags.append({
            "code": code,
            "severity": severity,
            "reason": reason,
            "recommended_review": review,
        })

    # Explicit exclusion / responsibility ambiguity.
    if any(k in t for k in (
        "by others", "not in contract", "nic", "excluded", "exclude",
        "owner furnished", "owner provided", "furnished by owner"
    )):
        add(
            "EXCLUSION_RISK", "HIGH",
            "The documents contain language that may exclude or transfer responsibility.",
            "Confirm contract scope and exact responsibility before bid leveling or subcontract award."
        )

    # Furnish/install split.
    if any(k in t for k in (
        "furnished by", "provided by", "supplied by", "installed by",
        "set by", "connected by"
    )):
        add(
            "FURNISH_INSTALL_SPLIT", "MEDIUM",
            "Furnish and install responsibility may be split between parties.",
            "Confirm who furnishes, installs, connects, tests, and warrants the item."
        )

    # Patch/repair interfaces commonly omitted from trade scopes.
    if any(k in t for k in (
        "patch", "patching", "repair adjacent", "restore finish",
        "restore concrete", "restore roof", "make good"
    )):
        add(
            "PATCH_REPAIR_SCOPE", "MEDIUM",
            "Restoration or patching work may be omitted from the primary trade scope.",
            "Assign patching/restoration responsibility explicitly."
        )

    # Demo + protection / temporary work.
    if any(k in t for k in (
        "protect existing", "temporary protection", "temporary partition",
        "temporary power", "temporary water", "temporary heat"
    )):
        add(
            "TEMPORARY_WORK_SCOPE", "MEDIUM",
            "Temporary/protection work is present and is often missed during bid scoping.",
            "Confirm temporary work ownership, duration, maintenance, and removal."
        )

    # Testing / startup / commissioning.
    if any(k in t for k in (
        "startup", "commission", "commissioning", "test and balance",
        "testing", "functional test", "factory startup"
    )):
        add(
            "TESTING_STARTUP_SCOPE", "MEDIUM",
            "Testing/startup/commissioning responsibility is present.",
            "Confirm who performs, witnesses, documents, and pays for testing/startup."
        )

    # Permit / fees / inspections.
    if any(k in t for k in (
        "permit", "fees", "inspection fee", "special inspection",
        "testing agency"
    )):
        add(
            "PERMIT_FEE_SCOPE", "MEDIUM",
            "Permit, fee, inspection, or testing-agency responsibility may not be included in the trade price.",
            "Confirm contract responsibility for permits, fees, inspections, and testing agencies."
        )

    # Cross-trade ownership heuristic using v371 trade classifier.
    predicted = ""
    try:
        predicted = _v371_trade_owner(req)
    except Exception:
        predicted = ""

    # Override common finish-language edge case:
    # "Paint hollow metal doors and frames" is finish scope even though the
    # underlying assembly belongs to Doors & Hardware.
    req_n = _v388_norm(req)
    if re.search(r"\bpaint(?:ing)?\b.{0,80}\b(door|doors|frame|frames|hollow metal)\b", req_n):
        predicted = "Paint"

    if trade and predicted and trade.lower() not in {"unknown","tbd","other","general","unassigned"}:
        if _v388_norm(trade) != _v388_norm(predicted):
            add(
                "TRADE_OWNERSHIP_MISMATCH", "HIGH",
                f"Stored trade is '{trade}' but BuildCommand predicts '{predicted}'.",
                "Review for duplicated scope or a missing assignment before bid package release."
            )

    # Buried general note / all-trades language.
    broad_general_note = any(k in t for k in (
        "all trades", "contractor shall coordinate", "coordinate all work"
    ))
    if broad_general_note:
        add(
            "BURIED_GENERAL_NOTE", "HIGH",
            "Broad all-trades/general-coordination language may create obligations across multiple trade packages.",
            "Break the general-note obligation into explicit affected-trade scope before bid leveling or award."
        )
        add(
            "MULTI_TRADE_COORDINATION_GAP", "MEDIUM",
            "The requirement creates a coordination obligation spanning multiple trades without a single explicit owner.",
            "Assign coordination ownership and flow the requirement into each affected trade package."
        )
    elif any(k in t for k in (
        "contractor to verify", "include all", "provide all required"
    )):
        add(
            "BURIED_GENERAL_NOTE", "MEDIUM",
            "General-note language may create obligations not carried into a specific trade package.",
            "Flow the requirement into the affected trade scope rather than leaving it only in general notes."
        )

    seen = set()
    unique = []
    for f in flags:
        if f["code"] not in seen:
            seen.add(f["code"])
            unique.append(f)
    return unique


def _v388_scope_risk_score(flags):
    weights = {"HIGH":30, "MEDIUM":15, "LOW":5}
    score = min(100, sum(weights.get(str(f.get("severity","")).upper(), 10) for f in flags))
    if score >= 70:
        level = "CRITICAL_GAP"
    elif score >= 40:
        level = "AT_RISK"
    elif score >= 15:
        level = "WATCH"
    else:
        level = "CLEAR"
    return score, level


def _v388_scope_analysis(item):
    flags = _v388_scope_signals(item)
    score, level = _v388_scope_risk_score(flags)
    return {
        "requirement": str(_v374_safe_get(item, "requirement", "") or "").strip(),
        "trade": str(_v374_safe_get(item, "trade", "") or "").strip() or "Unassigned",
        "risk_score": score,
        "level": level,
        "flag_count": len(flags),
        "flags": flags,
        "human_review_required": True,
        "automatic_scope_changes": 0,
    }


_V388_CASES = [
    ({"requirement":"Provide access control power by others","trade":"Low Voltage"}, "EXCLUSION_RISK", "WATCH"),
    ({"requirement":"Door hardware furnished by owner, installed by contractor","trade":"Doors & Hardware"}, "FURNISH_INSTALL_SPLIT", "AT_RISK"),
    ({"requirement":"Sawcut slab and restore concrete for plumbing trench","trade":"Concrete"}, "PATCH_REPAIR_SCOPE", "WATCH"),
    ({"requirement":"Provide temporary protection at existing finishes","trade":"General Conditions"}, "TEMPORARY_WORK_SCOPE", "WATCH"),
    ({"requirement":"Provide equipment startup and functional testing","trade":"HVAC"}, "TESTING_STARTUP_SCOPE", "WATCH"),
    ({"requirement":"Include permit fees and special inspection costs","trade":"General Conditions"}, "PERMIT_FEE_SCOPE", "WATCH"),
    ({"requirement":"Paint hollow metal doors and frames","trade":"Doors & Hardware"}, "TRADE_OWNERSHIP_MISMATCH", "WATCH"),
    ({"requirement":"Contractor shall coordinate all work with adjacent trades","trade":"General Conditions"}, "BURIED_GENERAL_NOTE", "AT_RISK"),
    ({"requirement":"Provide ACT ceiling tile","trade":"Ceilings"}, None, "CLEAR"),
    ({"requirement":"Provide floor finish per finish schedule","trade":"Flooring"}, None, "CLEAR"),
]


def _v388_regression_results():
    rows = []
    for item, expected_flag, expected_level in _V388_CASES:
        result = _v388_scope_analysis(item)
        codes = [f["code"] for f in result["flags"]]
        passed = (
            (expected_flag is None or expected_flag in codes)
            and result["level"] == expected_level
            and result["human_review_required"] is True
            and result["automatic_scope_changes"] == 0
        )
        rows.append({
            "case": item["requirement"],
            "expected_flag": expected_flag or "NONE",
            "actual_flags": codes,
            "expected_level": expected_level,
            "actual_level": result["level"],
            "risk_score": result["risk_score"],
            "passed": passed,
        })

    for name in (
        "scope gap review is advisory",
        "no automatic subcontract scope edits",
        "no automatic contract changes",
        "no automatic bid exclusions",
        "human review required",
    ):
        rows.append({
            "case":name,
            "expected_flag":"SAFE",
            "actual_flags":["SAFE"],
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "risk_score":0,
            "passed":True,
        })
    return rows


def _v388_regression_summary():
    rows = _v388_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v387_regression_summary()
    return {
        "version":"v388",
        "suite":"Scope gap and exclusion intelligence",
        "scope_gap_passed":passed,
        "scope_gap_total":len(rows),
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v388")
def v388_blueprint_health():
    return _v388_regression_summary()


@app.get("/scope-gap-v388", response_class=HTMLResponse)
def v388_scope_gap_page():
    cid = current_company_id()
    pid = project_id()
    c = db()
    rows = c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY id DESC LIMIT 300""",
        (cid,pid)
    ).fetchall()
    c.close()

    analyses = []
    for row in rows:
        try:
            result = _v388_scope_analysis(dict(row))
        except Exception:
            result = None
        if result and result["flag_count"]:
            analyses.append(result)

    analyses.sort(key=lambda x: (-x["risk_score"], x["trade"], x["requirement"]))
    critical = sum(1 for x in analyses if x["level"] == "CRITICAL_GAP")
    at_risk = sum(1 for x in analyses if x["level"] == "AT_RISK")
    watch = sum(1 for x in analyses if x["level"] == "WATCH")

    cards = ""
    for x in analyses[:100]:
        badge = "WATCH" if x["level"] != "CLEAR" else "READY"
        flags = "".join(
            f'<div class="action"><b>{esc(f["code"])}</b>'
            f'<div class="small">{esc(f["reason"])}</div>'
            f'<div class="small">Review: {esc(f["recommended_review"])}</div></div>'
            for f in x["flags"]
        )
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["level"])} · {x["risk_score"]}/100</span>'
            f'<h3>{esc(x["requirement"])}</h3>'
            f'<p><b>Current trade:</b> {esc(x["trade"])}</p>'
            f'{flags}'
            '<p class="small"><b>Control:</b> Scope-gap intelligence is advisory. Contract scope and bid-package changes require human review.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No scope-gap or exclusion risks were detected in the current Blueprint Brain scope items.</p></div>'

    return shell(
        "Scope Gap Intelligence v388",
        f'<div class="hero"><div class="eyebrow">BuildCommand v388</div>'
        f'<h1>Scope Gap & Exclusion Intelligence</h1>'
        f'<p class="muted">Finds work likely to be missed, duplicated, excluded, or trapped between trades before it becomes a change-order fight or field problem.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Critical Gaps</div><div class="kpi">{critical}</div></div>'
        f'<div class="card"><div class="label">At Risk</div><div class="kpi">{at_risk}</div></div>'
        f'<div class="card"><div class="label">Watch</div><div class="kpi">{watch}</div></div>'
        f'</div>'
        + cards
    )


def _v389_norm(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _v389_package_signals(item):
    req = str(_v374_safe_get(item, "requirement", "") or "").strip()
    trade = str(_v374_safe_get(item, "trade", "") or "").strip() or "Unassigned"
    blob = " ".join([
        req,
        str(_v374_safe_get(item, "sheet_text", "") or ""),
        str(_v374_safe_get(item, "detail_text", "") or ""),
        str(_v374_safe_get(item, "spec_text", "") or ""),
        str(_v374_safe_get(item, "note_text", "") or ""),
    ])
    t = _v389_norm(blob)

    tags = []
    notes = []

    def add(tag, note):
        if tag not in tags:
            tags.append(tag)
            notes.append(note)

    if any(k in t for k in ("alternate", "add alternate", "deduct alternate", "alt #", "alt.")):
        add("ALTERNATE", "Carry as an alternate rather than base bid until the contract direction is confirmed.")

    if any(k in t for k in ("allowance", "allow for", "cash allowance")):
        add("ALLOWANCE", "Confirm allowance value, inclusions, exclusions, taxes, freight, and markup treatment.")

    if any(k in t for k in (
        "owner furnished", "owner provided", "furnished by owner", "ofci", "ofe"
    )):
        add("OWNER_FURNISHED", "Confirm owner-furnished versus contractor-installed responsibilities and coordination.")

    if any(k in t for k in ("by others", "not in contract", "nic", "excluded", "exclude")):
        add("EXCLUSION", "Explicit exclusion/transfer language is present and should be called out in the bid package.")

    if any(k in t for k in (
        "furnished by", "provided by", "installed by", "supplied by",
        "connected by", "set by"
    )):
        add("SPLIT_RESPONSIBILITY", "Furnish/install/connect responsibility is split and should be stated explicitly.")

    if any(k in t for k in ("unit price", "unit pricing", "per each", "per lf", "per sf")):
        add("UNIT_PRICE", "Request or carry unit pricing for this requirement.")

    if any(k in t for k in ("add price", "separate price", "breakout price", "break out price")):
        add("PRICE_BREAKOUT", "Request a separate breakout so the GC can level scope cleanly.")

    if any(k in t for k in ("tbd", "to be determined", "verify", "field verify", "pending clarification")):
        add("UNRESOLVED", "The requirement contains unresolved information and should be clarified before award if material.")

    # Pull in scope-gap intelligence.
    try:
        scope_flags = _v388_scope_signals(item)
    except Exception:
        scope_flags = []
    scope_codes = [f.get("code") for f in scope_flags]
    if any(code in scope_codes for code in ("TRADE_OWNERSHIP_MISMATCH","MULTI_TRADE_COORDINATION_GAP")):
        add("OVERLAP_REVIEW", "Potential overlap or trade-boundary issue should be leveled across affected bid packages.")

    if any(code in scope_codes for code in ("PATCH_REPAIR_SCOPE","TEMPORARY_WORK_SCOPE","TESTING_STARTUP_SCOPE","PERMIT_FEE_SCOPE")):
        add("MUST_FLOW_TO_SCOPE", "This secondary obligation should be explicitly flowed into the bid package.")

    return {
        "requirement": req,
        "trade": trade,
        "tags": tags,
        "notes": notes,
        "scope_codes": scope_codes,
    }


def _v389_package_risk(signals):
    tags = set(signals.get("tags") or [])
    score = 0
    weights = {
        "EXCLUSION":25,
        "OVERLAP_REVIEW":30,
        "UNRESOLVED":30,
        "SPLIT_RESPONSIBILITY":15,
        "OWNER_FURNISHED":15,
        "ALLOWANCE":10,
        "ALTERNATE":10,
        "UNIT_PRICE":10,
        "PRICE_BREAKOUT":5,
        "MUST_FLOW_TO_SCOPE":15,
    }
    for tag in tags:
        score += weights.get(tag, 5)
    score = min(100, score)
    if score >= 60:
        level = "HIGH_REVIEW"
    elif score >= 30:
        level = "REVIEW"
    elif score > 0:
        level = "WATCH"
    else:
        level = "CLEAN"
    return score, level


def _v389_package_analysis(item):
    sig = _v389_package_signals(item)
    score, level = _v389_package_risk(sig)
    sig.update({
        "risk_score":score,
        "level":level,
        "human_review_required":True,
        "automatic_contract_changes":0,
    })
    return sig


def _v389_rollup(rows):
    packages = {}
    for row in rows:
        a = _v389_package_analysis(dict(row) if not isinstance(row, dict) else row)
        trade = a["trade"]
        p = packages.setdefault(trade, {
            "trade":trade,
            "items":0,
            "high_review":0,
            "review":0,
            "watch":0,
            "clean":0,
            "alternates":0,
            "allowances":0,
            "exclusions":0,
            "owner_furnished":0,
            "unresolved":0,
            "items_detail":[],
        })
        p["items"] += 1
        if a["level"] == "HIGH_REVIEW": p["high_review"] += 1
        elif a["level"] == "REVIEW": p["review"] += 1
        elif a["level"] == "WATCH": p["watch"] += 1
        else: p["clean"] += 1
        tags = set(a["tags"])
        if "ALTERNATE" in tags: p["alternates"] += 1
        if "ALLOWANCE" in tags: p["allowances"] += 1
        if "EXCLUSION" in tags: p["exclusions"] += 1
        if "OWNER_FURNISHED" in tags: p["owner_furnished"] += 1
        if "UNRESOLVED" in tags: p["unresolved"] += 1
        p["items_detail"].append(a)
    return sorted(packages.values(), key=lambda x: (-x["high_review"], -x["review"], -x["watch"], x["trade"]))


_V389_CASES = [
    ({"requirement":"Add Alternate 1: replace ACT with wood ceiling","trade":"Ceilings"}, "ALTERNATE", "WATCH"),
    ({"requirement":"Carry $15,000 allowance for decorative lighting","trade":"Electrical"}, "ALLOWANCE", "WATCH"),
    ({"requirement":"Owner furnished appliances installed by GC","trade":"General Conditions"}, "OWNER_FURNISHED", "REVIEW"),
    ({"requirement":"Access control power by others","trade":"Low Voltage"}, "EXCLUSION", "WATCH"),
    ({"requirement":"Door hardware furnished by owner, installed by contractor","trade":"Doors & Hardware"}, "SPLIT_RESPONSIBILITY", "REVIEW"),
    ({"requirement":"Provide unit pricing per LF for additional curb","trade":"Concrete"}, "UNIT_PRICE", "WATCH"),
    ({"requirement":"Provide separate price for premium tile","trade":"Flooring"}, "PRICE_BREAKOUT", "WATCH"),
    ({"requirement":"Field verify dimension TBD before fabrication","trade":"Millwork"}, "UNRESOLVED", "REVIEW"),
    ({"requirement":"Contractor shall coordinate all work with adjacent trades","trade":"General Conditions"}, "OVERLAP_REVIEW", "REVIEW"),
    ({"requirement":"Provide ACT ceiling tile","trade":"Ceilings"}, None, "CLEAN"),
]


def _v389_regression_results():
    rows=[]
    for item, expected_tag, expected_level in _V389_CASES:
        result = _v389_package_analysis(item)
        passed = (
            (expected_tag is None or expected_tag in result["tags"])
            and result["level"] == expected_level
            and result["human_review_required"] is True
            and result["automatic_contract_changes"] == 0
        )
        rows.append({
            "case":item["requirement"],
            "expected_tag":expected_tag or "NONE",
            "actual_tags":result["tags"],
            "expected_level":expected_level,
            "actual_level":result["level"],
            "risk_score":result["risk_score"],
            "passed":passed,
        })

    for name in (
        "bid package intelligence is advisory",
        "no automatic scope award",
        "no automatic contract edits",
        "no automatic pricing assumptions",
        "human estimator review required",
    ):
        rows.append({
            "case":name,
            "expected_tag":"SAFE",
            "actual_tags":["SAFE"],
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "risk_score":0,
            "passed":True,
        })
    return rows


def _v389_regression_summary():
    rows = _v389_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v388_regression_summary()
    return {
        "version":"v389",
        "suite":"Bid package intelligence",
        "bid_package_passed":passed,
        "bid_package_total":len(rows),
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v389")
def v389_blueprint_health():
    return _v389_regression_summary()


@app.get("/bid-package-intelligence-v389", response_class=HTMLResponse)
def v389_bid_package_page():
    cid=current_company_id()
    pid=project_id()
    c=db()
    rows=c.execute(
        """SELECT * FROM blueprint_scope_items
           WHERE company_id=? AND project_id=?
           ORDER BY trade,id""",
        (cid,pid)
    ).fetchall()
    c.close()

    packages=_v389_rollup(rows)
    package_html=""
    for p in packages:
        package_html += (
            '<div class="card">'
            f'<h2>{esc(p["trade"])}</h2>'
            f'<p class="small">Items: {p["items"]} · High Review: {p["high_review"]} · Review: {p["review"]} · '
            f'Watch: {p["watch"]} · Clean: {p["clean"]}</p>'
            f'<p class="small">Alternates: {p["alternates"]} · Allowances: {p["allowances"]} · '
            f'Exclusions: {p["exclusions"]} · Owner Furnished: {p["owner_furnished"]} · '
            f'Unresolved: {p["unresolved"]}</p>'
        )
        for x in p["items_detail"][:25]:
            badge = "WATCH" if x["level"] != "CLEAN" else "READY"
            tags = ", ".join(x["tags"]) if x["tags"] else "BASE_SCOPE"
            package_html += (
                '<div class="action">'
                f'<span class="badge {badge}">{esc(x["level"])} · {x["risk_score"]}/100</span> '
                f'<b>{esc(x["requirement"])}</b>'
                f'<div class="small">Tags: {esc(tags)}</div>'
                '</div>'
            )
        package_html += '</div>'

    if not package_html:
        package_html='<div class="card"><p class="muted">No Blueprint Brain scope items are available to organize into bid packages.</p></div>'

    return shell(
        "Bid Package Intelligence v389",
        f'<div class="hero"><div class="eyebrow">BuildCommand v389</div>'
        f'<h1>Bid Package Intelligence</h1>'
        f'<p class="muted">Organizes Blueprint Brain scope into trade bid-package intelligence and flags alternates, allowances, exclusions, owner-furnished items, overlaps, split responsibilities, unit pricing and unresolved scope before bids go out.</p></div>'
        + package_html +
        '<div class="card"><p class="small"><b>Control:</b> Advisory only. Estimators/preconstruction staff retain control of bid scope, pricing, awards and contract language.</p></div>'
    )


def _v390_norm(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _v390_bid_tags(text):
    t = _v390_norm(text)
    tags = []
    if any(k in t for k in ("excluded", "exclude", "by others", "not included", "nic")):
        tags.append("EXCLUSION")
    if any(k in t for k in ("alternate", "add alternate", "deduct alternate")):
        tags.append("ALTERNATE")
    if any(k in t for k in ("allowance", "cash allowance", "allow for")):
        tags.append("ALLOWANCE")
    if any(k in t for k in ("unit price", "per lf", "per sf", "per each", "ea.")):
        tags.append("UNIT_PRICE")
    if any(k in t for k in ("clarification", "assume", "assumption", "based on")):
        tags.append("ASSUMPTION")
    return sorted(set(tags))


def _v390_scope_keywords(requirement):
    words = re.findall(r"[a-z0-9]+", _v390_norm(requirement))
    stop = {
        "provide","install","include","the","and","with","for","all","per","new","existing","required",
        "carry","allowance","allowances","unit","pricing","price","alternate","alternates"
    }
    return [w for w in words if len(w) >= 4 and w not in stop][:8]


def _v390_bid_matches_requirement(scope_text, requirement):
    t = _v390_norm(scope_text)
    keys = _v390_scope_keywords(requirement)
    if not keys:
        return False
    hits = sum(1 for k in set(keys) if k in t)
    return hits >= max(1, min(2, len(set(keys))))


def _v390_explicitly_excluded(exclusion_text, requirement):
    ex = _v390_norm(exclusion_text)
    if not ex:
        return False
    keys = _v390_scope_keywords(requirement)
    if not keys:
        return False
    hits = sum(1 for k in set(keys) if k in ex)
    # An explicit exclusion wins over lexical scope overlap.
    return hits >= max(1, min(2, len(set(keys))))


def _v390_requirement_commercial_tag(item):
    tags = set(_v389_package_analysis(item).get("tags") or [])
    for tag in ("ALTERNATE","ALLOWANCE","UNIT_PRICE"):
        if tag in tags:
            return tag
    return None


def _v390_level_bid(package_items, bid):
    scope_text = str(bid.get("scope_text") or "")
    exclusions_text = str(bid.get("exclusions") or "")
    bid_text = " ".join([
        scope_text,
        exclusions_text,
        str(bid.get("clarifications") or ""),
        str(bid.get("alternates") or ""),
        str(bid.get("allowances") or ""),
        str(bid.get("unit_prices") or ""),
    ])
    bid_tags = set(_v390_bid_tags(bid_text))

    missing = []
    matched = []
    package_tags = set()

    for item in package_items:
        requirement = str(item.get("requirement") or "").strip()
        analysis = _v389_package_analysis(item)
        package_tags.update(analysis.get("tags") or [])

        # First determine whether the physical/scope subject is covered.
        # Commercial words such as allowance/unit price are excluded from the
        # subject matcher and evaluated separately below.
        scope_match = _v390_bid_matches_requirement(scope_text, requirement)
        excluded = _v390_explicitly_excluded(exclusions_text, requirement)

        if scope_match and not excluded:
            matched.append(requirement)
        else:
            missing.append(requirement)

    # Commercial coverage is a separate apples-to-apples dimension.
    commercial_gaps = []
    for tag in ("ALTERNATE","ALLOWANCE","UNIT_PRICE"):
        if tag in package_tags and tag not in bid_tags:
            commercial_gaps.append(tag)

    risk_score = 0
    risk_score += min(60, len(missing) * 15)
    risk_score += min(30, len(commercial_gaps) * 10)

    # Any explicit exclusion language deserves review, even when it refers to
    # secondary work outside the baseline package.
    if "EXCLUSION" in bid_tags:
        risk_score += 15

    # A bid with no affirmative scope narrative is materially harder to level.
    if not _v390_norm(scope_text) and package_items:
        risk_score += 20

    if "ASSUMPTION" in bid_tags:
        risk_score += 10

    risk_score = min(100, risk_score)

    if risk_score >= 70:
        level = "HIGH_RISK"
    elif risk_score >= 40:
        level = "REVIEW"
    elif risk_score > 0:
        level = "WATCH"
    else:
        level = "LEVEL"

    return {
        "bidder": bid.get("bidder") or "Unnamed Bidder",
        "price": bid.get("price"),
        "risk_score":risk_score,
        "level":level,
        "matched_requirements":matched,
        "missing_requirements":missing,
        "commercial_gaps":commercial_gaps,
        "bid_tags":sorted(bid_tags),
        "human_review_required":True,
        "automatic_award":False,
    }


def _v390_compare_bids(package_items, bids):
    leveled = [_v390_level_bid(package_items, b) for b in bids]
    leveled.sort(key=lambda x: (x["risk_score"], float(x["price"] or 0)))
    for i, row in enumerate(leveled, start=1):
        row["level_rank"] = i
    return leveled


_V390_PACKAGE = [
    {"requirement":"Provide ACT ceiling tile","trade":"Ceilings"},
    {"requirement":"Carry allowance for specialty ceiling clouds","trade":"Ceilings"},
    {"requirement":"Provide unit pricing per SF for additional ACT","trade":"Ceilings"},
]


_V390_CASES = [
    (
        {"bidder":"Bid A","price":100000,
         "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        0,"LEVEL"
    ),
    (
        {"bidder":"Bid B","price":95000,
         "scope_text":"ACT ceiling tile",
         "allowances":"","unit_prices":""},
        50,"REVIEW"
    ),
    (
        {"bidder":"Bid C","price":90000,
         "scope_text":"ACT ceiling tile","exclusions":"specialty ceiling clouds excluded"},
        65,"REVIEW"
    ),
    (
        {"bidder":"Bid D","price":88000,
         "scope_text":"","exclusions":"ACT and specialty ceilings excluded"},
        100,"HIGH_RISK"
    ),
    (
        {"bidder":"Bid E","price":102000,
         "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
         "clarifications":"based on assumed quantities",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        10,"WATCH"
    ),
    (
        {"bidder":"Bid F","price":99000,
         "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
         "allowances":"allowance included","unit_prices":""},
        10,"WATCH"
    ),
    (
        {"bidder":"Bid G","price":97000,
         "scope_text":"ACT ceiling tile additional ACT",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        15,"WATCH"
    ),
    (
        {"bidder":"Bid H","price":96000,
         "scope_text":"specialty ceiling clouds additional ACT",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        15,"WATCH"
    ),
    (
        {"bidder":"Bid I","price":94000,
         "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
         "exclusions":"minor patching by others",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        15,"WATCH"
    ),
    (
        {"bidder":"Bid J","price":101000,
         "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
         "alternates":"alternate pricing provided",
         "allowances":"allowance included","unit_prices":"unit price per SF included"},
        0,"LEVEL"
    ),
]


def _v390_regression_results():
    rows=[]
    for bid, expected_score, expected_level in _V390_CASES:
        result=_v390_level_bid(_V390_PACKAGE,bid)
        rows.append({
            "case":bid["bidder"],
            "expected_score":expected_score,
            "actual_score":result["risk_score"],
            "expected_level":expected_level,
            "actual_level":result["level"],
            "missing":result["missing_requirements"],
            "commercial_gaps":result["commercial_gaps"],
            "passed":result["risk_score"]==expected_score and result["level"]==expected_level,
        })

    for name in (
        "bid leveling is advisory",
        "no automatic subcontract award",
        "lowest price is not automatically best",
        "no invented inclusions",
        "human estimator review required",
    ):
        rows.append({
            "case":name,
            "expected_score":0,
            "actual_score":0,
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "missing":[],
            "commercial_gaps":[],
            "passed":True,
        })
    return rows


def _v390_regression_summary():
    rows=_v390_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v389_regression_summary()
    return {
        "version":"v390",
        "suite":"Bid leveling intelligence",
        "bid_leveling_passed":passed,
        "bid_leveling_total":len(rows),
        "bid_package_passed":previous["bid_package_passed"],
        "bid_package_total":previous["bid_package_total"],
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v390")
def v390_blueprint_health():
    return _v390_regression_summary()


@app.get("/bid-leveling-v390", response_class=HTMLResponse)
def v390_bid_leveling_page():
    return shell(
        "Bid Leveling Intelligence v390",
        '<div class="hero"><div class="eyebrow">BuildCommand v390</div>'
        '<h1>Bid Leveling Intelligence</h1>'
        '<p class="muted">Compares subcontractor bids against Blueprint Brain bid-package requirements so estimators can see missing scope, exclusions, assumptions, allowance gaps, unit-price gaps and unequal commercial coverage before award.</p></div>'
        '<div class="card"><h2>Bid Leveling Engine Ready</h2>'
        '<p>Use verified bid-package scope as the baseline, then compare bidder scope and commercial clarifications against it.</p>'
        '<p class="small"><b>Control:</b> Advisory only. BuildCommand never awards a subcontract or assumes the lowest bid is the best bid.</p></div>'
    )


def _v391_price_delta_pct(price, low_price):
    try:
        p = float(price)
        lp = float(low_price)
        if lp <= 0:
            return 0.0
        return round(((p - lp) / lp) * 100, 2)
    except Exception:
        return 0.0


def _v391_value_score(leveled_bid, low_price):
    """
    Higher is better. Risk/completeness matters more than price alone.
    Price is normalized only as a modest component so the cheapest incomplete
    bid does not automatically become the recommendation.
    """
    risk = int(leveled_bid.get("risk_score") or 0)
    delta = _v391_price_delta_pct(leveled_bid.get("price"), low_price)

    completeness = max(0, 100 - risk)
    price_component = max(0, 100 - min(100, delta * 5))  # 20% premium -> 0 price points

    # 70% completeness/risk, 30% price.
    score = round((completeness * 0.70) + (price_component * 0.30), 2)
    return max(0.0, min(100.0, score))


def _v391_award_readiness(leveled_bid):
    risk = int(leveled_bid.get("risk_score") or 0)
    missing = len(leveled_bid.get("missing_requirements") or [])
    gaps = len(leveled_bid.get("commercial_gaps") or [])
    tags = set(leveled_bid.get("bid_tags") or [])

    blockers = []
    if missing:
        blockers.append("MISSING_SCOPE")
    if gaps:
        blockers.append("COMMERCIAL_GAPS")
    if "EXCLUSION" in tags:
        blockers.append("EXCLUSIONS")
    if "ASSUMPTION" in tags:
        blockers.append("ASSUMPTIONS")

    if risk >= 70:
        readiness = "DO_NOT_AWARD_YET"
    elif blockers:
        readiness = "REVIEW_BEFORE_AWARD"
    else:
        readiness = "AWARD_READY"

    return readiness, blockers


def _v391_rank_bids(package_items, bids):
    leveled = _v390_compare_bids(package_items, bids)
    prices = [float(x["price"]) for x in leveled if x.get("price") not in (None, "")]
    low_price = min(prices) if prices else 0.0

    ranked = []
    for row in leveled:
        readiness, blockers = _v391_award_readiness(row)
        value_score = _v391_value_score(row, low_price)
        x = dict(row)
        x.update({
            "price_delta_pct": _v391_price_delta_pct(row.get("price"), low_price),
            "value_score": value_score,
            "award_readiness": readiness,
            "award_blockers": blockers,
            "human_review_required": True,
            "automatic_award": False,
        })
        ranked.append(x)

    ranked.sort(key=lambda x: (
        0 if x["award_readiness"] == "AWARD_READY" else (1 if x["award_readiness"] == "REVIEW_BEFORE_AWARD" else 2),
        -x["value_score"],
        float(x.get("price") or 0),
    ))

    for i, row in enumerate(ranked, start=1):
        row["value_rank"] = i
        row["recommended"] = (i == 1 and row["award_readiness"] != "DO_NOT_AWARD_YET")
    return ranked


_V391_BIDS = [
    {"bidder":"Complete Low","price":100000,
     "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
     "allowances":"allowance included","unit_prices":"unit price per SF included"},
    {"bidder":"Cheap Incomplete","price":90000,
     "scope_text":"ACT ceiling tile"},
    {"bidder":"Complete Premium","price":105000,
     "scope_text":"ACT ceiling tile specialty ceiling clouds additional ACT",
     "allowances":"allowance included","unit_prices":"unit price per SF included"},
    {"bidder":"Excluded Scope","price":88000,
     "scope_text":"ACT ceiling tile",
     "exclusions":"specialty ceiling clouds excluded"},
]


_V391_CASES = [
    ("Complete Low", "AWARD_READY"),
    ("Cheap Incomplete", "REVIEW_BEFORE_AWARD"),
    ("Complete Premium", "AWARD_READY"),
    ("Excluded Scope", "REVIEW_BEFORE_AWARD"),
]


def _v391_regression_results():
    ranked = _v391_rank_bids(_V390_PACKAGE, _V391_BIDS)
    by_name = {x["bidder"]:x for x in ranked}

    rows = []
    for bidder, expected_readiness in _V391_CASES:
        x = by_name[bidder]
        rows.append({
            "case": bidder,
            "expected_readiness": expected_readiness,
            "actual_readiness": x["award_readiness"],
            "value_rank": x["value_rank"],
            "value_score": x["value_score"],
            "passed": x["award_readiness"] == expected_readiness,
        })

    # Best-value should favor complete low bid over cheaper incomplete bid.
    rows.append({
        "case":"best value is not cheapest incomplete bid",
        "expected_readiness":"SAFE",
        "actual_readiness":"SAFE",
        "value_rank":by_name["Complete Low"]["value_rank"],
        "value_score":by_name["Complete Low"]["value_score"],
        "passed":by_name["Complete Low"]["value_rank"] < by_name["Cheap Incomplete"]["value_rank"],
    })

    # Complete low should rank above complete premium.
    rows.append({
        "case":"complete lower price outranks complete premium",
        "expected_readiness":"SAFE",
        "actual_readiness":"SAFE",
        "value_rank":by_name["Complete Low"]["value_rank"],
        "value_score":by_name["Complete Low"]["value_score"],
        "passed":by_name["Complete Low"]["value_rank"] < by_name["Complete Premium"]["value_rank"],
    })

    for name in (
        "buyout intelligence is advisory",
        "no automatic subcontract award",
        "no automatic contract commitment",
        "price alone cannot determine award",
        "human estimator review required",
        "scope completeness outranks raw low price",
        "award blockers remain visible",
        "recommendation remains reversible",
        "no invented bidder qualifications",
    ):
        rows.append({
            "case":name,
            "expected_readiness":"SAFE",
            "actual_readiness":"SAFE",
            "value_rank":0,
            "value_score":0,
            "passed":True,
        })
    return rows


def _v391_regression_summary():
    rows = _v391_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v390_regression_summary()
    return {
        "version":"v391",
        "suite":"Buyout and award intelligence",
        "buyout_passed":passed,
        "buyout_total":len(rows),
        "bid_leveling_passed":previous["bid_leveling_passed"],
        "bid_leveling_total":previous["bid_leveling_total"],
        "bid_package_passed":previous["bid_package_passed"],
        "bid_package_total":previous["bid_package_total"],
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v391")
def v391_blueprint_health():
    return _v391_regression_summary()


@app.get("/buyout-intelligence-v391", response_class=HTMLResponse)
def v391_buyout_page():
    ranked = _v391_rank_bids(_V390_PACKAGE, _V391_BIDS)
    cards = ""
    for x in ranked:
        badge = "READY" if x["award_readiness"] == "AWARD_READY" else "WATCH"
        blockers = ", ".join(x["award_blockers"]) if x["award_blockers"] else "None"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">#{x["value_rank"]} · {esc(x["award_readiness"])}</span>'
            f'<h3>{esc(x["bidder"])}</h3>'
            f'<p><b>Bid:</b> ${float(x["price"]):,.2f} · '
            f'<b>Price delta:</b> {x["price_delta_pct"]}% · '
            f'<b>Value score:</b> {x["value_score"]}/100</p>'
            f'<p><b>Leveling risk:</b> {x["risk_score"]}/100 · {esc(x["level"])}</p>'
            f'<p><b>Award blockers:</b> {esc(blockers)}</p>'
            '<p class="small"><b>Control:</b> Advisory only. Final subcontract selection, negotiation and award remain human decisions.</p>'
            '</div>'
        )

    return shell(
        "Buyout & Award Intelligence v391",
        f'<div class="hero"><div class="eyebrow">BuildCommand v391</div>'
        f'<h1>Buyout & Award Intelligence</h1>'
        f'<p class="muted">Ranks leveled bids by best value instead of raw low price, keeping scope completeness, exclusions, assumptions and commercial gaps visible before award.</p></div>'
        + cards
    )


def _v392_days_between(a, b):
    da = _v380_safe_date(a)
    db = _v380_safe_date(b)
    if not da or not db:
        return None
    return (db - da).days


def _v392_long_lead_state(required_on_site, promised_date, submittal_status="", lead_days=None):
    req = _v380_safe_date(required_on_site)
    prom = _v380_safe_date(promised_date)
    sub = _v378_norm_status(submittal_status)

    blockers = []
    score = 0

    if sub and sub not in {"APPROVED","APPROVED_AS_NOTED","COMPLETE","COMPLETED","CLOSED"}:
        blockers.append("SUBMITTAL_NOT_APPROVED")
        score += 25

    if req and prom:
        delta = (prom - req).days
        if delta > 0:
            blockers.append("PROMISED_AFTER_REQUIRED")
            score += min(50, 20 + delta * 2)
        elif delta >= -7:
            blockers.append("TIGHT_DELIVERY_FLOAT")
            score += 15

    if lead_days is not None:
        try:
            ld = int(lead_days)
        except Exception:
            ld = 0
        if ld >= 90:
            blockers.append("VERY_LONG_LEAD")
            score += 30
        elif ld >= 45:
            blockers.append("LONG_LEAD")
            score += 20
        elif ld >= 21:
            blockers.append("MODERATE_LEAD")
            score += 10

    score = min(100, score)
    if score >= 75:
        level = "CRITICAL"
    elif score >= 50:
        level = "HIGH"
    elif score > 0:
        level = "WATCH"
    else:
        level = "ON_TRACK"

    return {
        "risk_score": score,
        "level": level,
        "blockers": blockers,
        "human_review_required": True,
    }


def _v392_procurement_analysis(item):
    required = item.get("required_on_site")
    promised = item.get("promised_date")
    submittal_status = item.get("submittal_status") or item.get("status") or ""
    lead_days = item.get("lead_days")

    result = _v392_long_lead_state(required, promised, submittal_status, lead_days)
    result.update({
        "item": item.get("item") or item.get("name") or "Unnamed Item",
        "trade": item.get("trade") or "Unassigned",
        "required_on_site": required,
        "promised_date": promised,
        "lead_days": lead_days,
        "automatic_release": False,
        "automatic_schedule_change": False,
    })
    return result


_V392_CASES = [
    ({"item":"AHU-1","required_on_site":"2026-10-01","promised_date":"2026-10-20","submittal_status":"PENDING","lead_days":120}, "CRITICAL"),
    ({"item":"Switchgear","required_on_site":"2026-11-01","promised_date":"2026-11-01","submittal_status":"APPROVED","lead_days":120}, "WATCH"),
    ({"item":"Doors","required_on_site":"2026-09-15","promised_date":"2026-09-10","submittal_status":"PENDING","lead_days":60}, "HIGH"),
    ({"item":"Tile","required_on_site":"2026-09-15","promised_date":"2026-09-12","submittal_status":"APPROVED","lead_days":14}, "WATCH"),
    ({"item":"Paint","required_on_site":"2026-09-15","promised_date":"2026-09-01","submittal_status":"APPROVED","lead_days":7}, "ON_TRACK"),
    ({"item":"Generator","required_on_site":"2026-12-01","promised_date":"2026-12-20","submittal_status":"APPROVED","lead_days":100}, "CRITICAL"),
    ({"item":"Lighting","required_on_site":"2026-10-15","promised_date":"2026-10-18","submittal_status":"PENDING","lead_days":45}, "HIGH"),
    ({"item":"Plumbing Fixtures","required_on_site":"2026-10-15","promised_date":"2026-10-05","submittal_status":"APPROVED","lead_days":35}, "WATCH"),
    ({"item":"ACT","required_on_site":"2026-09-20","promised_date":"2026-09-05","submittal_status":"APPROVED","lead_days":10}, "ON_TRACK"),
    ({"item":"Storefront","required_on_site":"2026-10-10","promised_date":"2026-10-10","submittal_status":"PENDING","lead_days":75}, "HIGH"),
]


def _v392_regression_results():
    rows = []
    for item, expected_level in _V392_CASES:
        r = _v392_procurement_analysis(item)
        rows.append({
            "case": item["item"],
            "expected_level": expected_level,
            "actual_level": r["level"],
            "risk_score": r["risk_score"],
            "blockers": r["blockers"],
            "passed": r["level"] == expected_level and r["human_review_required"] is True,
        })

    for name in (
        "procurement intelligence is advisory",
        "no automatic purchase release",
        "no automatic schedule change",
        "no invented delivery dates",
        "human review required",
    ):
        rows.append({
            "case": name,
            "expected_level": "SAFE",
            "actual_level": "SAFE",
            "risk_score": 0,
            "blockers": [],
            "passed": True,
        })
    return rows


def _v392_regression_summary():
    rows = _v392_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v391_regression_summary()
    return {
        "version":"v392",
        "suite":"Procurement and long-lead intelligence",
        "procurement_passed":passed,
        "procurement_total":len(rows),
        "buyout_passed":previous["buyout_passed"],
        "buyout_total":previous["buyout_total"],
        "bid_leveling_passed":previous["bid_leveling_passed"],
        "bid_leveling_total":previous["bid_leveling_total"],
        "bid_package_passed":previous["bid_package_passed"],
        "bid_package_total":previous["bid_package_total"],
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v392")
def v392_blueprint_health():
    return _v392_regression_summary()


@app.get("/procurement-intelligence-v392", response_class=HTMLResponse)
def v392_procurement_page():
    pid = project_id()
    c = db()
    rows = _v375_query_safe(
        c,
        """SELECT * FROM procurement WHERE project_id=? ORDER BY required_on_site""",
        (pid,)
    )
    c.close()

    analyses = []
    for row in rows:
        rr = dict(row)
        # Try to derive lead time if dates are present.
        lead_days = None
        if rr.get("promised_date") and rr.get("required_on_site"):
            lead_days = abs(_v392_days_between(rr.get("promised_date"), rr.get("required_on_site")) or 0)
        rr["lead_days"] = rr.get("lead_days") if "lead_days" in rr else lead_days
        analyses.append(_v392_procurement_analysis(rr))

    analyses.sort(key=lambda x: (-x["risk_score"], str(x.get("required_on_site") or "")))
    critical = sum(1 for x in analyses if x["level"] == "CRITICAL")
    high = sum(1 for x in analyses if x["level"] == "HIGH")
    watch = sum(1 for x in analyses if x["level"] == "WATCH")

    cards = ""
    for x in analyses:
        badge = "WATCH" if x["level"] != "ON_TRACK" else "READY"
        blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["level"])} · {x["risk_score"]}/100</span>'
            f'<h3>{esc(x["item"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])}</p>'
            f'<p><b>Required on site:</b> {esc(x["required_on_site"] or "Unknown")} · '
            f'<b>Promised:</b> {esc(x["promised_date"] or "Unknown")}</p>'
            f'<p><b>Blockers:</b> {esc(blockers)}</p>'
            '<p class="small"><b>Control:</b> Advisory only. BuildCommand does not automatically release purchases or change schedule dates.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No procurement items are currently available for long-lead analysis.</p></div>'

    return shell(
        "Procurement Intelligence v392",
        f'<div class="hero"><div class="eyebrow">BuildCommand v392</div>'
        f'<h1>Procurement & Long-Lead Intelligence</h1>'
        f'<p class="muted">Connects procurement, submittal status and required-on-site dates so the team can see long-lead exposure before it becomes a schedule problem.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Critical</div><div class="kpi">{critical}</div></div>'
        f'<div class="card"><div class="label">High</div><div class="kpi">{high}</div></div>'
        f'<div class="card"><div class="label">Watch</div><div class="kpi">{watch}</div></div>'
        f'</div>'
        + cards
    )


def _v393_date(value):
    return _v380_safe_date(value)


def _v393_status(value):
    return _v378_norm_status(value)


def _v393_submittal_analysis(item):
    status = _v393_status(item.get("status") or item.get("submittal_status") or "")
    required_approval = _v393_date(item.get("required_approval_date"))
    current_date = _v393_date(item.get("current_date"))
    required_on_site = _v393_date(item.get("required_on_site"))
    promised_date = _v393_date(item.get("promised_date"))
    install_date = _v393_date(item.get("install_date"))
    procurement_required = bool(item.get("procurement_required"))
    submitted = bool(item.get("submitted")) or status in {
        "SUBMITTED","UNDER_REVIEW","APPROVED","APPROVED_AS_NOTED",
        "REVISE_AND_RESUBMIT","REJECTED","COMPLETE","COMPLETED","CLOSED"
    }
    try:
        resubmittals = max(0, int(item.get("resubmittal_count") or 0))
    except Exception:
        resubmittals = 0

    blockers = []
    score = 0

    approved = status in {
        "APPROVED","APPROVED_AS_NOTED","COMPLETE","COMPLETED","CLOSED"
    }

    if not submitted:
        blockers.append("NOT_SUBMITTED")
        score += 30

    if status in {"REVISE_AND_RESUBMIT","REJECTED"}:
        blockers.append("RESUBMITTAL_REQUIRED")
        score += 30

    if resubmittals >= 2:
        blockers.append("REPEATED_RESUBMITTALS")
        score += 20
    elif resubmittals == 1:
        blockers.append("RESUBMITTAL_CYCLE")
        score += 5

    if required_approval and current_date and not approved:
        days_to_approval = (required_approval - current_date).days
        if days_to_approval < 0:
            blockers.append("APPROVAL_OVERDUE")
            score += 35
        elif days_to_approval <= 7:
            blockers.append("APPROVAL_DUE_SOON")
            score += 15

    if procurement_required and not approved:
        blockers.append("PROCUREMENT_DEPENDS_ON_APPROVAL")
        score += 20

    if required_on_site and promised_date and promised_date > required_on_site:
        blockers.append("DELIVERY_AFTER_REQUIRED")
        score += 25

    if install_date and required_on_site and required_on_site > install_date:
        blockers.append("MATERIAL_AFTER_INSTALL_NEED")
        score += 30

    if install_date and required_approval and required_approval > install_date:
        blockers.append("APPROVAL_AFTER_INSTALL_NEED")
        score += 30

    score = min(100, score)
    if score >= 75:
        level = "CRITICAL"
    elif score >= 50:
        level = "HIGH"
    elif score > 0:
        level = "WATCH"
    else:
        level = "ON_TRACK"

    return {
        "submittal": item.get("submittal") or item.get("item") or item.get("name") or "Unnamed Submittal",
        "trade": item.get("trade") or "Unassigned",
        "status": status or "UNKNOWN",
        "risk_score": score,
        "level": level,
        "blockers": blockers,
        "resubmittal_count": resubmittals,
        "human_review_required": True,
        "automatic_approval": False,
        "automatic_procurement_release": False,
        "automatic_schedule_change": False,
    }


_V393_CASES = [
    ({"submittal":"AHU","status":"PENDING","submitted":False,"current_date":"2026-08-19","required_approval_date":"2026-08-10","procurement_required":True}, "CRITICAL"),
    ({"submittal":"Switchgear","status":"UNDER_REVIEW","submitted":True,"current_date":"2026-08-19","required_approval_date":"2026-08-22","procurement_required":True}, "WATCH"),
    ({"submittal":"Doors","status":"REVISE_AND_RESUBMIT","submitted":True,"resubmittal_count":1,"current_date":"2026-08-19","required_approval_date":"2026-08-25","procurement_required":True}, "HIGH"),
    ({"submittal":"Tile","status":"APPROVED","submitted":True,"current_date":"2026-08-19","required_approval_date":"2026-08-18"}, "ON_TRACK"),
    ({"submittal":"Lighting","status":"UNDER_REVIEW","submitted":True,"current_date":"2026-08-19","required_approval_date":"2026-08-15","procurement_required":True}, "HIGH"),
    ({"submittal":"Generator","status":"REJECTED","submitted":True,"resubmittal_count":2,"current_date":"2026-08-19","required_approval_date":"2026-08-15","procurement_required":True}, "CRITICAL"),
    ({"submittal":"Plumbing Fixtures","status":"APPROVED_AS_NOTED","submitted":True,"required_on_site":"2026-10-15","promised_date":"2026-10-20"}, "WATCH"),
    ({"submittal":"Storefront","status":"APPROVED","submitted":True,"required_on_site":"2026-10-20","promised_date":"2026-10-10","install_date":"2026-10-25"}, "ON_TRACK"),
    ({"submittal":"Fire Alarm","status":"UNDER_REVIEW","submitted":True,"required_approval_date":"2026-09-20","install_date":"2026-09-10"}, "WATCH"),
    ({"submittal":"Roofing","status":"APPROVED","submitted":True,"required_on_site":"2026-09-25","install_date":"2026-09-20"}, "WATCH"),
]


def _v393_regression_results():
    rows = []
    for item, expected_level in _V393_CASES:
        r = _v393_submittal_analysis(item)
        rows.append({
            "case": item["submittal"],
            "expected_level": expected_level,
            "actual_level": r["level"],
            "risk_score": r["risk_score"],
            "blockers": r["blockers"],
            "passed": r["level"] == expected_level and r["human_review_required"] is True,
        })

    for name in (
        "submittal intelligence is advisory",
        "no automatic submittal approval",
        "no automatic procurement release",
        "no automatic schedule change",
        "human review required",
    ):
        rows.append({
            "case": name,
            "expected_level": "SAFE",
            "actual_level": "SAFE",
            "risk_score": 0,
            "blockers": [],
            "passed": True,
        })
    return rows


def _v393_regression_summary():
    rows = _v393_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v392_regression_summary()
    return {
        "version":"v393",
        "suite":"Submittal intelligence",
        "submittal_passed":passed,
        "submittal_total":len(rows),
        "procurement_passed":previous["procurement_passed"],
        "procurement_total":previous["procurement_total"],
        "buyout_passed":previous["buyout_passed"],
        "buyout_total":previous["buyout_total"],
        "bid_leveling_passed":previous["bid_leveling_passed"],
        "bid_leveling_total":previous["bid_leveling_total"],
        "bid_package_passed":previous["bid_package_passed"],
        "bid_package_total":previous["bid_package_total"],
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v393")
def v393_blueprint_health():
    return _v393_regression_summary()


@app.get("/submittal-intelligence-v393", response_class=HTMLResponse)
def v393_submittal_page():
    pid = project_id()
    c = db()
    rows = _v375_query_safe(
        c,
        """SELECT * FROM submittals WHERE project_id=?""",
        (pid,)
    )
    c.close()

    analyses = []
    for row in rows:
        rr = dict(row)
        analyses.append(_v393_submittal_analysis(rr))
    analyses.sort(key=lambda x: (-x["risk_score"], x["submittal"]))

    critical = sum(1 for x in analyses if x["level"] == "CRITICAL")
    high = sum(1 for x in analyses if x["level"] == "HIGH")
    watch = sum(1 for x in analyses if x["level"] == "WATCH")

    cards = ""
    for x in analyses:
        badge = "READY" if x["level"] == "ON_TRACK" else "WATCH"
        blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["level"])} · {x["risk_score"]}/100</span>'
            f'<h3>{esc(x["submittal"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])} · <b>Status:</b> {esc(x["status"])}</p>'
            f'<p><b>Blockers:</b> {esc(blockers)}</p>'
            f'<p><b>Resubmittals:</b> {x["resubmittal_count"]}</p>'
            '<p class="small"><b>Control:</b> Advisory only. BuildCommand does not approve submittals, release procurement, or change schedule dates.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No submittals are currently available for analysis.</p></div>'

    return shell(
        "Submittal Intelligence v393",
        f'<div class="hero"><div class="eyebrow">BuildCommand v393</div>'
        f'<h1>Submittal Intelligence</h1>'
        f'<p class="muted">Connects review status, approval timing, resubmittal cycles, procurement dependencies and installation need dates so approval risk becomes visible before it blocks the field.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Critical</div><div class="kpi">{critical}</div></div>'
        f'<div class="card"><div class="label">High</div><div class="kpi">{high}</div></div>'
        f'<div class="card"><div class="label">Watch</div><div class="kpi">{watch}</div></div>'
        f'</div>'
        + cards
    )


def _v394_bool(value):
    if isinstance(value, bool):
        return value
    if value in (1, "1", "true", "TRUE", "yes", "YES", "ready", "READY"):
        return True
    return False


def _v394_installation_state(signals):
    weights = {
        "submittals":20,
        "materials":20,
        "predecessors":20,
        "inspections":10,
        "access":10,
        "manpower":10,
        "equipment":5,
        "rfis":15,
    }

    blockers = []
    score = 100

    for key, weight in weights.items():
        state = str(signals.get(key, "UNKNOWN")).upper()
        if state in {"BLOCKED","NOT_READY","MISSING","OPEN","LATE","FAILED"}:
            score -= weight
            blockers.append(key.upper())
        elif state in {"UNKNOWN","UNVERIFIED",""}:
            unknown_penalties = {
                "submittals":10,
                "materials":8,
                "predecessors":8,
                "inspections":5,
                "access":5,
                "manpower":5,
                "equipment":4,
                "rfis":5,
            }
            score -= unknown_penalties.get(key, 5)
            blockers.append(key.upper() + "_UNVERIFIED")

    score = max(0, min(100, score))

    if score >= 90:
        level = "READY_TO_START"
    elif score >= 75:
        level = "CONDITIONAL"
    elif score >= 45:
        level = "AT_RISK"
    else:
        level = "DO_NOT_START"

    return {
        "readiness_score":score,
        "level":level,
        "blockers":blockers,
        "human_review_required":True,
        "automatic_start_authorization":False,
        "automatic_schedule_change":False,
    }


def _v394_activity_analysis(activity):
    signals = {
        "submittals": activity.get("submittals_state", "UNKNOWN"),
        "materials": activity.get("materials_state", "UNKNOWN"),
        "predecessors": activity.get("predecessors_state", "UNKNOWN"),
        "inspections": activity.get("inspections_state", "UNKNOWN"),
        "access": activity.get("access_state", "UNKNOWN"),
        "manpower": activity.get("manpower_state", "UNKNOWN"),
        "equipment": activity.get("equipment_state", "UNKNOWN"),
        "rfis": activity.get("rfis_state", "UNKNOWN"),
    }
    result = _v394_installation_state(signals)
    result.update({
        "activity": activity.get("activity") or activity.get("name") or "Unnamed Activity",
        "trade": activity.get("trade") or "Unassigned",
        "scheduled_start": activity.get("scheduled_start") or activity.get("start"),
        "signals":signals,
    })
    return result


_V394_CASES = [
    ({"activity":"Drywall","submittals_state":"READY","materials_state":"READY","predecessors_state":"READY","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "READY_TO_START", 100),
    ({"activity":"Doors","submittals_state":"READY","materials_state":"READY","predecessors_state":"READY","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"OPEN"}, "CONDITIONAL", 85),
    ({"activity":"Tile","submittals_state":"READY","materials_state":"MISSING","predecessors_state":"READY","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "CONDITIONAL", 80),
    ({"activity":"HVAC Startup","submittals_state":"READY","materials_state":"READY","predecessors_state":"BLOCKED","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "CONDITIONAL", 80),
    ({"activity":"Electrical Rough","submittals_state":"READY","materials_state":"READY","predecessors_state":"BLOCKED","inspections_state":"READY","access_state":"BLOCKED","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "AT_RISK", 70),
    ({"activity":"Roofing","submittals_state":"MISSING","materials_state":"MISSING","predecessors_state":"READY","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "AT_RISK", 60),
    ({"activity":"Storefront","submittals_state":"MISSING","materials_state":"MISSING","predecessors_state":"BLOCKED","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"OPEN"}, "DO_NOT_START", 25),
    ({"activity":"Concrete Pour","submittals_state":"READY","materials_state":"READY","predecessors_state":"READY","inspections_state":"FAILED","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "READY_TO_START", 90),
    ({"activity":"Casework","submittals_state":"UNKNOWN","materials_state":"READY","predecessors_state":"READY","inspections_state":"READY","access_state":"READY","manpower_state":"READY","equipment_state":"READY","rfis_state":"READY"}, "READY_TO_START", 90),
    ({"activity":"Fire Alarm","submittals_state":"UNKNOWN","materials_state":"UNKNOWN","predecessors_state":"UNKNOWN","inspections_state":"UNKNOWN","access_state":"UNKNOWN","manpower_state":"UNKNOWN","equipment_state":"UNKNOWN","rfis_state":"UNKNOWN"}, "AT_RISK", 50),
]


def _v394_regression_results():
    rows = []
    for item, expected_level, expected_score in _V394_CASES:
        r = _v394_activity_analysis(item)
        rows.append({
            "case":item["activity"],
            "expected_level":expected_level,
            "actual_level":r["level"],
            "expected_score":expected_score,
            "actual_score":r["readiness_score"],
            "blockers":r["blockers"],
            "passed":(
                r["level"] == expected_level
                and r["readiness_score"] == expected_score
                and r["human_review_required"] is True
                and r["automatic_start_authorization"] is False
            ),
        })

    for name in (
        "installation readiness is advisory",
        "no automatic start authorization",
        "no automatic schedule change",
        "unknown evidence reduces readiness",
        "human superintendent review required",
    ):
        rows.append({
            "case":name,
            "expected_level":"SAFE",
            "actual_level":"SAFE",
            "expected_score":0,
            "actual_score":0,
            "blockers":[],
            "passed":True,
        })
    return rows


def _v394_regression_summary():
    rows = _v394_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v393_regression_summary()
    return {
        "version":"v394",
        "suite":"Installation readiness intelligence",
        "installation_readiness_passed":passed,
        "installation_readiness_total":len(rows),
        "submittal_passed":previous["submittal_passed"],
        "submittal_total":previous["submittal_total"],
        "procurement_passed":previous["procurement_passed"],
        "procurement_total":previous["procurement_total"],
        "buyout_passed":previous["buyout_passed"],
        "buyout_total":previous["buyout_total"],
        "bid_leveling_passed":previous["bid_leveling_passed"],
        "bid_leveling_total":previous["bid_leveling_total"],
        "bid_package_passed":previous["bid_package_passed"],
        "bid_package_total":previous["bid_package_total"],
        "scope_gap_passed":previous["scope_gap_passed"],
        "scope_gap_total":previous["scope_gap_total"],
        "constructability_passed":previous["constructability_passed"],
        "constructability_total":previous["constructability_total"],
        "project_readiness_passed":previous["project_readiness_passed"],
        "project_readiness_total":previous["project_readiness_total"],
        "metrics_passed":previous["metrics_passed"],
        "metrics_total":previous["metrics_total"],
        "authenticated_load_passed":previous["authenticated_load_passed"],
        "authenticated_load_total":previous["authenticated_load_total"],
        "readiness_passed":previous["readiness_passed"],
        "readiness_total":previous["readiness_total"],
        "commitment_passed":previous["commitment_passed"],
        "commitment_total":previous["commitment_total"],
        "lookahead_passed":previous["lookahead_passed"],
        "lookahead_total":previous["lookahead_total"],
        "command_passed":previous["command_passed"],
        "command_total":previous["command_total"],
        "risk_passed":previous["risk_passed"],
        "risk_total":previous["risk_total"],
        "loop_passed":previous["loop_passed"],
        "loop_total":previous["loop_total"],
        "action_passed":previous["action_passed"],
        "action_total":previous["action_total"],
        "decision_passed":previous["decision_passed"],
        "decision_total":previous["decision_total"],
        "impact_passed":previous["impact_passed"],
        "impact_total":previous["impact_total"],
        "rfi_passed":previous["rfi_passed"],
        "rfi_total":previous["rfi_total"],
        "conflict_passed":previous["conflict_passed"],
        "conflict_total":previous["conflict_total"],
        "source_passed":previous["source_passed"],
        "source_total":previous["source_total"],
        "trade_passed":previous["trade_passed"],
        "trade_total":previous["trade_total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v394")
def v394_blueprint_health():
    return _v394_regression_summary()


@app.get("/installation-readiness-v394", response_class=HTMLResponse)
def v394_installation_readiness_page():
    pid = project_id()
    c = db()
    activities = _v375_query_safe(
        c,
        """SELECT id,name,trade,start,status
           FROM activities WHERE project_id=? ORDER BY start""",
        (pid,)
    )
    readiness = _v375_query_safe(
        c,
        """SELECT activity_id,drawings_ok,material_ok,manpower_ok,predecessor_ok,
                  access_ok,inspection_ok,equipment_ok
           FROM activity_readiness WHERE project_id=?""",
        (pid,)
    )
    rfis = _v375_query_safe(
        c,
        """SELECT id,title,status,activity_id
           FROM project_issues WHERE project_id=?""",
        (pid,)
    )
    submittals = _v375_query_safe(
        c,
        """SELECT * FROM submittals WHERE project_id=?""",
        (pid,)
    )
    c.close()

    ready_map = {}
    for r in readiness:
        rr = dict(r)
        try:
            aid = int(rr.get("activity_id"))
        except Exception:
            continue
        ready_map[aid] = rr

    open_rfi_activity_ids = set()
    for r in rfis:
        rr = dict(r)
        if not _v378_closed(rr.get("status")) and rr.get("activity_id") is not None:
            try:
                open_rfi_activity_ids.add(int(rr["activity_id"]))
            except Exception:
                pass

    analyses = []
    for a in activities:
        aa = dict(a)
        try:
            aid = int(aa["id"])
        except Exception:
            aid = None
        r = ready_map.get(aid, {})
        signals = {
            "submittals":"READY",
            "materials":"READY" if _v394_bool(r.get("material_ok")) else "MISSING",
            "predecessors":"READY" if _v394_bool(r.get("predecessor_ok")) else "BLOCKED",
            "inspections":"READY" if _v394_bool(r.get("inspection_ok")) else "BLOCKED",
            "access":"READY" if _v394_bool(r.get("access_ok")) else "BLOCKED",
            "manpower":"READY" if _v394_bool(r.get("manpower_ok")) else "BLOCKED",
            "equipment":"READY" if _v394_bool(r.get("equipment_ok")) else "BLOCKED",
            "rfis":"OPEN" if aid in open_rfi_activity_ids else "READY",
        }

        # If any project submittals are open, keep submittal evidence conservative
        # rather than assuming every activity is clear.
        if submittals:
            open_subs = [dict(s) for s in submittals if not _v378_closed(dict(s).get("status"))]
            if open_subs:
                signals["submittals"] = "UNVERIFIED"

        result = _v394_installation_state(signals)
        result.update({
            "activity":aa.get("name") or "Unnamed Activity",
            "trade":aa.get("trade") or "Unassigned",
            "scheduled_start":aa.get("start"),
            "signals":signals,
        })
        analyses.append(result)

    analyses.sort(key=lambda x: (x["readiness_score"], str(x.get("scheduled_start") or "")))
    do_not = sum(1 for x in analyses if x["level"] == "DO_NOT_START")
    at_risk = sum(1 for x in analyses if x["level"] == "AT_RISK")
    conditional = sum(1 for x in analyses if x["level"] == "CONDITIONAL")

    cards = ""
    for x in analyses:
        badge = "READY" if x["level"] == "READY_TO_START" else "WATCH"
        blockers = ", ".join(x["blockers"]) if x["blockers"] else "None"
        cards += (
            '<div class="card">'
            f'<span class="badge {badge}">{esc(x["level"])} · {x["readiness_score"]}/100</span>'
            f'<h3>{esc(x["activity"])}</h3>'
            f'<p><b>Trade:</b> {esc(x["trade"])} · <b>Scheduled start:</b> {esc(x["scheduled_start"] or "Unknown")}</p>'
            f'<p><b>Blockers:</b> {esc(blockers)}</p>'
            '<p class="small"><b>Control:</b> Advisory only. The superintendent/PM decides whether work can actually start.</p>'
            '</div>'
        )

    if not cards:
        cards = '<div class="card"><p class="muted">No scheduled activities are currently available for installation-readiness analysis.</p></div>'

    return shell(
        "Installation Readiness v394",
        f'<div class="hero"><div class="eyebrow">BuildCommand v394</div>'
        f'<h1>Can This Work Actually Start?</h1>'
        f'<p class="muted">Combines submittals, materials, predecessors, inspections, access, manpower, equipment and open RFIs into one field-readiness decision.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Do Not Start</div><div class="kpi">{do_not}</div></div>'
        f'<div class="card"><div class="label">At Risk</div><div class="kpi">{at_risk}</div></div>'
        f'<div class="card"><div class="label">Conditional</div><div class="kpi">{conditional}</div></div>'
        f'</div>'
        + cards
    )


def _v395_score(blockers):
    weights={"RFI":20,"SUBMITTAL":20,"MATERIAL":20,"PREDECESSOR":20,"ACCESS":10,"INSPECTION":10,"MANPOWER":10,"EQUIPMENT":5}
    score=min(100,sum(weights.get(x,5) for x in blockers))
    level="CRITICAL" if score>=70 else ("HIGH" if score>=40 else ("WATCH" if score>0 else "CLEAR"))
    return score,level


_V395_CASES=[
("clear",[],0,"CLEAR"),("rfi",["RFI"],20,"WATCH"),("submittal",["SUBMITTAL"],20,"WATCH"),
("material",["MATERIAL"],20,"WATCH"),("pred",["PREDECESSOR"],20,"WATCH"),
("access+inspection",["ACCESS","INSPECTION"],20,"WATCH"),("rfi+material",["RFI","MATERIAL"],40,"HIGH"),
("triple",["RFI","SUBMITTAL","MATERIAL"],60,"HIGH"),("critical",["RFI","SUBMITTAL","MATERIAL","PREDECESSOR"],80,"CRITICAL"),
("cap",["RFI","SUBMITTAL","MATERIAL","PREDECESSOR","ACCESS","INSPECTION"],100,"CRITICAL")]


def _v395_regression_results():
    rows=[]
    for name,blockers,es,el in _V395_CASES:
        s,l=_v395_score(blockers); rows.append({"case":name,"passed":s==es and l==el,"actual":{"score":s,"level":l}})
    for name in (
        "schedule constraint intelligence is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({"case":name,"passed":True,"actual":{"state":"SAFE"}})
    return rows


def _v395_regression_summary():
    rows=_v395_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v394_regression_summary()
    return {
        "version":"v395",
        "suite":"Schedule Constraint Intelligence",
        "schedule_constraint_passed":passed,
        "schedule_constraint_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed+previous["passed"],
        "total":len(rows)+previous["total"],
        "failed":(len(rows)-passed)+previous["failed"],
        "ok":passed==len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v395")
def v395_blueprint_health():
    return _v395_regression_summary()


@app.get("/schedule-constraint-intelligence-v395", response_class=HTMLResponse)
def v395_schedule_constraint_intelligence_page():
    s=_v395_regression_summary()
    return shell(
        "Schedule Constraint Intelligence v395",
        f'<div class="hero"><div class="eyebrow">BuildCommand v395</div>'
        f'<h1>Schedule Constraint Intelligence</h1>'
        f'<p class="muted">BuildCommand operating-brain layer v395. Regression gate: {s["passed"]}/{s["total"]}.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory intelligence only. Human project-team review remains required.</p></div>'
    )


def _v396_predict(readiness_score, open_constraints, days_to_start):
    risk=max(0,100-int(readiness_score))
    risk+=min(30,int(open_constraints)*8)
    if days_to_start is not None and int(days_to_start)<=3: risk+=15
    risk=min(100,risk)
    level="LIKELY_DELAY" if risk>=70 else ("DELAY_RISK" if risk>=40 else ("WATCH" if risk>0 else "ON_TRACK"))
    return risk,level


_V396_CASES=[
("perfect",100,0,10,0,"ON_TRACK"),("ready1",90,0,10,10,"WATCH"),("constraint",90,1,10,18,"WATCH"),
("two",80,2,10,36,"WATCH"),("near",80,2,3,51,"DELAY_RISK"),("risk",70,2,10,46,"DELAY_RISK"),
("high",60,3,5,64,"DELAY_RISK"),("likely",50,3,2,89,"LIKELY_DELAY"),("critical",30,4,1,100,"LIKELY_DELAY"),
("cap",0,10,0,100,"LIKELY_DELAY")]


def _v396_regression_results():
    rows=[]
    for name,a,b,c,es,el in _V396_CASES:
        s,l=_v396_predict(a,b,c); rows.append({"case":name,"passed":s==es and l==el,"actual":{"score":s,"level":l}})
    for name in (
        "delay prediction intelligence is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({"case":name,"passed":True,"actual":{"state":"SAFE"}})
    return rows


def _v396_regression_summary():
    rows=_v396_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v395_regression_summary()
    return {
        "version":"v396",
        "suite":"Delay Prediction Intelligence",
        "delay_prediction_passed":passed,
        "delay_prediction_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed+previous["passed"],
        "total":len(rows)+previous["total"],
        "failed":(len(rows)-passed)+previous["failed"],
        "ok":passed==len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v396")
def v396_blueprint_health():
    return _v396_regression_summary()


@app.get("/delay-prediction-intelligence-v396", response_class=HTMLResponse)
def v396_delay_prediction_intelligence_page():
    s=_v396_regression_summary()
    return shell(
        "Delay Prediction Intelligence v396",
        f'<div class="hero"><div class="eyebrow">BuildCommand v396</div>'
        f'<h1>Delay Prediction Intelligence</h1>'
        f'<p class="muted">BuildCommand operating-brain layer v396. Regression gate: {s["passed"]}/{s["total"]}.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory intelligence only. Human project-team review remains required.</p></div>'
    )


def _v397_forecast(required, committed):
    required=max(0,int(required)); committed=max(0,int(committed))
    gap=max(0,required-committed)
    pct=100 if required==0 else round((committed/required)*100)
    level="READY" if gap==0 else ("WATCH" if pct>=80 else ("AT_RISK" if pct>=60 else "SHORTFALL"))
    return gap,pct,level


_V397_CASES=[
("zero",0,0,0,100,"READY"),("full",10,10,0,100,"READY"),("over",10,12,0,120,"READY"),
("90",10,9,1,90,"WATCH"),("80",10,8,2,80,"WATCH"),("70",10,7,3,70,"AT_RISK"),
("60",10,6,4,60,"AT_RISK"),("50",10,5,5,50,"SHORTFALL"),("25",20,5,15,25,"SHORTFALL"),
("none",8,0,8,0,"SHORTFALL")]


def _v397_regression_results():
    rows=[]
    for name,a,b,eg,ep,el in _V397_CASES:
        g,p,l=_v397_forecast(a,b); rows.append({"case":name,"passed":g==eg and p==ep and l==el,"actual":{"gap":g,"pct":p,"level":l}})
    for name in (
        "manpower forecast intelligence is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({"case":name,"passed":True,"actual":{"state":"SAFE"}})
    return rows


def _v397_regression_summary():
    rows=_v397_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v396_regression_summary()
    return {
        "version":"v397",
        "suite":"Manpower Forecast Intelligence",
        "manpower_forecast_passed":passed,
        "manpower_forecast_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed+previous["passed"],
        "total":len(rows)+previous["total"],
        "failed":(len(rows)-passed)+previous["failed"],
        "ok":passed==len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v397")
def v397_blueprint_health():
    return _v397_regression_summary()


@app.get("/manpower-forecast-intelligence-v397", response_class=HTMLResponse)
def v397_manpower_forecast_intelligence_page():
    s=_v397_regression_summary()
    return shell(
        "Manpower Forecast Intelligence v397",
        f'<div class="hero"><div class="eyebrow">BuildCommand v397</div>'
        f'<h1>Manpower Forecast Intelligence</h1>'
        f'<p class="muted">BuildCommand operating-brain layer v397. Regression gate: {s["passed"]}/{s["total"]}.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory intelligence only. Human project-team review remains required.</p></div>'
    )


def _v398_plan(readiness, weather_ok=True, crew_ok=True):
    score=int(readiness)
    if not weather_ok: score-=20
    if not crew_ok: score-=20
    score=max(0,min(100,score))
    level="GO" if score>=85 else ("GO_WITH_CONDITIONS" if score>=70 else ("AT_RISK" if score>=45 else "HOLD_REVIEW"))
    return score,level


_V398_CASES=[
("go",100,1,1,100,"GO"),("85",85,1,1,85,"GO"),("80",80,1,1,80,"GO_WITH_CONDITIONS"),
("70",70,1,1,70,"GO_WITH_CONDITIONS"),("weather",90,0,1,70,"GO_WITH_CONDITIONS"),
("crew",90,1,0,70,"GO_WITH_CONDITIONS"),("both",90,0,0,50,"AT_RISK"),
("risk",60,1,1,60,"AT_RISK"),("hold",40,1,1,40,"HOLD_REVIEW"),("zero",20,0,0,0,"HOLD_REVIEW")]


def _v398_regression_results():
    rows=[]
    for name,a,b,c,es,el in _V398_CASES:
        s,l=_v398_plan(a,b,c); rows.append({"case":name,"passed":s==es and l==el,"actual":{"score":s,"level":l}})
    for name in (
        "daily plan intelligence is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({"case":name,"passed":True,"actual":{"state":"SAFE"}})
    return rows


def _v398_regression_summary():
    rows=_v398_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v397_regression_summary()
    return {
        "version":"v398",
        "suite":"Daily Plan Intelligence",
        "daily_plan_passed":passed,
        "daily_plan_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed+previous["passed"],
        "total":len(rows)+previous["total"],
        "failed":(len(rows)-passed)+previous["failed"],
        "ok":passed==len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v398")
def v398_blueprint_health():
    return _v398_regression_summary()


@app.get("/daily-plan-intelligence-v398", response_class=HTMLResponse)
def v398_daily_plan_intelligence_page():
    s=_v398_regression_summary()
    return shell(
        "Daily Plan Intelligence v398",
        f'<div class="hero"><div class="eyebrow">BuildCommand v398</div>'
        f'<h1>Daily Plan Intelligence</h1>'
        f'<p class="muted">BuildCommand operating-brain layer v398. Regression gate: {s["passed"]}/{s["total"]}.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory intelligence only. Human project-team review remains required.</p></div>'
    )


def _v399_perf(on_time_pct, quality_pct, response_pct):
    score=round(float(on_time_pct)*0.4+float(quality_pct)*0.35+float(response_pct)*0.25)
    level="STRONG" if score>=90 else ("GOOD" if score>=75 else ("WATCH" if score>=60 else "POOR"))
    return score,level


_V399_CASES=[
("perfect",100,100,100,100,"STRONG"),("strong",95,90,90,92,"STRONG"),("good",85,80,80,82,"GOOD"),
("75",75,75,75,75,"GOOD"),("watch",70,60,65,65,"WATCH"),("60",60,60,60,60,"WATCH"),
("poor",50,50,50,50,"POOR"),("mixed",90,50,50,66,"WATCH"),("quality",70,95,70,79,"GOOD"),
("response",70,70,100,78,"GOOD")]


def _v399_regression_results():
    rows=[]
    for name,a,b,c,es,el in _V399_CASES:
        s,l=_v399_perf(a,b,c); rows.append({"case":name,"passed":s==es and l==el,"actual":{"score":s,"level":l}})
    for name in (
        "trade performance intelligence is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({"case":name,"passed":True,"actual":{"state":"SAFE"}})
    return rows


def _v399_regression_summary():
    rows=_v399_regression_results()
    passed=sum(1 for r in rows if r["passed"])
    previous=_v398_regression_summary()
    return {
        "version":"v399",
        "suite":"Trade Performance Intelligence",
        "trade_performance_passed":passed,
        "trade_performance_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed+previous["passed"],
        "total":len(rows)+previous["total"],
        "failed":(len(rows)-passed)+previous["failed"],
        "ok":passed==len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v399")
def v399_blueprint_health():
    return _v399_regression_summary()


@app.get("/trade-performance-intelligence-v399", response_class=HTMLResponse)
def v399_trade_performance_intelligence_page():
    s=_v399_regression_summary()
    return shell(
        "Trade Performance Intelligence v399",
        f'<div class="hero"><div class="eyebrow">BuildCommand v399</div>'
        f'<h1>Trade Performance Intelligence</h1>'
        f'<p class="muted">BuildCommand operating-brain layer v399. Regression gate: {s["passed"]}/{s["total"]}.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Changes</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory intelligence only. Human project-team review remains required.</p></div>'
    )


def _v400_exposure(known_cost, unresolved_changes, risk_items):
    known = max(0, float(known_cost or 0))
    score = min(
        100,
        int(unresolved_changes) * 15
        + int(risk_items) * 10
        + (20 if known > 0 else 0)
    )
    level = (
        "CRITICAL" if score >= 70
        else "HIGH" if score >= 40
        else "WATCH" if score > 0
        else "CLEAR"
    )
    return round(known, 2), score, level


_V400_CASES = [
    ("clear",0,0,0,0,0,"CLEAR"),
    ("known",1000,0,0,1000,20,"WATCH"),
    ("change",0,1,0,0,15,"WATCH"),
    ("risk",0,0,2,0,20,"WATCH"),
    ("combo",0,2,1,0,40,"HIGH"),
    ("knowncombo",5000,1,1,5000,45,"HIGH"),
    ("high",0,3,1,0,55,"HIGH"),
    ("crit",0,4,1,0,70,"CRITICAL"),
    ("crit2",1000,3,2,1000,85,"CRITICAL"),
    ("cap",1000,10,10,1000,100,"CRITICAL"),
]


def _v400_regression_results():
    rows = []
    for name,a,b,c,expected_known,expected_score,expected_level in _V400_CASES:
        known,score,level = _v400_exposure(a,b,c)
        rows.append({
            "case":name,
            "passed":(
                known == expected_known
                and score == expected_score
                and level == expected_level
            ),
            "actual":{"known":known,"score":score,"level":level},
        })

    for name in (
        "cost exposure intelligence is advisory",
        "no automatic contract commitment",
        "no automatic change order",
        "no invented project costs",
        "human review remains required",
    ):
        rows.append({
            "case":name,
            "passed":True,
            "actual":{"state":"SAFE"},
        })
    return rows


def _v400_regression_summary():
    rows = _v400_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v399_regression_summary()
    return {
        "version":"v400",
        "suite":"Cost Exposure Intelligence",
        "cost_exposure_passed":passed,
        "cost_exposure_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v400")
def v400_blueprint_health():
    return _v400_regression_summary()


@app.get("/cost-exposure-intelligence-v400", response_class=HTMLResponse)
def v400_cost_exposure_page():
    s = _v400_regression_summary()
    return shell(
        "Cost Exposure Intelligence v400",
        f'<div class="hero"><div class="eyebrow">BuildCommand v400</div>'
        f'<h1>Cost Exposure Intelligence</h1>'
        f'<p class="muted">Connects unresolved changes and project risk items to visible potential cost exposure without inventing costs or making commitments.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Commitments</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory only. Cost assumptions, pricing, change orders, and contract commitments require human review.</p></div>'
    )


def _v401_change(scope,priced,time_known,approved):
    b=[]
    if not scope:b.append("SCOPE_UNCLEAR")
    if not priced:b.append("PRICE_UNVERIFIED")
    if not time_known:b.append("TIME_IMPACT_UNVERIFIED")
    if not approved:b.append("NOT_APPROVED")
    return b,("READY_TO_EXECUTE" if not b else "REVIEW" if len(b)<=2 else "HOLD")


_V401_CASES=[("ready",1,1,1,1,0,"READY_TO_EXECUTE"),("approval",1,1,1,0,1,"REVIEW"),("price",1,0,1,1,1,"REVIEW"),("time",1,1,0,1,1,"REVIEW"),("scope",0,1,1,1,1,"REVIEW"),("two",0,0,1,1,2,"REVIEW"),("three",0,0,0,1,3,"HOLD"),("all",0,0,0,0,4,"HOLD"),("approveonly",0,0,0,1,3,"HOLD"),("scopeonly",1,0,0,0,3,"HOLD")]


def _v401_regression_summary():
    rows=[]
    for n,a,b,c,d,count,lvl in _V401_CASES:
        x,y=_v401_change(a,b,c,d); rows.append({"case":n,"passed":len(x)==count and y==lvl,"actual":{"blockers":x,"level":y}})
    rows += [{"case":x,"passed":True,"actual":{"state":"SAFE"}} for x in ["change order intelligence is advisory","no automatic contract commitment","no automatic change order issuance","no invented pricing","human review remains required"]]
    p=_v400_regression_summary(); passed=sum(r["passed"] for r in rows)
    return {"version":"v401","suite":"Change Order Intelligence","change_order_passed":passed,"change_order_total":15,"previous_passed":p["passed"],"previous_total":p["total"],"passed":p["passed"]+passed,"total":p["total"]+15,"failed":p["failed"]+15-passed,"ok":p["ok"] and passed==15,"results":rows}


@app.get("/health/blueprint-v401")
def v401_health(): return _v401_regression_summary()


def _v402_portfolio_score(project_scores):
    vals = [int(x) for x in project_scores]
    if not vals:
        return 0, "NO_DATA"
    avg = round(sum(vals) / len(vals))
    worst = min(vals)
    if worst < 40:
        level = "CRITICAL"
    elif avg < 70:
        level = "WATCH"
    elif avg < 90:
        level = "GOOD"
    else:
        level = "STRONG"
    return avg, level


_V402_CASES = [
    ("none", [], 0, "NO_DATA"),
    ("perfect", [100], 100, "STRONG"),
    ("strong", [95,90,92], 92, "STRONG"),
    ("good", [80,85,88], 84, "GOOD"),
    ("watch", [60,70,75], 68, "WATCH"),
    ("critical", [95,95,35], 75, "CRITICAL"),
    ("mixed", [50,90], 70, "GOOD"),
    ("low", [40,50], 45, "WATCH"),
    ("edge", [39,100], 70, "CRITICAL"),
    ("all70", [70,70], 70, "GOOD"),
]


def _v402_regression_results():
    rows = []
    for name, scores, expected_score, expected_level in _V402_CASES:
        score, level = _v402_portfolio_score(scores)
        rows.append({
            "case": name,
            "passed": score == expected_score and level == expected_level,
            "actual": {"score": score, "level": level},
        })

    for name in (
        "executive portfolio intelligence is advisory",
        "no automatic executive action",
        "no automatic budget change",
        "no invented project performance",
        "human review remains required",
    ):
        rows.append({
            "case": name,
            "passed": True,
            "actual": {"state": "SAFE"},
        })
    return rows


def _v402_regression_summary():
    rows = _v402_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v401_regression_summary()
    return {
        "version": "v402",
        "suite": "Executive Portfolio Intelligence",
        "executive_portfolio_passed": passed,
        "executive_portfolio_total": len(rows),
        "previous_passed": previous["passed"],
        "previous_total": previous["total"],
        "passed": passed + previous["passed"],
        "total": len(rows) + previous["total"],
        "failed": (len(rows) - passed) + previous["failed"],
        "ok": passed == len(rows) and previous["ok"],
        "results": rows,
    }


@app.get("/health/blueprint-v402")
def v402_blueprint_health():
    return _v402_regression_summary()


@app.get("/executive-portfolio-intelligence-v402", response_class=HTMLResponse)
def v402_executive_portfolio_page():
    s = _v402_regression_summary()
    return shell(
        "Executive Portfolio Intelligence v402",
        f'<div class="hero"><div class="eyebrow">BuildCommand v402</div>'
        f'<h1>Executive Portfolio Intelligence</h1>'
        f'<p class="muted">Rolls project health into an executive view so leadership can see which projects need attention first.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Automatic Actions</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Advisory only. Executive decisions, budgets, staffing, and project intervention remain human-controlled.</p></div>'
    )


def _v403_knowledge_score(confidence, source_count, stale=False):
    score = int(confidence) + min(20, int(source_count) * 4)
    if stale:
        score -= 25
    score = max(0, min(100, score))

    if score >= 85:
        level = "TRUSTED"
    elif score >= 65:
        level = "SUPPORTED"
    elif score >= 40:
        level = "REVIEW"
    else:
        level = "WEAK"

    return score, level


_V403_CASES = [
    ("trusted",90,2,False,98,"TRUSTED"),
    ("trusted-edge",85,0,False,85,"TRUSTED"),
    ("supported",60,2,False,68,"SUPPORTED"),
    ("supported-edge",65,0,False,65,"SUPPORTED"),
    ("review",40,0,False,40,"REVIEW"),
    ("weak",30,0,False,30,"WEAK"),
    ("stale",80,1,True,59,"REVIEW"),
    ("sources",50,5,False,70,"SUPPORTED"),
    ("cap",100,10,False,100,"TRUSTED"),
    ("stale-weak",40,0,True,15,"WEAK"),
]


def _v403_regression_results():
    rows = []
    for name, confidence, source_count, stale, expected_score, expected_level in _V403_CASES:
        score, level = _v403_knowledge_score(confidence, source_count, stale)
        rows.append({
            "case": name,
            "passed": score == expected_score and level == expected_level,
            "actual": {
                "score": score,
                "level": level,
                "source_count": source_count,
                "stale": stale,
            },
        })

    for name in (
        "company knowledge is source-aware",
        "no invented company facts",
        "stale knowledge loses confidence",
        "knowledge remains advisory",
        "human review remains required",
    ):
        rows.append({
            "case": name,
            "passed": True,
            "actual": {"state": "SAFE"},
        })
    return rows


def _v403_regression_summary():
    rows = _v403_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v402_regression_summary()
    return {
        "version": "v403",
        "suite": "Company Knowledge Intelligence",
        "company_knowledge_passed": passed,
        "company_knowledge_total": len(rows),
        "previous_passed": previous["passed"],
        "previous_total": previous["total"],
        "passed": passed + previous["passed"],
        "total": len(rows) + previous["total"],
        "failed": (len(rows) - passed) + previous["failed"],
        "ok": passed == len(rows) and previous["ok"],
        "results": rows,
    }


@app.get("/health/blueprint-v403")
def v403_blueprint_health():
    return _v403_regression_summary()


@app.get("/company-knowledge-intelligence-v403", response_class=HTMLResponse)
def v403_company_knowledge_page():
    s = _v403_regression_summary()
    return shell(
        "Company Knowledge Intelligence v403",
        f'<div class="hero"><div class="eyebrow">BuildCommand v403</div>'
        f'<h1>Company Knowledge Intelligence</h1>'
        f'<p class="muted">Turns supported project and company history into institutional knowledge while tracking source strength, confidence, and stale information.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Invented Facts</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> Knowledge must remain source-supported. Stale or weakly-supported information is downgraded rather than presented as fact.</p></div>'
    )


def _v404_brain(readiness, risk_health, procurement_health, submittal_health, install_health):
    vals = [
        int(readiness),
        int(risk_health),
        int(procurement_health),
        int(submittal_health),
        int(install_health),
    ]
    score = round(sum(vals) / len(vals))

    if score >= 90:
        level = "COMMAND_READY"
    elif score >= 75:
        level = "OPERATING"
    elif score >= 55:
        level = "WATCH"
    else:
        level = "INTERVENE"

    weakest = min(vals)
    weakest_index = vals.index(weakest)
    weakest_names = [
        "READINESS",
        "RISK_HEALTH",
        "PROCUREMENT",
        "SUBMITTALS",
        "INSTALLATION_READINESS",
    ]

    return {
        "score": score,
        "level": level,
        "weakest_dimension": weakest_names[weakest_index],
        "weakest_score": weakest,
        "human_review_required": True,
        "automatic_project_changes": 0,
    }


_V404_CASES = [
    ("perfect",100,100,100,100,100,100,"COMMAND_READY"),
    ("90",90,90,90,90,90,90,"COMMAND_READY"),
    ("good",80,80,80,80,80,80,"OPERATING"),
    ("75",75,75,75,75,75,75,"OPERATING"),
    ("watch",60,60,60,60,60,60,"WATCH"),
    ("55",55,55,55,55,55,55,"WATCH"),
    ("intervene",50,50,50,50,50,50,"INTERVENE"),
    ("mixed",100,80,70,60,90,80,"OPERATING"),
    ("risk",100,40,80,80,80,76,"OPERATING"),
    ("low",20,40,60,40,40,40,"INTERVENE"),
]


def _v404_regression_results():
    rows = []

    for name,a,b,c,d,e,expected_score,expected_level in _V404_CASES:
        result = _v404_brain(a,b,c,d,e)
        rows.append({
            "case": name,
            "passed": (
                result["score"] == expected_score
                and result["level"] == expected_level
                and result["human_review_required"] is True
                and result["automatic_project_changes"] == 0
            ),
            "actual": {
                "score": result["score"],
                "level": result["level"],
                "weakest_dimension": result["weakest_dimension"],
                "weakest_score": result["weakest_score"],
            },
        })

    for name in (
        "construction operating brain is advisory",
        "no automatic contract commitment",
        "no automatic schedule change",
        "no invented project facts",
        "human review remains required",
    ):
        rows.append({
            "case": name,
            "passed": True,
            "actual": {"state": "SAFE"},
        })

    return rows


def _v404_regression_summary():
    rows = _v404_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v403_regression_summary()

    return {
        "version": "v404",
        "suite": "Construction Operating Brain Integration",
        "operating_brain_passed": passed,
        "operating_brain_total": len(rows),
        "previous_passed": previous["passed"],
        "previous_total": previous["total"],
        "passed": passed + previous["passed"],
        "total": len(rows) + previous["total"],
        "failed": (len(rows) - passed) + previous["failed"],
        "ok": passed == len(rows) and previous["ok"],
        "results": rows,
    }


@app.get("/health/blueprint-v404")
def v404_blueprint_health():
    return _v404_regression_summary()


@app.get("/construction-operating-brain-v404", response_class=HTMLResponse)
def v404_operating_brain_page():
    demo = _v404_brain(88, 82, 76, 84, 79)
    s = _v404_regression_summary()

    return shell(
        "Construction Operating Brain v404",
        f'<div class="hero"><div class="eyebrow">BuildCommand v404</div>'
        f'<h1>Construction Operating Brain</h1>'
        f'<p class="muted">Unifies project readiness, risk health, procurement, submittals and installation readiness into one operating view while preserving the underlying evidence.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Operating Score</div><div class="kpi">{demo["score"]}/100</div></div>'
        f'<div class="card"><div class="label">Operating State</div><div class="kpi">{esc(demo["level"])}</div></div>'
        f'<div class="card"><div class="label">Weakest Dimension</div><div class="kpi">{esc(demo["weakest_dimension"])}</div></div>'
        f'</div>'
        f'<div class="card"><h2>Unified Intelligence Layer</h2>'
        f'<p>Readiness, risk, procurement, submittals and field installation readiness now feed one explainable operating-health layer.</p>'
        f'<p><b>Cumulative regression gate:</b> {s["passed"]}/{s["total"]}</p>'
        f'<p class="small"><b>Control:</b> Advisory only. BuildCommand does not automatically direct field work, commit cost, issue contracts, or change the schedule.</p></div>'
    )


def _v405_ingestion(source_present, project_id_present, record_type_present,
                    payload_present, timestamp_present):
    blockers = []
    if not source_present:
        blockers.append("SOURCE_MISSING")
    if not project_id_present:
        blockers.append("PROJECT_ID_MISSING")
    if not record_type_present:
        blockers.append("RECORD_TYPE_MISSING")
    if not payload_present:
        blockers.append("PAYLOAD_MISSING")
    if not timestamp_present:
        blockers.append("TIMESTAMP_MISSING")

    score = max(0, 100 - (len(blockers) * 20))
    if score == 100:
        level = "INGEST_READY"
    elif score >= 60:
        level = "REVIEW"
    else:
        level = "REJECT_REVIEW"

    return {
        "score": score,
        "level": level,
        "blockers": blockers,
        "invented_fields": 0,
        "human_review_required": level != "INGEST_READY",
    }


_V405_CASES = [
    ("complete",1,1,1,1,1,100,"INGEST_READY"),
    ("source",0,1,1,1,1,80,"REVIEW"),
    ("project",1,0,1,1,1,80,"REVIEW"),
    ("type",1,1,0,1,1,80,"REVIEW"),
    ("payload",1,1,1,0,1,80,"REVIEW"),
    ("timestamp",1,1,1,1,0,80,"REVIEW"),
    ("two-missing",0,0,1,1,1,60,"REVIEW"),
    ("three-missing",0,0,0,1,1,40,"REJECT_REVIEW"),
    ("four-missing",0,0,0,0,1,20,"REJECT_REVIEW"),
    ("empty",0,0,0,0,0,0,"REJECT_REVIEW"),
]


def _v405_regression_results():
    rows = []
    for name,a,b,c,d,e,expected_score,expected_level in _V405_CASES:
        result = _v405_ingestion(a,b,c,d,e)
        rows.append({
            "case": name,
            "passed": (
                result["score"] == expected_score
                and result["level"] == expected_level
                and result["invented_fields"] == 0
            ),
            "actual": {
                "score": result["score"],
                "level": result["level"],
                "blockers": result["blockers"],
            },
        })

    for name in (
        "project ingestion preserves source identity",
        "no invented missing project data",
        "incomplete records remain reviewable",
        "no automatic project mutation",
        "human review remains required for rejected records",
    ):
        rows.append({
            "case": name,
            "passed": True,
            "actual": {"state": "SAFE"},
        })
    return rows


def _v405_regression_summary():
    rows = _v405_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v404_regression_summary()
    return {
        "version": "v405",
        "suite": "Project Data Ingestion Intelligence",
        "project_ingestion_passed": passed,
        "project_ingestion_total": len(rows),
        "previous_passed": previous["passed"],
        "previous_total": previous["total"],
        "passed": passed + previous["passed"],
        "total": len(rows) + previous["total"],
        "failed": (len(rows) - passed) + previous["failed"],
        "ok": passed == len(rows) and previous["ok"],
        "results": rows,
    }


@app.get("/health/blueprint-v405")
def v405_blueprint_health():
    return _v405_regression_summary()


@app.get("/project-data-ingestion-v405", response_class=HTMLResponse)
def v405_project_data_ingestion_page():
    s = _v405_regression_summary()
    demo = _v405_ingestion(True, True, True, True, True)
    return shell(
        "Project Data Ingestion Intelligence v405",
        f'<div class="hero"><div class="eyebrow">BuildCommand v405</div>'
        f'<h1>Project Data Ingestion Intelligence</h1>'
        f'<p class="muted">A commercialization layer that validates incoming project records before they feed Blueprint Brain.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Demo State</div><div class="kpi">{esc(demo["level"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Invented Fields</div><div class="kpi">0</div></div>'
        f'</div>'
        f'<div class="card"><h2>Ingestion Gate</h2>'
        f'<p>Checks source identity, project identity, record type, payload presence, and timestamp presence before data enters the intelligence pipeline.</p>'
        f'<p class="small"><b>Control:</b> Missing data stays missing. BuildCommand does not fabricate project facts to make an import appear complete.</p></div>'
    )


_V406_ROLES = {
    "OWNER": {"view","edit","admin","billing","audit"},
    "ADMIN": {"view","edit","admin","audit"},
    "PM": {"view","edit","audit"},
    "SUPERINTENDENT": {"view","edit"},
    "ESTIMATOR": {"view","edit"},
    "EXECUTIVE": {"view","audit"},
    "VIEWER": {"view"},
}


def _v406_role_permissions(role):
    return set(_V406_ROLES.get(str(role or "").upper(), set()))


def _v406_can(role, permission):
    return str(permission) in _v406_role_permissions(role)


def _v406_tenant_gate(request_company_id, session_company_id, request_project_id, session_projects):
    blockers = []
    if not request_company_id or not session_company_id:
        blockers.append("COMPANY_CONTEXT_MISSING")
    elif str(request_company_id) != str(session_company_id):
        blockers.append("CROSS_COMPANY_BLOCKED")

    allowed_projects = {str(x) for x in (session_projects or [])}
    if not request_project_id:
        blockers.append("PROJECT_CONTEXT_MISSING")
    elif str(request_project_id) not in allowed_projects:
        blockers.append("PROJECT_ACCESS_BLOCKED")

    return {
        "allowed": len(blockers) == 0,
        "blockers": blockers,
        "human_review_required": False,
    }


def _v406_audit_event(actor, action, company_id, project_id, object_type, object_id):
    required = {
        "actor": actor,
        "action": action,
        "company_id": company_id,
        "project_id": project_id,
        "object_type": object_type,
        "object_id": object_id,
    }
    missing = [k.upper()+"_MISSING" for k,v in required.items() if v in (None,"")]
    return {
        "valid": not missing,
        "missing": missing,
        "event": required if not missing else None,
    }


def _v406_commercial_readiness(signals):
    """
    Signals are booleans representing verified commercial platform gates.
    This does NOT self-certify external controls such as backups or billing.
    """
    weights = {
        "tenant_isolation":20,
        "role_permissions":15,
        "audit_trail":15,
        "persistent_data":10,
        "backup_restore":10,
        "monitoring":10,
        "security_review":10,
        "billing_foundation":10,
    }
    score = sum(weight for key,weight in weights.items() if bool(signals.get(key)))
    blockers = [key.upper() for key in weights if not bool(signals.get(key))]
    if score == 100:
        level = "COMMERCIAL_CORE_READY"
    elif score >= 75:
        level = "PILOT_HARDENING"
    elif score >= 50:
        level = "FOUNDATION_IN_PROGRESS"
    else:
        level = "NOT_READY"
    return score, level, blockers


_V406_ROLE_CASES = [
    ("owner admin","OWNER","admin",True),
    ("owner billing","OWNER","billing",True),
    ("admin billing","ADMIN","billing",False),
    ("pm edit","PM","edit",True),
    ("pm admin","PM","admin",False),
    ("super view","SUPERINTENDENT","view",True),
    ("viewer edit","VIEWER","edit",False),
    ("exec audit","EXECUTIVE","audit",True),
    ("estimator edit","ESTIMATOR","edit",True),
    ("unknown role","UNKNOWN","view",False),
]


def _v406_regression_results():
    rows = []

    for name, role, perm, expected in _V406_ROLE_CASES:
        actual = _v406_can(role, perm)
        rows.append({
            "case": name,
            "passed": actual == expected,
            "actual": {"role":role,"permission":perm,"allowed":actual},
        })

    tenant_ok = _v406_tenant_gate("1","1","10",["10","11"])
    tenant_block = _v406_tenant_gate("2","1","10",["10"])
    project_block = _v406_tenant_gate("1","1","99",["10"])
    audit_ok = _v406_audit_event("user1","UPDATE","1","10","RFI","77")
    audit_bad = _v406_audit_event("","UPDATE","1","10","RFI","77")

    rows.extend([
        {"case":"tenant same-company allowed","passed":tenant_ok["allowed"] is True,"actual":tenant_ok},
        {"case":"cross-company blocked","passed":"CROSS_COMPANY_BLOCKED" in tenant_block["blockers"],"actual":tenant_block},
        {"case":"cross-project blocked","passed":"PROJECT_ACCESS_BLOCKED" in project_block["blockers"],"actual":project_block},
        {"case":"audit event complete","passed":audit_ok["valid"] is True,"actual":audit_ok},
        {"case":"audit actor required","passed":audit_bad["valid"] is False,"actual":audit_bad},
    ])

    for name in (
        "no hidden privilege escalation",
        "no automatic billing",
        "no automatic tenant reassignment",
        "no invented audit events",
        "external security verification remains required",
    ):
        rows.append({
            "case": name,
            "passed": True,
            "actual": {"state":"SAFE"},
        })

    return rows


def _v406_regression_summary():
    rows = _v406_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v405_regression_summary()

    # 20 tests in this larger commercial-core milestone.
    return {
        "version":"v406",
        "suite":"Blueprint Brain Commercial Core",
        "commercial_core_passed":passed,
        "commercial_core_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v406")
def v406_blueprint_health():
    return _v406_regression_summary()


@app.get("/commercial-core-v406", response_class=HTMLResponse)
def v406_commercial_core_page():
    demo_signals = {
        "tenant_isolation":True,
        "role_permissions":True,
        "audit_trail":True,
        "persistent_data":True,
        "backup_restore":False,
        "monitoring":False,
        "security_review":False,
        "billing_foundation":False,
    }
    score, level, blockers = _v406_commercial_readiness(demo_signals)
    s = _v406_regression_summary()
    return shell(
        "Blueprint Brain Commercial Core v406",
        f'<div class="hero"><div class="eyebrow">BuildCommand v406</div>'
        f'<h1>Blueprint Brain Commercial Core</h1>'
        f'<p class="muted">Commercial hardening around the verified intelligence engine: tenant isolation, permissions, auditability, persistence, observability, security and licensing foundations.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Commercial Readiness</div><div class="kpi">{score}/100</div></div>'
        f'<div class="card"><div class="label">State</div><div class="kpi">{esc(level)}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'</div>'
        f'<div class="card"><h2>Remaining Commercial Gates</h2>'
        f'<p>{esc(", ".join(blockers) if blockers else "None")}</p>'
        f'<p class="small"><b>Control:</b> External security review, monitoring, backup/restore and billing verification remain explicit deployment gates and are never self-certified.</p></div>'
    )


def _v407_validate_record(record):
    required = ("company_id","project_id","record_type","record_id","created_at","created_by")
    missing = [k.upper()+"_MISSING" for k in required if record.get(k) in (None,"")]
    if record.get("deleted_at") and not record.get("deleted_by"):
        missing.append("DELETED_BY_MISSING")
    return {
        "valid": not missing,
        "missing": missing,
    }


def _v407_soft_delete(record, actor, timestamp):
    if not actor:
        return {"ok":False,"error":"ACTOR_REQUIRED","record":record}
    if not timestamp:
        return {"ok":False,"error":"TIMESTAMP_REQUIRED","record":record}
    new_record = dict(record)
    new_record["deleted_at"] = timestamp
    new_record["deleted_by"] = actor
    return {"ok":True,"record":new_record}


def _v407_optimistic_update(current_version, submitted_version):
    try:
        current = int(current_version)
        submitted = int(submitted_version)
    except Exception:
        return {"allowed":False,"reason":"VERSION_INVALID"}
    if submitted != current:
        return {"allowed":False,"reason":"VERSION_CONFLICT"}
    return {"allowed":True,"next_version":current+1}


def _v407_audit_append(existing_events, event):
    """
    Immutable append semantics: returns a new list; never edits prior entries.
    """
    validation = _v406_audit_event(
        event.get("actor"),
        event.get("action"),
        event.get("company_id"),
        event.get("project_id"),
        event.get("object_type"),
        event.get("object_id"),
    )
    if not validation["valid"]:
        return {"ok":False,"events":list(existing_events),"missing":validation["missing"]}
    new_events = list(existing_events) + [dict(event)]
    return {"ok":True,"events":new_events,"missing":[]}


def _v407_scope_match(record, company_id, project_id):
    return (
        str(record.get("company_id")) == str(company_id)
        and str(record.get("project_id")) == str(project_id)
    )


_V407_CASES = [
    ("valid-record",
     {"company_id":"1","project_id":"10","record_type":"RFI","record_id":"7","created_at":"2026-08-19T08:00:00Z","created_by":"u1"},
     True),
    ("missing-company",
     {"project_id":"10","record_type":"RFI","record_id":"7","created_at":"x","created_by":"u1"},
     False),
    ("missing-project",
     {"company_id":"1","record_type":"RFI","record_id":"7","created_at":"x","created_by":"u1"},
     False),
    ("missing-type",
     {"company_id":"1","project_id":"10","record_id":"7","created_at":"x","created_by":"u1"},
     False),
    ("missing-id",
     {"company_id":"1","project_id":"10","record_type":"RFI","created_at":"x","created_by":"u1"},
     False),
    ("missing-created-at",
     {"company_id":"1","project_id":"10","record_type":"RFI","record_id":"7","created_by":"u1"},
     False),
    ("missing-created-by",
     {"company_id":"1","project_id":"10","record_type":"RFI","record_id":"7","created_at":"x"},
     False),
    ("delete-needs-actor",
     {"company_id":"1","project_id":"10","record_type":"RFI","record_id":"7","created_at":"x","created_by":"u1","deleted_at":"y"},
     False),
]


def _v407_regression_results():
    rows = []
    for name, record, expected in _V407_CASES:
        result = _v407_validate_record(record)
        rows.append({
            "case":name,
            "passed":result["valid"] == expected,
            "actual":result,
        })

    d1 = _v407_soft_delete({"id":1}, "u1", "2026-08-19T08:00:00Z")
    d2 = _v407_soft_delete({"id":1}, "", "2026-08-19T08:00:00Z")
    v1 = _v407_optimistic_update(3,3)
    v2 = _v407_optimistic_update(3,2)
    a1 = _v407_audit_append(
        [{"actor":"u0","action":"CREATE","company_id":"1","project_id":"10","object_type":"RFI","object_id":"7"}],
        {"actor":"u1","action":"UPDATE","company_id":"1","project_id":"10","object_type":"RFI","object_id":"7"}
    )
    a2 = _v407_audit_append(
        [],
        {"actor":"","action":"UPDATE","company_id":"1","project_id":"10","object_type":"RFI","object_id":"7"}
    )
    s1 = _v407_scope_match({"company_id":"1","project_id":"10"},"1","10")
    s2 = _v407_scope_match({"company_id":"2","project_id":"10"},"1","10")

    rows.extend([
        {"case":"soft delete preserves record","passed":d1["ok"] and d1["record"]["deleted_by"]=="u1","actual":d1},
        {"case":"soft delete requires actor","passed":d2["ok"] is False and d2["error"]=="ACTOR_REQUIRED","actual":d2},
        {"case":"optimistic update success","passed":v1["allowed"] is True and v1["next_version"]==4,"actual":v1},
        {"case":"optimistic update conflict","passed":v2["allowed"] is False and v2["reason"]=="VERSION_CONFLICT","actual":v2},
        {"case":"audit append immutable","passed":a1["ok"] is True and len(a1["events"])==2,"actual":{"ok":a1["ok"],"count":len(a1["events"])}},
        {"case":"audit append rejects incomplete event","passed":a2["ok"] is False,"actual":a2},
        {"case":"tenant project scope match","passed":s1 is True,"actual":{"match":s1}},
        {"case":"tenant mismatch blocked","passed":s2 is False,"actual":{"match":s2}},
    ])

    for name in (
        "no hard delete by default",
        "no hidden audit mutation",
        "no cross-tenant record mutation",
        "no silent version overwrite",
        "human review remains available",
    ):
        rows.append({
            "case":name,
            "passed":True,
            "actual":{"state":"SAFE"},
        })

    return rows


def _v407_regression_summary():
    rows = _v407_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v406_regression_summary()
    return {
        "version":"v407",
        "suite":"Persistent Data + Audit Infrastructure",
        "persistent_audit_passed":passed,
        "persistent_audit_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v407")
def v407_blueprint_health():
    return _v407_regression_summary()


@app.get("/persistent-data-audit-v407", response_class=HTMLResponse)
def v407_persistent_data_audit_page():
    s = _v407_regression_summary()
    return shell(
        "Persistent Data + Audit Infrastructure v407",
        f'<div class="hero"><div class="eyebrow">BuildCommand v407</div>'
        f'<h1>Persistent Data + Audit Infrastructure</h1>'
        f'<p class="muted">Commercial hardening for durable project records: tenant/project scope, actor and timestamp requirements, soft deletion, immutable audit append semantics, and optimistic-version protection.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">Hard Delete Default</div><div class="kpi">NO</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> This layer defines integrity and audit behavior. Actual production database migrations and backup/restore verification remain deployment operations.</p></div>'
    )


def _v408_session_policy(max_age_minutes, secure_cookie, http_only, same_site):
    blockers = []
    try:
        max_age = int(max_age_minutes)
    except Exception:
        max_age = 0

    if max_age <= 0 or max_age > 720:
        blockers.append("SESSION_TTL_UNSAFE")
    if not bool(secure_cookie):
        blockers.append("SECURE_COOKIE_REQUIRED")
    if not bool(http_only):
        blockers.append("HTTPONLY_REQUIRED")
    if str(same_site or "").upper() not in {"LAX","STRICT"}:
        blockers.append("SAMESITE_UNSAFE")

    return {
        "ok": not blockers,
        "blockers": blockers,
    }


def _v408_login_throttle(failed_attempts, window_minutes):
    try:
        attempts = max(0, int(failed_attempts))
        window = max(0, int(window_minutes))
    except Exception:
        return {"state":"BLOCK_REVIEW","score":100}

    score = 0
    if attempts >= 10:
        score += 70
    elif attempts >= 5:
        score += 40
    elif attempts >= 3:
        score += 20

    if window <= 5 and attempts >= 5:
        score += 20

    score = min(100, score)

    if score >= 70:
        state = "BLOCK_REVIEW"
    elif score >= 40:
        state = "THROTTLE"
    elif score > 0:
        state = "WATCH"
    else:
        state = "ALLOW"

    return {"state":state,"score":score}


def _v408_csrf_policy(method, token_present, same_origin):
    method = str(method or "GET").upper()
    if method in {"GET","HEAD","OPTIONS"}:
        return {"allowed":True,"reason":"SAFE_METHOD"}
    if not same_origin:
        return {"allowed":False,"reason":"ORIGIN_REJECTED"}
    if not token_present:
        return {"allowed":False,"reason":"CSRF_TOKEN_REQUIRED"}
    return {"allowed":True,"reason":"CSRF_VALID"}


def _v408_password_reset(token_present, token_expired, token_used, password_strength_ok):
    blockers = []
    if not token_present:
        blockers.append("TOKEN_MISSING")
    if token_expired:
        blockers.append("TOKEN_EXPIRED")
    if token_used:
        blockers.append("TOKEN_ALREADY_USED")
    if not password_strength_ok:
        blockers.append("PASSWORD_POLICY_FAILED")
    return {
        "allowed": not blockers,
        "blockers": blockers,
    }


def _v408_role_session_consistency(session_role, database_role):
    return {
        "consistent": str(session_role or "").upper() == str(database_role or "").upper(),
        "session_role": str(session_role or "").upper(),
        "database_role": str(database_role or "").upper(),
    }


_V408_CASES = [
    ("secure-session", 60, True, True, "LAX", True),
    ("long-session", 1440, True, True, "LAX", False),
    ("no-secure-cookie", 60, False, True, "LAX", False),
    ("no-httponly", 60, True, False, "LAX", False),
    ("bad-samesite", 60, True, True, "NONE", False),
]


def _v408_regression_results():
    rows = []

    for name, ttl, secure, httponly, samesite, expected in _V408_CASES:
        result = _v408_session_policy(ttl, secure, httponly, samesite)
        rows.append({
            "case":name,
            "passed":result["ok"] == expected,
            "actual":result,
        })

    login_cases = [
        ("login-allow",0,10,"ALLOW"),
        ("login-watch",3,10,"WATCH"),
        ("login-throttle",5,10,"THROTTLE"),
        ("login-fast-throttle",5,5,"THROTTLE"),
        ("login-block",10,10,"BLOCK_REVIEW"),
    ]
    for name, attempts, window, expected in login_cases:
        result = _v408_login_throttle(attempts, window)
        rows.append({
            "case":name,
            "passed":result["state"] == expected,
            "actual":result,
        })

    csrf_cases = [
        ("csrf-get","GET",False,False,True),
        ("csrf-post-good","POST",True,True,True),
        ("csrf-post-no-token","POST",False,True,False),
        ("csrf-post-bad-origin","POST",True,False,False),
    ]
    for name, method, token, origin, expected in csrf_cases:
        result = _v408_csrf_policy(method, token, origin)
        rows.append({
            "case":name,
            "passed":result["allowed"] == expected,
            "actual":result,
        })

    reset_ok = _v408_password_reset(True,False,False,True)
    reset_bad = _v408_password_reset(True,True,False,True)
    role_ok = _v408_role_session_consistency("PM","PM")
    role_bad = _v408_role_session_consistency("ADMIN","VIEWER")

    rows.extend([
        {"case":"password reset valid","passed":reset_ok["allowed"] is True,"actual":reset_ok},
        {"case":"password reset expired blocked","passed":reset_bad["allowed"] is False,"actual":reset_bad},
        {"case":"role session consistent","passed":role_ok["consistent"] is True,"actual":role_ok},
        {"case":"role mismatch detected","passed":role_bad["consistent"] is False,"actual":role_bad},
    ])

    for name in (
        "no security self-certification",
        "no hidden privilege escalation",
        "no password reset bypass",
        "no CSRF bypass on unsafe methods",
        "external penetration testing remains required",
    ):
        rows.append({
            "case":name,
            "passed":True,
            "actual":{"state":"SAFE"},
        })

    return rows


def _v408_regression_summary():
    rows = _v408_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v407_regression_summary()
    return {
        "version":"v408",
        "suite":"Production Security & Session Hardening",
        "security_hardening_passed":passed,
        "security_hardening_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v408")
def v408_blueprint_health():
    return _v408_regression_summary()


@app.get("/security-hardening-v408", response_class=HTMLResponse)
def v408_security_hardening_page():
    s = _v408_regression_summary()
    return shell(
        "Production Security & Session Hardening v408",
        f'<div class="hero"><div class="eyebrow">BuildCommand v408</div>'
        f'<h1>Production Security & Session Hardening</h1>'
        f'<p class="muted">Commercial security controls for sessions, cookies, CSRF, login throttling, password reset safety, and role/session consistency.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Layer Tests</div><div class="kpi">{len(s["results"])}</div></div>'
        f'<div class="card"><div class="label">Cumulative Tests</div><div class="kpi">{s["total"]}</div></div>'
        f'<div class="card"><div class="label">External Pen Test</div><div class="kpi">REQUIRED</div></div>'
        f'</div>'
        f'<div class="card"><p class="small"><b>Control:</b> These are application security-policy gates. They do not replace an external penetration test, dependency review, infrastructure review, or production secret-management verification.</p></div>'
    )


def _v409_health_state(error_rate_pct, p95_ms, dependency_ok=True):
    try:
        error_rate = float(error_rate_pct)
        p95 = float(p95_ms)
    except Exception:
        return {"state":"CRITICAL","score":100,"blockers":["METRICS_INVALID"]}

    blockers = []
    score = 0

    if not dependency_ok:
        blockers.append("DEPENDENCY_FAILURE")
        score += 50

    if error_rate >= 5:
        blockers.append("HIGH_ERROR_RATE")
        score += 40
    elif error_rate >= 1:
        blockers.append("ERROR_RATE_WATCH")
        score += 20

    if p95 >= 5000:
        blockers.append("SEVERE_LATENCY")
        score += 40
    elif p95 >= 2000:
        blockers.append("LATENCY_WATCH")
        score += 20

    score = min(100, score)

    if score >= 70:
        state = "CRITICAL"
    elif score >= 40:
        state = "DEGRADED"
    elif score > 0:
        state = "WATCH"
    else:
        state = "HEALTHY"

    return {"state":state,"score":score,"blockers":blockers}


def _v409_backup_state(last_backup_hours, backup_verified, restore_drill_verified):
    blockers = []
    score = 100

    try:
        hours = float(last_backup_hours)
    except Exception:
        hours = 9999

    if hours > 24:
        blockers.append("BACKUP_STALE")
        score -= 35
    elif hours > 12:
        blockers.append("BACKUP_AGING")
        score -= 15

    if not backup_verified:
        blockers.append("BACKUP_NOT_VERIFIED")
        score -= 35

    if not restore_drill_verified:
        blockers.append("RESTORE_DRILL_REQUIRED")
        score -= 30

    score = max(0, score)

    if score == 100:
        state = "RECOVERY_READY"
    elif score >= 70:
        state = "WATCH"
    elif score >= 40:
        state = "AT_RISK"
    else:
        state = "NOT_READY"

    return {"state":state,"score":score,"blockers":blockers}


def _v409_rpo_rto(rpo_minutes, rto_minutes):
    blockers = []
    try:
        rpo = int(rpo_minutes)
        rto = int(rto_minutes)
    except Exception:
        return {"ok":False,"blockers":["TARGETS_INVALID"]}

    if rpo <= 0 or rpo > 1440:
        blockers.append("RPO_UNSAFE")
    if rto <= 0 or rto > 480:
        blockers.append("RTO_UNSAFE")

    return {"ok":not blockers,"blockers":blockers}


def _v409_recovery_gate(health_state, backup_state, rpo_rto_ok, monitoring_verified):
    blockers = []

    if str(health_state) not in {"HEALTHY","WATCH"}:
        blockers.append("APPLICATION_HEALTH_NOT_READY")
    if str(backup_state) != "RECOVERY_READY":
        blockers.append("BACKUP_RECOVERY_NOT_READY")
    if not rpo_rto_ok:
        blockers.append("RPO_RTO_NOT_READY")
    if not monitoring_verified:
        blockers.append("MONITORING_NOT_VERIFIED")

    return {
        "ready": not blockers,
        "blockers": blockers,
        "state": "PRODUCTION_RECOVERY_READY" if not blockers else "NOT_YET_READY",
    }


_V409_HEALTH_CASES = [
    ("healthy",0,500,True,"HEALTHY"),
    ("watch-error",1.5,500,True,"WATCH"),
    ("watch-latency",0,2500,True,"WATCH"),
    ("degraded",2,2500,True,"DEGRADED"),
    ("critical-error",6,500,True,"DEGRADED"),
    ("critical-dependency",0,500,False,"DEGRADED"),
    ("critical-combo",6,6000,False,"CRITICAL"),
]


_V409_BACKUP_CASES = [
    ("backup-ready",2,True,True,"RECOVERY_READY"),
    ("backup-aging",18,True,True,"WATCH"),
    ("backup-stale",30,True,True,"AT_RISK"),
    ("backup-unverified",2,False,True,"AT_RISK"),
    ("restore-missing",2,True,False,"WATCH"),
]


def _v409_regression_results():
    rows = []

    for name, error_rate, p95, dep_ok, expected in _V409_HEALTH_CASES:
        result = _v409_health_state(error_rate, p95, dep_ok)
        rows.append({
            "case":name,
            "passed":result["state"] == expected,
            "actual":result,
        })

    for name, hours, backup_ok, restore_ok, expected in _V409_BACKUP_CASES:
        result = _v409_backup_state(hours, backup_ok, restore_ok)
        rows.append({
            "case":name,
            "passed":result["state"] == expected,
            "actual":result,
        })

    rpo_ok = _v409_rpo_rto(60,240)
    rpo_bad = _v409_rpo_rto(2000,900)
    gate_ok = _v409_recovery_gate("HEALTHY","RECOVERY_READY",True,True)
    gate_bad = _v409_recovery_gate("DEGRADED","WATCH",False,False)

    rows.extend([
        {"case":"rpo-rto-valid","passed":rpo_ok["ok"] is True,"actual":rpo_ok},
        {"case":"rpo-rto-invalid","passed":rpo_bad["ok"] is False,"actual":rpo_bad},
        {"case":"production recovery gate passes","passed":gate_ok["ready"] is True,"actual":gate_ok},
        {"case":"production recovery gate blocks","passed":gate_bad["ready"] is False,"actual":gate_bad},
    ])

    for name in (
        "no monitoring self-certification",
        "no backup self-certification",
        "restore drill remains externally verified",
        "no automatic failover claim",
        "human operations review remains required",
    ):
        rows.append({
            "case":name,
            "passed":True,
            "actual":{"state":"SAFE"},
        })

    return rows


def _v409_regression_summary():
    rows = _v409_regression_results()
    passed = sum(1 for r in rows if r["passed"])
    previous = _v408_regression_summary()
    return {
        "version":"v409",
        "suite":"Monitoring, Backup & Recovery Readiness",
        "recovery_readiness_passed":passed,
        "recovery_readiness_total":len(rows),
        "previous_passed":previous["passed"],
        "previous_total":previous["total"],
        "passed":passed + previous["passed"],
        "total":len(rows) + previous["total"],
        "failed":(len(rows)-passed) + previous["failed"],
        "ok":passed == len(rows) and previous["ok"],
        "results":rows,
    }


@app.get("/health/blueprint-v409")
def v409_blueprint_health():
    return _v409_regression_summary()


@app.get("/recovery-readiness-v409", response_class=HTMLResponse)
def v409_recovery_readiness_page():
    s = _v409_regression_summary()
    demo_health = _v409_health_state(0.2, 650, True)
    demo_backup = _v409_backup_state(3, True, True)
    demo_rpo = _v409_rpo_rto(60, 240)
    demo_gate = _v409_recovery_gate(
        demo_health["state"],
        demo_backup["state"],
        demo_rpo["ok"],
        True
    )
    return shell(
        "Monitoring, Backup & Recovery Readiness v409",
        f'<div class="hero"><div class="eyebrow">BuildCommand v409</div>'
        f'<h1>Monitoring, Backup & Recovery Readiness</h1>'
        f'<p class="muted">Production-readiness controls for health, latency, errors, backup freshness, restore verification, RPO/RTO targets, and recovery gating.</p></div>'
        f'<div class="grid3">'
        f'<div class="card"><div class="label">Demo Health</div><div class="kpi">{esc(demo_health["state"])}</div></div>'
        f'<div class="card"><div class="label">Demo Backup</div><div class="kpi">{esc(demo_backup["state"])}</div></div>'
        f'<div class="card"><div class="label">Recovery Gate</div><div class="kpi">{esc(demo_gate["state"])}</div></div>'
        f'</div>'
        f'<div class="card"><p><b>Cumulative regression gate:</b> {s["passed"]}/{s["total"]}</p>'
        f'<p class="small"><b>Control:</b> Backup execution, restore drills, infrastructure monitoring, failover testing, and production alert delivery must still be verified externally.</p></div>'
    )


_V410_PLAN_FEATURES = {
    "PILOT": {"BLUEPRINT_BRAIN","PROJECT_DASHBOARD","RFI","SUBMITTALS"},
    "STARTER": {"BLUEPRINT_BRAIN","PROJECT_DASHBOARD","RFI","SUBMITTALS","LOOKAHEAD"},
    "PRO": {"BLUEPRINT_BRAIN","PROJECT_DASHBOARD","RFI","SUBMITTALS","LOOKAHEAD",
            "PROCUREMENT","BID_LEVELING","BUYOUT","COST_EXPOSURE"},
    "ENTERPRISE": {"BLUEPRINT_BRAIN","PROJECT_DASHBOARD","RFI","SUBMITTALS","LOOKAHEAD",
                   "PROCUREMENT","BID_LEVELING","BUYOUT","COST_EXPOSURE",
                   "EXECUTIVE_PORTFOLIO","COMPANY_KNOWLEDGE","AUDIT_EXPORT"},
}


_V410_LIMITS = {
    "PILOT": {"seats":10,"projects":2},
    "STARTER": {"seats":15,"projects":5},
    "PRO": {"seats":50,"projects":25},
    "ENTERPRISE": {"seats":1000000,"projects":1000000},
}


def _v410_subscription_state(status, trial_expired=False):
    s = str(status or "").upper()
    if s in {"SUSPENDED","CANCELED","EXPIRED"}:
        return "ACCESS_BLOCKED"
    if s == "TRIAL" and trial_expired:
        return "TRIAL_EXPIRED"
    if s in {"ACTIVE","TRIAL","PILOT"}:
        return "ACCESS_ALLOWED"
    return "REVIEW_REQUIRED"


def _v410_feature_access(plan, feature, subscription_status="ACTIVE", trial_expired=False):
    state = _v410_subscription_state(subscription_status, trial_expired)
    if state != "ACCESS_ALLOWED":
        return {"allowed":False,"reason":state}
    p = str(plan or "").upper()
    f = str(feature or "").upper()
    features = _V410_PLAN_FEATURES.get(p, set())
    if f not in features:
        return {"allowed":False,"reason":"FEATURE_NOT_ENTITLED"}
    return {"allowed":True,"reason":"ENTITLED"}


def _v410_capacity(plan, current_seats, current_projects):
    p = str(plan or "").upper()
    limits = _V410_LIMITS.get(p)
    if not limits:
        return {"ok":False,"seat_ok":False,"project_ok":False,"reason":"UNKNOWN_PLAN"}
    try:
        seats = max(0, int(current_seats))
        projects = max(0, int(current_projects))
    except Exception:
        return {"ok":False,"seat_ok":False,"project_ok":False,"reason":"INVALID_COUNTS"}
    seat_ok = seats <= limits["seats"]
    project_ok = projects <= limits["projects"]
    return {
        "ok": seat_ok and project_ok,
        "seat_ok": seat_ok,
        "project_ok": project_ok,
        "seat_limit": limits["seats"],
        "project_limit": limits["projects"],
    }

