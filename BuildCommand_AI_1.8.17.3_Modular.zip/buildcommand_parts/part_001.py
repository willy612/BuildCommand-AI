# BuildCommand AI 1.8.17.3 modular source fragment 001
# Generated from verified 1.8.17.2; execute only through full_app.py.

from fastapi import FastAPI, Form, Request, UploadFile, File


from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse, Response, FileResponse


import sqlite3


try:
    import openpyxl
except Exception:
    openpyxl = None


try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None


try:
    import psycopg
    from psycopg.rows import dict_row
except Exception:
    psycopg = None
    dict_row = None


import os


import io


import csv


import json


import base64


import re


import secrets


import hashlib


import hmac


import mimetypes


import zipfile


from contextvars import ContextVar


from datetime import date, datetime, timedelta


from pathlib import Path


try:
    from openai import OpenAI
except Exception:
    OpenAI = None


try:
    from reportlab.pdfgen import canvas
except Exception:
    canvas = None


app=FastAPI(title="BuildCommand AI",version="418.0")


DB="construction_ai_web.db"


DEFAULT_UPLOAD_DIR="/var/data/buildcommand_uploads" if os.path.isdir("/var/data") else "/tmp/buildcommand_uploads"


UPLOAD_DIR=os.environ.get("UPLOAD_DIR",DEFAULT_UPLOAD_DIR)


os.makedirs(UPLOAD_DIR,exist_ok=True)


_current_user_id=ContextVar("buildcommand_user_id",default=None)


_current_company_id=ContextVar("buildcommand_company_id",default=None)


MAX_UPLOAD_BYTES=45*1024*1024


ALLOWED_UPLOAD_EXTENSIONS={".pdf",".png",".jpg",".jpeg",".webp",".doc",".docx",".xls",".xlsx",".csv",".txt"}


DATABASE_URL=os.environ.get("DATABASE_URL","").strip()


DATABASE_KIND="postgres" if DATABASE_URL.startswith(("postgres://","postgresql://")) else "sqlite"


class PgCompatConnection:
    def __init__(self,conn):
        self.conn=conn
        self.last_insert_id=None
    def _sql(self,sql):
        if sql.strip().lower().startswith("select last_insert_rowid()"):
            return None
        sql=sql.replace("?","%s")
        sql=re.sub(r"INSERT OR REPLACE INTO user_state\s*\(user_id,selected_project_id\)\s*VALUES\(%s,%s\)","INSERT INTO user_state(user_id,selected_project_id) VALUES(%s,%s) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=EXCLUDED.selected_project_id",sql,flags=re.I|re.S)
        sql=re.sub(r"INSERT OR REPLACE INTO app_state\s*\(id,selected_project_id\)\s*VALUES\(%s,%s\)","INSERT INTO app_state(id,selected_project_id) VALUES(%s,%s) ON CONFLICT(id) DO UPDATE SET selected_project_id=EXCLUDED.selected_project_id",sql,flags=re.I|re.S)
        return sql
    def execute(self,sql,params=()):
        translated=self._sql(sql)
        if translated is None:
            class OneRow:
                def __init__(self,v): self.v=v
                def fetchone(self): return {"id":self.v}
                def fetchall(self): return [{"id":self.v}]
                def __iter__(self): return iter([{"id":self.v}])
            return OneRow(self.last_insert_id)
        cur=self.conn.cursor()
        m=re.match(r"\s*INSERT\s+INTO\s+([A-Za-z_][A-Za-z0-9_]*)",translated,re.I)
        if m and "RETURNING" not in translated.upper() and m.group(1).lower() not in {"user_state"}:
            try:
                cur.execute(translated.rstrip().rstrip(";")+" RETURNING id",params)
                row=cur.fetchone()
                if row and "id" in row: self.last_insert_id=row["id"]
                return cur
            except Exception:
                self.conn.rollback(); cur=self.conn.cursor()
        cur.execute(translated,params)
        return cur
    def executescript(self,script):
        ddl=re.sub(r"\bid INTEGER PRIMARY KEY\b","id BIGSERIAL PRIMARY KEY",script,flags=re.I)
        for stmt in [s.strip() for s in ddl.split(";") if s.strip()]: self.execute(stmt)
        return self
    def commit(self): self.conn.commit()
    def rollback(self): self.conn.rollback()
    def close(self): self.conn.close()


def db():
    if DATABASE_KIND=="postgres":
        if psycopg is None: raise RuntimeError("PostgreSQL DATABASE_URL is set but psycopg is not installed")
        return PgCompatConnection(psycopg.connect(DATABASE_URL,row_factory=dict_row))
    conn=sqlite3.connect(DB)
    conn.row_factory=sqlite3.Row
    return conn


def init():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY,name TEXT NOT NULL,logo_url TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,email TEXT NOT NULL UNIQUE,display_name TEXT,password_hash TEXT NOT NULL,role TEXT DEFAULT 'MEMBER',created TEXT);
    CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,token_hash TEXT NOT NULL UNIQUE,expires TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS user_state(user_id INTEGER PRIMARY KEY,selected_project_id INTEGER);
    CREATE TABLE IF NOT EXISTS attachments(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER,category TEXT,title TEXT,original_name TEXT,stored_name TEXT,mime_type TEXT,size_bytes INTEGER,created_by INTEGER,created TEXT);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER,severity TEXT,title TEXT,detail TEXT,source TEXT,status TEXT DEFAULT 'UNREAD',created TEXT);
    CREATE TABLE IF NOT EXISTS morning_briefs(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,brief_date TEXT,brief_text TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS beta_feedback(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,user_id INTEGER,project_id INTEGER,rating INTEGER,category TEXT,feedback TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS user_favorites(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,user_id INTEGER NOT NULL,tool_name TEXT,tool_url TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS project_archive_state(project_id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,archived INTEGER DEFAULT 0,archived_at TEXT);
    CREATE TABLE IF NOT EXISTS attachment_tags(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,attachment_id INTEGER NOT NULL,tag TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS notification_rules(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,rule_name TEXT,enabled INTEGER DEFAULT 1,severity TEXT DEFAULT 'HIGH',threshold_value REAL DEFAULT 0,created TEXT);
    CREATE TABLE IF NOT EXISTS health_history(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,snapshot_date TEXT,overall REAL,schedule REAL,readiness REAL,procurement REAL,risk REAL,field REAL,created TEXT);
    CREATE TABLE IF NOT EXISTS admin_audit_log(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,user_id INTEGER,project_id INTEGER,action TEXT,detail TEXT,created TEXT);

    CREATE TABLE IF NOT EXISTS invitations(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,email TEXT NOT NULL,role TEXT DEFAULT 'FIELD_USER',token_hash TEXT NOT NULL UNIQUE,expires TEXT,accepted INTEGER DEFAULT 0,created_by INTEGER,created TEXT);
    CREATE TABLE IF NOT EXISTS company_settings(company_id INTEGER PRIMARY KEY,auto_ai_brief INTEGER DEFAULT 1,email_alerts INTEGER DEFAULT 0,beta_mode INTEGER DEFAULT 1,onboarding_complete INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS weekly_ai_reports(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,week_ending TEXT,report_text TEXT,created TEXT);
    
    CREATE TABLE IF NOT EXISTS weather_impacts(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,activity_id INTEGER,impact_date TEXT,weather_type TEXT,lost_hours REAL DEFAULT 0,description TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS schedule_import_batches(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,file_name TEXT,row_count INTEGER DEFAULT 0,imported_count INTEGER DEFAULT 0,created TEXT);
    CREATE TABLE IF NOT EXISTS photo_observations(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,attachment_id INTEGER,activity_id INTEGER,observation TEXT,severity TEXT DEFAULT 'WATCH',created TEXT);
    CREATE TABLE IF NOT EXISTS communication_drafts(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,sub_id INTEGER,draft_type TEXT,subject TEXT,body TEXT,status TEXT DEFAULT 'DRAFT',created TEXT);
    CREATE TABLE IF NOT EXISTS meeting_ai_summaries(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,source_text TEXT,summary_text TEXT,created TEXT);

    CREATE TABLE IF NOT EXISTS document_ai_chunks(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,attachment_id INTEGER NOT NULL,chunk_index INTEGER,text_content TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS blueprint_runs(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,status TEXT DEFAULT 'COMPLETE',source_files TEXT,project_summary TEXT,detected_disciplines TEXT,cross_discipline_flags TEXT,rfi_candidates TEXT,review_notes TEXT,model_name TEXT,created_by INTEGER,created TEXT);
    CREATE TABLE IF NOT EXISTS blueprint_trade_scopes(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,run_id INTEGER NOT NULL,trade TEXT NOT NULL,division TEXT,summary TEXT,scope_text TEXT,item_count INTEGER DEFAULT 0,created TEXT);
    CREATE TABLE IF NOT EXISTS blueprint_scope_items(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,run_id INTEGER NOT NULL,trade_scope_id INTEGER,trade TEXT NOT NULL,requirement TEXT NOT NULL,source_sheet TEXT,source_detail TEXT,source_spec TEXT,source_note TEXT,related_trade TEXT,confidence TEXT DEFAULT 'MEDIUM',item_type TEXT DEFAULT 'SCOPE',status TEXT DEFAULT 'NOT_STARTED',created TEXT);
    CREATE TABLE IF NOT EXISTS schedule_import_sources(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,source_type TEXT,file_name TEXT,imported_count INTEGER DEFAULT 0,created TEXT);
    CREATE TABLE IF NOT EXISTS forecast_snapshots(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,snapshot_date TEXT,health_score REAL,projected_delay_days REAL,confidence REAL,explanation TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS sub_risk_snapshots(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,sub_id INTEGER NOT NULL,risk_score REAL,risk_band TEXT,explanation TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS change_packages(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,change_event_id INTEGER,package_text TEXT,created TEXT);
CREATE TABLE IF NOT EXISTS quick_entries(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,project_id INTEGER NOT NULL,user_id INTEGER,entry_type TEXT,text TEXT,routed_to TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS daily_reports(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        report_date TEXT,
        weather TEXT,
        manpower INTEGER DEFAULT 0,
        work_completed TEXT,
        delays TEXT,
        deliveries TEXT,
        inspections TEXT,
        safety TEXT,
        tomorrow_plan TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS daily_report_analysis(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        report_id INTEGER,
        analysis_text TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS action_items(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        title TEXT,
        owner TEXT,
        priority TEXT,
        due TEXT,
        status TEXT DEFAULT 'OPEN',
        notes TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS activity_readiness(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        drawings INTEGER DEFAULT 0,
        material INTEGER DEFAULT 0,
        manpower INTEGER DEFAULT 0,
        predecessor INTEGER DEFAULT 0,
        access_ready INTEGER DEFAULT 0,
        inspection INTEGER DEFAULT 0,
        equipment INTEGER DEFAULT 0,
        notes TEXT,
        updated TEXT,
        UNIQUE(project_id, activity_id)
    );

    CREATE TABLE IF NOT EXISTS procurement(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        item TEXT,
        vendor TEXT,
        required_on_site TEXT,
        promised_date TEXT,
        status TEXT,
        notes TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS project_issues(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        issue_type TEXT,
        title TEXT,
        owner TEXT,
        due TEXT,
        priority TEXT,
        status TEXT DEFAULT 'OPEN',
        description TEXT,
        response TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS punch_items(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        title TEXT,
        location TEXT,
        trade TEXT,
        owner TEXT,
        priority TEXT,
        due TEXT,
        status TEXT DEFAULT 'OPEN',
        description TEXT,
        resolution TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS inspections_tracker(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        inspection_type TEXT,
        authority TEXT,
        scheduled_date TEXT,
        result TEXT DEFAULT 'PENDING',
        reinspection_date TEXT,
        notes TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS submittals(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        title TEXT,
        spec_section TEXT,
        responsible_party TEXT,
        sent_date TEXT,
        due_date TEXT,
        status TEXT DEFAULT 'PENDING',
        notes TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS safety_items(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        event_date TEXT,
        item_type TEXT,
        title TEXT,
        location TEXT,
        responsible_party TEXT,
        severity TEXT,
        status TEXT DEFAULT 'OPEN',
        description TEXT,
        corrective_action TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS change_events(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        activity_id INTEGER,
        event_type TEXT,
        title TEXT,
        responsible_party TEXT,
        estimated_cost REAL DEFAULT 0,
        schedule_days REAL DEFAULT 0,
        status TEXT DEFAULT 'OPEN',
        description TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS meeting_notes(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        meeting_date TEXT,
        meeting_type TEXT,
        title TEXT,
        attendees TEXT,
        decisions TEXT,
        commitments TEXT,
        follow_up TEXT,
        created TEXT
    );

    CREATE TABLE IF NOT EXISTS app_state(
        id INTEGER PRIMARY KEY,
        selected_project_id INTEGER
    );
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,name TEXT,number TEXT,status TEXT);
    CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY,project_id INTEGER,external_id TEXT,name TEXT,trade TEXT,start TEXT,finish TEXT,pct REAL DEFAULT 0,status TEXT DEFAULT 'NOT_STARTED');
    CREATE TABLE IF NOT EXISTS make_ready(id INTEGER PRIMARY KEY,project_id INTEGER,activity_id INTEGER,title TEXT,reason TEXT,due TEXT,priority TEXT,status TEXT DEFAULT 'OPEN');
    CREATE TABLE IF NOT EXISTS risks(id INTEGER PRIMARY KEY,project_id INTEGER,activity_id INTEGER,score REAL,band TEXT,explanation TEXT);
    CREATE TABLE IF NOT EXISTS subs(id INTEGER PRIMARY KEY,project_id INTEGER,name TEXT,trade TEXT);

    CREATE TABLE IF NOT EXISTS subcontractor_updates(
        id INTEGER PRIMARY KEY,
        project_id INTEGER,
        sub_id INTEGER,
        update_date TEXT,
        manpower INTEGER DEFAULT 0,
        commitment TEXT,
        issue TEXT,
        status TEXT,
        created TEXT
    );
    CREATE TABLE IF NOT EXISTS production(id INTEGER PRIMARY KEY,project_id INTEGER,activity_id INTEGER,work_date TEXT,crew INTEGER,qty REAL,planned_qty REAL,unit TEXT);
    CREATE TABLE IF NOT EXISTS field_updates(id INTEGER PRIMARY KEY,project_id INTEGER,activity_id INTEGER,update_type TEXT,text TEXT,created TEXT);
    CREATE TABLE IF NOT EXISTS memory(id INTEGER PRIMARY KEY,project_id INTEGER,category TEXT,insight TEXT,confidence REAL);
    CREATE TABLE IF NOT EXISTS recovery(id INTEGER PRIMARY KEY,project_id INTEGER,activity_id INTEGER,scenario TEXT,days_recovered REAL,est_cost REAL,status TEXT);
    """)

    if c.execute("SELECT COUNT(*) n FROM projects").fetchone()["n"] == 0:
        c.execute(
            "INSERT INTO projects(name,number,status) VALUES(?,?,?)",
            ("Canyon Medical Office", "CMO-024", "ACTIVE")
        )
        pid = c.execute("SELECT id FROM projects ORDER BY id LIMIT 1").fetchone()["id"]

        acts = [
            ("A100", "Footings & Foundations", "Concrete", "2026-08-10", "2026-08-18", 80, "IN_PROGRESS"),
            ("A200", "Structural Steel / Deck", "Structural", "2026-08-19", "2026-09-04", 15, "NOT_STARTED"),
            ("A300", "MEP Underground / Rough", "MEP", "2026-08-24", "2026-09-11", 5, "NOT_STARTED"),
            ("A400", "Interior Framing", "Framing", "2026-09-08", "2026-09-25", 0, "NOT_STARTED"),
            ("A500", "Drywall Close-In", "Drywall", "2026-09-22", "2026-10-09", 0, "NOT_STARTED"),
        ]
        for x in acts:
            c.execute(
                "INSERT INTO activities(project_id,external_id,name,trade,start,finish,pct,status) VALUES(?,?,?,?,?,?,?,?)",
                (pid, *x)
            )

        ids = {
            r["external_id"]: r["id"]
            for r in c.execute(
                "SELECT id,external_id FROM activities WHERE project_id=?",
                (pid,)
            )
        }

        c.execute(
            "INSERT INTO make_ready(project_id,activity_id,title,reason,due,priority) VALUES(?,?,?,?,?,?)",
            (pid, ids["A300"], "Clear MEP rough-in access", "Material laydown is blocking east-side access.", "2026-08-12", "CRITICAL")
        )
        c.execute(
            "INSERT INTO make_ready(project_id,activity_id,title,reason,due,priority) VALUES(?,?,?,?,?,?)",
            (pid, ids["A200"], "Confirm steel delivery", "Fabricator delivery confirmation has not been received.", "2026-08-13", "HIGH")
        )

        for aid, score, band, why in [
            (ids["A300"], 82, "CRITICAL", "MEP rough-in is behind the field plan and access remains unresolved."),
            (ids["A200"], 68, "HIGH", "Steel delivery confirmation is unresolved; downstream starts are exposed."),
            (ids["A400"], 44, "WATCH", "Framing depends on MEP rough-in and inspection clearance."),
        ]:
            c.execute(
                "INSERT INTO risks(project_id,activity_id,score,band,explanation) VALUES(?,?,?,?,?)",
                (pid, aid, score, band, why)
            )

        for name, trade in [
            ("Apex Concrete", "Concrete"),
            ("Metro Steel", "Structural"),
            ("Summit MEP", "MEP"),
        ]:
            c.execute(
                "INSERT INTO subs(project_id,name,trade) VALUES(?,?,?)",
                (pid, name, trade)
            )

        c.execute(
            "INSERT INTO memory(project_id,category,insight,confidence) VALUES(?,?,?,?)",
            (pid, "Company Memory", "Early access constraints on MEP rough-in should be cleared before manpower is increased.", .72)
        )

    if c.execute("SELECT COUNT(*) n FROM app_state").fetchone()["n"] == 0:
        first_project = c.execute("SELECT id FROM projects ORDER BY id LIMIT 1").fetchone()
        if first_project:
            c.execute(
                "INSERT INTO app_state(id, selected_project_id) VALUES(1, ?)",
                (first_project["id"],)
            )

    if DATABASE_KIND=="postgres":
        project_columns={row["column_name"] for row in c.execute("SELECT column_name FROM information_schema.columns WHERE table_schema='public' AND table_name='projects'").fetchall()}
    else:
        project_columns={row["name"] for row in c.execute("PRAGMA table_info(projects)").fetchall()}
    if "company_id" not in project_columns:
        c.execute("ALTER TABLE projects ADD COLUMN company_id INTEGER")

    c.commit()
    c.close()


init()


def hash_password(password):
    salt = secrets.token_bytes(16)
    rounds = 210000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, rounds)
    return f"pbkdf2_sha256${rounds}${salt.hex()}${digest.hex()}"


def verify_password(password, stored):
    try:
        algorithm, rounds, salt_hex, digest_hex = stored.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        calc = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(rounds)).hex()
        return hmac.compare_digest(calc, digest_hex)
    except Exception:
        return False


def current_user_id():
    return _current_user_id.get()


def current_company_id():
    return _current_company_id.get()


def current_user():
    uid = current_user_id()
    if not uid:
        return None
    c = db()
    row = c.execute("""
        SELECT u.*, c.name AS company_name, c.logo_url
        FROM users u JOIN companies c ON c.id=u.company_id
        WHERE u.id=?
    """, (uid,)).fetchone()
    c.close()
    return row


ROLE_ORDER={"READ_ONLY":0,"FIELD_USER":1,"MEMBER":1,"SUPERINTENDENT":2,"PROJECT_MANAGER":3,"ADMIN":4,"OWNER":5}


def role_level(role):
    return ROLE_ORDER.get((role or "").upper(),0)


def require_role(min_role):
    u=current_user()
    return bool(u and role_level(u["role"])>=role_level(min_role))


def ensure_company_settings(company_id):
    if not company_id: return
    c=db()
    row=c.execute("SELECT company_id FROM company_settings WHERE company_id=?",(company_id,)).fetchone()
    if not row:
        c.execute("INSERT INTO company_settings(company_id,auto_ai_brief,email_alerts,beta_mode,onboarding_complete) VALUES(?,?,?,?,?)",(company_id,1,0,1,0))
        c.commit()
    c.close()


def company_setting(name,default=0):
    cid=current_company_id()
    if not cid: return default
    ensure_company_settings(cid)
    c=db(); row=c.execute("SELECT * FROM company_settings WHERE company_id=?",(cid,)).fetchone(); c.close()
    try: return row[name]
    except Exception: return default


def create_session(user_id):
    raw = secrets.token_urlsafe(40)
    token_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    expires = (datetime.utcnow() + timedelta(days=30)).isoformat()
    c = db()
    c.execute("INSERT INTO sessions(user_id,token_hash,expires,created) VALUES(?,?,?,?)",
              (user_id, token_hash, expires, datetime.utcnow().isoformat()))
    c.commit(); c.close()
    return raw


def user_from_session(raw_token):
    if not raw_token:
        return None
    token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    c = db()
    row = c.execute("""
        SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
        WHERE s.token_hash=? AND (s.expires IS NULL OR s.expires>?)
    """, (token_hash, datetime.utcnow().isoformat())).fetchone()
    c.close()
    return row


PUBLIC_PATHS = {"/login", "/register", "/health"}


@app.middleware("http")
async def v169_performance_headers(request, call_next):
    response=await call_next(request)
    path=request.url.path
    if path.startswith("/api/dashboard/"):
        response.headers["Cache-Control"]="private, max-age=10"
    elif path in {"/","/build","/estimate","/manage","/intelligence"}:
        response.headers["Cache-Control"]="private, no-store"
    return response


@app.middleware("http")
async def authentication_middleware(request: Request, call_next):
    raw_token = request.cookies.get("bc_session")
    user = user_from_session(raw_token)
    t1 = _current_user_id.set(user["id"] if user else None)
    t2 = _current_company_id.set(user["company_id"] if user else None)
    try:
        if not user and request.url.path not in PUBLIC_PATHS:
            return RedirectResponse("/login", status_code=303)
        return await call_next(request)
    finally:
        _current_user_id.reset(t1)
        _current_company_id.reset(t2)


def login_page(message=""):
    return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>BuildCommand AI Login</title>
    <style>body{{margin:0;background:#0a1017;color:#eef4fb;font-family:Inter,system-ui,sans-serif;padding:28px}}.box{{max-width:460px;margin:6vh auto;background:#111923;border:1px solid #213042;border-radius:16px;padding:26px}}input{{width:100%;box-sizing:border-box;background:#0d1620;color:#eef4fb;border:1px solid #213042;border-radius:9px;padding:12px;margin:8px 0 16px}}button{{background:#f0b44d;border:0;border-radius:9px;padding:11px 16px;font-weight:800}}a{{color:#f0b44d}}.muted{{color:#8fa2b5}}.error{{color:#ff9b9b}}</style></head><body>
    <div class="box"><div class="muted">Construction Intelligence Platform</div><h1>BuildCommand AI</h1><p class="error">{esc(message)}</p>
    <form method="post" action="/login"><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required><button type="submit">Sign In</button></form>
    <p><a href="/register">Create a company account</a></p><p class="muted">Built by Wilson LaHood · © 2026 Wilson LaHood</p></div></body></html>'''


@app.get("/login", response_class=HTMLResponse)
def login_get():
    return login_page()


@app.post("/login", response_class=HTMLResponse)
def login_post(email: str = Form(...), password: str = Form(...)):
    c = db(); user = c.execute("SELECT * FROM users WHERE lower(email)=lower(?)", (email.strip(),)).fetchone(); c.close()
    if not user or not verify_password(password, user["password_hash"]):
        return HTMLResponse(login_page("Email or password is incorrect."), status_code=401)
    raw = create_session(user["id"])
    response = RedirectResponse("/", status_code=303)
    response.set_cookie("bc_session", raw, httponly=True, secure=os.environ.get("COOKIE_SECURE", "1") == "1", samesite="lax", max_age=2592000)
    return response


@app.get("/register", response_class=HTMLResponse)
def register_get():
    return '''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create BuildCommand Account</title>
    <style>body{margin:0;background:#0a1017;color:#eef4fb;font-family:Inter,system-ui,sans-serif;padding:28px}.box{max-width:520px;margin:4vh auto;background:#111923;border:1px solid #213042;border-radius:16px;padding:26px}input{width:100%;box-sizing:border-box;background:#0d1620;color:#eef4fb;border:1px solid #213042;border-radius:9px;padding:12px;margin:8px 0 16px}button{background:#f0b44d;border:0;border-radius:9px;padding:11px 16px;font-weight:800}a{color:#f0b44d}.muted{color:#8fa2b5}</style></head><body>
    <div class="box"><div class="muted">BuildCommand AI</div><h1>Create Company Account</h1><form method="post" action="/register"><label>Company Name</label><input name="company_name" required><label>Your Name</label><input name="display_name" required><label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" minlength="8" required><button type="submit">Create Account</button></form><p><a href="/login">Back to login</a></p></div></body></html>'''


@app.post("/register")
def register_post(company_name: str = Form(...), display_name: str = Form(...), email: str = Form(...), password: str = Form(...)):
    if len(password) < 8:
        return HTMLResponse("Password must be at least 8 characters.", status_code=400)
    c = db()
    if c.execute("SELECT id FROM users WHERE lower(email)=lower(?)", (email.strip(),)).fetchone():
        c.close(); return HTMLResponse("That email is already registered.", status_code=400)
    c.execute("INSERT INTO companies(name,created) VALUES(?,?)", (company_name.strip(), date.today().isoformat()))
    company_id = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    c.execute("INSERT INTO users(company_id,email,display_name,password_hash,role,created) VALUES(?,?,?,?,?,?)",
              (company_id,email.strip().lower(),display_name.strip(),hash_password(password),"OWNER",date.today().isoformat()))
    user_id = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    c.execute("UPDATE projects SET company_id=? WHERE company_id IS NULL", (company_id,))
    first_project = c.execute("SELECT id FROM projects WHERE company_id=? ORDER BY id LIMIT 1", (company_id,)).fetchone()
    if first_project:
        c.execute("INSERT INTO user_state(user_id,selected_project_id) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=excluded.selected_project_id", (user_id, first_project["id"]))
    c.commit(); c.close()
    raw = create_session(user_id)
    response = RedirectResponse("/", status_code=303)
    response.set_cookie("bc_session", raw, httponly=True, secure=os.environ.get("COOKIE_SECURE", "1") == "1", samesite="lax", max_age=2592000)
    return response


@app.post("/logout")
def logout(request: Request):
    raw = request.cookies.get("bc_session")
    if raw:
        token_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest(); c = db(); c.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash,)); c.commit(); c.close()
    response = RedirectResponse("/login", status_code=303); response.delete_cookie("bc_session"); return response


@app.get("/health")
def health():
    return {"status":"ok","app":"BuildCommand AI","version":"31.1"}


@app.get("/projects/new", response_class=HTMLResponse)
def new_project_form():
    return """
    <html>
    <head>
        <title>Add Project</title>
        <style>
            body {
                background:#0a1017;
                color:white;
                font-family:Arial,sans-serif;
                padding:40px;
            }
            .box {
                max-width:500px;
                margin:auto;
                background:#111923;
                padding:30px;
                border-radius:15px;
            }
            input, select {
                width:100%;
                padding:12px;
                margin:8px 0 18px;
                box-sizing:border-box;
                border-radius:8px;
                border:1px solid #213042;
                background:#0d1620;
                color:white;
            }
            button {
                background:#f0b44d;
                border:none;
                padding:12px 20px;
                border-radius:8px;
                font-weight:bold;
                cursor:pointer;
            }
            a {
                color:#f0b44d;
            }
        </style>
    </head>

    <body>
        <div class="box">
            <h1>Add New Project</h1>

            <form method="post" action="/projects/new">

                <label>Project Name</label>
                <input
                    type="text"
                    name="name"
                    placeholder="Example: Phoenix Medical Center"
                    required
                >

                <label>Project Number</label>
                <input
                    type="text"
                    name="number"
                    placeholder="Example: PMC-001"
                    required
                >

                <label>Status</label>
                <select name="status">
                    <option value="ACTIVE">Active</option>
                    <option value="PLANNING">Planning</option>
                    <option value="ON_HOLD">On Hold</option>
                    <option value="COMPLETE">Complete</option>
                </select>

                <button type="submit">
                    Save Project
                </button>

            </form>

            <p>
                <a href="/">← Back to Dashboard</a>
            </p>
        </div>
    </body>
    </html>
    """


@app.post("/projects/new")
def create_project(name: str = Form(...), number: str = Form(...), status: str = Form(...)):
    c=db(); c.execute("INSERT INTO projects(name,number,status,company_id) VALUES(?,?,?,?)",(name.strip(),number.strip(),status,current_company_id())); pid=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]; c.execute("INSERT INTO user_state(user_id,selected_project_id) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=excluded.selected_project_id",(current_user_id(),pid)); c.commit(); c.close(); return RedirectResponse(url="/",status_code=303)


CSS="""
:root{--bg:#0a1017;--panel:#111923;--line:#213042;--text:#eef4fb;--muted:#8fa2b5;--gold:#f0b44d}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif}
.app{display:grid;grid-template-columns:260px 1fr;min-height:100vh}.side{background:#0c141d;border-right:1px solid var(--line);padding:22px 16px}.brand{font-size:20px;font-weight:800}.company{font-size:12px;color:var(--muted);margin:5px 0 20px}.nav a{display:block;color:#cbd7e3;text-decoration:none;padding:10px;border-radius:9px;margin:2px 0}.nav a:hover{background:#162333}.creator-footer{margin-top:24px;padding-top:16px;border-top:1px solid var(--line);color:var(--muted);font-size:11px;line-height:1.6}.main{padding:26px;max-width:1400px}
.hero,.card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:18px;margin-bottom:12px}.hero h1{margin:4px 0}.eyebrow{color:var(--gold);font-size:11px;text-transform:uppercase;letter-spacing:.13em}.muted,.small{color:var(--muted)}.small{font-size:12px}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.kpi{font-size:28px;font-weight:800}.label{font-size:11px;color:var(--muted);text-transform:uppercase}.badge{display:inline-block;padding:4px 8px;border-radius:999px;font-weight:800;font-size:10px}.CRITICAL,.HOLD{background:#492324;color:#ff9b9b}.HIGH,.WATCH{background:#43381b;color:#ffd779}.READY,.LOW,.COMPLETE{background:#18392c;color:#82e4b5}.OPEN{background:#1d2e44;color:#99c9ff}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px;border-bottom:1px solid var(--line);font-size:13px}th{color:var(--muted)}input,textarea,select{width:100%;background:#0d1620;color:var(--text);border:1px solid var(--line);border-radius:9px;padding:10px}textarea{min-height:90px}button{background:var(--gold);border:0;border-radius:9px;padding:10px 14px;font-weight:800}.action{padding:12px 0;border-bottom:1px solid var(--line)}
@media(max-width:850px){.app{grid-template-columns:1fr}.grid4,.grid3,.grid2{grid-template-columns:1fr}.main{padding:14px}}

.mobile-menu-btn{display:none}
@media(max-width:900px){.app{grid-template-columns:1fr}.side{position:relative;border-right:0;border-bottom:1px solid var(--line)}.grid4,.grid3,.grid2{grid-template-columns:1fr}.mobile-menu-btn{display:block;width:100%;margin:12px 0}.nav{display:none}.nav.mobile-open{display:block}}
"""


NAV=[("Daily Command","/"),("AI Command","/ai-command"),("Blueprint Brain","/plans-specs-ai"),("Deep Document AI","/document-ai"),("Schedule Import","/schedule-import"),("Advanced Schedule Import","/advanced-schedule-import"),("Photo Intelligence","/photo-intelligence"),("AI Photo Analysis","/photo-ai"),("3-Week Lookahead","/lookahead-intelligence"),("Project Health","/project-health"),("Predictive Forecast","/predictive-forecast"),("Morning Brief","/morning-brief"),("Action Center","/actions"),("RFIs / Issues","/issues"),("Punch List","/punch"),("Inspections","/inspections"),("Submittals","/submittals"),("Safety","/safety"),("Change Events","/changes"),("Meetings","/meetings"),("Documents","/documents"),("Notifications","/notifications"),("AI Assistant","/assistant"),("AI Analysis","/ai-analysis"),("Daily Report","/daily-report"),("Auto Daily Report","/auto-daily-report"),("Schedule","/schedule"),("Schedule Health","/schedule-health"),("Procurement","/procurement"),("Readiness","/readiness"),("Make Ready","/make-ready"),("Field","/field"),("Subcontractors","/subcontractors"),("Production","/production"),("Predictive Risk","/risk"),("Recovery","/recovery"),("Company Memory","/memory"),("Playbooks","/playbooks"),("Portfolio","/portfolio"),("Owner Dashboard","/owner-dashboard"),("Portfolio Intelligence","/portfolio-intelligence"),("Exports","/exports"),("Team","/team"),("Company Settings","/company-settings"),("Project Settings","/project-settings"),("System Check","/system-check"),("Beta Feedback","/beta-feedback"),("Setup","/setup"),("Invitations","/invitations"),("Production Settings","/production-settings"),("Sub Scorecards","/sub-scorecards"),("Sub Risk","/sub-risk"),("RFI Impact","/rfi-impact"),("Procurement Warning","/procurement-warning"),("Recovery Planner","/ai-recovery"),("Quick Entry","/quick-entry"),("Weekly AI Report","/weekly-report"),("RFI Drafting","/rfi-drafting"),("Sub Communications","/sub-communications"),("AI Meeting Minutes","/meeting-minutes-ai"),("Weather Impacts","/weather-impacts"),("PDF Reports","/pdf-reports"),("Cost Intelligence","/cost-intelligence"),("Change Package","/change-package"),("Mobile Home","/mobile-home"),("Mobile Field+","/mobile-field-plus"),("Beta Checklist","/beta-checklist")]


NAV_GROUPS=[
    ('🏠 Home',[
        ('BuildCommand Brain','/brain'),('Estimator Intelligence','/brain/estimator'),('Takeoff Intelligence','/brain/takeoff'),('Daily Command','/'),('AI Command','/ai-command'),('Morning Brief','/morning-brief'),('Action Center','/actions'),
        ('Global Search','/global-search'),('Favorites','/favorites'),('Recent Activity','/recent-activity'),('Mobile Field+','/mobile-field-plus')
    ]),
    ('📅 Schedule & Production',[
        ('Schedule','/schedule'),('Schedule Import','/schedule-import'),('Advanced Schedule Import','/advanced-schedule-import'),
        ('3-Week Lookahead','/lookahead-intelligence'),('Schedule Health','/schedule-health'),('Predictive Forecast','/predictive-forecast'),
        ('Production','/production'),('Readiness','/readiness'),('Make Ready','/make-ready'),('Procurement','/procurement'),
        ('Procurement Warning','/procurement-warning'),('Recovery','/recovery'),('Recovery Planner','/ai-recovery'),('Predictive Risk','/risk')
    ]),
    ('👷 Field Operations',[
        ('Field','/field'),('Quick Entry','/quick-entry'),('Daily Report','/daily-report'),('Auto Daily Report','/auto-daily-report'),
        ('Photo Intelligence','/photo-intelligence'),('AI Photo Analysis','/photo-ai'),('Weather Impacts','/weather-impacts'),
        ('Safety','/safety'),('Inspections','/inspections'),('Punch List','/punch')
    ]),
    ('📄 Documents & AI',[
        ('Documents','/documents'),('Document Tags','/document-tags'),('Plan Intake','/plans-specs-ai'),('Deep Document AI','/document-ai'),
        ('RFIs / Issues','/issues'),('RFI Drafting','/rfi-drafting'),('RFI Impact','/rfi-impact'),('Submittals','/submittals'),
        ('Meetings','/meetings'),('AI Meeting Minutes','/meeting-minutes-ai'),('AI Assistant','/assistant'),('AI Analysis','/ai-analysis'),
        ('Weekly AI Report','/weekly-report'),('PDF Reports','/pdf-reports')
    ]),
    ('🤝 Subs & Communication',[
        ('Subcontractors','/subcontractors'),('Sub Scorecards','/sub-scorecards'),('Sub Risk','/sub-risk'),
        ('Sub Communications','/sub-communications'),('Notifications','/notifications'),('Notification Rules','/notification-rules')
    ]),
    ('💰 Management & Executive',[
        ('Project Health','/project-health'),('Health History','/health-history'),('Change Events','/changes'),('Cost Intelligence','/cost-intelligence'),
        ('Change Package','/change-package'),('Owner Dashboard','/owner-dashboard'),('Portfolio','/portfolio'),('Portfolio Intelligence','/portfolio-intelligence'),
        ('Company Memory','/memory'),('Playbooks','/playbooks'),('Bulk Export','/bulk-export')
    ]),
    ('⚙️ Admin',[
        ('Team','/team'),('Invitations','/invitations'),('Company Settings','/company-settings'),('Project Settings','/project-settings'),
        ('Clone Project','/project-clone'),('Archive Projects','/project-archive'),('Storage Status','/storage-status'),('Audit Log','/audit-log'),
        ('Setup','/setup'),('System Check','/system-check'),('Beta Feedback','/beta-feedback'),('Beta Checklist','/beta-checklist')
    ])
]


def _v37_esc(value):
    import html
    return html.escape(str(value or ""), quote=True)


def esc(value):
    return _v37_esc(value)


def categorized_nav():
    groups=[
        ("PROJECTS",[("Projects Home","/"),("Add Project","/projects/new"),("Recent Activity","/recent-activity"),("Archive Projects","/project-archive")]),
        ("BUILD",[("Build Home","/build"),("Field Command 3.0","/field-command-3"),("Analyze Project","/build/analyze-project"),("Blueprint Brain","/blueprint-brain"),("Review Project Scope","/brain"),("Preconstruction & Bid Intelligence","/preconstruction"),("Documents","/documents"),("Deep Document AI","/document-ai"),("Field Context & Assembly Intelligence","/field-context")]),
        ("ESTIMATE",[("Estimate Home","/estimate"),("Preconstruction Command","/precon-command"),("Estimator Intelligence","/brain/estimator"),("Takeoff Intelligence","/brain/takeoff"),("Bid Packages","/preconstruction/packages"),("Bid Leveling","/preconstruction/leveling"),("Historical Cost Brain","/learning/costs"),("Budget & Commitments","/project-control/budget")]),
        ("MANAGE",[("Manage Home","/manage"),("PM Command","/pm-command"),("Performance Monitor","/performance"),("Project Autopilot","/autopilot"),("Daily Superintendent Command","/daily-superintendent"),("Look-Ahead Intelligence","/lookahead-intelligence"),("Trade Readiness Brain","/trade-readiness"),("Trade Coordination Engine","/trade-coordination"),("Proactive Superintendent AI","/proactive-superintendent"),("Field Command","/field-command"),("Schedule","/schedule"),("Sequence Intelligence","/sequence-intelligence"),("RFIs / Issues","/issues"),("Submittals","/submittals"),("Procurement","/procurement"),("Inspections","/inspections"),("Subcontractors","/subcontractors"),("Project Control","/project-control"),("Punch","/punch"),("Closeout","/field-command/closeout")]),
        ("INTELLIGENCE",[("Intelligence Center","/intelligence"),("Knowledge Brain 2.0","/knowledge-brain-2"),("Smart RFI & Conflict Detection","/smart-rfi"),("Long-Lead Prediction","/longlead-intelligence"),("Inspection & QC Intelligence","/quality-intelligence"),("Scope Gap & Buyout Intelligence","/scope-gap-intelligence"),("Change Order Intelligence","/change-order-intelligence"),("Event-Driven Intelligence","/event-intelligence"),("Drawing Revision & Change Intelligence","/revision-intelligence"),("Project Memory & Continuous Learning","/project-memory"),("Master Construction Reasoning","/master-reasoning"),("Real Construction Reasoning 2.0","/reasoning-2"),("Project Knowledge Graph","/knowledge-graph"),("Prediction & Decision Intelligence","/prediction-intelligence"),("Brain Quality & Self-Learning","/brain-quality"),("Constructability Intelligence","/intelligence-engine/constructability"),("Learning Intelligence","/learning"),("Field Context Intelligence","/field-context")]),
        ("ASK BUILDCOMMAND",[("Ask BuildCommand","/ask-buildcommand"),("Search Everything","/global-search"),("Explain This Finding","/reasoning-2/explain"),("Reasoning Chain","/master-reasoning/chain"),("Answer Guardrails","/brain-quality/answer-guard")]),
    ]
    html='<div class="bc-topnav">'
    for label,items in groups:
        links=''.join(f'<a class="bc-drop-link" href="{href}">{_v37_esc(name)}</a>' for name,href in items)
        html+=(
            '<div class="bc-navdrop">'
            f'<button type="button" class="bc-navbtn" onclick="bcToggleMenu(this,event)">{_v37_esc(label)} <span class="bc-caret">▾</span></button>'
            f'<div class="bc-dropdown">{links}</div>'
            '</div>'
        )
    html+='</div>'
    return html


def shell(title, body):
    current_pid = project_id()
    company_id = current_company_id()
    user = current_user()
    c = db()
    projects = c.execute(
        "SELECT p.id,p.name,p.number,p.status FROM projects p "
        "LEFT JOIN project_archive_state a ON a.project_id=p.id "
        "WHERE p.company_id=? AND COALESCE(a.archived,0)=0 ORDER BY p.name",
        (company_id,)
    ).fetchall()
    current = c.execute(
        "SELECT * FROM projects WHERE id=? AND company_id=?",
        (current_pid, company_id)
    ).fetchone() if current_pid else None
    c.close()

    nav = categorized_nav()
    project_options = "".join(
        f'<option value="{p["id"]}" {"selected" if p["id"]==current_pid else ""}>{_v37_esc(p["number"])} - {_v37_esc(p["name"])}</option>'
        for p in projects
    )
    current_name = _v37_esc(current["name"]) if current else "No Project Selected"
    company_name = _v37_esc(user["company_name"]) if user else "BuildCommand Company"
    display_name = _v37_esc(user["display_name"]) if user else ""

    project_bar = f'''<div class="bc-projectbar">
      <div class="bc-project-meta">
        <div class="bc-project-label">CURRENT PROJECT</div>
        <div class="bc-project-name">{current_name}</div>
      </div>
      <form method="post" action="/projects/select" class="bc-project-switch">
        <select name="project_id">{project_options}</select>
        <button type="submit">Switch</button>
      </form>
      <a class="bc-add-project" href="/projects/new">+ Add Project</a>
    </div>'''

    _groups=[
      ("PROJECT",[("Project Command","/"),("Execution & Control Platform","/platform-369"),("Unified Platform","/platform-269"),("Projects","/projects"),("Project Autopilot","/autopilot")]),
      ("BUILD",[("Build Home","/build"),("Blueprint Brain","/blueprint-brain"),("Daily Superintendent","/daily-superintendent"),("Look-Ahead","/lookahead-intelligence"),("Trade Readiness","/trade-readiness"),("Trade Coordination","/trade-coordination")]),
      ("ESTIMATE",[("Estimate Home","/estimate"),("Preconstruction","/preconstruction"),("Scope Gap Intelligence","/scope-gap-intelligence")]),
      ("MANAGE",[("Manage Home","/manage"),("Proactive Superintendent AI","/proactive-superintendent"),("Change Order Intelligence","/change-order-intelligence"),("Performance Monitor","/performance")]),
      ("INTELLIGENCE",[("Intelligence Center","/intelligence"),("Knowledge Brain 2.0","/knowledge-brain-2"),("Event Intelligence","/event-intelligence"),("Smart RFI","/smart-rfi"),("Long-Lead Intelligence","/longlead-intelligence"),("Quality Intelligence","/quality-intelligence")])
    ]
    _side='<aside class="bc170-side" id="bc170-side"><div class="bc170-brand">BuildCommand AI<small>CONSTRUCTION OPERATION INTELLIGENCE SYSTEM</small></div>'
    for _g,_items in _groups:
        _side+=f'<div class="bc170-group"><button type="button" onclick="this.parentElement.classList.toggle(\'open\')">{esc(_g)} ▾</button><div class="bc170-links">'
        for _label,_href in _items: _side+=f'<a href="{_href}">{esc(_label)}</a>'
        _side+='</div></div>'
    _side+='</aside>'
    _top=f'<header class="bc170-top"><button class="bc170-menu" type="button" onclick="document.getElementById(\'bc170-side\').classList.toggle(\'show\')">☰</button><div class="bc170-title">{esc(title)}</div><div class="bc170-quick"><a href="/ask-buildcommand">Ask BuildCommand</a><a href="/autopilot">Autopilot</a></div></header>'
    _rail='<details class="bc170-rail"><summary>AI Command ▴</summary><div><a href="/proactive-superintendent/command">What should I deal with next?</a><a href="/lookahead-intelligence">Upcoming work readiness</a><a href="/event-intelligence/command">What changed?</a><a href="/performance">Performance monitor</a></div></details>'
    body=_side+_top+'<main class="bc170-main"><div class="bc170-work">'+body+'</div></main>'+_rail

    return f'''<!doctype html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_v37_esc(title)} · BuildCommand AI</title>
<style>
{CSS}
body{{margin:0}}
.app{{display:block;min-height:100vh}}
.side{{position:sticky;top:0;z-index:1000;width:100%;min-height:auto;padding:0;background:rgba(12,15,19,.98);border-right:0;border-bottom:1px solid rgba(255,255,255,.10)}}
.main{{max-width:1500px;margin:0 auto;padding:28px 26px 70px}}
.bc-header{{display:flex;align-items:center;gap:22px;padding:12px 22px 10px;border-bottom:1px solid rgba(255,255,255,.07)}}
.bc-brand-wrap{{min-width:210px}}
.brand{{font-size:22px;font-weight:900;letter-spacing:-.4px;margin:0}}
.company{{font-size:11px;color:var(--muted);margin-top:2px}}
.bc-nav-wrap{{flex:1;min-width:0}}
.bc-topnav{{display:flex;align-items:center;gap:4px;flex-wrap:wrap}}
.bc-navdrop{{position:relative}}
.bc-navbtn{{width:auto;border:0;background:transparent;color:#f3f3f3;padding:10px 12px;border-radius:8px;font-weight:800;font-size:12px;letter-spacing:.35px;cursor:pointer}}
.bc-navbtn:hover,.bc-navdrop.open .bc-navbtn{{background:rgba(255,255,255,.08);color:#f0b44d}}
.bc-caret{{font-size:10px;margin-left:3px}}
.bc-dropdown{{display:none;position:absolute;top:calc(100% + 7px);left:0;min-width:275px;max-height:70vh;overflow:auto;padding:8px;background:#171b20;border:1px solid rgba(255,255,255,.12);border-radius:12px;box-shadow:0 18px 45px rgba(0,0,0,.45);z-index:1200}}
.bc-navdrop.open .bc-dropdown{{display:block}}
.bc-drop-link{{display:block;padding:10px 11px;border-radius:8px;text-decoration:none;color:#eee;font-size:13px;font-weight:650}}
.bc-drop-link:hover{{background:rgba(240,180,77,.12);color:#f0b44d}}
.bc-projectbar{{display:flex;align-items:center;gap:12px;padding:8px 22px 10px;background:rgba(255,255,255,.025)}}
.bc-project-meta{{min-width:210px}}
.bc-project-label{{font-size:9px;letter-spacing:1.2px;color:var(--muted);font-weight:800}}
.bc-project-name{{font-size:13px;font-weight:800}}
.bc-project-switch{{display:flex;gap:7px;align-items:center;flex:1;max-width:560px;margin:0}}
.bc-project-switch select{{margin:0;min-width:240px;padding:8px 10px}}
.bc-project-switch button{{width:auto;padding:8px 13px}}
.bc-add-project{{color:#f0b44d;text-decoration:none;font-weight:800;font-size:12px}}
.bc-user-actions{{margin-left:auto;display:flex;align-items:center;gap:10px}}
.bc-user-name{{font-size:11px;color:var(--muted)}}
.bc-signout{{margin:0}}
.bc-signout button{{width:auto;padding:8px 11px;font-size:11px}}
.creator-footer{{text-align:center;color:var(--muted);font-size:11px;padding:18px 10px 24px;border-top:1px solid rgba(255,255,255,.06)}}
.mobile-menu-btn{{display:none}}
.bc-home-grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}}
.bc-priority{{border-left:3px solid #f0b44d}}
@media(max-width:980px){{
  .bc-header{{align-items:flex-start;flex-wrap:wrap}}
  .bc-brand-wrap{{min-width:0}}
  .bc-nav-wrap{{width:100%;order:3}}
  .bc-topnav{{display:grid;grid-template-columns:repeat(3,1fr);width:100%}}
  .bc-navbtn{{width:100%;text-align:left}}
  .bc-dropdown{{position:fixed;left:18px;right:18px;top:120px;min-width:0;max-height:65vh}}
  .bc-projectbar{{flex-wrap:wrap}}
  .bc-project-switch{{max-width:none;width:100%;flex-basis:100%}}
  .bc-project-switch select{{min-width:0;flex:1}}
  .main{{padding:20px 14px 50px}}
  .bc-home-grid{{grid-template-columns:repeat(2,minmax(0,1fr))}}
}}
@media(max-width:620px){{
  .bc-topnav{{grid-template-columns:repeat(2,1fr)}}
  .bc-header{{padding:10px 12px}}
  .bc-projectbar{{padding:8px 12px}}
  .bc-home-grid{{grid-template-columns:1fr}}
}}
/* v170 Professional Command Center */
:root{{--bc170-side:255px;--bc170-top:62px}}.bc170-side{{position:fixed;left:0;top:0;bottom:0;width:var(--bc170-side);background:#101820;color:#fff;z-index:200;overflow:auto;padding:16px 12px;box-sizing:border-box}}.bc170-brand{{font-size:19px;font-weight:850;padding:7px 9px 18px}}.bc170-brand small{{display:block;font-size:9px;opacity:.55;letter-spacing:1.2px;margin-top:4px}}.bc170-group{{margin:4px 0}}.bc170-group button{{width:100%;border:0;background:transparent;color:#d9e0e6;text-align:left;padding:10px;border-radius:9px;font-weight:750;cursor:pointer}}.bc170-group button:hover{{background:rgba(255,255,255,.08)}}.bc170-links{{display:none;padding-bottom:5px}}.bc170-group.open .bc170-links{{display:block}}.bc170-links a{{display:block;color:#c7d0d8;text-decoration:none;padding:8px 10px 8px 18px;border-radius:8px;font-size:13px}}.bc170-links a:hover{{background:rgba(255,255,255,.08);color:#fff}}.bc170-top{{position:fixed;left:var(--bc170-side);right:0;top:0;height:var(--bc170-top);z-index:190;background:rgba(255,255,255,.97);border-bottom:1px solid #e5e9ee;display:flex;align-items:center;gap:10px;padding:0 18px;box-sizing:border-box}}.bc170-title{{font-weight:850;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}.bc170-quick{{display:flex;gap:7px}}.bc170-quick a{{text-decoration:none;border:1px solid #dce2e8;border-radius:8px;padding:7px 10px;font-size:12px}}.bc170-main{{margin-left:var(--bc170-side);padding-top:var(--bc170-top);min-height:100vh}}.bc170-work{{max-width:1500px;margin:auto;padding:20px}}.bc170-menu{{display:none;border:1px solid #dce2e8;background:#fff;border-radius:8px;padding:7px 10px}}.bc170-rail{{position:fixed;right:14px;bottom:14px;width:285px;background:#fff;border:1px solid #e2e7ec;border-radius:14px;box-shadow:0 12px 35px rgba(0,0,0,.13);z-index:180}}.bc170-rail summary{{padding:13px 15px;font-weight:850;cursor:pointer}}.bc170-rail div{{padding:0 15px 13px}}.bc170-rail a{{display:block;text-decoration:none;padding:6px 0;font-size:12px}}@media(max-width:900px){{.bc170-side{{transform:translateX(-100%);transition:.18s}}.bc170-side.show{{transform:translateX(0)}}.bc170-top{{left:0}}.bc170-main{{margin-left:0}}.bc170-menu{{display:block}}.bc170-rail{{width:calc(100% - 28px)}}}}</style>
<script>
function bcToggleMenu(btn,event){{
  if(event) event.stopPropagation();
  var parent=btn.parentElement;
  document.querySelectorAll('.bc-navdrop.open').forEach(function(el){{if(el!==parent) el.classList.remove('open');}});
  parent.classList.toggle('open');
}}
document.addEventListener('click',function(e){{
  if(!e.target.closest('.bc-navdrop')){{
    document.querySelectorAll('.bc-navdrop.open').forEach(function(el){{el.classList.remove('open');}});
  }}
}});
document.addEventListener('keydown',function(e){{
  if(e.key==='Escape') document.querySelectorAll('.bc-navdrop.open').forEach(function(el){{el.classList.remove('open');}});
}});
</script>
</head><body><div class="app">
<header class="side">
  <div class="bc-header">
    <div class="bc-brand-wrap"><div class="brand"><span>BuildCommand AI</span></div><div class="company">{company_name}</div></div>
    <div class="bc-nav-wrap">{nav}</div>
    <div class="bc-user-actions"><div class="bc-user-name">{display_name}</div><form method="post" action="/logout" class="bc-signout"><button type="submit">Sign Out</button></form></div>
  </div>
  {project_bar}
</header>
<main class="main">{body}</main>
<footer class="creator-footer">Built by Wilson LaHood · © 2026 Wilson LaHood</footer>
</div></body></html>'''


def project_id():
    user_id = current_user_id(); company_id = current_company_id()
    if not user_id or not company_id:
        return None
    c = db()
    state = c.execute("""SELECT us.selected_project_id FROM user_state us JOIN projects p ON p.id=us.selected_project_id WHERE us.user_id=? AND p.company_id=?""", (user_id, company_id)).fetchone()
    if state and state["selected_project_id"]:
        pid = state["selected_project_id"]
    else:
        first = c.execute("SELECT p.id FROM projects p LEFT JOIN project_archive_state a ON a.project_id=p.id WHERE p.company_id=? AND COALESCE(a.archived,0)=0 ORDER BY p.id LIMIT 1", (company_id,)).fetchone()
        pid = first["id"] if first else None
        if pid:
            c.execute("INSERT INTO user_state(user_id,selected_project_id) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=excluded.selected_project_id", (user_id,pid)); c.commit()
    c.close(); return pid


@app.post("/projects/select")
def select_project(project_id: int = Form(...)):
    company_id = current_company_id(); user_id = current_user_id(); c = db()
    exists = c.execute("SELECT id FROM projects WHERE id=? AND company_id=?", (project_id, company_id)).fetchone()
    if exists:
        c.execute("INSERT INTO user_state(user_id,selected_project_id) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=excluded.selected_project_id", (user_id,project_id)); c.commit()
    c.close(); return RedirectResponse("/", status_code=303)


def _v37_count(sql,args=()):
    """
    PostgreSQL/SQLite-safe scalar counter for unified dashboard.
    Always aliases COUNT(*) as n so dict_row and sqlite Row behave the same.
    """
    c=db()
    try:
        r=c.execute(sql,args).fetchone()
        value=int((r["n"] if r and "n" in r.keys() else 0) or 0)
        c.close()
        return value
    except Exception:
        try: c.rollback()
        except Exception: pass
        try: c.close()
        except Exception: pass
        return 0


def _v37_snapshot(pid):
    if not pid:
        return dict(scope=0,estimate=0,review=0,issues=0,submittals=0,actions=0,inspections=0)
    co=current_company_id()
    return {
        "scope":_v37_count(
            "SELECT COUNT(*) AS n FROM blueprint_scope_items WHERE company_id=? AND project_id=?",
            (co,pid)
        ),
        "estimate":_v37_count(
            "SELECT COUNT(*) AS n FROM estimator_items WHERE company_id=? AND project_id=?",
            (co,pid)
        ),
        "review":_v37_count(
            "SELECT COUNT(*) AS n FROM estimator_items WHERE company_id=? AND project_id=? AND COALESCE(verified,0)=0",
            (co,pid)
        ),
        "issues":_v37_count(
            "SELECT COUNT(*) AS n FROM project_issues WHERE project_id=? AND COALESCE(status,'OPEN')!='CLOSED'",
            (pid,)
        ),
        "submittals":_v37_count(
            "SELECT COUNT(*) AS n FROM submittals WHERE project_id=? AND COALESCE(status,'PENDING') NOT IN ('APPROVED','APPROVED_AS_NOTED','CLOSED','COMPLETE')",
            (pid,)
        ),
        "actions":_v37_count(
            "SELECT COUNT(*) AS n FROM action_items WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('CLOSED','COMPLETE')",
            (pid,)
        ),
        "inspections":_v37_count(
            "SELECT COUNT(*) AS n FROM inspections_tracker WHERE project_id=? AND COALESCE(result,'PENDING')!='PASSED'",
            (pid,)
        )
    }


def _v37_link_card(title,desc,href,label="Open"):
    return ('<div class="card"><h2>'+_v37_esc(title)+'</h2><p class="muted">'+_v37_esc(desc)+'</p>'
            '<a href="'+href+'" style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:10px 14px;border-radius:9px;font-weight:800;">'
            +_v37_esc(label)+' →</a></div>')


@app.get("/",response_class=HTMLResponse)
def unified_projects_home():
    return shell("Today", _v117r_home_body())


@app.get("/build/analyze-project",response_class=HTMLResponse)
def unified_analyze_project_page():
    pid=project_id(); c=db()
    docs=c.execute("SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid)).fetchall(); c.close()
    eligible=[d for d in docs if Path(d["original_name"] or "").suffix.lower() in {".pdf",".txt",".csv",".xlsx",".xlsm"}]
    checks="".join(f'<label style="display:flex;gap:10px;align-items:center;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.08)"><input type="checkbox" name="attachment_ids" value="{d["id"]}" style="width:auto"><span><b>{esc(d["original_name"])}</b><br><span class="small">{(int(d["size_bytes"] or 0)/1024/1024):.1f} MB</span></span></label>' for d in eligible) or '<div class="muted">No supported project documents are uploaded yet.</div>'
    body='<div class="hero"><div class="eyebrow">BuildCommand · Unified Project Intelligence · v38</div><h1>Analyze the project once.</h1><p class="muted">BuildCommand runs Plan Intelligence, trade scope cleanup, estimator sync, takeoff splitting and quantity review.</p></div>'
    body+='<div class="card"><form method="post" action="/build/analyze-project"><h2>Select project documents</h2>'+checks+'<label style="margin-top:16px">Optional analysis focus</label><textarea name="focus" placeholder="Example: Full bid/scope review"></textarea><button type="submit">Analyze Project</button></form><p class="small">Selected files must total less than 50 MB. AI quantity proposals never overwrite estimator-entered quantities.</p></div>'
    return shell("Analyze Project",body)


@app.post("/build/analyze-project",response_class=HTMLResponse)
def unified_analyze_project_run(attachment_ids:list[int] | None=Form(None),focus:str=Form("")):
    pid=project_id(); docs=_v38_selected_docs(pid,attachment_ids)
    if not docs: return shell("Analyze Project",'<div class="card"><h2>Select at least one project document.</h2><p><a href="/build/analyze-project">← Back</a></p></div>')
    stages=[]
    try:
        bp=_v38_run_blueprint(pid,docs,focus); stages.append(("Plan Intelligence","COMPLETE",f'{bp["trades"]} trade scopes generated'))
        est=_seed_estimator_from_latest(pid); stages.append(("Estimator Sync","COMPLETE",f'{est["added"]} new · {est["updated"]} refreshed'))
        comp=_v38_run_component_split(pid)
        stages.append(("Takeoff Component Split","REVIEW" if comp.get("skipped") else "COMPLETE",comp.get("skipped") or f'{comp["created"]} measurable components created'))
        auto=_v38_run_auto_takeoff(pid)
        stages.append(("Automatic Quantity Review","REVIEW" if auto.get("skipped") else "COMPLETE",auto.get("skipped") or f'{auto["proposed"]} quantity proposals · {auto["verify"]} need verification'))
        rows="".join(f'<div class="action"><span class="badge {"READY" if status=="COMPLETE" else "WATCH"}">{status}</span> <b>{esc(name)}</b><div class="small">{esc(detail)}</div></div>' for name,status,detail in stages)
        body='<div class="hero"><div class="eyebrow">Unified Project Intelligence · v38</div><h1>Project intelligence ready.</h1><p class="muted">The brains ran as one pipeline. Review only the items that need human judgment.</p></div><div class="card"><h2>Pipeline Results</h2>'+rows+'</div><div class="grid3">'
        body+=_v37_link_card("Review BUILD","Review cleaned trade scope and project intelligence.","/build","Open BUILD")+_v37_link_card("Review ESTIMATE","Review takeoff proposals and estimator data.","/estimate","Open ESTIMATE")+_v37_link_card("Things That Need You","Review human-decision items.","/actions","Review")+'</div>'
        return shell("Project Intelligence Ready",body)
    except Exception as exc:
        rows="".join(f'<div class="action"><span class="badge READY">{status}</span> <b>{esc(name)}</b><div class="small">{esc(detail)}</div></div>' for name,status,detail in stages)
        body='<div class="hero"><h1>Analyze Project stopped.</h1></div><div class="card"><p>'+esc(str(exc))+'</p></div>'
        if rows: body+='<div class="card"><h2>Completed before stop</h2>'+rows+'</div>'
        body+='<div class="card"><p><a href="/build/analyze-project">← Back to Analyze Project</a></p></div>'
        return shell("Analyze Project",body)


def _v39_rows(sql,args=()):
    c=db()
    try:
        return c.execute(sql,args).fetchall()
    finally:
        c.close()


def _v39_safe_date(v):
    try:
        return datetime.fromisoformat(str(v)[:10]).date()
    except Exception:
        return None


def _v39_priority(due,priority=""):
    p=str(priority or "").upper()
    d=_v39_safe_date(due)
    today=datetime.utcnow().date()
    if p in {"CRITICAL","URGENT"} or (d and d<today): return "CRITICAL"
    if d==today or p=="HIGH": return "TODAY"
    if d and 0 < (d-today).days <= 7: return "THIS WEEK"
    return "REVIEW"


def _v39_attention(pid):
    items=[]
    for r in _v39_rows("SELECT * FROM action_items WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('CLOSED','COMPLETE')",(pid,)):
        items.append((_v39_priority(r["due"],r["priority"]),"ACTION",r["title"],r["due"] or "",r["owner"] or ""))
    for r in _v39_rows("SELECT * FROM project_issues WHERE project_id=? AND COALESCE(status,'OPEN')!='CLOSED'",(pid,)):
        items.append((_v39_priority(r["due"],r["priority"]),"ISSUE",r["title"],r["due"] or "",r["owner"] or ""))
    for r in _v39_rows("SELECT * FROM submittals WHERE project_id=? AND COALESCE(status,'PENDING') NOT IN ('APPROVED','CLOSED','COMPLETE')",(pid,)):
        items.append((_v39_priority(r["due_date"],"HIGH" if r["due_date"] else ""),"SUBMITTAL",r["title"],r["due_date"] or "",r["responsible_party"] or ""))
    for r in _v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? AND COALESCE(result,'PENDING')!='PASSED'",(pid,)):
        items.append((_v39_priority(r["scheduled_date"],"HIGH" if r["scheduled_date"] else ""),"INSPECTION",r["inspection_type"],r["scheduled_date"] or "",r["authority"] or ""))
    for r in _v39_rows("SELECT * FROM estimator_items WHERE project_id=? AND COALESCE(verified,0)=0 AND COALESCE(ai_confidence,'') IN ('LOW','VERIFY')",(pid,)):
        items.append(("REVIEW","ESTIMATE",r["description"],"",r["trade"] or ""))
    rank={"CRITICAL":0,"TODAY":1,"THIS WEEK":2,"REVIEW":3,"FYI":4}
    return sorted(items,key=lambda x:rank.get(x[0],9))


def _v39_memory_rules(pid):
    return _v39_rows("SELECT trade,requirement,confidence FROM blueprint_scope_items WHERE project_id=? AND COALESCE(confidence,'')='HIGH' ORDER BY id DESC LIMIT 100",(pid,))


def _v39_conflicts(pid):
    return _v39_rows("SELECT requirement,COUNT(DISTINCT trade) AS n,MIN(trade) AS trade FROM blueprint_scope_items WHERE project_id=? GROUP BY requirement HAVING COUNT(DISTINCT trade)>1 ORDER BY n DESC LIMIT 50",(pid,))


def _v39_schedule_risks(pid):
    today=datetime.utcnow().date()
    rows=_v39_rows("SELECT * FROM activities WHERE project_id=? AND COALESCE(status,'NOT_STARTED')!='COMPLETE' ORDER BY start LIMIT 100",(pid,))
    out=[]
    for r in rows:
        s=_v39_safe_date(r["start"]); f=_v39_safe_date(r["finish"]); pct=float(r["pct"] or 0)
        if f and f<today and pct<100: out.append(("CRITICAL",r["name"],"Past finish date",r["finish"]))
        elif s and 0 <= (s-today).days <= 14 and pct==0: out.append(("THIS WEEK",r["name"],"Upcoming / make-ready",r["start"]))
    return out


def _v39_procurement(pid):
    return _v39_rows("SELECT * FROM procurement WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('DELIVERED','COMPLETE','CLOSED') ORDER BY required_on_site LIMIT 100",(pid,))


def _v39_changes(pid):
    return _v39_rows("SELECT * FROM change_events WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('CLOSED','COMPLETE') ORDER BY id DESC LIMIT 100",(pid,))


@app.get("/intelligence",response_class=HTMLResponse)
def v39_intelligence_center():
    pid=project_id(); attention=_v39_attention(pid); conflicts=_v39_conflicts(pid); sched=_v39_schedule_risks(pid); proc=_v39_procurement(pid); changes=_v39_changes(pid)
    cards=[
        ("Things That Need You",len(attention),"/intelligence/attention","Prioritized decisions across the job."),
        ("Project Memory",len(_v39_memory_rules(pid)),"/intelligence/memory","High-confidence construction knowledge retained from this project."),
        ("Conflict Brain",len(conflicts),"/intelligence/conflicts","Cross-scope conflicts that deserve review."),
        ("RFI Intelligence",len(conflicts),"/intelligence/rfis","Draft RFIs from detected conflicts."),
        ("Schedule Intelligence",len(sched),"/intelligence/schedule","Late and upcoming work requiring make-ready."),
        ("Look-Ahead Brain",len(sched),"/intelligence/lookahead","2, 3 and 6 week field outlook."),
        ("Procurement Brain",len(proc),"/intelligence/procurement","Long-lead and required-on-site tracking."),
        ("Bid Scope Brain",_v37_snapshot(pid)["scope"],"/intelligence/bids","Trade scope package intelligence."),
        ("Cost & Change",len(changes),"/intelligence/changes","Open cost and schedule exposure."),
        ("Daily Superintendent Command",len(attention)+len(sched),"/intelligence/daily-command","Today's project command brief.")
    ]
    body='<div class="hero"><div class="eyebrow">BuildCommand v40</div><h1>Construction Intelligence Center</h1><p class="muted">Ten brains. One project operating system. The main menu stays simple.</p></div><div class="grid3">'
    for name,count,href,desc in cards:
        body+=f'<div class="card"><div class="label">{esc(name)}</div><div class="kpi">{count}</div><p class="muted">{esc(desc)}</p><a href="{href}">Open →</a></div>'
    body+='</div>'
    body += '<div class="grid3">'+_v37_link_card("Constructability Intelligence","Find access, clearance, penetration, ceiling and coordination risks.","/intelligence-engine/constructability","Open")+_v37_link_card("Superintendent Command Intelligence","Prioritized view of sequence, procurement, conflicts, gaps and inspections.","/intelligence-engine/command","Open")+_v37_link_card("Full Intelligence Engine","Conflict, RFI, scope, change, procurement, inspection and learning intelligence.","/intelligence-engine","Open")+'</div>'
    body += '<div class="grid3">' + _v37_link_card("Project Knowledge Graph","Drawing revisions, dependencies, equipment chains, prediction and verification.","/knowledge-graph","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Prediction & Decision Intelligence","Dependency impacts, decision deadlines, manpower, materials, closeout and risk propagation.","/prediction-intelligence","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Brain Quality & Self-Learning","Verification, confidence calibration, source quality, contradiction detection and improvement queue.","/brain-quality","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Field Context & Assembly Intelligence","Rooms, assemblies, systems, prerequisites, hold points, commissioning and field work packages.","/field-context","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Master Construction Reasoning","One connected project judgment across scope, sequence, risk, field, quality and commercial intelligence.","/master-reasoning","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Real Construction Reasoning 2.0","Cause, dependency, consequence, ownership, alternatives and uncertainty.","/reasoning-2","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Project Memory & Continuous Learning","Approved corrections, RFI answers, lessons and cross-project patterns.","/project-memory","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Drawing Revision & Change Intelligence","Added/removed scope, affected trades, cost/schedule exposure and downstream controls.","/revision-intelligence","Open") + '</div>'
    body += '<div class="grid3">' + _v37_link_card("Event-Driven Intelligence","Refresh only the brain modules affected by a project change.","/event-intelligence","Open") + '</div>'










    return shell("Intelligence",body)


@app.get("/intelligence/attention",response_class=HTMLResponse)
def v39_attention_page():
    items=_v39_attention(project_id())
    rows="".join(f'<div class="action"><span class="badge">{esc(level)}</span> <b>{esc(kind)}</b> — {esc(title)}<div class="small">{esc(due)} {esc(owner)}</div></div>' for level,kind,title,due,owner in items)
    return shell("Things That Need You",'<div class="hero"><h1>Things That Need You</h1><p class="muted">Critical → Today → This Week → Review.</p></div><div class="card">'+(rows or '<p class="muted">Nothing needs attention.</p>')+'</div>')


@app.get("/intelligence/memory",response_class=HTMLResponse)
def v39_memory_page():
    rows=_v39_memory_rules(project_id())
    h="".join(f'<div class="action"><b>{esc(r["trade"])}</b><div>{esc(r["requirement"])}</div><span class="small">Confidence: {esc(r["confidence"])}</span></div>' for r in rows)
    return shell("Project Memory",'<div class="hero"><h1>Project Memory Brain</h1><p class="muted">High-confidence project construction knowledge retained for future reasoning.</p></div><div class="card">'+(h or '<p class="muted">Memory grows as project intelligence is reviewed.</p>')+'</div>')


@app.get("/intelligence/conflicts",response_class=HTMLResponse)
def v39_conflicts_page():
    rows=_v39_conflicts(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">REVIEW</span> {esc(r["requirement"])}<div class="small">Appears under {r["n"]} trades.</div></div>' for r in rows)
    return shell("Conflict Brain",'<div class="hero"><h1>Cross-Document Conflict Brain</h1></div><div class="card">'+(h or '<p class="muted">No duplicate cross-trade requirements detected.</p>')+'</div>')


@app.get("/intelligence/rfis",response_class=HTMLResponse)
def v39_rfi_page():
    rows=_v39_conflicts(project_id())
    h="".join(f'<div class="card"><span class="badge WATCH">DRAFT RFI</span><h3>{esc(r["requirement"])}</h3><p>Please clarify the governing scope/document requirement. BuildCommand detected this requirement across multiple trade assignments.</p><p class="small">Human approval required before issue.</p></div>' for r in rows)
    return shell("RFI Intelligence",'<div class="hero"><h1>Automatic RFI Intelligence</h1><p class="muted">Proposals only. Nothing is sent automatically.</p></div>'+(h or '<div class="card">No RFI candidates detected.</div>'))


@app.get("/intelligence/schedule",response_class=HTMLResponse)
def v39_schedule_page():
    rows=_v39_schedule_risks(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(name)}</b><div class="small">{esc(reason)} · {esc(date)}</div></div>' for level,name,reason,date in rows)
    return shell("Schedule Intelligence",'<div class="hero"><h1>Schedule Intelligence Brain</h1></div><div class="card">'+(h or '<p class="muted">No immediate schedule exceptions detected.</p>')+'</div>')


@app.get("/intelligence/lookahead",response_class=HTMLResponse)
def v39_lookahead_page():
    pid=project_id(); today=datetime.utcnow().date(); rows=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,))
    body='<div class="hero"><h1>Look-Ahead Brain</h1><p class="muted">2, 3 and 6 week production outlook.</p></div>'
    for weeks in (2,3,6):
        end=today+timedelta(days=weeks*7)
        subset=[r for r in rows if _v39_safe_date(r["start"]) and today <= _v39_safe_date(r["start"]) <= end]
        h="".join(f'<div class="action"><b>{esc(r["name"])}</b><div class="small">{esc(r["trade"])} · {esc(r["start"])} → {esc(r["finish"])}</div></div>' for r in subset)
        body+=f'<div class="card"><h2>{weeks}-Week Look-Ahead</h2>{h or "<p class=muted>No scheduled starts in this window.</p>"}</div>'
    return shell("Look-Ahead",body)


@app.get("/intelligence/procurement",response_class=HTMLResponse)
def v39_procurement_page():
    rows=_v39_procurement(project_id())
    h="".join(f'<div class="action"><b>{esc(r["item"])}</b><div class="small">Required: {esc(r["required_on_site"])} · Promised: {esc(r["promised_date"])} · {esc(r["status"])}</div></div>' for r in rows)
    return shell("Procurement Intelligence",'<div class="hero"><h1>Procurement & Long-Lead Brain</h1></div><div class="card">'+(h or '<p class="muted">No open procurement items.</p>')+'</div>')


@app.get("/intelligence/bids",response_class=HTMLResponse)
def v39_bid_page():
    rows=_v39_rows("SELECT trade,COUNT(*) AS n FROM blueprint_scope_items WHERE project_id=? GROUP BY trade ORDER BY trade",(project_id(),))
    h="".join(f'<div class="action"><b>{esc(r["trade"])}</b><div class="small">{r["n"]} source-backed scope items ready for bid-package review.</div></div>' for r in rows)
    return shell("Bid Scope Intelligence",'<div class="hero"><h1>Subcontractor Scope & Bid Brain</h1><p class="muted">Trade packages originate from the cleaned Blueprint Brain scope.</p></div><div class="card">'+(h or '<p class="muted">Analyze project documents first.</p>')+'</div>')


@app.get("/intelligence/changes",response_class=HTMLResponse)
def v39_change_page():
    rows=_v39_changes(project_id()); total=sum(float(r["estimated_cost"] or 0) for r in rows); days=sum(float(r["schedule_days"] or 0) for r in rows)
    h="".join(f'<div class="action"><b>{esc(r["title"])}</b><div class="small">${float(r["estimated_cost"] or 0):,.0f} · {float(r["schedule_days"] or 0):g} days · {esc(r["status"])}</div></div>' for r in rows)
    return shell("Cost & Change",f'<div class="hero"><h1>Cost & Change Intelligence</h1><p class="muted">Open exposure: ${total:,.0f} · {days:g} schedule days.</p></div><div class="card">'+(h or '<p class="muted">No open change exposure.</p>')+'</div>')


@app.get("/intelligence/daily-command",response_class=HTMLResponse)
def v39_daily_command():
    pid=project_id(); attention=_v39_attention(pid); sched=_v39_schedule_risks(pid); proc=_v39_procurement(pid)
    critical=sum(1 for x in attention if x[0]=="CRITICAL"); today=sum(1 for x in attention if x[0]=="TODAY")
    body=f'<div class="hero"><div class="eyebrow">Daily Superintendent Command</div><h1>Run the job from here.</h1><p class="muted">{critical} critical · {today} today · {len(sched)} schedule exceptions · {len(proc)} procurement items.</p></div>'
    body+='<div class="grid3">'+_v37_link_card("Decisions","Prioritized items requiring human attention.","/intelligence/attention","Review")+_v37_link_card("Look-Ahead","Upcoming production and make-ready.","/intelligence/lookahead","Open")+_v37_link_card("Ask BuildCommand","Ask the project what matters now.","/ask-buildcommand","Ask")+'</div>'
    return shell("Daily Command",body)


def _v40_score(pid):
    att=_v39_attention(pid); sched=_v39_schedule_risks(pid); proc=_v39_procurement(pid); changes=_v39_changes(pid)
    critical=sum(1 for x in att if x[0]=="CRITICAL")+sum(1 for x in sched if x[0]=="CRITICAL")
    high=sum(1 for x in att if x[0] in {"TODAY","THIS WEEK"})
    score=min(100,critical*20+high*7+len(proc)*4+len(changes)*5)
    return {"risk":score,"health":max(0,100-score),"level":"CRITICAL" if score>=70 else "HIGH" if score>=45 else "MEDIUM" if score>=20 else "LOW"}


def _v40_revision_candidates(pid):
    rows=_v39_rows("SELECT * FROM attachments WHERE project_id=? ORDER BY id DESC LIMIT 100",(pid,))
    seen={}; pairs=[]
    for r in rows:
        name=str(r["original_name"] or "")
        base=re.sub(r'(?i)(rev(?:ision)?[ _-]*[A-Z0-9]+|addendum[ _-]*[A-Z0-9]+|bulletin[ _-]*[A-Z0-9]+)','',name)
        base=re.sub(r'[^a-z0-9]+',' ',base.lower()).strip()
        if base in seen: pairs.append((r,seen[base]))
        else: seen[base]=r
    return pairs[:25]


def _v40_gap_summary(pid):
    scopes=_v39_rows("SELECT trade,COUNT(*) AS n FROM blueprint_scope_items WHERE project_id=? GROUP BY trade ORDER BY trade",(pid,))
    subs=_v39_rows("SELECT trade,COUNT(*) AS n FROM subcontractors WHERE project_id=? GROUP BY trade",(pid,))
    covered={str(r["trade"] or "").lower() for r in subs}
    return [(r["trade"],r["n"],str(r["trade"] or "").lower() in covered) for r in scopes]


def _v40_inspection_ready(pid):
    inspections=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? AND COALESCE(result,'PENDING')!='PASSED' ORDER BY scheduled_date LIMIT 50",(pid,))
    issues=len(_v39_rows("SELECT id FROM project_issues WHERE project_id=? AND COALESCE(status,'OPEN')!='CLOSED'",(pid,)))
    subs=len(_v39_rows("SELECT id FROM submittals WHERE project_id=? AND COALESCE(status,'PENDING') NOT IN ('APPROVED','CLOSED','COMPLETE')",(pid,)))
    return inspections,issues,subs


@app.get("/autopilot",response_class=HTMLResponse)
def v40_autopilot():
    pid=project_id(); s=_v40_score(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v40 - Project Autopilot</div><h1>Your project is {s["level"]} risk.</h1><p class="muted">Health {s["health"]}/100 - Risk {s["risk"]}/100. Autopilot connects project decisions to downstream construction impact.</p></div><div class="grid3">'
    cards=[
      ("Risk Prediction","Score and prioritize project threats.","/autopilot/risks"),
      ("Revision Brain","Identify drawing and addendum revision candidates.","/autopilot/revisions"),
      ("Change Detection","Surface potential cost and time exposure.","/autopilot/change-detection"),
      ("Subcontractor Gaps","Compare cleaned scopes against subcontractor coverage.","/autopilot/gaps"),
      ("Inspection Readiness","Preflight upcoming inspections.","/autopilot/inspection-readiness"),
      ("Quality Control","Source-backed QC verification.","/autopilot/qc"),
      ("Field Photo Intelligence","Route photos into reviewed field intelligence.","/autopilot/photos"),
      ("Project Forecast","Forecast health, completion pressure and decisions.","/autopilot/forecast"),
      ("Executive Command","See project health across the company.","/autopilot/executive")
    ]
    for name,desc,href in cards: body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Project Autopilot",body)


@app.get("/autopilot/risks",response_class=HTMLResponse)
def v40_risks():
    pid=project_id(); s=_v40_score(pid); items=_v39_attention(pid); sched=_v39_schedule_risks(pid)
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(x[0])}</span> <b>{esc(x[1])}</b> - {esc(x[2])}<div class="small">{esc(x[3])}</div></div>' for x in items[:60])
    h+="".join(f'<div class="action"><span class="badge WATCH">{esc(x[0])}</span> <b>SCHEDULE</b> - {esc(x[1])}<div class="small">{esc(x[2])} - {esc(x[3])}</div></div>' for x in sched)
    return shell("Risk Prediction",f'<div class="hero"><h1>Risk Prediction Engine</h1><p class="muted">{s["level"]} - Risk score {s["risk"]}/100</p></div><div class="card">{h or "No major risk signals detected."}</div>')


@app.get("/autopilot/revisions",response_class=HTMLResponse)
def v40_revisions():
    pairs=_v40_revision_candidates(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">COMPARE</span> <b>{esc(a["original_name"])}</b><div class="small">Possible revision of {esc(b["original_name"])}</div></div>' for a,b in pairs)
    return shell("Revision Brain",'<div class="hero"><h1>Drawing Revision / Addendum Brain</h1><p class="muted">Revision candidates are flagged for review. Contract scope is never changed automatically.</p></div><div class="card">'+(h or '<p class="muted">No likely revision pairs detected.</p>')+'</div>')


@app.get("/autopilot/change-detection",response_class=HTMLResponse)
def v40_change_detection():
    rows=_v39_conflicts(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">POTENTIAL CHANGE</span> {esc(r["requirement"])}<div class="small">Detected across {r["n"]} trade assignments. Review contract scope.</div></div>' for r in rows)
    return shell("Change Detection",'<div class="hero"><h1>Automatic Change-Order Detection</h1><p class="muted">Potential exposure only. Human approval required.</p></div><div class="card">'+(h or '<p class="muted">No current change candidates.</p>')+'</div>')


@app.get("/autopilot/gaps",response_class=HTMLResponse)
def v40_gaps():
    rows=_v40_gap_summary(project_id())
    h="".join(f'<div class="action"><span class="badge">{"COVERED" if ok else "GAP"}</span> <b>{esc(trade)}</b><div class="small">{n} cleaned scope items</div></div>' for trade,n,ok in rows)
    return shell("Subcontractor Gaps",'<div class="hero"><h1>Subcontractor Gap Analyzer</h1></div><div class="card">'+(h or '<p class="muted">Analyze project scope first.</p>')+'</div>')


@app.get("/autopilot/inspection-readiness",response_class=HTMLResponse)
def v40_inspection_readiness():
    rows,issues,subs=_v40_inspection_ready(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{"NOT READY" if issues or subs else "READY"}</span> <b>{esc(r["inspection_type"])}</b><div class="small">{esc(r["scheduled_date"])} - {issues} open issues - {subs} open submittals</div></div>' for r in rows)
    return shell("Inspection Readiness",'<div class="hero"><h1>Inspection Readiness Brain</h1></div><div class="card">'+(h or '<p class="muted">No pending inspections.</p>')+'</div>')


@app.get("/autopilot/qc",response_class=HTMLResponse)
def v40_qc():
    rows=_v39_rows("SELECT trade,requirement,source_ref FROM blueprint_scope_items WHERE project_id=? AND COALESCE(confidence,'')='HIGH' ORDER BY trade,id LIMIT 120",(project_id(),))
    h="".join(f'<div class="action"><input type="checkbox" style="width:auto"> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Quality Control",'<div class="hero"><h1>Quality-Control Brain</h1><p class="muted">Source-backed verification checklist.</p></div><div class="card">'+(h or '<p class="muted">Analyze plans first.</p>')+'</div>')


@app.get("/autopilot/photos",response_class=HTMLResponse)
def v40_photos():
    rows=_v39_rows("SELECT * FROM attachments WHERE project_id=? ORDER BY id DESC LIMIT 100",(project_id(),))
    photos=[r for r in rows if Path(r["original_name"] or "").suffix.lower() in {".jpg",".jpeg",".png",".webp"}]
    h="".join(f'<div class="action"><span class="badge WATCH">REVIEW PHOTO</span> <b>{esc(r["original_name"])}</b><div class="small">Associate with location, trade, QC, punch or schedule impact.</div></div>' for r in photos)
    return shell("Field Photo Intelligence",'<div class="hero"><h1>Field Photo Intelligence</h1><p class="muted">Human review required before formal issue creation.</p></div><div class="card">'+(h or '<p class="muted">No project photos uploaded.</p>')+'</div>')


@app.get("/autopilot/forecast",response_class=HTMLResponse)
def v40_forecast():
    pid=project_id(); s=_v40_score(pid); acts=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY finish DESC LIMIT 1",(pid,)); finish=acts[0]["finish"] if acts else ""; open_items=len(_v39_attention(pid))
    return shell("Project Forecast",f'<div class="hero"><h1>Project Forecast Brain</h1><p class="muted">Current planned finish: {esc(finish or "Not scheduled")}</p></div><div class="grid3"><div class="card"><div class="label">Health</div><div class="kpi">{s["health"]}</div></div><div class="card"><div class="label">Risk</div><div class="kpi">{s["risk"]}</div></div><div class="card"><div class="label">Open Decisions</div><div class="kpi">{open_items}</div></div></div>')


@app.get("/autopilot/executive",response_class=HTMLResponse)
def v40_executive():
    rows=_v39_rows("SELECT * FROM projects WHERE company_id=? ORDER BY id DESC",(current_company_id(),)); h=""
    for p in rows:
        s=_v40_score(p["id"]); h+=f'<div class="action"><span class="badge">{esc(s["level"])}</span> <b>{esc(p["number"])} - {esc(p["name"])}</b><div class="small">Health {s["health"]}/100 - Risk {s["risk"]}/100</div></div>'
    return shell("Executive Command",'<div class="hero"><h1>Executive Command Center</h1><p class="muted">Which projects need leadership attention and why.</p></div><div class="card">'+(h or '<p class="muted">No projects found.</p>')+'</div>')


def _v41_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        c.execute("CREATE TABLE IF NOT EXISTS closeout_items(id BIGSERIAL PRIMARY KEY,company_id BIGINT,project_id BIGINT,category TEXT,item TEXT,responsible_party TEXT,due_date TEXT,status TEXT DEFAULT 'OPEN',notes TEXT DEFAULT '',created TEXT,updated TEXT)")
    else:
        c.execute("CREATE TABLE IF NOT EXISTS closeout_items(id INTEGER PRIMARY KEY,company_id INTEGER,project_id INTEGER,category TEXT,item TEXT,responsible_party TEXT,due_date TEXT,status TEXT DEFAULT 'OPEN',notes TEXT DEFAULT '',created TEXT,updated TEXT)")
    c.commit(); c.close()


def _v41_make_ready(pid):
    rows=_v39_rows("SELECT a.*,r.drawings,r.material,r.manpower,r.predecessor,r.access_ready,r.inspection,r.equipment,r.notes readiness_notes FROM activities a LEFT JOIN activity_readiness r ON r.activity_id=a.id AND r.project_id=a.project_id WHERE a.project_id=? AND COALESCE(a.status,'NOT_STARTED')!='COMPLETE' ORDER BY a.start LIMIT 80",(pid,))
    out=[]
    for r in rows:
        checks=[r["drawings"],r["material"],r["manpower"],r["predecessor"],r["access_ready"],r["inspection"],r["equipment"]]
        missing=7-sum(1 for x in checks if int(x or 0)==1)
        status="READY" if missing==0 else "AT RISK" if missing<=2 else "NOT READY"
        out.append((r,status,missing))
    return out


def _v41_sub_center(pid):
    return (
        _v39_rows("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(pid,)),
        _v39_rows("SELECT * FROM activities WHERE project_id=? AND COALESCE(status,'NOT_STARTED')!='COMPLETE' ORDER BY start",(pid,)),
        _v39_rows("SELECT * FROM subcontractor_updates WHERE project_id=? ORDER BY id DESC LIMIT 100",(pid,))
    )


def _v41_delivery_risks(pid):
    today=datetime.utcnow().date()
    rows=_v39_rows("SELECT * FROM procurement WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('DELIVERED','COMPLETE','CLOSED') ORDER BY required_on_site",(pid,))
    out=[]
    for r in rows:
        need=_v39_safe_date(r["required_on_site"]); promised=_v39_safe_date(r["promised_date"])
        exposure=(promised-need).days if need and promised else None
        level="CRITICAL" if exposure is not None and exposure>=7 else "HIGH" if exposure is not None and exposure>0 else "TODAY" if need and need<=today else "WATCH"
        out.append((r,level,exposure))
    return out


def _v41_inspection_countdown(pid):
    today=datetime.utcnow().date()
    rows=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? AND COALESCE(result,'PENDING')!='PASSED' ORDER BY scheduled_date",(pid,))
    out=[]
    for r in rows:
        d=_v39_safe_date(r["scheduled_date"]); days=(d-today).days if d else None
        label="UNSCHEDULED" if days is None else "OVERDUE" if days<0 else "TODAY" if days==0 else "TOMORROW" if days==1 else f"{days} DAYS" if days<=7 else "UPCOMING"
        out.append((r,label,days))
    return out


def _v41_delay_candidates(pid):
    rows=_v39_rows("SELECT * FROM project_issues WHERE project_id=? AND COALESCE(status,'OPEN')!='CLOSED' ORDER BY id DESC",(pid,))
    out=[]
    for r in rows:
        txt=(str(r["title"] or "")+" "+str(r["description"] or "")+" "+str(r["issue_type"] or "")).lower()
        if any(x in txt for x in ["delay","late","waiting","hold","blocked","impact","shutdown","unavailable"]):
            out.append({"title":r["title"],"description":r["description"] or "","due":r["due"] or "","owner":r["owner"] or ""})
    for level,name,reason,datev in _v39_schedule_risks(pid):
        if level=="CRITICAL":
            out.append({"title":name,"description":reason,"due":datev,"owner":""})
    return out


def _v41_closeout_seed(pid):
    _v41_ensure_tables()
    c=db()
    r=c.execute("SELECT COUNT(*) AS n FROM closeout_items WHERE company_id=? AND project_id=?",(current_company_id(),pid)).fetchone()
    if int(r["n"] or 0)==0:
        now=datetime.utcnow().isoformat()
        defaults=[
            ("As-Builts","Record drawings / as-builts"),
            ("O&M","Operations and maintenance manuals"),
            ("Warranties","Warranty documentation"),
            ("Training","Owner training completion"),
            ("Attic Stock","Required attic stock / spare materials"),
            ("Inspections","Final inspections and certificates"),
            ("Testing","Final testing and commissioning"),
            ("Lien Releases","Final lien releases"),
            ("Turnover","Keys, access, owner turnover documents")
        ]
        for category,item in defaults:
            c.execute("INSERT INTO closeout_items(company_id,project_id,category,item,responsible_party,due_date,status,notes,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?)",(current_company_id(),pid,category,item,"","","OPEN","",now,now))
        c.commit()
    c.close()


@app.get("/field-command",response_class=HTMLResponse)
def v41_field_command():
    pid=project_id()
    ready=_v41_make_ready(pid); deliveries=_v41_delivery_risks(pid); inspections=_v41_inspection_countdown(pid)
    subs,acts,updates=_v41_sub_center(pid); delays=_v41_delay_candidates(pid); attention=_v39_attention(pid)
    not_ready=sum(1 for _,s,_ in ready if s=="NOT READY")
    today_ins=sum(1 for _,label,_ in inspections if label in {"TODAY","TOMORROW"})
    delivery_risk=sum(1 for _,level,_ in deliveries if level in {"CRITICAL","HIGH","TODAY"})
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v41 - Superintendent Field Command</div><h1>Run today&#39;s job.</h1><p class="muted">{len(subs)} subcontractors - {today_ins} inspections due now/next - {delivery_risk} delivery risks - {not_ready} activities not ready - {len(delays)} delay signals - {len(attention)} decisions need review.</p></div>'
    body+='<div class="grid3">'
    body+=_v37_link_card("Make-Ready","See what can actually start and why, with sequence intelligence.","/sequence-intelligence","Open")
    body+=_v37_link_card("Subcontractors","Crews, commitments and upcoming work.","/field-command/subs","Open")
    body+=_v37_link_card("Sub Alerts","Prepare schedule/field alerts for human approval.","/field-command/sub-alerts","Open")
    body+=_v37_link_card("Deliveries","Required-on-site vs promised-date exposure.","/field-command/deliveries","Open")
    body+=_v37_link_card("Inspections","Countdown and readiness before the inspector arrives.","/field-command/inspections","Open")
    body+=_v37_link_card("Daily Report","Build today's superintendent report from project data.","/field-command/daily-report","Open")
    body+=_v37_link_card("Delay Documentation","Capture possible delay events before the record is lost.","/field-command/delays","Open")
    body+=_v37_link_card("Punch & Completion","Open punch organized by location/trade.","/field-command/punch","Open")
    body+=_v37_link_card("Closeout","Track turnover requirements to completion.","/field-command/closeout","Open")
    body+='</div>'
    return shell("Field Command",body)


@app.get("/field-command/make-ready",response_class=HTMLResponse)
def v41_make_ready_page():
    rows=_v41_make_ready(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(status)}</span> <b>{esc(r["name"])}</b><div class="small">{esc(r["trade"])} - {esc(r["start"])} - {missing} readiness checks incomplete</div></div>' for r,status,missing in rows)
    return shell("Make-Ready Brain",'<div class="hero"><h1>Make-Ready Brain</h1><p class="muted">Drawings - material - manpower - predecessor - access - inspection - equipment.</p></div><div class="card">'+(h or '<p class="muted">No active activities.</p>')+'</div>')


@app.get("/field-command/subs",response_class=HTMLResponse)
def v41_subs_page():
    subs,acts,updates=_v41_sub_center(project_id()); h=""
    for s in subs:
        related=[a for a in acts if str(a["trade"] or "").lower()==str(s["trade"] or "").lower()]
        nxt=related[0] if related else None
        next_text=("Next: "+esc(nxt["name"])+" - "+esc(nxt["start"])) if nxt else "No upcoming activity matched."
        h+=f'<div class="card"><h3>{esc(s["name"])}</h3><div class="small">{esc(s["trade"])}</div><p>{next_text}</p></div>'
    return shell("Subcontractor Command",'<div class="hero"><h1>Subcontractor Command Center</h1></div><div class="grid3">'+(h or '<div class="card">No subcontractors loaded.</div>')+'</div>')


@app.get("/field-command/sub-alerts",response_class=HTMLResponse)
def v41_sub_alerts():
    subs,acts,updates=_v41_sub_center(project_id()); risks=_v39_schedule_risks(project_id()); h=""
    for s in subs:
        matching=[r for r in risks if any(str(a["trade"] or "").lower()==str(s["trade"] or "").lower() and a["name"]==r[1] for a in acts)]
        if matching:
            msg=f'BuildCommand draft: Please review upcoming {s["trade"]} schedule requirements and confirm manpower/material readiness. Human approval required before sending.'
            h+=f'<div class="card"><span class="badge WATCH">DRAFT ALERT</span><h3>{esc(s["name"])}</h3><p>{esc(msg)}</p></div>'
    return shell("Sub Alerts",'<div class="hero"><h1>Automatic Sub Alerts</h1><p class="muted">Prepared only. BuildCommand does not send external messages without approval.</p></div>'+(h or '<div class="card">No current alert candidates.</div>'))


@app.get("/field-command/deliveries",response_class=HTMLResponse)
def v41_deliveries_page():
    rows=_v41_delivery_risks(project_id()); h=""
    for r,level,exposure in rows:
        ex=(f' - {exposure} day exposure' if exposure is not None and exposure>0 else '')
        h+=f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(r["item"])}</b><div class="small">Need {esc(r["required_on_site"])} - Promised {esc(r["promised_date"])}{ex}</div></div>'
    return shell("Delivery Intelligence",'<div class="hero"><h1>Delivery Intelligence</h1></div><div class="card">'+(h or '<p class="muted">No open deliveries.</p>')+'</div>')


@app.get("/field-command/inspections",response_class=HTMLResponse)
def v41_inspections_page():
    rows=_v41_inspection_countdown(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(label)}</span> <b>{esc(r["inspection_type"])}</b><div class="small">{esc(r["scheduled_date"])} - {esc(r["authority"])}</div></div>' for r,label,days in rows)
    return shell("Inspection Countdown",'<div class="hero"><h1>Inspection Countdown</h1><p class="muted">7 days - 3 days - tomorrow - today.</p></div><div class="card">'+(h or '<p class="muted">No pending inspections.</p>')+'</div>')


@app.get("/field-command/daily-report",response_class=HTMLResponse)
def v41_daily_report_page():
    pid=project_id()
    acts=_v39_rows("SELECT * FROM activities WHERE project_id=? AND COALESCE(status,'NOT_STARTED')!='COMPLETE' ORDER BY start LIMIT 20",(pid,))
    deliveries=_v41_delivery_risks(pid); inspections=_v41_inspection_countdown(pid); delays=_v41_delay_candidates(pid)
    work=", ".join(str(a["name"]) for a in acts[:8])
    body=f'<div class="hero"><h1>Daily Report Brain</h1><p class="muted">Draft from live project information; superintendent reviews before saving.</p></div><div class="card"><h2>Draft</h2><p><b>Work / upcoming:</b> {esc(work or "No active activities")}</p><p><b>Deliveries:</b> {len(deliveries)} open</p><p><b>Inspections:</b> {len(inspections)} pending</p><p><b>Potential delays:</b> {len(delays)}</p><p><a href="/daily-report">Open Daily Report editor -&gt;</a></p></div>'
    return shell("Daily Report Brain",body)


@app.get("/field-command/delays",response_class=HTMLResponse)
def v41_delays_page():
    rows=_v41_delay_candidates(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">DOCUMENT</span> <b>{esc(r["title"])}</b><div class="small">{esc(r["description"])}</div></div>' for r in rows)
    return shell("Delay Documentation",'<div class="hero"><h1>Delay Documentation Brain</h1><p class="muted">Capture dates, affected activity, responsible party, photos, RFIs and schedule impact.</p></div><div class="card">'+(h or '<p class="muted">No obvious delay candidates detected.</p>')+'</div>')


@app.get("/field-command/punch",response_class=HTMLResponse)
def v41_punch_page():
    rows=_v39_rows("SELECT * FROM punch_items WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('VERIFIED','CLOSED','COMPLETE') ORDER BY location,trade,due",(project_id(),))
    h="".join(f'<div class="action"><b>{esc(r["location"] or "No location")} - {esc(r["title"])}</b><div class="small">{esc(r["trade"])} - {esc(r["owner"])} - Due {esc(r["due"])}</div></div>' for r in rows)
    return shell("Punch & Completion",'<div class="hero"><h1>Punch & Completion Brain</h1></div><div class="card">'+(h or '<p class="muted">No open punch items.</p>')+'<p><a href="/punch">Open full Punch List -&gt;</a></p></div>')


@app.get("/field-command/closeout",response_class=HTMLResponse)
def v41_closeout_page():
    pid=project_id(); _v41_closeout_seed(pid)
    rows=_v39_rows("SELECT * FROM closeout_items WHERE company_id=? AND project_id=? ORDER BY category,id",(current_company_id(),pid))
    complete=sum(1 for r in rows if str(r["status"] or "").upper() in {"COMPLETE","CLOSED","RECEIVED"})
    h="".join(f'<div class="action"><span class="badge">{esc(r["status"])}</span> <b>{esc(r["category"])}</b> - {esc(r["item"])}<div class="small">{esc(r["responsible_party"])} {esc(r["due_date"])}</div></div>' for r in rows)
    return shell("Closeout Brain",f'<div class="hero"><h1>Closeout Brain</h1><p class="muted">{complete}/{len(rows)} core turnover requirements complete.</p></div><div class="card">'+h+'</div>')


def _v42_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"CREATE TABLE IF NOT EXISTS rfi_control(id {pk},company_id BIGINT,project_id BIGINT,number TEXT,title TEXT,question TEXT,responsible_party TEXT,due_date TEXT,status TEXT DEFAULT 'DRAFT',answer TEXT,cost_impact {num} DEFAULT 0,schedule_days {num} DEFAULT 0,source_ref TEXT,created TEXT,updated TEXT)",
      f"CREATE TABLE IF NOT EXISTS budget_commitments(id {pk},company_id BIGINT,project_id BIGINT,trade TEXT,vendor TEXT,original_budget {num} DEFAULT 0,commitment {num} DEFAULT 0,approved_changes {num} DEFAULT 0,pending_exposure {num} DEFAULT 0,notes TEXT,created TEXT,updated TEXT)",
      f"CREATE TABLE IF NOT EXISTS contract_scopes(id {pk},company_id BIGINT,project_id BIGINT,sub_name TEXT,trade TEXT,scope_text TEXT,exclusions TEXT,allowances TEXT,alternates TEXT,status TEXT DEFAULT 'REVIEW',created TEXT,updated TEXT)",
      f"CREATE TABLE IF NOT EXISTS correspondence_control(id {pk},company_id BIGINT,project_id BIGINT,correspondence_date TEXT,subject TEXT,party TEXT,trade TEXT,related_type TEXT,related_ref TEXT,summary TEXT,status TEXT DEFAULT 'OPEN',created TEXT)",
      f"CREATE TABLE IF NOT EXISTS owner_decisions(id {pk},company_id BIGINT,project_id BIGINT,title TEXT,decision_needed TEXT,due_date TEXT,cost_impact {num} DEFAULT 0,schedule_days {num} DEFAULT 0,status TEXT DEFAULT 'OPEN',source_ref TEXT,created TEXT,updated TEXT)",
      f"CREATE TABLE IF NOT EXISTS project_audit_log(id {pk},company_id BIGINT,project_id BIGINT,event_time TEXT,event_type TEXT,title TEXT,source_ref TEXT,decision TEXT,downstream_impact TEXT,reviewed_by TEXT,created TEXT)"
    ]
    for s in stmts: c.execute(s)
    c.commit(); c.close()


def _v42_rfis(pid):
    _v42_ensure_tables()
    return _v39_rows("SELECT * FROM rfi_control WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid))


def _v42_budget(pid):
    _v42_ensure_tables()
    return _v39_rows("SELECT * FROM budget_commitments WHERE company_id=? AND project_id=? ORDER BY trade,vendor",(current_company_id(),pid))


def _v42_contract_gaps(pid):
    _v42_ensure_tables()
    scopes=_v39_rows("SELECT trade,COUNT(*) n FROM blueprint_scope_items WHERE project_id=? GROUP BY trade ORDER BY trade",(pid,))
    contracts=_v39_rows("SELECT * FROM contract_scopes WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    covered={str(r["trade"] or "").lower():r for r in contracts}
    return [(r["trade"],r["n"],covered.get(str(r["trade"] or "").lower())) for r in scopes]


def _v42_meeting_actions(pid):
    meetings=_v39_rows("SELECT * FROM meeting_notes WHERE project_id=? ORDER BY meeting_date DESC,id DESC LIMIT 50",(pid,))
    actions=_v39_rows("SELECT * FROM action_items WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('CLOSED','COMPLETE') ORDER BY due",(pid,))
    return meetings,actions


def _v42_correspondence(pid):
    _v42_ensure_tables()
    return _v39_rows("SELECT * FROM correspondence_control WHERE company_id=? AND project_id=? ORDER BY correspondence_date DESC,id DESC",(current_company_id(),pid))


def _v42_owner(pid):
    _v42_ensure_tables()
    return _v39_rows("SELECT * FROM owner_decisions WHERE company_id=? AND project_id=? AND COALESCE(status,'OPEN') NOT IN ('CLOSED','COMPLETE') ORDER BY due_date",(current_company_id(),pid))


def _v42_audit(pid):
    _v42_ensure_tables()
    return _v39_rows("SELECT * FROM project_audit_log WHERE company_id=? AND project_id=? ORDER BY event_time DESC,id DESC LIMIT 200",(current_company_id(),pid))


@app.get("/project-control",response_class=HTMLResponse)
def v42_project_control():
    pid=project_id(); _v42_ensure_tables()
    rfis=_v42_rfis(pid); subs=_v39_rows("SELECT * FROM submittals WHERE project_id=? AND COALESCE(status,'PENDING') NOT IN ('APPROVED','CLOSED','COMPLETE')",(pid,))
    budget=_v42_budget(pid); changes=_v39_changes(pid); owners=_v42_owner(pid); gaps=_v42_contract_gaps(pid)
    meetings,actions=_v42_meeting_actions(pid); corr=_v42_correspondence(pid); audit=_v42_audit(pid)
    pending=sum(float(r["pending_exposure"] or 0) for r in budget)+sum(float(r["estimated_cost"] or 0) for r in changes)
    gap_count=sum(1 for _,_,c in gaps if c is None)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v42 - Project Control</div><h1>Control cost, schedule and decisions.</h1><p class="muted">{len(rfis)} RFIs - {len(subs)} open submittals - ${pending:,.0f} pending exposure - {len(owners)} owner decisions - {gap_count} contract scope gaps - {len(actions)} open actions.</p></div><div class="grid3">'
    cards=[
      ("RFI Command","Lifecycle, cost/schedule impact and field verification.","/project-control/rfis"),
      ("Submittal Command","Track required, submitted, review and release status.","/project-control/submittals"),
      ("Budget & Commitments","Budget, commitments, approved changes and exposure.","/project-control/budget"),
      ("Change Management","Trace potential changes through cost and schedule.","/project-control/changes"),
      ("Contract Scope","Compare subcontract coverage against Blueprint Brain.","/project-control/contracts"),
      ("Meeting Intelligence","Decisions, commitments and open actions.","/project-control/meetings"),
      ("Correspondence","Organize important communication around project issues.","/project-control/correspondence"),
      ("Owner Decisions","Decisions required and their consequence.","/project-control/owner-decisions"),
      ("Audit Trail","Chronological project intelligence record.","/project-control/audit")
    ]
    for name,desc,href in cards: body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Project Control",body)


@app.get("/project-control/rfis",response_class=HTMLResponse)
def v42_rfi_page():
    rows=_v42_rfis(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(r["status"])}</span> <b>{esc(r["number"] or "DRAFT")} - {esc(r["title"])}</b><div class="small">Due {esc(r["due_date"])} - Cost ${float(r["cost_impact"] or 0):,.0f} - {float(r["schedule_days"] or 0):g} days</div></div>' for r in rows)
    return shell("RFI Command",'<div class="hero"><h1>RFI Command Brain</h1><p class="muted">Detected - draft - submitted - answered - cost/schedule impact - field verification.</p></div><div class="card">'+(h or '<p class="muted">No controlled RFIs yet. Conflict Brain proposals remain available for human review.</p>')+'</div>')


@app.get("/project-control/submittals",response_class=HTMLResponse)
def v42_submittal_page():
    rows=_v39_rows("SELECT * FROM submittals WHERE project_id=? ORDER BY due_date,id",(project_id(),))
    h="".join(f'<div class="action"><span class="badge">{esc(r["status"])}</span> <b>{esc(r["title"])}</b><div class="small">Spec {esc(r["spec_section"])} - {esc(r["responsible_party"])} - Due {esc(r["due_date"])}</div></div>' for r in rows)
    return shell("Submittal Command",'<div class="hero"><h1>Submittal Command Brain</h1></div><div class="card">'+(h or '<p class="muted">No submittals loaded.</p>')+'</div>')


@app.get("/project-control/budget",response_class=HTMLResponse)
def v42_budget_page():
    rows=_v42_budget(project_id()); h=""; tb=tc=ta=tp=0
    for r in rows:
        b=float(r["original_budget"] or 0); c=float(r["commitment"] or 0); a=float(r["approved_changes"] or 0); p=float(r["pending_exposure"] or 0)
        tb+=b; tc+=c; ta+=a; tp+=p; forecast=c+a+p; level="WATCH" if b and forecast>b else "READY"
        h+=f'<div class="action"><span class="badge {level}">{level}</span> <b>{esc(r["trade"])}</b><div class="small">Budget ${b:,.0f} - Committed ${c:,.0f} - Approved ${a:,.0f} - Pending ${p:,.0f} - Forecast ${forecast:,.0f}</div></div>'
    head=f'<div class="hero"><h1>Budget & Commitment Brain</h1><p class="muted">Budget ${tb:,.0f} - Commitments ${tc:,.0f} - Approved changes ${ta:,.0f} - Pending exposure ${tp:,.0f}</p></div>'
    return shell("Budget & Commitments",head+'<div class="card">'+(h or '<p class="muted">No budget commitments loaded yet.</p>')+'</div>')


@app.get("/project-control/changes",response_class=HTMLResponse)
def v42_changes_page():
    rows=_v39_changes(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["status"])}</span> <b>{esc(r["event_type"])} - {esc(r["title"])}</b><div class="small">${float(r["estimated_cost"] or 0):,.0f} - {float(r["schedule_days"] or 0):g} days - {esc(r["responsible_party"])}</div></div>' for r in rows)
    return shell("Change Management",'<div class="hero"><h1>Change Management Brain</h1><p class="muted">RFI / ASI / bulletin / owner request / field condition to cost and schedule exposure.</p></div><div class="card">'+(h or '<p class="muted">No open change events.</p>')+'</div>')


@app.get("/project-control/contracts",response_class=HTMLResponse)
def v42_contract_page():
    rows=_v42_contract_gaps(project_id()); h=""
    for trade,n,c in rows:
        if c is None:
            h+=f'<div class="action"><span class="badge WATCH">GAP</span> <b>{esc(trade)}</b><div class="small">{n} Blueprint Brain scope items - no contract scope record loaded.</div></div>'
        else:
            exclusions=str(c["exclusions"] or "")
            h+=f'<div class="action"><span class="badge READY">REVIEWED</span> <b>{esc(trade)} - {esc(c["sub_name"])}</b><div class="small">{n} source-backed items - exclusions: {esc(exclusions[:300])}</div></div>'
    return shell("Contract Scope",'<div class="hero"><h1>Contract Scope Brain</h1><p class="muted">Scope gaps, exclusions, overlaps, allowances and unclear responsibility.</p></div><div class="card">'+(h or '<p class="muted">Analyze Blueprint Brain scope first.</p>')+'</div>')


@app.get("/project-control/meetings",response_class=HTMLResponse)
def v42_meeting_page():
    meetings,actions=_v42_meeting_actions(project_id()); h=""
    for m in meetings:
        h+=f'<div class="card"><span class="badge">{esc(m["meeting_type"])}</span><h3>{esc(m["title"])}</h3><div class="small">{esc(m["meeting_date"])} - {esc(m["attendees"])}</div><p><b>Decisions:</b> {esc(m["decisions"])}</p><p><b>Commitments:</b> {esc(m["commitments"])}</p></div>'
    ah="".join(f'<div class="action"><b>{esc(a["title"])}</b><div class="small">{esc(a["owner"])} - Due {esc(a["due"])} - {esc(a["priority"])}</div></div>' for a in actions)
    return shell("Meeting Intelligence",'<div class="hero"><h1>Meeting Intelligence</h1><p class="muted">Keep decisions and commitments from disappearing.</p></div>'+(h or '<div class="card">No meeting notes loaded.</div>')+'<div class="card"><h2>Open Actions</h2>'+ (ah or '<p class="muted">No open actions.</p>')+'</div>')


@app.get("/project-control/correspondence",response_class=HTMLResponse)
def v42_correspondence_page():
    rows=_v42_correspondence(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(r["related_type"])}</span> <b>{esc(r["subject"])}</b><div class="small">{esc(r["correspondence_date"])} - {esc(r["party"])} - {esc(r["trade"])} - {esc(r["related_ref"])}</div><p>{esc(r["summary"])}</p></div>' for r in rows)
    return shell("Correspondence",'<div class="hero"><h1>Correspondence Brain</h1><p class="muted">Communication organized around trade, issue, RFI, submittal, schedule and change.</p></div><div class="card">'+(h or '<p class="muted">No controlled correspondence loaded yet.</p>')+'</div>')


@app.get("/project-control/owner-decisions",response_class=HTMLResponse)
def v42_owner_page():
    rows=_v42_owner(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">DECISION</span> <b>{esc(r["title"])}</b><div>{esc(r["decision_needed"])}</div><div class="small">Due {esc(r["due_date"])} - ${float(r["cost_impact"] or 0):,.0f} exposure - {float(r["schedule_days"] or 0):g} days at risk - {esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Owner Decisions",'<div class="hero"><h1>Owner Decision Tracker</h1><p class="muted">Decision needed - deadline - downstream cost/schedule consequence.</p></div><div class="card">'+(h or '<p class="muted">No owner decisions currently tracked.</p>')+'</div>')


@app.get("/project-control/audit",response_class=HTMLResponse)
def v42_audit_page():
    rows=_v42_audit(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(r["event_type"])}</span> <b>{esc(r["title"])}</b><div class="small">{esc(r["event_time"])} - {esc(r["source_ref"])} - reviewed by {esc(r["reviewed_by"])}</div><p>{esc(r["downstream_impact"])}</p></div>' for r in rows)
    return shell("Project Audit Trail",'<div class="hero"><h1>Project Audit Trail</h1><p class="muted">What changed, source, decision, downstream impact and review history.</p></div><div class="card">'+(h or '<p class="muted">Audit events will accumulate as controlled project decisions are recorded.</p>')+'</div>')


def _v43_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS learning_rules(
        id {pk},company_id BIGINT,project_id BIGINT,rule_type TEXT,subject TEXT,
        learned_rule TEXT,source_ref TEXT,scope_level TEXT DEFAULT 'PROJECT ONLY',
        approval_status TEXT DEFAULT 'PROPOSED',approved_by TEXT,confidence TEXT DEFAULT 'HIGH',
        created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS estimator_learning(
        id {pk},company_id BIGINT,project_id BIGINT,estimator_item_id BIGINT,trade TEXT,
        description TEXT,ai_quantity {num},accepted_quantity {num},unit TEXT,
        decision TEXT,reason TEXT,approval_status TEXT DEFAULT 'PROPOSED',
        approved_by TEXT,created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS historical_costs(
        id {pk},company_id BIGINT,project_id BIGINT,trade TEXT,scope TEXT,unit TEXT,
        quantity {num},unit_cost {num},total_cost {num},building_type TEXT,location TEXT,
        vendor TEXT,cost_date TEXT,approval_status TEXT DEFAULT 'APPROVED',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS schedule_learning(
        id {pk},company_id BIGINT,project_id BIGINT,activity_id BIGINT,trade TEXT,
        activity_name TEXT,planned_start TEXT,planned_finish TEXT,actual_start TEXT,actual_finish TEXT,
        planned_days {num},actual_days {num},production_note TEXT,approval_status TEXT DEFAULT 'PROPOSED',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS subcontractor_performance(
        id {pk},company_id BIGINT,project_id BIGINT,sub_name TEXT,trade TEXT,
        schedule_score {num} DEFAULT 0,quality_score {num} DEFAULT 0,safety_score {num} DEFAULT 0,
        responsiveness_score {num} DEFAULT 0,change_score {num} DEFAULT 0,closeout_score {num} DEFAULT 0,
        notes TEXT,approval_status TEXT DEFAULT 'PROPOSED',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS inspection_learning(
        id {pk},company_id BIGINT,project_id BIGINT,inspection_type TEXT,authority TEXT,trade TEXT,
        result TEXT,failure_reason TEXT,correction TEXT,lesson TEXT,
        approval_status TEXT DEFAULT 'PROPOSED',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS lessons_learned(
        id {pk},company_id BIGINT,project_id BIGINT,category TEXT,title TEXT,lesson TEXT,
        recommendation TEXT,source_ref TEXT,scope_level TEXT DEFAULT 'PROJECT ONLY',
        approval_status TEXT DEFAULT 'PROPOSED',approved_by TEXT,created TEXT)"""
    ]
    for s in stmts: c.execute(s)
    c.commit(); c.close()


def _v43_rules(pid=None):
    _v43_ensure_tables()
    if pid:
        return _v39_rows("SELECT * FROM learning_rules WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid))
    return _v39_rows("SELECT * FROM learning_rules WHERE company_id=? ORDER BY id DESC LIMIT 300",(current_company_id(),))


def _v43_trade_proposals(pid):
    # Current high-confidence reviewed scope becomes a learning candidate only.
    rows=_v39_rows("SELECT * FROM blueprint_scope_items WHERE project_id=? AND COALESCE(confidence,'')='HIGH' ORDER BY id DESC LIMIT 150",(pid,))
    return rows


def _v43_estimator_signals(pid):
    return _v39_rows("SELECT * FROM estimator_items WHERE project_id=? AND (COALESCE(verified,0)=1 OR ai_quantity IS NOT NULL) ORDER BY id DESC LIMIT 150",(pid,))


def _v43_schedule_signals(pid):
    return _v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY id DESC LIMIT 150",(pid,))


def _v43_inspection_signals(pid):
    return _v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? AND COALESCE(result,'PENDING') NOT IN ('PENDING','PASSED') ORDER BY id DESC LIMIT 100",(pid,))


def _v43_rfi_change_patterns(pid):
    _v42_ensure_tables()
    rfis=_v39_rows("SELECT * FROM rfi_control WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid))
    changes=_v39_rows("SELECT * FROM change_events WHERE project_id=? ORDER BY id DESC",(pid,))
    return rfis,changes


@app.get("/learning",response_class=HTMLResponse)
def v43_learning_center():
    pid=project_id(); _v43_ensure_tables()
    rules=_v43_rules(pid); trade=_v43_trade_proposals(pid); est=_v43_estimator_signals(pid)
    inspections=_v43_inspection_signals(pid); rfis,changes=_v43_rfi_change_patterns(pid)
    approved=sum(1 for r in rules if str(r["approval_status"] or "").upper()=="APPROVED")
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v43 - Construction Learning Intelligence</div><h1>Every approved lesson makes the next project smarter.</h1><p class="muted">{approved} approved learned rules - {len(trade)} trade-learning candidates - {len(est)} estimator signals - {len(inspections)} inspection lessons - {len(rfis)+len(changes)} RFI/change patterns.</p><p><b>Learning firewall:</b> AI proposals never become permanent construction knowledge without human approval.</p></div><div class="grid3">'
    cards=[
      ("Trade Assignment Learning","Turn reviewed trade corrections into reusable rules.","/learning/trades"),
      ("Scope Boundary Brain","Learn where one trade stops and another starts.","/learning/boundaries"),
      ("Estimator Learning","Learn from accepted, rejected and adjusted takeoff proposals.","/learning/estimator"),
      ("Historical Cost Brain","Private cost history by trade, scope, unit and project.","/learning/costs"),
      ("Schedule Learning","Compare planned durations with actual field performance.","/learning/schedule"),
      ("Sub Performance","Learn which subcontractors actually perform.","/learning/subs"),
      ("Inspection Learning","Remember failures, corrections and AHJ patterns.","/learning/inspections"),
      ("RFI / Change Patterns","Find recurring drawing conflicts and cost exposure.","/learning/patterns"),
      ("Lessons Learned","Turn project experience into approved future guidance.","/learning/lessons"),
      ("Knowledge Core","Controlled project/company/global construction knowledge.","/learning/core")
    ]
    for name,desc,href in cards: body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Construction Learning",body)


@app.get("/learning/trades",response_class=HTMLResponse)
def v43_trade_learning():
    rows=_v43_trade_proposals(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">PROPOSAL</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} {esc(r["source_detail"])} - Human approval required before learning.</div></div>' for r in rows)
    return shell("Trade Assignment Learning",'<div class="hero"><h1>Trade Assignment Learning Brain</h1><p class="muted">Reviewed construction corrections become candidates for reusable knowledge, never automatic rules.</p></div><div class="card">'+(h or '<p class="muted">No high-confidence trade candidates yet.</p>')+'</div>')


@app.get("/learning/boundaries",response_class=HTMLResponse)
def v43_boundaries():
    rows=_v43_rules()
    rows=[r for r in rows if str(r["rule_type"] or "").upper() in {"SCOPE BOUNDARY","TRADE ASSIGNMENT"}]
    h="".join(f'<div class="action"><span class="badge">{esc(r["scope_level"])}</span> <b>{esc(r["subject"])}</b><div>{esc(r["learned_rule"])}</div><div class="small">{esc(r["approval_status"])} - {esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Scope Boundary Brain",'<div class="hero"><h1>Scope Boundary Brain</h1><p class="muted">Responsibility rules can be PROJECT ONLY, COMPANY STANDARD, or controlled GLOBAL BUILDCOMMAND RULE.</p></div><div class="card">'+(h or '<p class="muted">No approved boundary rules recorded yet.</p>')+'</div>')


@app.get("/learning/estimator",response_class=HTMLResponse)
def v43_estimator_learning():
    rows=_v43_estimator_signals(project_id()); h=""
    for r in rows:
        ai=r["ai_quantity"]; accepted=r["quantity"]; delta=(float(accepted or 0)-float(ai or 0)) if ai is not None else None
        h+=f'<div class="action"><span class="badge {"READY" if r["verified"] else "WATCH"}">{"VERIFIED" if r["verified"] else "REVIEW"}</span> <b>{esc(r["trade"])} - {esc(r["description"])}</b><div class="small">AI {esc(ai)} {esc(r["ai_unit"])} - Current {esc(accepted)} {esc(r["unit"])}'+(f' - Delta {delta:g}' if delta is not None else '')+'</div></div>'
    return shell("Estimator Learning",'<div class="hero"><h1>Estimator Learning Brain</h1><p class="muted">Quantity decisions remain proposals until reviewed; estimator quantities are never silently overwritten.</p></div><div class="card">'+(h or '<p class="muted">No estimator learning signals yet.</p>')+'</div>')


@app.get("/learning/costs",response_class=HTMLResponse)
def v43_costs():
    _v43_ensure_tables()
    rows=_v39_rows("SELECT * FROM historical_costs WHERE company_id=? ORDER BY cost_date DESC,id DESC LIMIT 200",(current_company_id(),))
    h="".join(f'<div class="action"><b>{esc(r["trade"])} - {esc(r["scope"])}</b><div class="small">{float(r["quantity"] or 0):g} {esc(r["unit"])} @ ${float(r["unit_cost"] or 0):,.2f} - Total ${float(r["total_cost"] or 0):,.0f} - {esc(r["vendor"])}</div></div>' for r in rows)
    return shell("Historical Cost Brain",'<div class="hero"><h1>Historical Cost Brain</h1><p class="muted">Private company cost intelligence by trade, scope, unit, project, vendor and date.</p></div><div class="card">'+(h or '<p class="muted">Historical costs will build from reviewed project actuals.</p>')+'</div>')


@app.get("/learning/schedule",response_class=HTMLResponse)
def v43_schedule_learning():
    rows=_v43_schedule_signals(project_id())
    h="".join(f'<div class="action"><b>{esc(r["trade"])} - {esc(r["name"])}</b><div class="small">Planned {esc(r["start"])} to {esc(r["finish"])} - {float(r["pct"] or 0):g}% complete - {esc(r["status"])}</div></div>' for r in rows)
    return shell("Schedule Learning",'<div class="hero"><h1>Schedule Learning Brain</h1><p class="muted">Build realistic production intelligence by comparing planned work against actual field performance.</p></div><div class="card">'+(h or '<p class="muted">No schedule activities loaded.</p>')+'</div>')


@app.get("/learning/subs",response_class=HTMLResponse)
def v43_sub_learning():
    _v43_ensure_tables()
    rows=_v39_rows("SELECT * FROM subcontractor_performance WHERE company_id=? ORDER BY id DESC LIMIT 200",(current_company_id(),))
    current=_v39_rows("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(project_id(),))
    h="".join(f'<div class="action"><b>{esc(r["sub_name"])} - {esc(r["trade"])}</b><div class="small">Schedule {float(r["schedule_score"] or 0):g} - Quality {float(r["quality_score"] or 0):g} - Safety {float(r["safety_score"] or 0):g} - Responsiveness {float(r["responsiveness_score"] or 0):g} - Closeout {float(r["closeout_score"] or 0):g}</div></div>' for r in rows)
    if not h:
        h="".join(f'<div class="action"><span class="badge WATCH">NEEDS HISTORY</span> <b>{esc(r["name"])} - {esc(r["trade"])}</b></div>' for r in current)
    return shell("Subcontractor Performance",'<div class="hero"><h1>Subcontractor Performance Brain</h1><p class="muted">Performance history should inform future selection, not price alone.</p></div><div class="card">'+(h or '<p class="muted">No subcontractors loaded.</p>')+'</div>')


@app.get("/learning/inspections",response_class=HTMLResponse)
def v43_inspection_learning():
    rows=_v43_inspection_signals(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["result"])}</span> <b>{esc(r["inspection_type"])}</b><div class="small">{esc(r["authority"])} - {esc(r["notes"])}</div></div>' for r in rows)
    return shell("Inspection Learning",'<div class="hero"><h1>Inspection Learning Brain</h1><p class="muted">Remember failed inspections and corrections by jurisdiction, trade and inspection type.</p></div><div class="card">'+(h or '<p class="muted">No failed/rejected inspection signals.</p>')+'</div>')


@app.get("/learning/patterns",response_class=HTMLResponse)
def v43_patterns():
    rfis,changes=_v43_rfi_change_patterns(project_id()); h=""
    for r in rfis:
        h+=f'<div class="action"><span class="badge">RFI</span> <b>{esc(r["title"])}</b><div class="small">{esc(r["source_ref"])} - ${float(r["cost_impact"] or 0):,.0f} - {float(r["schedule_days"] or 0):g} days</div></div>'
    for r in changes:
        h+=f'<div class="action"><span class="badge WATCH">CHANGE</span> <b>{esc(r["title"])}</b><div class="small">{esc(r["event_type"])} - ${float(r["estimated_cost"] or 0):,.0f} - {float(r["schedule_days"] or 0):g} days</div></div>'
    return shell("RFI / Change Patterns",'<div class="hero"><h1>RFI / Change Pattern Brain</h1><p class="muted">Recurring conflicts become preconstruction warnings after review.</p></div><div class="card">'+(h or '<p class="muted">No RFI/change history yet.</p>')+'</div>')


@app.get("/learning/lessons",response_class=HTMLResponse)
def v43_lessons():
    _v43_ensure_tables()
    rows=_v39_rows("SELECT * FROM lessons_learned WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),project_id()))
    h="".join(f'<div class="action"><span class="badge">{esc(r["approval_status"])}</span> <b>{esc(r["category"])} - {esc(r["title"])}</b><div>{esc(r["lesson"])}</div><div class="small">Recommendation: {esc(r["recommendation"])} - {esc(r["scope_level"])}</div></div>' for r in rows)
    return shell("Lessons Learned",'<div class="hero"><h1>Project Lessons-Learned Brain</h1><p class="muted">What worked, what failed, what cost money, what delayed the job, and what the next project should do differently.</p></div><div class="card">'+(h or '<p class="muted">Lessons will accumulate through reviewed project closeout.</p>')+'</div>')


@app.get("/learning/core",response_class=HTMLResponse)
def v43_knowledge_core():
    rows=_v43_rules(); project=sum(1 for r in rows if r["scope_level"]=="PROJECT ONLY"); company=sum(1 for r in rows if r["scope_level"]=="COMPANY STANDARD"); globaln=sum(1 for r in rows if r["scope_level"]=="GLOBAL BUILDCOMMAND RULE"); approved=sum(1 for r in rows if str(r["approval_status"]).upper()=="APPROVED")
    h="".join(f'<div class="action"><span class="badge">{esc(r["scope_level"])}</span> <b>{esc(r["rule_type"])} - {esc(r["subject"])}</b><div>{esc(r["learned_rule"])}</div><div class="small">{esc(r["approval_status"])} - source {esc(r["source_ref"])}</div></div>' for r in rows[:150])
    head=f'<div class="hero"><h1>BuildCommand Construction Knowledge Core</h1><p class="muted">{approved} approved - {project} project-only - {company} company standards - {globaln} controlled global rules.</p><p><b>Knowledge firewall:</b> PROJECT ONLY can never silently become COMPANY STANDARD or GLOBAL. Promotion requires human approval.</p></div>'
    return shell("Knowledge Core",head+'<div class="card">'+(h or '<p class="muted">The controlled knowledge core is ready to learn from approved construction decisions.</p>')+'</div>')


def _v44_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS pursuit_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,client TEXT,project_type TEXT,
        location TEXT,bid_due TEXT,estimated_value {num} DEFAULT 0,competition TEXT,
        strategic_fit {num} DEFAULT 0,risk_score {num} DEFAULT 0,win_score {num} DEFAULT 0,
        recommendation TEXT DEFAULT 'REVIEW',notes TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS bid_invites(
        id {pk},company_id BIGINT,project_id BIGINT,trade TEXT,sub_name TEXT,
        contact TEXT,invite_date TEXT,due_date TEXT,status TEXT DEFAULT 'PLANNED',
        response TEXT,notes TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS bid_proposals(
        id {pk},company_id BIGINT,project_id BIGINT,trade TEXT,sub_name TEXT,
        base_bid {num} DEFAULT 0,alternates {num} DEFAULT 0,allowances {num} DEFAULT 0,
        exclusions TEXT,qualifications TEXT,scope_coverage {num} DEFAULT 0,
        risk_score {num} DEFAULT 0,status TEXT DEFAULT 'REVIEW',received_date TEXT,
        notes TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS bid_packages(
        id {pk},company_id BIGINT,project_id BIGINT,trade TEXT,title TEXT,
        scope_text TEXT,source_count INTEGER DEFAULT 0,status TEXT DEFAULT 'DRAFT',
        issued_date TEXT,due_date TEXT,created TEXT,updated TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v44_scope_by_trade(pid):
    return _v39_rows(
        "SELECT trade,COUNT(*) AS n FROM blueprint_scope_items WHERE project_id=? GROUP BY trade ORDER BY trade",
        (pid,)
    )


def _v44_estimate_by_trade(pid):
    rows=_v39_rows("""
        SELECT trade,
               SUM(COALESCE(quantity,0)*COALESCE(material_unit_cost,0)) AS material,
               SUM(COALESCE(quantity,0)*COALESCE(labor_unit_cost,0)) AS labor,
               SUM(COALESCE(subcontract_quote,0)) AS subquote,
               SUM(COALESCE(allowance,0)) AS allowance
        FROM estimator_items
        WHERE project_id=?
        GROUP BY trade ORDER BY trade
    """,(pid,))
    return rows


def _v44_historical_cost_by_trade():
    _v43_ensure_tables()
    return _v39_rows("""
        SELECT trade,AVG(COALESCE(unit_cost,0)) AS avg_unit_cost,
               COUNT(*) AS samples,SUM(COALESCE(total_cost,0)) AS total_history
        FROM historical_costs
        WHERE company_id=? AND COALESCE(approval_status,'APPROVED')='APPROVED'
        GROUP BY trade ORDER BY trade
    """,(current_company_id(),))


def _v44_bid_coverage(pid):
    _v44_ensure_tables()
    scopes=_v44_scope_by_trade(pid)
    invites=_v39_rows("SELECT * FROM bid_invites WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    proposals=_v39_rows("SELECT * FROM bid_proposals WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    out=[]
    for r in scopes:
        trade=str(r["trade"] or "")
        ti=[x for x in invites if str(x["trade"] or "").lower()==trade.lower()]
        tp=[x for x in proposals if str(x["trade"] or "").lower()==trade.lower()]
        status="PRICED" if tp else "INVITED" if ti else "NO COVERAGE"
        out.append((trade,int(r["n"] or 0),len(ti),len(tp),status))
    return out


def _v44_scope_gaps(pid):
    rows=_v39_rows("""
        SELECT * FROM blueprint_scope_items
        WHERE project_id=? AND (
            COALESCE(confidence,'MEDIUM') IN ('LOW','MEDIUM')
            OR COALESCE(related_trade,'')!=''
        )
        ORDER BY trade,id LIMIT 150
    """,(pid,))
    return rows


def _v44_allowances(pid):
    rows=_v39_rows("""
        SELECT * FROM estimator_items
        WHERE project_id=? AND (
            COALESCE(allowance,0)>0
            OR LOWER(COALESCE(description,'')) LIKE '%allowance%'
            OR LOWER(COALESCE(description,'')) LIKE '%alternate%'
            OR LOWER(COALESCE(description,'')) LIKE '%owner furnished%'
        )
        ORDER BY trade,id
    """,(pid,))
    return rows


def _v44_long_leads(pid):
    rows=_v39_rows("""
        SELECT * FROM procurement
        WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('DELIVERED','COMPLETE','CLOSED')
        ORDER BY required_on_site
    """,(pid,))
    return rows


def _v44_precon_risk(pid):
    coverage=_v44_bid_coverage(pid)
    gaps=_v44_scope_gaps(pid)
    est=_v44_estimate_by_trade(pid)
    longleads=_v44_long_leads(pid)
    uncovered=sum(1 for x in coverage if x[4]=="NO COVERAGE")
    unverified=_v37_snapshot(pid)["review"]
    score=min(100,uncovered*10+len(gaps)*2+unverified*2+len(longleads)*4)
    level="CRITICAL" if score>=70 else "HIGH" if score>=45 else "MEDIUM" if score>=20 else "LOW"
    return {"score":score,"level":level,"uncovered":uncovered,"gaps":len(gaps),"unverified":unverified,"longleads":len(longleads)}


def _v44_pursuit(pid):
    _v44_ensure_tables()
    rows=_v39_rows("SELECT * FROM pursuit_intelligence WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 1",(current_company_id(),pid))
    return rows[0] if rows else None


@app.get("/preconstruction",response_class=HTMLResponse)
def v44_preconstruction():
    pid=project_id(); _v44_ensure_tables()
    risk=_v44_precon_risk(pid); coverage=_v44_bid_coverage(pid); gaps=_v44_scope_gaps(pid)
    proposals=_v39_rows("SELECT * FROM bid_proposals WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    allowances=_v44_allowances(pid); longleads=_v44_long_leads(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v44 - Preconstruction & Bid Intelligence</div><h1>Decide what to bid, what it should cost, and where the risk is.</h1><p class="muted">Preconstruction risk {risk["level"]} ({risk["score"]}/100) - {risk["uncovered"]} trades without bid coverage - {len(proposals)} proposals - {len(gaps)} scope review items - {len(allowances)} allowance/alternate items - {len(longleads)} long-lead signals.</p></div><div class="grid3">'
    cards=[
      ("Pursuit / Go-No-Go","Should we chase this project? Score fit, risk, competition and win potential.","/preconstruction/pursuit"),
      ("Scope Completeness","What is in the job, what is unclear, and what might be missing.","/preconstruction/scope"),
      ("Estimate Benchmark","Compare current estimate structure with approved historical company costs.","/preconstruction/benchmark"),
      ("Bid Coverage","Which trades are covered, invited, priced or completely exposed.","/preconstruction/coverage"),
      ("Bidder Strategy","Build the subcontractor pursuit list by trade and performance history.","/preconstruction/bidders"),
      ("Bid Packages","Turn cleaned Blueprint Brain scopes into trade bid-package readiness.","/preconstruction/packages"),
      ("Bid Leveling","Compare subcontractor pricing, coverage, exclusions and qualifications.","/preconstruction/leveling"),
      ("Allowances & Alternates","Separate uncertain money before it disappears into the estimate.","/preconstruction/allowances"),
      ("Long-Lead / Schedule Risk","Find procurement items that can hurt the proposed schedule.","/preconstruction/long-lead"),
      ("Preconstruction Risk","One consolidated view of scope, pricing, coverage and schedule exposure.","/preconstruction/risk")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Preconstruction",body)


@app.get("/preconstruction/pursuit",response_class=HTMLResponse)
def v44_pursuit_page():
    pid=project_id(); p=_v44_pursuit(pid); risk=_v44_precon_risk(pid)
    if p:
        win=float(p["win_score"] or 0); fit=float(p["strategic_fit"] or 0)
        rec=p["recommendation"] or "REVIEW"
        detail=f'<div class="grid3"><div class="card"><div class="label">Win Score</div><div class="kpi">{win:g}</div></div><div class="card"><div class="label">Strategic Fit</div><div class="kpi">{fit:g}</div></div><div class="card"><div class="label">Recommendation</div><div class="kpi">{esc(rec)}</div></div></div><div class="card"><p>{esc(p["notes"])}</p></div>'
    else:
        detail=f'<div class="card"><span class="badge WATCH">REVIEW</span><h2>Go / No-Go candidate</h2><p>Current preconstruction risk: <b>{risk["level"]}</b> ({risk["score"]}/100).</p><p class="muted">Add client, competition, strategic fit, project value and win probability before making a pursuit decision.</p></div>'
    return shell("Pursuit Intelligence",'<div class="hero"><h1>Pursuit / Go-No-Go Brain</h1><p class="muted">Do not burn estimating time on every opportunity. Score whether the project is worth chasing.</p></div>'+detail)


@app.get("/preconstruction/scope",response_class=HTMLResponse)
def v44_scope_page():
    rows=_v44_scope_gaps(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["confidence"])}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">{esc(r["source_sheet"])} {esc(r["source_detail"])} {esc(r["source_spec"])}'+(f' - Related trade: {esc(r["related_trade"])}' if r["related_trade"] else '')+'</div></div>' for r in rows)
    return shell("Scope Completeness",'<div class="hero"><h1>Scope Completeness Brain</h1><p class="muted">Focus estimating attention on ambiguous, cross-trade and lower-confidence requirements.</p></div><div class="card">'+(h or '<p class="muted">No obvious scope-completeness exceptions detected.</p>')+'</div>')


@app.get("/preconstruction/benchmark",response_class=HTMLResponse)
def v44_benchmark_page():
    current=_v44_estimate_by_trade(project_id()); hist=_v44_historical_cost_by_trade()
    hm={str(r["trade"] or "").lower():r for r in hist}; h=""
    for r in current:
        trade=str(r["trade"] or ""); current_total=float(r["material"] or 0)+float(r["labor"] or 0)+float(r["subquote"] or 0)+float(r["allowance"] or 0)
        old=hm.get(trade.lower())
        hist_text=f'{int(old["samples"] or 0)} historical samples - avg unit cost ${float(old["avg_unit_cost"] or 0):,.2f}' if old else 'No approved historical benchmark'
        h+=f'<div class="action"><b>{esc(trade)}</b><div class="small">Current estimator total ${current_total:,.0f} - {esc(hist_text)}</div></div>'
    return shell("Estimate Benchmark",'<div class="hero"><h1>Estimate Benchmark Brain</h1><p class="muted">Historical costs inform review; they never replace current project takeoff or subcontractor pricing.</p></div><div class="card">'+(h or '<p class="muted">No current estimate data.</p>')+'</div>')


@app.get("/preconstruction/coverage",response_class=HTMLResponse)
def v44_coverage_page():
    rows=_v44_bid_coverage(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if status=="PRICED" else "WATCH"}">{esc(status)}</span> <b>{esc(trade)}</b><div class="small">{n} scope items - {invites} invite(s) - {proposals} proposal(s)</div></div>' for trade,n,invites,proposals,status in rows)
    return shell("Bid Coverage",'<div class="hero"><h1>Bid Coverage Brain</h1><p class="muted">Every trade should have deliberate pricing coverage before bid day.</p></div><div class="card">'+(h or '<p class="muted">Analyze project scope first.</p>')+'</div>')


@app.get("/preconstruction/bidders",response_class=HTMLResponse)
def v44_bidders_page():
    pid=project_id()
    subs=_v39_rows("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(pid,))
    perf=_v39_rows("SELECT * FROM subcontractor_performance WHERE company_id=? AND COALESCE(approval_status,'PROPOSED')='APPROVED' ORDER BY trade,sub_name",(current_company_id(),))
    pm={(str(r["sub_name"] or "").lower(),str(r["trade"] or "").lower()):r for r in perf}
    h=""
    for s in subs:
        p=pm.get((str(s["name"] or "").lower(),str(s["trade"] or "").lower()))
        score=""
        if p:
            vals=[float(p[k] or 0) for k in ["schedule_score","quality_score","safety_score","responsiveness_score","closeout_score"]]
            score=f' - Performance avg {sum(vals)/len(vals):.1f}'
        h+=f'<div class="action"><b>{esc(s["name"])} - {esc(s["trade"])}</b><div class="small">Bidder candidate{esc(score)}</div></div>'
    return shell("Bidder Strategy",'<div class="hero"><h1>Bidder Strategy Brain</h1><p class="muted">Build the bidder list using trade coverage and approved performance history, not price alone.</p></div><div class="card">'+(h or '<p class="muted">No subcontractors loaded for this project.</p>')+'</div>')


@app.get("/preconstruction/packages",response_class=HTMLResponse)
def v44_packages_page():
    rows=_v44_scope_by_trade(project_id())
    h="".join(f'<div class="action"><span class="badge READY">READY TO BUILD</span> <b>{esc(r["trade"])}</b><div class="small">{int(r["n"] or 0)} source-backed scope items can feed a trade bid package.</div></div>' for r in rows)
    return shell("Bid Packages",'<div class="hero"><h1>Bid Package Brain</h1><p class="muted">Clean Blueprint Brain scope becomes the foundation of each subcontractor bid package.</p></div><div class="card">'+(h or '<p class="muted">Analyze project documents first.</p>')+'</div>')


@app.get("/preconstruction/leveling",response_class=HTMLResponse)
def v44_leveling_page():
    _v44_ensure_tables()
    rows=_v39_rows("SELECT * FROM bid_proposals WHERE company_id=? AND project_id=? ORDER BY trade,base_bid",(current_company_id(),project_id()))
    h="".join(f'<div class="action"><span class="badge {"READY" if float(r["scope_coverage"] or 0)>=90 else "WATCH"}">{float(r["scope_coverage"] or 0):g}% COVERAGE</span> <b>{esc(r["trade"])} - {esc(r["sub_name"])}</b><div class="small">Base ${float(r["base_bid"] or 0):,.0f} - Alternates ${float(r["alternates"] or 0):,.0f} - Allowances ${float(r["allowances"] or 0):,.0f} - Risk {float(r["risk_score"] or 0):g}</div><p><b>Exclusions:</b> {esc(r["exclusions"])}</p><p><b>Qualifications:</b> {esc(r["qualifications"])}</p></div>' for r in rows)
    return shell("Bid Leveling",'<div class="hero"><h1>Subcontractor Bid Leveling Brain</h1><p class="muted">Lowest number does not mean lowest risk. Compare scope coverage, exclusions, qualifications and price.</p></div><div class="card">'+(h or '<p class="muted">No subcontractor proposals loaded yet.</p>')+'</div>')


@app.get("/preconstruction/allowances",response_class=HTMLResponse)
def v44_allowance_page():
    rows=_v44_allowances(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">REVIEW</span> <b>{esc(r["trade"])}</b> - {esc(r["description"])}<div class="small">Allowance ${float(r["allowance"] or 0):,.0f} - {esc(r["source_ref"])}</div></div>' for r in rows)
    return shell("Allowances & Alternates",'<div class="hero"><h1>Allowances & Alternates Brain</h1><p class="muted">Keep uncertain money, owner-furnished items and alternates visible before final bid.</p></div><div class="card">'+(h or '<p class="muted">No allowance/alternate signals detected.</p>')+'</div>')


@app.get("/preconstruction/long-lead",response_class=HTMLResponse)
def v44_longlead_page():
    rows=_v44_long_leads(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["status"])}</span> <b>{esc(r["item"])}</b><div class="small">Required onsite {esc(r["required_on_site"])} - Promised {esc(r["promised_date"])} - {esc(r["vendor"])}</div></div>' for r in rows)
    return shell("Long Lead",'<div class="hero"><h1>Long-Lead / Schedule Risk Brain</h1><p class="muted">Preconstruction should identify procurement threats before the baseline schedule is committed.</p></div><div class="card">'+(h or '<p class="muted">No long-lead procurement items loaded yet.</p>')+'</div>')


@app.get("/preconstruction/risk",response_class=HTMLResponse)
def v44_risk_page():
    r=_v44_precon_risk(project_id())
    body=f'<div class="hero"><h1>Preconstruction Risk Brain</h1><p class="muted">{r["level"]} risk - Score {r["score"]}/100.</p></div><div class="grid4"><div class="card"><div class="label">Uncovered Trades</div><div class="kpi">{r["uncovered"]}</div></div><div class="card"><div class="label">Scope Review</div><div class="kpi">{r["gaps"]}</div></div><div class="card"><div class="label">Unverified Estimate</div><div class="kpi">{r["unverified"]}</div></div><div class="card"><div class="label">Long-Lead Signals</div><div class="kpi">{r["longleads"]}</div></div></div>'
    return shell("Preconstruction Risk",body)


def _v442_normalize_existing_blueprint(pid):
    """
    Normalize saved Blueprint Brain items, delete excluded items,
    merge duplicate parent scopes, and rebuild every displayed scope boiler
    from the corrected child items.
    """
    company=current_company_id()
    c=db()

    items=c.execute(
        "SELECT * FROM blueprint_scope_items WHERE company_id=? AND project_id=? ORDER BY run_id,id",
        (company,pid)
    ).fetchall()

    changed=0
    for item in items:
        req=str(item["requirement"] or "").strip()

        # Remove explicitly excluded generic scope notes.
        if _v442_exclude_scope_item(req):
            c.execute("DELETE FROM blueprint_scope_items WHERE id=?",(item["id"],))
            changed+=1
            continue

        proposed=_v33_normalize_trade(item["trade"])
        target=_v441_primary_trade(req, proposed)
        target=_v441_apply_approved_learning(pid, req, target)

        # Find/create canonical parent scope for this run.
        parent=c.execute(
            "SELECT * FROM blueprint_trade_scopes WHERE run_id=? AND company_id=? AND project_id=? AND trade=? LIMIT 1",
            (item["run_id"],company,pid,target)
        ).fetchone()

        if parent:
            target_id=parent["id"]
        else:
            div={
                "GC / General Contractor":"01","Demolition":"02","Concrete":"03","Roofing":"07",
                "Doors / Frames / Hardware":"08","Storefront / Glazing":"08",
                "Framing / Drywall":"09","Ceilings":"09","Flooring / Tile":"09",
                "Painting":"09","Toilet / Bath Accessories":"10","Specialties":"10",
                "Fire Sprinkler":"21","Plumbing":"22","HVAC / Mechanical":"23",
                "Controls":"23","Electrical":"26","Low Voltage":"27","Fire Alarm":"28"
            }.get(target,"")
            now=datetime.utcnow().isoformat()
            c.execute(
                "INSERT INTO blueprint_trade_scopes(company_id,project_id,run_id,trade,division,summary,scope_text,item_count,created) VALUES(?,?,?,?,?,?,?,?,?)",
                (company,pid,item["run_id"],target,div,
                 f"BuildCommand source-backed scope for {target}.","",0,now)
            )
            target_id=c.execute("SELECT last_insert_rowid() id").fetchone()["id"]

        if target != item["trade"] or target_id != item["trade_scope_id"]:
            c.execute(
                "UPDATE blueprint_scope_items SET trade=?,trade_scope_id=? WHERE id=? AND company_id=? AND project_id=?",
                (target,target_id,item["id"],company,pid)
            )
            changed+=1

    # Canonicalize duplicate parent names.
    scopes=c.execute(
        "SELECT * FROM blueprint_trade_scopes WHERE company_id=? AND project_id=? ORDER BY run_id,id",
        (company,pid)
    ).fetchall()

    for sc in scopes:
        canonical=_v33_normalize_trade(sc["trade"])
        if canonical != sc["trade"]:
            other=c.execute(
                "SELECT * FROM blueprint_trade_scopes WHERE run_id=? AND company_id=? AND project_id=? AND trade=? AND id<>? LIMIT 1",
                (sc["run_id"],company,pid,canonical,sc["id"])
            ).fetchone()
            if other:
                c.execute(
                    "UPDATE blueprint_scope_items SET trade_scope_id=?,trade=? WHERE trade_scope_id=?",
                    (other["id"],canonical,sc["id"])
                )
                c.execute("DELETE FROM blueprint_trade_scopes WHERE id=?",(sc["id"],))
            else:
                c.execute(
                    "UPDATE blueprint_trade_scopes SET trade=? WHERE id=?",
                    (canonical,sc["id"])
                )
                c.execute(
                    "UPDATE blueprint_scope_items SET trade=? WHERE trade_scope_id=?",
                    (canonical,sc["id"])
                )

    # REBUILD every scope boiler from corrected child items.
    scopes=c.execute(
        "SELECT * FROM blueprint_trade_scopes WHERE company_id=? AND project_id=? ORDER BY run_id,id",
        (company,pid)
    ).fetchall()

    for sc in scopes:
        children=c.execute(
            "SELECT * FROM blueprint_scope_items WHERE trade_scope_id=? AND company_id=? AND project_id=? ORDER BY id",
            (sc["id"],company,pid)
        ).fetchall()

        if not children:
            c.execute("DELETE FROM blueprint_trade_scopes WHERE id=?",(sc["id"],))
            continue

        lines=[]
        for i,ch in enumerate(children,1):
            refs=[]
            if ch["source_sheet"]: refs.append("Sheet "+str(ch["source_sheet"]))
            if ch["source_detail"]: refs.append("Detail "+str(ch["source_detail"]))
            if ch["source_spec"]: refs.append("Spec "+str(ch["source_spec"]))
            ref_txt=f" [{' · '.join(refs)}]" if refs else ""
            lines.append(f"{i}. {ch['requirement']}{ref_txt}")

        boiler="\n".join(lines)
        c.execute(
            "UPDATE blueprint_trade_scopes SET trade=?,summary=?,scope_text=?,item_count=? WHERE id=?",
            ( _v33_normalize_trade(sc["trade"]),
              f"BuildCommand source-backed scope for {_v33_normalize_trade(sc['trade'])}.",
              boiler,len(children),sc["id"])
        )

    c.commit(); c.close()
    return changed


@app.post("/blueprint-brain/final-cleanup")
def v442_run_final_cleanup():
    pid=project_id()
    _v442_normalize_existing_blueprint(pid)
    return RedirectResponse("/blueprint-brain",status_code=303)


def _v45_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"
    else:
        pk="INTEGER PRIMARY KEY"
    c.execute(f"""CREATE TABLE IF NOT EXISTS sequence_intelligence(
        id {pk},
        company_id BIGINT,
        project_id BIGINT,
        activity_id BIGINT,
        activity_name TEXT,
        activity_trade TEXT,
        sequence_stage INTEGER DEFAULT 0,
        readiness_status TEXT DEFAULT 'REVIEW',
        risk_level TEXT DEFAULT 'LOW',
        predecessor_summary TEXT DEFAULT '',
        blocking_reason TEXT DEFAULT '',
        downstream_impact TEXT DEFAULT '',
        recommended_action TEXT DEFAULT '',
        source_type TEXT DEFAULT 'SYSTEM',
        created TEXT,
        updated TEXT
    )""")
    c.commit(); c.close()


def _v45_stage_for_activity(name,trade):
    s=(str(name or "")+" "+str(trade or "")).lower()
    rules=[
        (10,("mobilization","survey","layout","erosion","swppp","clearing","site prep")),
        (20,("earthwork","excavat","grading","underground","site utilities","storm drain","sanitary sewer","water line")),
        (30,("footing","foundation","stem wall","grade beam","slab","concrete")),
        (40,("structural steel","masonry","cmu","tilt","framing","stud","sheathing")),
        (50,("roof","waterproof")),
        (60,("mep rough","rough-in","rough in","electrical rough","plumbing rough","hvac rough","duct rough","overhead mep","fire sprinkler rough","low voltage rough")),
        (70,("rough inspection","above ceiling inspection","in-wall inspection","in wall inspection","pressure test","rough test")),
        (80,("insulation","drywall","gypsum","gyp board","close wall")),
        (90,("ceiling grid","act ceiling","acoustical ceiling")),
        (100,("paint","flooring","tile","millwork","casework","doors","hardware","finish")),
        (110,("fixture","trim out","trim-out","device","startup","start-up","commission","test and balance","tab")),
        (120,("punch","final inspection","closeout","turnover")),
    ]
    for stage,terms in rules:
        if any(term in s for term in terms):
            return stage
    return 65 if any(x in s for x in ("electrical","plumbing","hvac","mechanical","sprinkler","low voltage")) else 50


def _v45_gate_requirements(stage):
    gates=[]
    if stage>=30:
        gates.append("survey/layout and below-grade prerequisites complete")
    if stage>=40:
        gates.append("foundation/slab prerequisites complete where applicable")
    if stage>=60:
        gates.append("framing/supporting construction ready")
    if stage>=80:
        gates.append("MEP rough-in complete")
        gates.append("required rough inspections/testing passed")
    if stage>=90:
        gates.append("above-ceiling work coordinated and inspected")
    if stage>=100:
        gates.append("substrates and predecessor finishes ready")
    if stage>=110:
        gates.append("equipment/material available and approved")
    if stage>=120:
        gates.append("punch/testing/final documentation progressing")
    return gates


def _v45_sequence_analysis_uncached(pid):
    _v45_ensure_tables()
    today=datetime.utcnow().date()
    acts=_v39_rows("SELECT * FROM activities WHERE project_id=? ORDER BY start,id",(pid,))
    readiness={}
    for r in _v39_rows("SELECT * FROM activity_readiness WHERE project_id=?",(pid,)):
        readiness[int(r["activity_id"])]=r
    inspections=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=?",(pid,))
    procurement=_v39_rows("SELECT * FROM procurement WHERE project_id=?",(pid,))
    submittals=_v39_rows("SELECT * FROM submittals WHERE project_id=?",(pid,))
    issues=_v39_rows("SELECT * FROM project_issues WHERE project_id=? AND COALESCE(status,'OPEN')!='CLOSED'",(pid,))

    analyzed=[]
    prior=[]
    for a in acts:
        stage=_v45_stage_for_activity(a["name"],a["trade"])
        start=_v39_safe_date(a["start"]); finish=_v39_safe_date(a["finish"])
        pct=float(a["pct"] or 0)
        status=str(a["status"] or "NOT_STARTED").upper()
        reasons=[]
        risk="LOW"

        earlier=[p for p in prior if p["stage"] < stage and p["status"]!="COMPLETE"]
        immediate=sorted(earlier,key=lambda x:x["stage"],reverse=True)[:3]
        if immediate and (status=="IN_PROGRESS" or pct>0):
            reasons.append("Work appears started while earlier-stage activities remain incomplete.")
            risk="HIGH"

        rd=readiness.get(int(a["id"]))
        if rd:
            missing=[]
            labels=[("drawings","drawings"),("material","materials"),("manpower","manpower"),
                    ("predecessor","predecessors"),("access_ready","access"),
                    ("inspection","inspection gate"),("equipment","equipment")]
            for col,label in labels:
                if int(rd[col] or 0)!=1:
                    missing.append(label)
            if missing and start and start<=today+timedelta(days=7):
                reasons.append("Make-ready incomplete: "+", ".join(missing)+".")
                risk="CRITICAL" if start and start<=today else "HIGH"

        pending_insp=[i for i in inspections if i["activity_id"]==a["id"] and str(i["result"] or "PENDING").upper() not in {"PASSED","COMPLETE"}]
        if pending_insp and stage>=80:
            reasons.append(f"{len(pending_insp)} inspection gate(s) remain open before concealment/finish work.")
            risk="CRITICAL" if status=="IN_PROGRESS" or pct>0 else "HIGH"

        late_material=[]
        for p in procurement:
            if p["activity_id"]==a["id"]:
                need=_v39_safe_date(p["required_on_site"]); promised=_v39_safe_date(p["promised_date"])
                if need and promised and promised>need:
                    late_material.append(p)
        if late_material:
            reasons.append(f"{len(late_material)} procurement item(s) are promised after required-on-site date.")
            risk="CRITICAL" if risk=="HIGH" else "HIGH"

        open_subs=[s for s in submittals if s["activity_id"]==a["id"] and str(s["status"] or "PENDING").upper() not in {"APPROVED","COMPLETE","CLOSED"}]
        if open_subs and start and start<=today+timedelta(days=14):
            reasons.append(f"{len(open_subs)} submittal approval(s) remain open before planned start.")
            if risk=="LOW": risk="HIGH"

        open_issues=[i for i in issues if i["activity_id"]==a["id"]]
        if open_issues:
            reasons.append(f"{len(open_issues)} open issue(s) are tied to this activity.")
            if risk=="LOW": risk="MEDIUM"

        if finish and finish<today and pct<100:
            reasons.append("Activity is past its planned finish date.")
            risk="CRITICAL"

        readiness_status="READY" if not reasons else "NOT READY" if risk=="CRITICAL" else "AT RISK"
        gates=_v45_gate_requirements(stage)
        predecessor_summary="; ".join(gates)
        blocking_reason=" ".join(reasons)
        downstream=(
            "Downstream work may be delayed or forced out of sequence."
            if reasons else
            "No current sequence exception detected from available project data."
        )
        recommendation=(
            "Resolve blocking prerequisites before releasing downstream work."
            if reasons else
            "Maintain planned sequence and continue make-ready verification."
        )
        analyzed.append({
            "activity":a,"stage":stage,"status":status,"risk":risk,
            "readiness":readiness_status,"predecessor_summary":predecessor_summary,
            "blocking_reason":blocking_reason,"downstream":downstream,"recommendation":recommendation
        })
        prior.append({"stage":stage,"status":status,"name":a["name"]})

    # Persist latest intelligence snapshot.
    c=db()
    c.execute("DELETE FROM sequence_intelligence WHERE company_id=? AND project_id=?",(current_company_id(),pid))
    now=datetime.utcnow().isoformat()
    for x in analyzed:
        a=x["activity"]
        c.execute("""INSERT INTO sequence_intelligence(
            company_id,project_id,activity_id,activity_name,activity_trade,sequence_stage,
            readiness_status,risk_level,predecessor_summary,blocking_reason,downstream_impact,
            recommended_action,source_type,created,updated
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(
            current_company_id(),pid,a["id"],a["name"],a["trade"],x["stage"],
            x["readiness"],x["risk"],x["predecessor_summary"],x["blocking_reason"],
            x["downstream"],x["recommendation"],"SYSTEM",now,now
        ))
    c.commit(); c.close()
    return analyzed


def _v45_sequence_analysis(pid):
    return _v56_sequence(pid)


@app.get("/sequence-intelligence",response_class=HTMLResponse)
def v45_sequence_home():
    pid=project_id()
    rows=_v45_sequence_analysis(pid)
    critical=sum(1 for x in rows if x["risk"]=="CRITICAL")
    high=sum(1 for x in rows if x["risk"]=="HIGH")
    medium=sum(1 for x in rows if x["risk"]=="MEDIUM")
    ready=sum(1 for x in rows if x["readiness"]=="READY")
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v45 - Sequence Intelligence</div><h1>Build in the right order.</h1><p class="muted">{critical} critical - {high} high - {medium} medium sequence risks - {ready}/{len(rows)} activities currently ready from available data.</p></div>'
    body+='<div class="grid3">'
    body+=_v37_link_card("Sequence Exceptions","Activities that are late, blocked or out of order.","/sequence-intelligence/exceptions","Review")
    body+=_v37_link_card("Inspection Gates","See inspection/testing gates before concealment and finishes.","/sequence-intelligence/inspection-gates","Review")
    body+=_v37_link_card("Downstream Impact","See which activities can push following work.","/sequence-intelligence/downstream","Review")
    body+='</div><div class="card"><h2>Sequence Map</h2>'
    for x in rows:
        a=x["activity"]
        body+=f'<div class="action"><span class="badge {"READY" if x["readiness"]=="READY" else "WATCH"}">{esc(x["readiness"])}</span> <b>{esc(a["name"])}</b><div class="small">Stage {x["stage"]} - {esc(a["trade"])} - {esc(a["start"])} to {esc(a["finish"])} - Risk {esc(x["risk"])}</div><p>{esc(x["blocking_reason"] or "No current sequence exception.")}</p></div>'
    body+='</div>'
    return shell("Sequence Intelligence",body)


@app.get("/sequence-intelligence/exceptions",response_class=HTMLResponse)
def v45_sequence_exceptions():
    rows=_v45_sequence_analysis(project_id())
    rows=[x for x in rows if x["readiness"]!="READY"]
    h="".join(
        f'<div class="action"><span class="badge WATCH">{esc(x["risk"])}</span> <b>{esc(x["activity"]["name"])}</b>'
        f'<div class="small">{esc(x["activity"]["trade"])} - Stage {x["stage"]}</div>'
        f'<p>{esc(x["blocking_reason"])}</p><p><b>Recommended:</b> {esc(x["recommendation"])}</p></div>'
        for x in rows
    )
    return shell("Sequence Exceptions",'<div class="hero"><h1>Sequence Exceptions</h1><p class="muted">Only activities with a detected sequencing or readiness problem appear here.</p></div><div class="card">'+(h or '<p class="muted">No current sequence exceptions detected.</p>')+'</div>')


@app.get("/sequence-intelligence/inspection-gates",response_class=HTMLResponse)
def v45_inspection_gates():
    pid=project_id()
    rows=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? ORDER BY scheduled_date,id",(pid,))
    h="".join(
        f'<div class="action"><span class="badge {"READY" if str(r["result"] or "").upper()=="PASSED" else "WATCH"}">{esc(r["result"])}</span> '
        f'<b>{esc(r["inspection_type"])}</b><div class="small">{esc(r["scheduled_date"])} - {esc(r["authority"])}</div></div>'
        for r in rows
    )
    return shell("Inspection Gates",'<div class="hero"><h1>Inspection & Testing Gates</h1><p class="muted">Sequence Intelligence treats required inspections as gates before concealment and downstream finish work.</p></div><div class="card">'+(h or '<p class="muted">No inspection gates loaded.</p>')+'</div>')


@app.get("/sequence-intelligence/downstream",response_class=HTMLResponse)
def v45_downstream():
    rows=_v45_sequence_analysis(project_id())
    risky=[x for x in rows if x["risk"] in {"CRITICAL","HIGH"}]
    h="".join(
        f'<div class="action"><span class="badge WATCH">{esc(x["risk"])}</span> <b>{esc(x["activity"]["name"])}</b>'
        f'<p>{esc(x["downstream"])}</p><div class="small">Prerequisite model: {esc(x["predecessor_summary"])}</div></div>'
        for x in risky
    )
    return shell("Downstream Impact",'<div class="hero"><h1>Downstream Sequence Impact</h1><p class="muted">Shows high-risk activities that can force later work out of sequence.</p></div><div class="card">'+(h or '<p class="muted">No high downstream sequence exposure detected.</p>')+'</div>')


def _v452_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS constructability_findings(
        id {pk},company_id BIGINT,project_id BIGINT,finding_type TEXT,title TEXT,
        description TEXT,trade TEXT,related_trade TEXT,source_ref TEXT,
        severity TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'OPEN',
        recommended_action TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS scope_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,intelligence_type TEXT,
        trade TEXT,related_trade TEXT,requirement TEXT,source_ref TEXT,
        severity TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'OPEN',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS procurement_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,procurement_id BIGINT,
        item TEXT,risk_level TEXT,days_exposure INTEGER DEFAULT 0,
        reason TEXT,recommended_action TEXT,created TEXT,updated TEXT)"""
    ]
    for s in stmts: c.execute(s)
    c.commit(); c.close()


def _v452_scope_rows(pid):
    return _v39_rows("""
        SELECT * FROM blueprint_scope_items
        WHERE company_id=? AND project_id=?
        ORDER BY run_id,trade,id
    """,(current_company_id(),pid))


def _v452_constructability(pid):
    rows=_v452_scope_rows(pid)
    findings=[]
    patterns=[
      ("ACCESS","Equipment/service access",
       ("access","clearance","service space","maintenance access","working clearance"),
       "Verify physical access, service clearance, and installation path before release."),
      ("PENETRATION","Penetration / support coordination",
       ("penetration","core drill","sleeve","opening","curb","blocking","backing","support"),
       "Coordinate opening/support responsibility and verify structural/finish impact."),
      ("CEILING","Above-ceiling congestion",
       ("ceiling","diffuser","sprinkler","light fixture","duct","above ceiling"),
       "Coordinate ceiling layout and above-ceiling systems before grid/closure."),
      ("ADA","Accessibility / clearance",
       ("ada","accessible","grab bar","clear floor","maneuvering clearance"),
       "Verify dimensions and mounting requirements against accessibility details."),
      ("ROOF","Roof penetration coordination",
       ("roof penetration","roof curb","roof flashing","roof patch"),
       "Coordinate equipment, curb, flashing and roofing responsibility before installation."),
    ]
    seen=set()
    for r in rows:
        text=(str(r["requirement"] or "")+" "+str(r["source_note"] or "")).lower()
        for typ,title,terms,action in patterns:
            if any(term in text for term in terms):
                key=(typ,r["requirement"])
                if key in seen: continue
                seen.add(key)
                severity="HIGH" if typ in {"ACCESS","PENETRATION","ROOF"} else "REVIEW"
                findings.append({
                    "type":typ,"title":title,"description":r["requirement"],
                    "trade":r["trade"],"related":r["related_trade"] or "",
                    "source":" · ".join(x for x in [r["source_sheet"],r["source_detail"],r["source_spec"]] if x),
                    "severity":severity,"action":action
                })
    return findings[:150]


def _v452_conflicts(pid):
    rows=_v452_scope_rows(pid)
    by_req={}
    for r in rows:
        key=re.sub(r'\s+',' ',str(r["requirement"] or "").lower()).strip()
        if not key: continue
        by_req.setdefault(key,[]).append(r)
    out=[]
    for req,items in by_req.items():
        trades=sorted(set(str(x["trade"] or "") for x in items))
        if len(trades)>1:
            out.append((items[0]["requirement"],trades,items[0]["source_sheet"] or ""))
    return out[:100]


def _v452_scope_gaps(pid):
    rows=_v452_scope_rows(pid)
    out=[]
    for r in rows:
        trade=str(r["trade"] or "").strip()
        conf=str(r["confidence"] or "MEDIUM").upper()
        if trade in {"","Unassigned"} or conf=="LOW":
            out.append(r)
    return out[:150]


def _v452_scope_overlaps(pid):
    return _v452_conflicts(pid)


def _v452_change_exposure(pid):
    conflicts=_v452_conflicts(pid)
    rfis=_v42_rfis(pid)
    changes=_v39_changes(pid)
    return conflicts,rfis,changes


def _v452_procurement_analysis(pid):
    rows=_v39_rows("SELECT * FROM procurement WHERE project_id=? AND COALESCE(status,'OPEN') NOT IN ('DELIVERED','COMPLETE','CLOSED') ORDER BY required_on_site",(pid,))
    today=datetime.utcnow().date()
    out=[]
    for r in rows:
        need=_v39_safe_date(r["required_on_site"])
        promised=_v39_safe_date(r["promised_date"])
        exposure=(promised-need).days if need and promised else 0
        if exposure>=7: level="CRITICAL"
        elif exposure>0: level="HIGH"
        elif need and need<=today: level="TODAY"
        else: level="WATCH"
        reason=(f"Promised date is {exposure} day(s) after required-on-site date." if exposure>0
                else "Required-on-site timing requires monitoring.")
        action=("Escalate vendor/submittal/fabrication plan and evaluate schedule recovery."
                if exposure>0 else "Confirm fabrication, shipping and delivery status.")
        out.append((r,level,exposure,reason,action))
    return out


def _v452_inspection_derived(pid):
    scopes=_v452_scope_rows(pid)
    inspections=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=?",(pid,))
    existing=" ".join(str(i["inspection_type"] or "").lower() for i in inspections)
    candidates=[]
    mapping=[
      ("Concrete",("concrete","footing","slab","rebar"),"Concrete / reinforcing inspection"),
      ("Framing / Drywall",("framing","stud","drywall","gypsum"),"Framing / in-wall inspection"),
      ("Electrical",("electrical","conduit","branch circuit"),"Electrical rough inspection"),
      ("Plumbing",("plumbing","sanitary","domestic water"),"Plumbing rough / pressure test"),
      ("HVAC / Mechanical",("duct","hvac","mechanical"),"Mechanical rough inspection"),
      ("Fire Sprinkler",("sprinkler","fire suppression"),"Fire sprinkler inspection / test"),
      ("Roofing",("roof","roofing"),"Roofing / waterproofing inspection"),
    ]
    corpus=" ".join(str(r["requirement"] or "").lower() for r in scopes)
    for trade,terms,name in mapping:
        if any(term in corpus for term in terms) and name.lower() not in existing:
            candidates.append((trade,name,"Derived from analyzed project scope; verify with AHJ/project requirements."))
    return candidates


def _v452_learning_context(pid):
    _v43_ensure_tables()
    rules=_v39_rows("""
        SELECT * FROM learning_rules
        WHERE company_id=? AND approval_status='APPROVED'
          AND (project_id=? OR scope_level='COMPANY STANDARD')
        ORDER BY CASE WHEN project_id=? THEN 0 ELSE 1 END,id DESC
        LIMIT 200
    """,(current_company_id(),pid,pid))
    return rules


def _v452_command(pid):
    sequence=_v45_sequence_analysis(pid)
    attention=_v39_attention(pid)
    proc=_v452_procurement_analysis(pid)
    conflicts=_v452_conflicts(pid)
    gaps=_v452_scope_gaps(pid)
    inspection_candidates=_v452_inspection_derived(pid)

    critical_sequence=[x for x in sequence if x["risk"]=="CRITICAL"]
    high_sequence=[x for x in sequence if x["risk"]=="HIGH"]
    critical_proc=[x for x in proc if x[1]=="CRITICAL"]
    top=[]
    for x in critical_sequence[:3]:
        top.append(("CRITICAL","Sequence",x["activity"]["name"],x["blocking_reason"]))
    for x in critical_proc[:3]:
        top.append(("CRITICAL","Procurement",x[0]["item"],x[3]))
    for x in attention[:4]:
        top.append((x[0],x[1],x[2],x[3]))
    for req,trades,source in conflicts[:3]:
        top.append(("REVIEW","Conflict",req,f"Assigned across {', '.join(trades)}"))
    return {
        "top":top[:10],
        "sequence_critical":len(critical_sequence),
        "sequence_high":len(high_sequence),
        "proc_critical":len(critical_proc),
        "conflicts":len(conflicts),
        "gaps":len(gaps),
        "inspection_candidates":len(inspection_candidates)
    }


@app.get("/intelligence-engine",response_class=HTMLResponse)
def v452_intelligence_engine():
    pid=project_id()
    construct=_v452_constructability(pid)
    conflicts=_v452_conflicts(pid)
    gaps=_v452_scope_gaps(pid)
    proc=_v452_procurement_analysis(pid)
    inspections=_v452_inspection_derived(pid)
    learning=_v452_learning_context(pid)
    command=_v452_command(pid)

    body=f'<div class="hero"><div class="eyebrow">BuildCommand v45.2 - Intelligence Engine</div><h1>Think across the whole project.</h1><p class="muted">{len(construct)} constructability signals - {len(conflicts)} conflicts/overlaps - {len(gaps)} scope gaps - {len(proc)} procurement items - {len(inspections)} derived inspection candidates - {len(learning)} approved learning rules.</p></div><div class="grid3">'
    cards=[
      ("Constructability Intelligence","Find access, clearance, penetration, ceiling and coordination risks.","/intelligence-engine/constructability"),
      ("Conflict Intelligence","Find contradictory/duplicate ownership across project scope.","/intelligence-engine/conflicts"),
      ("Automatic RFI Brain","Draft RFI candidates from confirmed conflicts. Human approval required.","/intelligence-engine/rfis"),
      ("Scope Gap Intelligence","Find low-confidence or unassigned scope before award.","/intelligence-engine/gaps"),
      ("Scope Overlap Intelligence","Detect duplicate ownership and coordination overlap.","/intelligence-engine/overlaps"),
      ("Change-Order Intelligence","Connect conflicts, RFIs and open changes to exposure.","/intelligence-engine/change-exposure"),
      ("Procurement Intelligence","Connect promised dates to required-on-site risk.","/intelligence-engine/procurement"),
      ("Inspection Intelligence 2.0","Derive likely inspection/testing gates from project scope.","/intelligence-engine/inspections"),
      ("Approved Learning Context","See what company/project knowledge is influencing the brain.","/intelligence-engine/learning"),
      ("Superintendent Command Intelligence","One prioritized view of what can hurt the job now.","/intelligence-engine/command")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Intelligence Engine",body)


@app.get("/intelligence-engine/constructability",response_class=HTMLResponse)
def v452_constructability_page():
    rows=_v452_constructability(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(r["severity"])}</span> <b>{esc(r["title"])}</b><div>{esc(r["description"])}</div><div class="small">{esc(r["trade"])} {("· "+esc(r["related"])) if r["related"] else ""} · {esc(r["source"])}</div><p><b>Check:</b> {esc(r["action"])}</p></div>' for r in rows)
    return shell("Constructability Intelligence",'<div class="hero"><h1>Constructability Intelligence</h1><p class="muted">Signals for things that may not coordinate, fit, or remain accessible. These are review prompts, not automatic design decisions.</p></div><div class="card">'+(h or '<p class="muted">No constructability signals detected from current scope.</p>')+'</div>')


@app.get("/intelligence-engine/conflicts",response_class=HTMLResponse)
def v452_conflict_page():
    rows=_v452_conflicts(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">CONFLICT</span> <b>{esc(req)}</b><div class="small">Trades: {esc(", ".join(trades))} · {esc(source)}</div></div>' for req,trades,source in rows)
    return shell("Conflict Intelligence",'<div class="hero"><h1>Conflict Intelligence</h1><p class="muted">Finds identical requirements assigned to multiple trades for review.</p></div><div class="card">'+(h or '<p class="muted">No duplicate cross-trade requirements detected.</p>')+'</div>')


@app.get("/intelligence-engine/rfis",response_class=HTMLResponse)
def v452_rfi_brain():
    rows=_v452_conflicts(project_id())
    h=""
    for i,(req,trades,source) in enumerate(rows,1):
        h+=f'<div class="card"><span class="badge WATCH">DRAFT RFI</span><h3>RFI Candidate {i}: {esc(req)}</h3><p><b>Question:</b> Please clarify the governing trade responsibility and document requirement for this item.</p><p><b>Detected trades:</b> {esc(", ".join(trades))}</p><p><b>Source:</b> {esc(source)}</p><p class="small">Proposal only. Human approval required before issue.</p></div>'
    return shell("Automatic RFI Brain",'<div class="hero"><h1>Automatic RFI Brain</h1><p class="muted">Turns conflicts into reviewable RFI drafts without sending anything automatically.</p></div>'+(h or '<div class="card">No RFI candidates detected.</div>'))


@app.get("/intelligence-engine/gaps",response_class=HTMLResponse)
def v452_gap_page():
    rows=_v452_scope_gaps(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">GAP / REVIEW</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Confidence {esc(r["confidence"])} · {esc(r["source_sheet"])}</div></div>' for r in rows)
    return shell("Scope Gap Intelligence",'<div class="hero"><h1>Scope Gap Intelligence</h1><p class="muted">Find scope with weak or missing ownership before it becomes a field problem.</p></div><div class="card">'+(h or '<p class="muted">No obvious low-confidence/unassigned scope detected.</p>')+'</div>')


@app.get("/intelligence-engine/overlaps",response_class=HTMLResponse)
def v452_overlap_page():
    rows=_v452_scope_overlaps(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">OVERLAP</span> <b>{esc(req)}</b><div class="small">{esc(" / ".join(trades))}</div></div>' for req,trades,source in rows)
    return shell("Scope Overlap Intelligence",'<div class="hero"><h1>Scope Overlap Intelligence</h1><p class="muted">Separates true coordination interfaces from accidental duplicate ownership.</p></div><div class="card">'+(h or '<p class="muted">No current duplicate ownership detected.</p>')+'</div>')


@app.get("/intelligence-engine/change-exposure",response_class=HTMLResponse)
def v452_change_page():
    conflicts,rfis,changes=_v452_change_exposure(project_id())
    total=sum(float(r["estimated_cost"] or 0) for r in changes)
    days=sum(float(r["schedule_days"] or 0) for r in changes)
    body=f'<div class="hero"><h1>Change-Order Intelligence</h1><p class="muted">{len(conflicts)} scope conflicts · {len(rfis)} controlled RFIs · {len(changes)} open changes · ${total:,.0f} known exposure · {days:g} schedule days.</p></div>'
    body+='<div class="card"><p>Use conflicts and RFIs as early warning signals. Human review determines whether any item is truly extra-contract work.</p></div>'
    return shell("Change-Order Intelligence",body)


@app.get("/intelligence-engine/procurement",response_class=HTMLResponse)
def v452_procurement_page():
    rows=_v452_procurement_analysis(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(r["item"])}</b><div class="small">Need {esc(r["required_on_site"])} · Promised {esc(r["promised_date"])} · Exposure {exposure} day(s)</div><p>{esc(reason)}</p><p><b>Action:</b> {esc(action)}</p></div>' for r,level,exposure,reason,action in rows)
    return shell("Procurement Intelligence",'<div class="hero"><h1>Procurement Intelligence</h1><p class="muted">Connects required-on-site timing to delivery exposure.</p></div><div class="card">'+(h or '<p class="muted">No open procurement items.</p>')+'</div>')


@app.get("/intelligence-engine/inspections",response_class=HTMLResponse)
def v452_inspection_page():
    candidates=_v452_inspection_derived(project_id())
    existing=_v39_rows("SELECT * FROM inspections_tracker WHERE project_id=? ORDER BY scheduled_date,id",(project_id(),))
    h="".join(f'<div class="action"><span class="badge WATCH">DERIVED</span> <b>{esc(name)}</b><div class="small">{esc(trade)}</div><p>{esc(note)}</p></div>' for trade,name,note in candidates)
    eh="".join(f'<div class="action"><span class="badge">{esc(r["result"])}</span> <b>{esc(r["inspection_type"])}</b><div class="small">{esc(r["scheduled_date"])} · {esc(r["authority"])}</div></div>' for r in existing)
    return shell("Inspection Intelligence 2.0",'<div class="hero"><h1>Inspection Intelligence 2.0</h1><p class="muted">Derives likely inspection/testing gates from actual scope. AHJ/project requirements still govern.</p></div><div class="card"><h2>Derived Candidates</h2>'+(h or '<p class="muted">No new inspection candidates.</p>')+'</div><div class="card"><h2>Tracked Inspections</h2>'+(eh or '<p class="muted">No tracked inspections.</p>')+'</div>')


@app.get("/intelligence-engine/learning",response_class=HTMLResponse)
def v452_learning_page():
    rows=_v452_learning_context(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(r["scope_level"])}</span> <b>{esc(r["rule_type"])} - {esc(r["subject"])}</b><div>{esc(r["learned_rule"])}</div><div class="small">Approved by {esc(r["approved_by"])}</div></div>' for r in rows)
    return shell("Approved Learning Context",'<div class="hero"><h1>Approved Learning Context</h1><p class="muted">Only approved project/company rules influence automated ownership logic.</p></div><div class="card">'+(h or '<p class="muted">No approved learning rules yet.</p>')+'</div>')


@app.get("/intelligence-engine/command",response_class=HTMLResponse)
def v452_command_page():
    d=_v452_command(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(kind)}</b> - {esc(title)}<div class="small">{esc(detail)}</div></div>' for level,kind,title,detail in d["top"])
    body=f'<div class="hero"><div class="eyebrow">Superintendent Command Intelligence</div><h1>What can hurt the job now?</h1><p class="muted">{d["sequence_critical"]} critical sequence · {d["sequence_high"]} high sequence · {d["proc_critical"]} critical procurement · {d["conflicts"]} conflicts · {d["gaps"]} scope gaps · {d["inspection_candidates"]} derived inspection candidates.</p></div><div class="card"><h2>Top Priorities</h2>{h or "<p class=muted>No major current intelligence exceptions.</p>"}</div>'
    return shell("Superintendent Command Intelligence",body)


def _v46_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS knowledge_nodes(
        id {pk},company_id BIGINT,project_id BIGINT,node_type TEXT,node_key TEXT,
        label TEXT,trade TEXT,source_ref TEXT,status TEXT DEFAULT 'ACTIVE',
        confidence TEXT DEFAULT 'MEDIUM',metadata TEXT DEFAULT '',created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS knowledge_edges(
        id {pk},company_id BIGINT,project_id BIGINT,from_key TEXT,to_key TEXT,
        relationship TEXT,source_ref TEXT,confidence TEXT DEFAULT 'MEDIUM',
        status TEXT DEFAULT 'ACTIVE',created TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS revision_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,new_attachment_id BIGINT,
        prior_attachment_id BIGINT,revision_group TEXT,change_summary TEXT,
        affected_trades TEXT,cost_risk TEXT DEFAULT 'REVIEW',
        schedule_risk TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'REVIEW',
        created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS equipment_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,equipment_key TEXT,equipment_name TEXT,
        furnish_trade TEXT,install_trade TEXT,power_trade TEXT,controls_trade TEXT,
        plumbing_trade TEXT,support_trade TEXT,roofing_trade TEXT,startup_trade TEXT,
        source_ref TEXT,status TEXT DEFAULT 'REVIEW',created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS verification_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,subject_type TEXT,subject_key TEXT,
        primary_conclusion TEXT,verification_conclusion TEXT,agreement TEXT DEFAULT 'REVIEW',
        confidence TEXT DEFAULT 'MEDIUM',reason TEXT,source_ref TEXT,created TEXT,updated TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v46_docs(pid):
    return _v39_rows("SELECT * FROM attachments WHERE company_id=? AND project_id=? ORDER BY id DESC",(current_company_id(),pid))


def _v46_revision_pairs(pid):
    rows=_v46_docs(pid)
    groups={}
    for r in rows:
        name=str(r["original_name"] or "")
        base=re.sub(r'(?i)(rev(?:ision)?[\s_-]*[A-Z0-9]+|addendum[\s_-]*[A-Z0-9]+|bulletin[\s_-]*[A-Z0-9]+)','',name)
        base=re.sub(r'[^a-z0-9]+',' ',base.lower()).strip()
        groups.setdefault(base,[]).append(r)
    pairs=[]
    for base,items in groups.items():
        if len(items)>1:
            items=sorted(items,key=lambda x:x["id"],reverse=True)
            for i in range(len(items)-1):
                pairs.append((items[i],items[i+1],base))
    return pairs[:50]


def _v46_dependencies(pid):
    scopes=_v452_scope_rows(pid)
    out=[]
    for r in scopes:
        req=str(r["requirement"] or "")
        trade=str(r["trade"] or "")
        related=set()
        low=req.lower()
        if any(x in low for x in ["power","disconnect","electrical connection","branch circuit"]):
            related.add("Electrical")
        if any(x in low for x in ["roof curb","roof flashing","roof patch","roof penetration"]):
            related.add("Roofing")
        if any(x in low for x in ["thermostat","controls","control wiring"]):
            related.add("Controls")
        if any(x in low for x in ["water","drain","condensate","piping","valve"]):
            related.add("Plumbing")
        if any(x in low for x in ["duct","diffuser","grille","rtu","ahu","exhaust fan"]):
            related.add("HVAC / Mechanical")
        if any(x in low for x in ["blocking","backing","support framing","rough opening"]):
            related.add("Framing / Drywall")
        if any(x in low for x in ["storefront","glazing","curtain wall"]):
            related.add("Storefront / Glazing")
        if any(x in low for x in ["door operator","access control","card reader","electronic strike"]):
            related.add("Low Voltage")
        related.discard(trade)
        if related:
            out.append((r,sorted(related)))
    return out[:200]


def _v46_spec_drawing_checks(pid):
    rows=_v452_scope_rows(pid)
    out=[]
    for r in rows:
        has_drawing=bool(r["source_sheet"] or r["source_detail"])
        has_spec=bool(r["source_spec"])
        if has_drawing != has_spec:
            out.append((r,"DRAWING ONLY" if has_drawing else "SPEC ONLY"))
    return out[:150]


def _v46_equipment(pid):
    rows=_v452_scope_rows(pid)
    eq=[]
    patterns=[
        ("WH","water heater","Plumbing"),
        ("RTU","rooftop unit","HVAC / Mechanical"),
        ("AHU","air handler","HVAC / Mechanical"),
        ("EF","exhaust fan","HVAC / Mechanical"),
        ("VAV","vav","HVAC / Mechanical"),
        ("PUMP","pump","Plumbing"),
        ("PANEL","panelboard","Electrical"),
        ("XFMR","transformer","Electrical"),
    ]
    seen=set()
    for r in rows:
        low=str(r["requirement"] or "").lower()
        for prefix,term,primary in patterns:
            if term in low:
                key=f"{prefix}:{re.sub(r'[^a-z0-9]+','-',low[:80]).strip('-')}"
                if key in seen: continue
                seen.add(key)
                eq.append({
                    "key":key,"name":r["requirement"],"primary":primary,
                    "source":" · ".join(x for x in [r["source_sheet"],r["source_detail"],r["source_spec"]] if x),
                    "power":"Electrical" if primary!="Electrical" else "",
                    "controls":"Controls" if primary=="HVAC / Mechanical" else "",
                    "plumbing":"Plumbing" if primary in {"HVAC / Mechanical","Plumbing"} else "",
                    "support":"Framing / Drywall" if any(x in low for x in ["wall mounted","supported","curb","hung"]) else "",
                    "roof":"Roofing" if any(x in low for x in ["roof","rooftop","curb"]) else "",
                    "startup":primary
                })
    return eq[:100]


def _v46_schedule_prediction(pid):
    seq=_v45_sequence_analysis(pid)
    proc=_v452_procurement_analysis(pid)
    out=[]
    for x in seq:
        risk=x["risk"]
        if risk in {"CRITICAL","HIGH"}:
            out.append((risk,x["activity"]["name"],x["blocking_reason"],"Sequence / readiness"))
    for r,level,exposure,reason,action in proc:
        if level in {"CRITICAL","HIGH"}:
            out.append((level,r["item"],reason,"Procurement"))
    return out[:100]


def _v46_cost_risk(pid):
    conflicts=_v452_conflicts(pid)
    gaps=_v452_scope_gaps(pid)
    changes=_v39_changes(pid)
    out=[]
    for req,trades,source in conflicts:
        out.append(("HIGH","Conflict",req,f"Multiple trade ownership: {', '.join(trades)}",source))
    for r in gaps:
        out.append(("MEDIUM","Scope Gap",r["requirement"],f"Trade {r['trade']} / confidence {r['confidence']}",r["source_sheet"] or ""))
    for r in changes:
        if float(r["estimated_cost"] or 0)>0:
            out.append(("HIGH","Open Change",r["title"],f"${float(r['estimated_cost'] or 0):,.0f} exposure",""))
    return out[:100]


def _v46_plan_completeness(pid):
    rows=_v452_scope_rows(pid)
    findings=[]
    for r in rows:
        if not r["source_sheet"] and not r["source_spec"]:
            findings.append(("SOURCE","Missing source reference",r["requirement"],r["trade"]))
        if str(r["confidence"] or "").upper()=="LOW":
            findings.append(("CONFIDENCE","Low-confidence requirement",r["requirement"],r["trade"]))
        low=str(r["requirement"] or "").lower()
        if any(x in low for x in ["verify","confirm","coordinate","as required","where required"]) and str(r["confidence"] or "").upper()!="HIGH":
            findings.append(("AMBIGUITY","Open-ended requirement",r["requirement"],r["trade"]))
    return findings[:150]


def _v46_second_opinion(pid):
    rows=_v452_scope_rows(pid)
    out=[]
    for r in rows:
        primary=str(r["trade"] or "")
        verify=_v441_primary_trade(r["requirement"],primary)
        agreement="AGREE" if verify==primary else "DISAGREE"
        out.append((r,verify,agreement))
    return out[:200]


def _v46_graph(pid):
    _v46_ensure_tables()
    scopes=_v452_scope_rows(pid)
    deps=_v46_dependencies(pid)
    eq=_v46_equipment(pid)
    nodes=[]; edges=[]
    for r in scopes:
        key=f"scope:{r['id']}"
        nodes.append((key,"SCOPE",r["requirement"],r["trade"],r["source_sheet"] or ""))
        edges.append((f"trade:{r['trade']}",key,"OWNS"))
        if r["source_sheet"]:
            edges.append((f"sheet:{r['source_sheet']}",key,"DEFINES"))
        if r["source_spec"]:
            edges.append((f"spec:{r['source_spec']}",key,"GOVERNS"))
    for r,rels in deps:
        for tr in rels:
            edges.append((f"scope:{r['id']}",f"trade:{tr}","COORDINATES_WITH"))
    for e in eq:
        nodes.append((f"equipment:{e['key']}","EQUIPMENT",e["name"],e["primary"],e["source"]))
        for rel,tr in [("INSTALLED_BY",e["primary"]),("POWERED_BY",e["power"]),("CONTROLLED_BY",e["controls"]),("PIPED_BY",e["plumbing"]),("SUPPORTED_BY",e["support"]),("ROOFED_BY",e["roof"]),("STARTED_BY",e["startup"])]:
            if tr:
                edges.append((f"equipment:{e['key']}",f"trade:{tr}",rel))
    return nodes,edges


@app.get("/knowledge-graph",response_class=HTMLResponse)
def v46_knowledge_graph_home():
    pid=project_id()
    pairs=_v46_revision_pairs(pid)
    deps=_v46_dependencies(pid)
    specchecks=_v46_spec_drawing_checks(pid)
    equipment=_v46_equipment(pid)
    schedule=_v46_schedule_prediction(pid)
    cost=_v46_cost_risk(pid)
    complete=_v46_plan_completeness(pid)
    verify=_v46_second_opinion(pid)
    nodes,edges=_v46_graph(pid)
    disagreements=sum(1 for _,_,a in verify if a=="DISAGREE")

    body=f'<div class="hero"><div class="eyebrow">BuildCommand v46 - Project Knowledge Graph</div><h1>Understand how the project connects.</h1><p class="muted">{len(nodes)} knowledge nodes - {len(edges)} relationships - {len(pairs)} revision pairs - {len(deps)} cross-trade dependencies - {len(equipment)} equipment chains - {disagreements} verification disagreements.</p></div><div class="grid3">'
    cards=[
      ("Drawing Revision Intelligence","Identify likely prior/new document pairs and affected-project review needs.","/knowledge-graph/revisions"),
      ("Cross-Sheet Dependencies","See which trades and systems depend on the same requirement.","/knowledge-graph/dependencies"),
      ("Spec vs Drawing Verification","Find scope documented only in drawings or only in specifications.","/knowledge-graph/spec-drawing"),
      ("Equipment Intelligence","Map furnish/install/power/controls/piping/support/roof/startup responsibility.","/knowledge-graph/equipment"),
      ("Trade Handoff Intelligence","Show responsibility boundaries and coordination handoffs.","/knowledge-graph/handoffs"),
      ("Schedule Prediction","Predict likely near-term schedule threats from sequence and procurement.","/knowledge-graph/schedule-prediction"),
      ("Cost-Risk Prediction","Surface conflicts, scope gaps and known change exposure.","/knowledge-graph/cost-risk"),
      ("Plan Completeness Audit","Find missing sources, low-confidence and open-ended requirements.","/knowledge-graph/completeness"),
      ("Second Opinion Engine","Challenge Blueprint Brain trade ownership before trusting it.","/knowledge-graph/verification"),
      ("Project Knowledge Graph","View the connected nodes and relationships behind the intelligence.","/knowledge-graph/graph")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Project Knowledge Graph",body)


@app.get("/knowledge-graph/revisions",response_class=HTMLResponse)
def v46_revisions():
    rows=_v46_revision_pairs(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">COMPARE</span> <b>{esc(new["original_name"])}</b><div class="small">Possible prior version: {esc(old["original_name"])} · Group {esc(group)}</div></div>' for new,old,group in rows)
    return shell("Drawing Revision Intelligence",'<div class="hero"><h1>Drawing Revision Intelligence</h1><p class="muted">Candidate pairs only; document content still requires comparison before scope or cost changes.</p></div><div class="card">'+(h or '<p class="muted">No likely revision pairs detected.</p>')+'</div>')


@app.get("/knowledge-graph/dependencies",response_class=HTMLResponse)
def v46_dependencies():
    rows=_v46_dependencies(project_id())
    h="".join(f'<div class="action"><b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Coordinates with: {esc(", ".join(rels))}</div></div>' for r,rels in rows)
    return shell("Cross-Sheet Dependencies",'<div class="hero"><h1>Cross-Sheet Dependency Brain</h1><p class="muted">A requirement can belong to one trade while creating dependencies for several others.</p></div><div class="card">'+(h or '<p class="muted">No cross-trade dependency signals detected.</p>')+'</div>')


@app.get("/knowledge-graph/spec-drawing",response_class=HTMLResponse)
def v46_specdrawing():
    rows=_v46_spec_drawing_checks(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Sheet {esc(r["source_sheet"])} · Spec {esc(r["source_spec"])}</div></div>' for r,kind in rows)
    return shell("Spec vs Drawing Verification",'<div class="hero"><h1>Specification-to-Drawing Verification</h1><p class="muted">Find requirements supported by only one side of the contract-document set.</p></div><div class="card">'+(h or '<p class="muted">No one-sided source signals detected.</p>')+'</div>')


@app.get("/knowledge-graph/equipment",response_class=HTMLResponse)
def v46_equipment():
    rows=_v46_equipment(project_id())
    h=""
    for e in rows:
        h+=f'<div class="card"><h3>{esc(e["name"])}</h3><div class="small">{esc(e["source"])}</div><p><b>Install:</b> {esc(e["primary"])}</p><p><b>Power:</b> {esc(e["power"] or "N/A")} · <b>Controls:</b> {esc(e["controls"] or "N/A")} · <b>Plumbing:</b> {esc(e["plumbing"] or "N/A")} · <b>Support:</b> {esc(e["support"] or "N/A")} · <b>Roofing:</b> {esc(e["roof"] or "N/A")} · <b>Startup:</b> {esc(e["startup"])}</p></div>'
    return shell("Equipment Intelligence",'<div class="hero"><h1>Equipment Responsibility Intelligence</h1><p class="muted">Connect equipment to the trades required to make it operational.</p></div>'+(h or '<div class="card">No major equipment signals detected.</div>'))


@app.get("/knowledge-graph/handoffs",response_class=HTMLResponse)
def v46_handoffs():
    rows=_v46_dependencies(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">HANDOFF</span> <b>{esc(r["trade"])}</b> → {esc(", ".join(rels))}<div class="small">{esc(r["requirement"])}</div></div>' for r,rels in rows)
    return shell("Trade Handoff Intelligence",'<div class="hero"><h1>Trade Handoff Intelligence</h1><p class="muted">Shows where one subcontractor stops and another trade must pick up supporting work.</p></div><div class="card">'+(h or '<p class="muted">No handoff signals detected.</p>')+'</div>')


@app.get("/knowledge-graph/schedule-prediction",response_class=HTMLResponse)
def v46_schedule_prediction_page():
    rows=_v46_schedule_prediction(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(title)}</b><div>{esc(reason)}</div><div class="small">{esc(source)}</div></div>' for level,title,reason,source in rows)
    return shell("Schedule Prediction",'<div class="hero"><h1>Schedule Prediction Brain</h1><p class="muted">Predicts likely near-term schedule trouble from current sequence/readiness and procurement signals.</p></div><div class="card">'+(h or '<p class="muted">No high schedule prediction signals.</p>')+'</div>')


@app.get("/knowledge-graph/cost-risk",response_class=HTMLResponse)
def v46_costrisk():
    rows=_v46_cost_risk(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(kind)}</b> - {esc(title)}<div>{esc(reason)}</div><div class="small">{esc(source)}</div></div>' for level,kind,title,reason,source in rows)
    return shell("Cost Risk Prediction",'<div class="hero"><h1>Cost-Risk Prediction</h1><p class="muted">Early-warning signals only; human review determines contractual cost responsibility.</p></div><div class="card">'+(h or '<p class="muted">No major cost-risk signals detected.</p>')+'</div>')


@app.get("/knowledge-graph/completeness",response_class=HTMLResponse)
def v46_completeness():
    rows=_v46_plan_completeness(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(trade)}</b> - {esc(title)}<div class="small">{esc(req)}</div></div>' for kind,title,req,trade in rows)
    return shell("Plan Completeness Audit",'<div class="hero"><h1>Plan Completeness Audit</h1><p class="muted">Asks what an experienced builder would want clarified before relying on the information.</p></div><div class="card">'+(h or '<p class="muted">No obvious completeness exceptions detected.</p>')+'</div>')


@app.get("/knowledge-graph/verification",response_class=HTMLResponse)
def v46_verification():
    rows=_v46_second_opinion(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if agreement=="AGREE" else "WATCH"}">{esc(agreement)}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Second opinion: {esc(verify)} · Confidence {esc(r["confidence"])}</div></div>' for r,verify,agreement in rows if agreement=="DISAGREE")
    return shell("Second Opinion Engine",'<div class="hero"><h1>AI Verification / Second Opinion Engine</h1><p class="muted">When ownership logic disagrees with the saved scope, BuildCommand flags it instead of pretending certainty.</p></div><div class="card">'+(h or '<p class="muted">No trade-ownership disagreements detected.</p>')+'</div>')


@app.get("/knowledge-graph/graph",response_class=HTMLResponse)
def v46_graph_page():
    nodes,edges=_v46_graph(project_id())
    node_counts={}
    edge_counts={}
    for _,typ,_,_,_ in nodes: node_counts[typ]=node_counts.get(typ,0)+1
    for _,_,rel in edges: edge_counts[rel]=edge_counts.get(rel,0)+1
    nh="".join(f'<div class="action"><b>{esc(k)}</b><div class="small">{v} node(s)</div></div>' for k,v in sorted(node_counts.items()))
    eh="".join(f'<div class="action"><b>{esc(k)}</b><div class="small">{v} relationship(s)</div></div>' for k,v in sorted(edge_counts.items()))
    return shell("Project Knowledge Graph",f'<div class="hero"><h1>Project Knowledge Graph</h1><p class="muted">{len(nodes)} nodes · {len(edges)} relationships.</p></div><div class="grid2"><div class="card"><h2>Nodes</h2>{nh}</div><div class="card"><h2>Relationships</h2>{eh}</div></div>')


def _v47_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS decision_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,decision_type TEXT,title TEXT,
        responsible_party TEXT,decision_needed_by TEXT,affected_activity TEXT,
        affected_trade TEXT,cost_exposure {num} DEFAULT 0,schedule_days {num} DEFAULT 0,
        severity TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'OPEN',source_ref TEXT,
        recommended_action TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS manpower_forecast(
        id {pk},company_id BIGINT,project_id BIGINT,forecast_date TEXT,trade TEXT,
        active_activities INTEGER DEFAULT 0,risk_level TEXT DEFAULT 'LOW',
        readiness_note TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS risk_propagation(
        id {pk},company_id BIGINT,project_id BIGINT,source_type TEXT,source_key TEXT,
        source_title TEXT,target_type TEXT,target_key TEXT,target_title TEXT,
        relationship TEXT,risk_level TEXT DEFAULT 'REVIEW',reason TEXT,created TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v47_dependency_impacts(pid):
    deps=_v46_dependencies(pid)
    seq=_v45_sequence_analysis(pid)
    seq_by_trade={}
    for x in seq:
        seq_by_trade.setdefault(str(x["activity"]["trade"] or ""),[]).append(x)

    impacts=[]
    for r,related in deps:
        for tr in related:
            related_seq=seq_by_trade.get(tr,[])
            high=[x for x in related_seq if x["risk"] in {"CRITICAL","HIGH"}]
            level="HIGH" if high else "REVIEW"
            reason=(f"{len(high)} related {tr} activity risk(s) may affect this requirement."
                    if high else f"Requirement depends on coordination with {tr}.")
            impacts.append((r,tr,level,reason))
    return impacts[:200]


def _v47_critical_path_signals(pid):
    seq=_v45_sequence_analysis(pid)
    # No CPM dependency network exists yet, so this is a transparent proxy:
    # upcoming/high-risk activities with downstream stage exposure.
    rows=[]
    for x in seq:
        a=x["activity"]
        start=_v39_safe_date(a["start"]); finish=_v39_safe_date(a["finish"])
        duration=(finish-start).days+1 if start and finish and finish>=start else 0
        score=0
        if x["risk"]=="CRITICAL": score+=50
        elif x["risk"]=="HIGH": score+=30
        if x["stage"]>=60: score+=10
        if duration>=10: score+=10
        if float(a["pct"] or 0)>0 and float(a["pct"] or 0)<100: score+=10
        if score>=30:
            rows.append((score,x))
    rows.sort(key=lambda z:z[0],reverse=True)
    return rows[:50]


def _v47_decision_deadlines(pid):
    _v42_ensure_tables()
    today=datetime.utcnow().date()
    rows=[]
    # Owner decisions
    for r in _v42_owner(pid):
        due=_v39_safe_date(r["due_date"])
        days=(due-today).days if due else None
        severity="CRITICAL" if days is not None and days<0 else "HIGH" if days is not None and days<=3 else "REVIEW"
        rows.append(("OWNER",r["title"],r["due_date"],severity,float(r["cost_impact"] or 0),float(r["schedule_days"] or 0),r["source_ref"] or ""))
    # RFIs
    for r in _v42_rfis(pid):
        if str(r["status"] or "").upper() in {"CLOSED","ANSWERED","COMPLETE"}: continue
        due=_v39_safe_date(r["due_date"])
        days=(due-today).days if due else None
        severity="CRITICAL" if days is not None and days<0 else "HIGH" if days is not None and days<=3 else "REVIEW"
        rows.append(("RFI",r["title"],r["due_date"],severity,float(r["cost_impact"] or 0),float(r["schedule_days"] or 0),r["source_ref"] or ""))
    # Submittals
    for r in _v39_rows("SELECT * FROM submittals WHERE project_id=? AND COALESCE(status,'PENDING') NOT IN ('APPROVED','CLOSED','COMPLETE') ORDER BY due_date",(pid,)):
        due=_v39_safe_date(r["due_date"])
        days=(due-today).days if due else None
        severity="CRITICAL" if days is not None and days<0 else "HIGH" if days is not None and days<=3 else "REVIEW"
        rows.append(("SUBMITTAL",r["title"],r["due_date"],severity,0,0,r["spec_section"] or ""))
    rank={"CRITICAL":0,"HIGH":1,"REVIEW":2}
    rows.sort(key=lambda x:(rank.get(x[3],9),x[2] or "9999"))
    return rows[:100]


def _v47_manpower_forecast(pid):
    acts=_v39_rows("SELECT * FROM activities WHERE project_id=? AND COALESCE(status,'NOT_STARTED')!='COMPLETE' ORDER BY start",(pid,))
    today=datetime.utcnow().date()
    buckets={}
    for a in acts:
        start=_v39_safe_date(a["start"]); finish=_v39_safe_date(a["finish"])
        if not start or not finish: continue
        for offset in range(0,15):
            d=today+timedelta(days=offset)
            if start<=d<=finish:
                tr=str(a["trade"] or "Unassigned")
                buckets.setdefault((d.isoformat(),tr),[]).append(a)
    out=[]
    for (d,tr),items in sorted(buckets.items()):
        count=len(items)
        level="HIGH" if count>=3 else "MEDIUM" if count==2 else "LOW"
        out.append((d,tr,count,level,[x["name"] for x in items]))
    return out[:200]


def _v47_material_readiness(pid):
    acts={int(a["id"]):a for a in _v39_rows("SELECT * FROM activities WHERE project_id=?",(pid,))}
    proc=_v452_procurement_analysis(pid)
    out=[]
    for r,level,exposure,reason,action in proc:
        aid=r["activity_id"]
        act=acts.get(int(aid)) if aid is not None else None
        out.append((r,act,level,exposure,reason,action))
    return out[:150]


def _v47_coordination_agenda(pid):
    conflicts=_v452_conflicts(pid)
    construct=_v452_constructability(pid)
    seq=[x for x in _v45_sequence_analysis(pid) if x["risk"] in {"CRITICAL","HIGH"}]
    decisions=_v47_decision_deadlines(pid)
    agenda=[]
    for req,trades,source in conflicts[:8]:
        agenda.append(("Conflict",req,f"Trades: {', '.join(trades)} · {source}"))
    for r in construct[:8]:
        agenda.append(("Constructability",r["title"],r["description"]))
    for x in seq[:8]:
        agenda.append(("Schedule",x["activity"]["name"],x["blocking_reason"]))
    for typ,title,due,severity,cost,days,source in decisions[:8]:
        agenda.append(("Decision",title,f"{typ} · Due {due} · {severity}"))
    return agenda[:25]


def _v47_change_causality(pid):
    changes=_v39_changes(pid)
    rfis=_v42_rfis(pid)
    issues=_v39_rows("SELECT * FROM project_issues WHERE project_id=? ORDER BY id DESC",(pid,))
    out=[]
    for c in changes:
        title=str(c["title"] or "").lower()
        linked=[]
        for r in rfis:
            if title and (title in str(r["title"] or "").lower() or str(r["title"] or "").lower() in title):
                linked.append(("RFI",r["title"]))
        for i in issues:
            if title and (title in str(i["title"] or "").lower() or str(i["title"] or "").lower() in title):
                linked.append(("ISSUE",i["title"]))
        out.append((c,linked))
    return out[:100]


def _v47_closeout_prediction(pid):
    _v41_closeout_seed(pid)
    rows=_v39_rows("SELECT * FROM closeout_items WHERE company_id=? AND project_id=? ORDER BY category,id",(current_company_id(),pid))
    today=datetime.utcnow().date()
    out=[]
    for r in rows:
        status=str(r["status"] or "OPEN").upper()
        due=_v39_safe_date(r["due_date"])
        if status in {"COMPLETE","CLOSED","RECEIVED"}:
            level="READY"
        elif due and due<today:
            level="CRITICAL"
        elif due and (due-today).days<=14:
            level="HIGH"
        else:
            level="REVIEW"
        out.append((r,level))
    return out


def _v47_risk_propagation(pid):
    impacts=[]
    for r,tr,level,reason in _v47_dependency_impacts(pid):
        impacts.append(("SCOPE",f"scope:{r['id']}",r["requirement"],"TRADE",f"trade:{tr}",tr,"DEPENDS_ON",level,reason))
    for score,x in _v47_critical_path_signals(pid):
        a=x["activity"]
        impacts.append(("ACTIVITY",f"activity:{a['id']}",a["name"],"PROJECT","project", "Project Completion","CAN_DELAY",x["risk"],x["blocking_reason"]))
    return impacts[:250]


def _v47_forecast_summary(pid):
    cp=_v47_critical_path_signals(pid)
    decisions=_v47_decision_deadlines(pid)
    material=_v47_material_readiness(pid)
    closeout=_v47_closeout_prediction(pid)
    critical_decisions=sum(1 for x in decisions if x[3]=="CRITICAL")
    critical_material=sum(1 for x in material if x[2]=="CRITICAL")
    critical_closeout=sum(1 for _,level in closeout if level=="CRITICAL")
    return {
        "critical_path":len(cp),
        "critical_decisions":critical_decisions,
        "critical_material":critical_material,
        "critical_closeout":critical_closeout,
        "risk_propagation":len(_v47_risk_propagation(pid))
    }


@app.get("/prediction-intelligence",response_class=HTMLResponse)
def v47_prediction_home():
    pid=project_id()
    s=_v47_forecast_summary(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v47 - Prediction & Decision Intelligence</div><h1>See problems before they become field problems.</h1><p class="muted">{s["critical_path"]} critical-path proxy signals · {s["critical_decisions"]} overdue decision(s) · {s["critical_material"]} critical material risk(s) · {s["critical_closeout"]} critical closeout risk(s) · {s["risk_propagation"]} propagated dependency risks.</p></div><div class="grid3">'
    cards=[
      ("Dependency Impact Engine","Trace how one scope/trade dependency can affect another.","/prediction-intelligence/dependency-impact"),
      ("Critical Path Intelligence","Prioritize activities most likely to threaten completion.","/prediction-intelligence/critical-path"),
      ("Decision Deadline Engine","Put RFIs, submittals and owner decisions on one urgency clock.","/prediction-intelligence/decision-deadlines"),
      ("Manpower Forecast","See overlapping trade demand for the next two weeks.","/prediction-intelligence/manpower"),
      ("Material Readiness","Connect procurement timing directly to scheduled activities.","/prediction-intelligence/materials"),
      ("Coordination Agenda Brain","Auto-build coordination meeting topics from live project intelligence.","/prediction-intelligence/agenda"),
      ("Change Causality","Trace open changes back to related RFIs/issues when evidence exists.","/prediction-intelligence/change-causality"),
      ("Closeout Readiness Predictor","See turnover items likely to become late before project end.","/prediction-intelligence/closeout"),
      ("Risk Propagation Graph","Show how scope/activity risk spreads downstream.","/prediction-intelligence/risk-propagation"),
      ("Predictive Project Brief","One forward-looking view of the next problems to solve.","/prediction-intelligence/brief")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Prediction Intelligence",body)


@app.get("/prediction-intelligence/dependency-impact",response_class=HTMLResponse)
def v47_dependency_page():
    rows=_v47_dependency_impacts(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(r["trade"])}</b> → {esc(tr)}<div>{esc(r["requirement"])}</div><div class="small">{esc(reason)}</div></div>' for r,tr,level,reason in rows)
    return shell("Dependency Impact",'<div class="hero"><h1>Dependency Impact Engine</h1><p class="muted">Shows where supporting-trade risk can affect the primary scope.</p></div><div class="card">'+(h or '<p class="muted">No dependency impacts detected.</p>')+'</div>')


@app.get("/prediction-intelligence/critical-path",response_class=HTMLResponse)
def v47_critical_path_page():
    rows=_v47_critical_path_signals(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">SCORE {score}</span> <b>{esc(x["activity"]["name"])}</b><div class="small">{esc(x["activity"]["trade"])} · Stage {x["stage"]} · {esc(x["risk"])}</div><p>{esc(x["blocking_reason"] or "Upcoming activity with completion exposure.")}</p></div>' for score,x in rows)
    return shell("Critical Path Intelligence",'<div class="hero"><h1>Critical Path Intelligence</h1><p class="muted">This is a transparent risk proxy until a full CPM dependency network is available.</p></div><div class="card">'+(h or '<p class="muted">No major critical-path proxy signals.</p>')+'</div>')


@app.get("/prediction-intelligence/decision-deadlines",response_class=HTMLResponse)
def v47_decisions_page():
    rows=_v47_decision_deadlines(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(severity)}</span> <b>{esc(typ)} - {esc(title)}</b><div class="small">Due {esc(due)} · ${cost:,.0f} exposure · {days:g} days · {esc(source)}</div></div>' for typ,title,due,severity,cost,days,source in rows)
    return shell("Decision Deadlines",'<div class="hero"><h1>Decision Deadline Engine</h1><p class="muted">One urgency clock for owner decisions, RFIs and submittals.</p></div><div class="card">'+(h or '<p class="muted">No open decision deadlines.</p>')+'</div>')


@app.get("/prediction-intelligence/manpower",response_class=HTMLResponse)
def v47_manpower_page():
    rows=_v47_manpower_forecast(project_id())
    h="".join(f'<div class="action"><span class="badge {"WATCH" if level!="LOW" else "READY"}">{esc(level)}</span> <b>{esc(date)} - {esc(trade)}</b><div class="small">{count} active activity(ies): {esc(", ".join(names))}</div></div>' for date,trade,count,level,names in rows)
    return shell("Manpower Forecast",'<div class="hero"><h1>Manpower Forecast</h1><p class="muted">Predict overlapping trade demand from the next two weeks of scheduled activities.</p></div><div class="card">'+(h or '<p class="muted">No dated activities available for manpower forecasting.</p>')+'</div>')


@app.get("/prediction-intelligence/materials",response_class=HTMLResponse)
def v47_material_page():
    rows=_v47_material_readiness(project_id())
    h=""
    for r,act,level,exposure,reason,action in rows:
        h+=f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(r["item"])}</b><div class="small">Activity: {esc(act["name"] if act else "Unlinked")} · Need {esc(r["required_on_site"])} · Promised {esc(r["promised_date"])} · Exposure {exposure} day(s)</div><p>{esc(reason)}</p></div>'
    return shell("Material Readiness",'<div class="hero"><h1>Material Readiness Intelligence</h1><p class="muted">Procurement risk is most useful when connected directly to installation work.</p></div><div class="card">'+(h or '<p class="muted">No open material-readiness risks.</p>')+'</div>')


@app.get("/prediction-intelligence/agenda",response_class=HTMLResponse)
def v47_agenda_page():
    rows=_v47_coordination_agenda(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(title)}</b><div class="small">{esc(detail)}</div></div>' for kind,title,detail in rows)
    return shell("Coordination Agenda Brain",'<div class="hero"><h1>Coordination Agenda Brain</h1><p class="muted">Builds meeting topics from live conflicts, constructability, schedule and decision intelligence.</p></div><div class="card">'+(h or '<p class="muted">No current coordination agenda items.</p>')+'</div>')


@app.get("/prediction-intelligence/change-causality",response_class=HTMLResponse)
def v47_change_causality_page():
    rows=_v47_change_causality(project_id())
    h=""
    for c,links in rows:
        linktxt=", ".join(f"{k}: {v}" for k,v in links) if links else "No obvious linked RFI/issue by title."
        h+=f'<div class="action"><b>{esc(c["title"])}</b><div class="small">{esc(c["event_type"])} · ${float(c["estimated_cost"] or 0):,.0f} · {float(c["schedule_days"] or 0):g} days</div><p>{esc(linktxt)}</p></div>'
    return shell("Change Causality",'<div class="hero"><h1>Change Causality Intelligence</h1><p class="muted">Helps preserve the reason chain behind change exposure.</p></div><div class="card">'+(h or '<p class="muted">No open change events.</p>')+'</div>')


@app.get("/prediction-intelligence/closeout",response_class=HTMLResponse)
def v47_closeout_page():
    rows=_v47_closeout_prediction(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if level=="READY" else "WATCH"}">{esc(level)}</span> <b>{esc(r["category"])}</b> - {esc(r["item"])}<div class="small">{esc(r["status"])} · Due {esc(r["due_date"])} · {esc(r["responsible_party"])}</div></div>' for r,level in rows)
    return shell("Closeout Readiness",'<div class="hero"><h1>Closeout Readiness Predictor</h1><p class="muted">Turnover risk should be managed before the final month, not discovered at the end.</p></div><div class="card">'+h+'</div>')


@app.get("/prediction-intelligence/risk-propagation",response_class=HTMLResponse)
def v47_risk_graph_page():
    rows=_v47_risk_propagation(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(level)}</span> <b>{esc(stitle)}</b> → {esc(ttitle)}<div class="small">{esc(rel)} · {esc(reason)}</div></div>' for stype,skey,stitle,ttype,tkey,ttitle,rel,level,reason in rows)
    return shell("Risk Propagation",'<div class="hero"><h1>Risk Propagation Graph</h1><p class="muted">Shows how one unresolved dependency can create downstream project exposure.</p></div><div class="card">'+(h or '<p class="muted">No propagated risk signals.</p>')+'</div>')


@app.get("/prediction-intelligence/brief",response_class=HTMLResponse)
def v47_predictive_brief():
    pid=project_id()
    cp=_v47_critical_path_signals(pid)[:5]
    decisions=_v47_decision_deadlines(pid)[:5]
    materials=[x for x in _v47_material_readiness(pid) if x[2] in {"CRITICAL","HIGH"}][:5]
    closeout=[x for x in _v47_closeout_prediction(pid) if x[1] in {"CRITICAL","HIGH"}][:5]
    body='<div class="hero"><div class="eyebrow">Predictive Project Brief</div><h1>What is most likely to hurt the job next?</h1><p class="muted">Forward-looking signals from schedule, decisions, material readiness and closeout.</p></div>'
    body+='<div class="card"><h2>Critical Path / Sequence</h2>'+("".join(f'<div class="action"><b>{esc(x["activity"]["name"])}</b><div class="small">Score {score} · {esc(x["risk"])}</div></div>' for score,x in cp) or '<p class="muted">No major sequence threats.</p>')+'</div>'
    body+='<div class="card"><h2>Decision Deadlines</h2>'+("".join(f'<div class="action"><b>{esc(typ)} - {esc(title)}</b><div class="small">Due {esc(due)} · {esc(sev)}</div></div>' for typ,title,due,sev,cost,days,source in decisions) or '<p class="muted">No urgent decisions.</p>')+'</div>'
    body+='<div class="card"><h2>Material Risk</h2>'+("".join(f'<div class="action"><b>{esc(r["item"])}</b><div class="small">{esc(level)} · {exposure} day(s) exposure</div></div>' for r,act,level,exposure,reason,action in materials) or '<p class="muted">No high material risks.</p>')+'</div>'
    body+='<div class="card"><h2>Closeout Risk</h2>'+("".join(f'<div class="action"><b>{esc(r["item"])}</b><div class="small">{esc(level)} · Due {esc(r["due_date"])}</div></div>' for r,level in closeout) or '<p class="muted">No high closeout risks.</p>')+'</div>'
    return shell("Predictive Project Brief",body)


def _v48_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS quality_audit(
        id {pk},company_id BIGINT,project_id BIGINT,subject_type TEXT,subject_key TEXT,
        primary_result TEXT,secondary_result TEXT,agreement TEXT DEFAULT 'REVIEW',
        source_quality TEXT DEFAULT 'MEDIUM',confidence_score {num} DEFAULT 0,
        contradiction_flag INTEGER DEFAULT 0,reason TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS confidence_calibration(
        id {pk},company_id BIGINT,project_id BIGINT,subject_type TEXT,subject_key TEXT,
        stated_confidence TEXT,calibrated_confidence TEXT,score {num} DEFAULT 0,
        reason TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS contradiction_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,subject TEXT,source_a TEXT,source_b TEXT,
        contradiction_type TEXT,severity TEXT DEFAULT 'REVIEW',status TEXT DEFAULT 'OPEN',
        reason TEXT,created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS learning_feedback(
        id {pk},company_id BIGINT,project_id BIGINT,subject_type TEXT,subject_key TEXT,
        original_result TEXT,approved_result TEXT,feedback_type TEXT,reason TEXT,
        approved_by TEXT,scope_level TEXT DEFAULT 'PROJECT ONLY',created TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v48_source_quality(r):
    score=0
    if r["source_sheet"]: score+=35
    if r["source_detail"]: score+=25
    if r["source_spec"]: score+=25
    if r["source_note"]: score+=15
    if score>=75: return ("HIGH",score)
    if score>=40: return ("MEDIUM",score)
    return ("LOW",score)


def _v48_calibrated_confidence(r):
    stated=str(r["confidence"] or "MEDIUM").upper()
    source_level,source_score=_v48_source_quality(r)
    verify=_v441_primary_trade(r["requirement"],r["trade"])
    agrees=(verify==r["trade"])
    score=source_score
    score += 15 if agrees else -25
    score += 10 if stated=="HIGH" else 0
    score -= 10 if stated=="LOW" else 0
    score=max(0,min(100,score))
    calibrated="HIGH" if score>=75 else "MEDIUM" if score>=45 else "LOW"
    reason=f"Source quality {source_level}; second opinion {'agrees' if agrees else 'disagrees'} with saved trade."
    return calibrated,score,reason,verify


def _v48_self_audit_uncached(pid):
    rows=_v452_scope_rows(pid)
    out=[]
    for r in rows:
        calibrated,score,reason,verify=_v48_calibrated_confidence(r)
        agreement="AGREE" if verify==r["trade"] else "DISAGREE"
        source_level,_=_v48_source_quality(r)
        contradiction=1 if agreement=="DISAGREE" else 0
        out.append((r,verify,agreement,source_level,calibrated,score,contradiction,reason))
    return out[:300]


def _v48_self_audit(pid):
    return _v56_self_audit(pid)


def _v48_contradictions(pid):
    rows=_v452_scope_rows(pid)
    by_key={}
    out=[]
    for r in rows:
        req=re.sub(r'\s+',' ',str(r["requirement"] or "").lower()).strip()
        if not req: continue
        by_key.setdefault(req,[]).append(r)
    for req,items in by_key.items():
        trades=sorted(set(str(x["trade"] or "") for x in items))
        if len(trades)>1:
            out.append(("TRADE OWNERSHIP",items[0]["requirement"]," / ".join(trades),items[0]["source_sheet"] or "",items[-1]["source_sheet"] or ""))
    # One-sided spec/drawing signals are treated as possible document contradictions.
    for r,kind in _v46_spec_drawing_checks(pid):
        out.append(("SOURCE MISMATCH",r["requirement"],kind,r["source_sheet"] or "",r["source_spec"] or ""))
    return out[:200]


def _v48_learning_rules(pid):
    _v43_ensure_tables()
    return _v39_rows("""
        SELECT * FROM learning_rules
        WHERE company_id=? AND approval_status='APPROVED'
          AND (project_id=? OR scope_level='COMPANY STANDARD')
        ORDER BY CASE WHEN project_id=? THEN 0 ELSE 1 END,id DESC
        LIMIT 300
    """,(current_company_id(),pid,pid))


def _v48_quality_score(pid):
    audit=_v48_self_audit(pid)
    if not audit:
        return {"score":100,"disagree":0,"low":0,"missing_source":0}
    disagree=sum(1 for x in audit if x[2]=="DISAGREE")
    low=sum(1 for x in audit if x[4]=="LOW")
    missing_source=sum(1 for x in audit if x[3]=="LOW")
    score=max(0,100 - disagree*6 - low*3 - missing_source*2)
    return {"score":score,"disagree":disagree,"low":low,"missing_source":missing_source}


def _v48_learning_opportunities(pid):
    audit=_v48_self_audit(pid)
    approved=_v48_learning_rules(pid)
    subjects={str(r["subject"] or "").lower() for r in approved}
    out=[]
    for r,verify,agreement,source_level,calibrated,score,contradiction,reason in audit:
        if agreement=="DISAGREE" and str(r["requirement"] or "").lower() not in subjects:
            out.append((r,verify,calibrated,reason))
    return out[:150]


def _v48_answer_guard(pid,question):
    """
    Lightweight quality gate for Ask BuildCommand:
    surfaces uncertainty and related knowledge rather than fabricating certainty.
    """
    q=(question or "").lower()
    rows=_v452_scope_rows(pid)
    matches=[]
    for r in rows:
        text=(str(r["requirement"] or "")+" "+str(r["trade"] or "")+" "+str(r["source_note"] or "")).lower()
        if any(tok in text for tok in [w for w in re.findall(r'[a-z0-9]+',q) if len(w)>3]):
            matches.append(r)
    matches=matches[:12]
    if not matches:
        return {"confidence":"LOW","note":"No strong project-source match found.","matches":[]}
    low=sum(1 for r in matches if _v48_calibrated_confidence(r)[0]=="LOW")
    conf="LOW" if low>=max(1,len(matches)//2) else "MEDIUM" if low else "HIGH"
    note="Answer should cite project sources and expose uncertainty where sources conflict."
    return {"confidence":conf,"note":note,"matches":matches}


@app.get("/brain-quality",response_class=HTMLResponse)
def v48_brain_quality_home():
    pid=project_id(); _v48_ensure_tables()
    q=_v48_quality_score(pid)
    contradictions=_v48_contradictions(pid)
    rules=_v48_learning_rules(pid)
    opportunities=_v48_learning_opportunities(pid)
    body=f'<div class="hero"><div class="eyebrow">BuildCommand v48 - Brain Quality & Self-Learning</div><h1>Make the brain more accurate before making it bigger.</h1><p class="muted">Quality score {q["score"]}/100 · {q["disagree"]} second-opinion disagreement(s) · {q["low"]} low-confidence item(s) · {len(contradictions)} contradiction/source mismatch signal(s) · {len(rules)} approved learning rule(s).</p></div><div class="grid3">'
    cards=[
      ("Multi-Pass Verification","Primary ownership vs independent second opinion.","/brain-quality/verification"),
      ("Confidence Calibration","Re-score confidence using source quality and agreement.","/brain-quality/confidence"),
      ("Source Quality Audit","Find weakly sourced project intelligence.","/brain-quality/sources"),
      ("Contradiction Detection","Find ownership or source inconsistencies.","/brain-quality/contradictions"),
      ("Approved Learning Reuse","Show the project/company rules the brain can trust.","/brain-quality/learning"),
      ("Learning Opportunities","Find disagreements that should become reviewed corrections.","/brain-quality/opportunities"),
      ("Scope Self-Audit","Run trade/source/confidence QA before downstream use.","/brain-quality/self-audit"),
      ("Answer Guardrails","Show how Ask BuildCommand should expose uncertainty.","/brain-quality/answer-guard"),
      ("Quality Dashboard","One score for current intelligence quality.","/brain-quality/dashboard"),
      ("Brain Improvement Queue","Prioritize the highest-value corrections first.","/brain-quality/queue")
    ]
    for name,desc,href in cards:
        body+=_v37_link_card(name,desc,href,"Open")
    body+='</div>'
    return shell("Brain Quality",body)


@app.get("/brain-quality/verification",response_class=HTMLResponse)
def v48_verification_page():
    rows=_v48_self_audit(project_id())
    h="".join(f'<div class="action"><span class="badge {"READY" if agreement=="AGREE" else "WATCH"}">{esc(agreement)}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Second opinion: {esc(verify)} · Calibrated {esc(calibrated)} ({score:.0f})</div></div>' for r,verify,agreement,source_level,calibrated,score,contradiction,reason in rows if agreement=="DISAGREE")
    return shell("Multi-Pass Verification",'<div class="hero"><h1>Multi-Pass Verification</h1><p class="muted">The second pass challenges the saved result instead of rubber-stamping it.</p></div><div class="card">'+(h or '<p class="muted">No current ownership disagreements.</p>')+'</div>')


@app.get("/brain-quality/confidence",response_class=HTMLResponse)
def v48_confidence_page():
    rows=_v48_self_audit(project_id())
    h="".join(f'<div class="action"><span class="badge">{esc(calibrated)}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Stated {esc(r["confidence"])} → Calibrated {esc(calibrated)} ({score:.0f}/100) · {esc(reason)}</div></div>' for r,verify,agreement,source_level,calibrated,score,contradiction,reason in rows)
    return shell("Confidence Calibration",'<div class="hero"><h1>Confidence Calibration</h1><p class="muted">Confidence now considers source strength and whether an independent ownership pass agrees.</p></div><div class="card">'+(h or '<p class="muted">No scope intelligence available.</p>')+'</div>')


@app.get("/brain-quality/sources",response_class=HTMLResponse)
def v48_sources_page():
    rows=_v48_self_audit(project_id())
    weak=[x for x in rows if x[3]=="LOW"]
    h="".join(f'<div class="action"><span class="badge WATCH">LOW SOURCE</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Sheet {esc(r["source_sheet"])} · Detail {esc(r["source_detail"])} · Spec {esc(r["source_spec"])}</div></div>' for r,verify,agreement,source_level,calibrated,score,contradiction,reason in weak)
    return shell("Source Quality Audit",'<div class="hero"><h1>Source Quality Audit</h1><p class="muted">Weak sourcing should lower trust even when the wording looks convincing.</p></div><div class="card">'+(h or '<p class="muted">No low-source-quality scope items detected.</p>')+'</div>')


@app.get("/brain-quality/contradictions",response_class=HTMLResponse)
def v48_contradictions_page():
    rows=_v48_contradictions(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">{esc(kind)}</span> <b>{esc(subject)}</b><div class="small">{esc(detail)} · Source A {esc(a)} · Source B {esc(b)}</div></div>' for kind,subject,detail,a,b in rows)
    return shell("Contradiction Detection",'<div class="hero"><h1>Contradiction Detection</h1><p class="muted">Conflicting ownership or one-sided documentation should become review work, not false certainty.</p></div><div class="card">'+(h or '<p class="muted">No contradiction signals detected.</p>')+'</div>')


@app.get("/brain-quality/learning",response_class=HTMLResponse)
def v48_learning_page():
    rows=_v48_learning_rules(project_id())
    h="".join(f'<div class="action"><span class="badge READY">{esc(r["scope_level"])}</span> <b>{esc(r["rule_type"])} - {esc(r["subject"])}</b><div>{esc(r["learned_rule"])}</div><div class="small">Approved by {esc(r["approved_by"])}</div></div>' for r in rows)
    return shell("Approved Learning Reuse",'<div class="hero"><h1>Approved Learning Reuse</h1><p class="muted">Only reviewed project/company rules are trusted by the brain.</p></div><div class="card">'+(h or '<p class="muted">No approved learning rules available.</p>')+'</div>')


@app.get("/brain-quality/opportunities",response_class=HTMLResponse)
def v48_opportunities_page():
    rows=_v48_learning_opportunities(project_id())
    h="".join(f'<div class="action"><span class="badge WATCH">LEARN</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Second opinion says {esc(verify)} · {esc(calibrated)} · {esc(reason)}</div></div>' for r,verify,calibrated,reason in rows)
    return shell("Learning Opportunities",'<div class="hero"><h1>Learning Opportunities</h1><p class="muted">These are disagreements worth human review before they become approved knowledge.</p></div><div class="card">'+(h or '<p class="muted">No new learning opportunities detected.</p>')+'</div>')


@app.get("/brain-quality/self-audit",response_class=HTMLResponse)
def v48_selfaudit_page():
    rows=_v48_self_audit(project_id())
    bad=[x for x in rows if x[2]=="DISAGREE" or x[4]=="LOW" or x[3]=="LOW"]
    h="".join(f'<div class="action"><span class="badge WATCH">REVIEW</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Agreement {esc(agreement)} · Source {esc(source_level)} · Confidence {esc(calibrated)} ({score:.0f})</div></div>' for r,verify,agreement,source_level,calibrated,score,contradiction,reason in bad)
    return shell("Scope Self-Audit",'<div class="hero"><h1>Scope Self-Audit</h1><p class="muted">Runs QA before intelligence feeds estimating, bidding, schedule or field execution.</p></div><div class="card">'+(h or '<p class="muted">No major quality exceptions detected.</p>')+'</div>')


@app.get("/brain-quality/answer-guard",response_class=HTMLResponse)
def v48_answer_guard_page(q:str=''):
    result=_v48_answer_guard(project_id(),q)
    matches=result["matches"]
    h="".join(f'<div class="action"><b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">Sheet {esc(r["source_sheet"])} · Spec {esc(r["source_spec"])} · Confidence {esc(_v48_calibrated_confidence(r)[0])}</div></div>' for r in matches)
    body='<div class="hero"><h1>Answer Guardrails</h1><p class="muted">Ask BuildCommand should say when project evidence is weak or conflicting.</p></div><div class="card"><form method="get"><input name="q" value="'+esc(q)+'" placeholder="Test a project question"><button type="submit">Check evidence</button></form></div>'
    if q:
        body+=f'<div class="card"><span class="badge">{esc(result["confidence"])}</span><p>{esc(result["note"])}</p>{h or "<p class=muted>No strong project-source matches.</p>"}</div>'
    return shell("Answer Guardrails",body)


@app.get("/brain-quality/dashboard",response_class=HTMLResponse)
def v48_dashboard_page():
    q=_v48_quality_score(project_id())
    return shell("Quality Dashboard",f'<div class="hero"><h1>Brain Quality Dashboard</h1><p class="muted">Current intelligence quality score: {q["score"]}/100.</p></div><div class="grid3"><div class="card"><div class="label">Second-Opinion Disagreements</div><div class="kpi">{q["disagree"]}</div></div><div class="card"><div class="label">Low Confidence</div><div class="kpi">{q["low"]}</div></div><div class="card"><div class="label">Weak Sources</div><div class="kpi">{q["missing_source"]}</div></div></div>')


@app.get("/brain-quality/queue",response_class=HTMLResponse)
def v48_queue_page():
    rows=_v48_self_audit(project_id())
    queue=[]
    for r,verify,agreement,source_level,calibrated,score,contradiction,reason in rows:
        priority=0
        if agreement=="DISAGREE": priority+=50
        if calibrated=="LOW": priority+=30
        if source_level=="LOW": priority+=20
        if priority:
            queue.append((priority,r,verify,agreement,source_level,calibrated,score))
    queue.sort(key=lambda x:x[0],reverse=True)
    h="".join(f'<div class="action"><span class="badge WATCH">PRIORITY {p}</span> <b>{esc(r["trade"])}</b> - {esc(r["requirement"])}<div class="small">2nd opinion {esc(verify)} · Source {esc(source)} · Confidence {esc(conf)} ({score:.0f})</div></div>' for p,r,verify,agreement,source,conf,score in queue[:100])
    return shell("Brain Improvement Queue",'<div class="hero"><h1>Brain Improvement Queue</h1><p class="muted">Fix the highest-value intelligence problems first.</p></div><div class="card">'+(h or '<p class="muted">No current quality-improvement queue.</p>')+'</div>')


def _v49_ensure_tables():
    c=db()
    if DATABASE_KIND=="postgres":
        pk="BIGSERIAL PRIMARY KEY"; num="DOUBLE PRECISION"
    else:
        pk="INTEGER PRIMARY KEY"; num="REAL"
    stmts=[
      f"""CREATE TABLE IF NOT EXISTS room_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,room_key TEXT,room_name TEXT,
        room_number TEXT,source_ref TEXT,trade_count INTEGER DEFAULT 0,
        issue_count INTEGER DEFAULT 0,status TEXT DEFAULT 'REVIEW',created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS assembly_intelligence(
        id {pk},company_id BIGINT,project_id BIGINT,assembly_type TEXT,assembly_key TEXT,
        description TEXT,primary_trade TEXT,related_trades TEXT,source_ref TEXT,
        prerequisite_summary TEXT,inspection_summary TEXT,status TEXT DEFAULT 'REVIEW',
        created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS field_work_packages(
        id {pk},company_id BIGINT,project_id BIGINT,package_type TEXT,title TEXT,
        location TEXT,trade TEXT,scope_summary TEXT,prerequisites TEXT,
        inspection_gates TEXT,materials TEXT,status TEXT DEFAULT 'DRAFT',
        created TEXT,updated TEXT)""",
      f"""CREATE TABLE IF NOT EXISTS commissioning_chain(
        id {pk},company_id BIGINT,project_id BIGINT,equipment_key TEXT,equipment_name TEXT,
        install_trade TEXT,power_trade TEXT,controls_trade TEXT,startup_trade TEXT,
        testing_requirement TEXT,closeout_requirement TEXT,status TEXT DEFAULT 'REVIEW',
        source_ref TEXT,created TEXT,updated TEXT)"""
    ]
    for s in stmts:
        c.execute(s)
    c.commit(); c.close()


def _v49_scope_rows(pid):
    return _v452_scope_rows(pid)


def _v49_room_key(text):
    s=str(text or "")
    # Common room-number patterns such as 101, 122A, Room 203.
    m=re.search(r'(?i)\broom\s+([A-Z]?\d{2,4}[A-Z]?)\b',s)
    if m:
        return m.group(1)
    m=re.search(r'\b([1-9]\d{2}[A-Z]?)\b',s)
    return m.group(1) if m else ""


def _v49_rooms(pid):
    rows=_v49_scope_rows(pid)
    rooms={}
    for r in rows:
        corpus=" ".join(str(r[k] or "") for k in ["requirement","source_note","source_detail"])
        rk=_v49_room_key(corpus)
        if not rk:
            continue
        ent=rooms.setdefault(rk,{"room":rk,"items":[],"trades":set()})
        ent["items"].append(r)
        ent["trades"].add(str(r["trade"] or ""))
    return list(rooms.values())[:200]

