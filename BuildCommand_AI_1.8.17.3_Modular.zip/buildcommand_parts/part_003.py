# BuildCommand AI 1.8.17.3 modular source fragment 003
# Generated from verified 1.8.17.2; execute only through full_app.py.

@app.get("/activities/{activity_id}/edit", response_class=HTMLResponse)
def edit_activity_form(activity_id: int):
    pid = project_id()
    c = db()
    activity = c.execute(
        "SELECT * FROM activities WHERE id=? AND project_id=?",
        (activity_id, pid)
    ).fetchone()
    c.close()

    if not activity:
        return RedirectResponse(url="/schedule", status_code=303)

    statuses = ["NOT_STARTED", "IN_PROGRESS", "COMPLETE", "HOLD"]
    options = "".join(
        f'<option value="{s}" {"selected" if activity["status"] == s else ""}>{s.replace("_"," ").title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Schedule</div>
        <h1>Edit Activity</h1>
        <div class="muted">Update schedule information for this activity.</div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/activities/{activity_id}/edit">
            <div class="grid2">
                <div>
                    <label>Activity ID</label>
                    <input type="text" name="external_id" value="{esc(activity["external_id"])}" required>
                </div>
                <div>
                    <label>Trade</label>
                    <input type="text" name="trade" value="{esc(activity["trade"])}" required>
                </div>
            </div>

            <label>Activity Name</label>
            <input type="text" name="name" value="{esc(activity["name"])}" required>

            <div class="grid2">
                <div>
                    <label>Start Date</label>
                    <input type="date" name="start" value="{activity["start"]}" required>
                </div>
                <div>
                    <label>Finish Date</label>
                    <input type="date" name="finish" value="{activity["finish"]}" required>
                </div>
            </div>

            <div class="grid2">
                <div>
                    <label>Percent Complete</label>
                    <input type="number" name="pct" min="0" max="100" step="1" value="{activity["pct"]:.0f}" required>
                </div>
                <div>
                    <label>Status</label>
                    <select name="status">{options}</select>
                </div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Changes</button>
                <a href="/schedule" style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">Cancel</a>
            </div>
        </form>

        <form method="post" action="/activities/{activity_id}/delete" style="margin-top:22px;padding-top:18px;border-top:1px solid #213042;">
            <button type="submit" style="background:#492324;color:#ffb0b0;">Delete Activity</button>
        </form>
    </div>
    """
    return shell("Edit Activity", body)


@app.post("/activities/{activity_id}/edit")
def edit_activity(
    activity_id: int,
    external_id: str = Form(...),
    name: str = Form(...),
    trade: str = Form(...),
    start: str = Form(...),
    finish: str = Form(...),
    pct: float = Form(0),
    status: str = Form("NOT_STARTED")
):
    pid = project_id()
    pct = max(0.0, min(100.0, pct))
    c = db()
    c.execute(
        """
        UPDATE activities
        SET external_id=?, name=?, trade=?, start=?, finish=?, pct=?, status=?
        WHERE id=? AND project_id=?
        """,
        (external_id.strip(), name.strip(), trade.strip(), start, finish, pct, status, activity_id, pid)
    )
    c.commit()
    c.close()
    return RedirectResponse(url="/schedule", status_code=303)


@app.post("/activities/{activity_id}/delete")
def delete_activity(activity_id: int):
    pid = project_id()
    c = db()

    c.execute("DELETE FROM field_updates WHERE activity_id=? AND project_id=?", (activity_id, pid))
    c.execute("DELETE FROM production WHERE activity_id=? AND project_id=?", (activity_id, pid))
    c.execute("DELETE FROM make_ready WHERE activity_id=? AND project_id=?", (activity_id, pid))
    c.execute("DELETE FROM risks WHERE activity_id=? AND project_id=?", (activity_id, pid))
    c.execute("DELETE FROM recovery WHERE activity_id=? AND project_id=?", (activity_id, pid))
    c.execute("DELETE FROM activities WHERE id=? AND project_id=?", (activity_id, pid))

    c.commit()
    c.close()
    return RedirectResponse(url="/schedule", status_code=303)


@app.get("/subcontractors/new", response_class=HTMLResponse)
def new_subcontractor_form():
    pid = project_id()
    c = db()
    project = c.execute("SELECT name,number FROM projects WHERE id=?", (pid,)).fetchone()
    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Subcontractors</div>
        <h1>Add Subcontractor</h1>
        <div class="muted">Add a trade partner to {project_label}.</div>
    </div>

    <div class="card" style="max-width:680px;">
        <form method="post" action="/subcontractors/new">
            <label>Company Name</label>
            <input type="text" name="name" placeholder="Example: Valley Electric" required>

            <label>Trade</label>
            <input type="text" name="trade" placeholder="Example: Electrical" required>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Subcontractor</button>
                <a href="/subcontractors" style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">Cancel</a>
            </div>
        </form>
    </div>
    """
    return shell("Add Subcontractor", body)


@app.post("/subcontractors/new")
def create_subcontractor(
    name: str = Form(...),
    trade: str = Form(...)
):
    pid = project_id()
    c = db()
    c.execute(
        "INSERT INTO subs(project_id,name,trade) VALUES(?,?,?)",
        (pid, name.strip(), trade.strip())
    )
    c.commit()
    c.close()
    return RedirectResponse(url="/subcontractors", status_code=303)


@app.get("/daily-report", response_class=HTMLResponse)
def daily_report():
    pid = project_id()
    c = db()

    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    reports = c.execute(
        """
        SELECT *
        FROM daily_reports
        WHERE project_id=?
        ORDER BY report_date DESC, id DESC
        LIMIT 10
        """,
        (pid,)
    ).fetchall()

    analyses = c.execute(
        """
        SELECT *
        FROM daily_report_analysis
        WHERE project_id=?
        ORDER BY id DESC
        """,
        (pid,)
    ).fetchall()

    c.close()

    analysis_by_report = {}
    for a in analyses:
        if a["report_id"] not in analysis_by_report:
            analysis_by_report[a["report_id"]] = a

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    report_cards = ""

    for r in reports:
        analysis = analysis_by_report.get(r["id"])

        if analysis:
            analysis_html = (
                '<div style="margin-top:16px;padding-top:14px;border-top:1px solid #213042;">'
                '<div class="small">BUILDCOMMAND ANALYSIS</div>'
                f'<div style="margin-top:8px;line-height:1.6;">{esc(analysis["analysis_text"]).replace(chr(10), "<br>")}</div>'
                '</div>'
            )
            analyze_button = (
                f'<form method="post" action="/daily-report/{r["id"]}/analyze">'
                '<button type="submit">Analyze Again</button>'
                '</form>'
            )
        else:
            analysis_html = ""
            analyze_button = (
                f'<form method="post" action="/daily-report/{r["id"]}/analyze">'
                '<button type="submit">Analyze Report</button>'
                '</form>'
            )

        report_cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start;">
                <div>
                    <div class="eyebrow">Daily Report</div>
                    <h3 style="margin:6px 0;">{esc(r["report_date"])}</h3>
                    <div class="badge OPEN">{r["manpower"] or 0} workers</div>
                </div>
                <div>{analyze_button}</div>
            </div>

            <div class="small" style="margin-top:14px;">Weather</div>
            <p>{esc(r["weather"]) or "—"}</p>

            <div class="small">Work Completed</div>
            <p>{esc(r["work_completed"]) or "—"}</p>

            <div class="small">Delays / Constraints</div>
            <p>{esc(r["delays"]) or "—"}</p>

            <div class="small">Deliveries</div>
            <p>{esc(r["deliveries"]) or "—"}</p>

            <div class="small">Inspections</div>
            <p>{esc(r["inspections"]) or "—"}</p>

            <div class="small">Safety</div>
            <p>{esc(r["safety"]) or "—"}</p>

            <div class="small">Tomorrow's Plan</div>
            <p>{esc(r["tomorrow_plan"]) or "—"}</p>

            {analysis_html}
        </div>
        """

    if not report_cards:
        report_cards = '<div class="card"><div class="muted">No daily reports yet.</div></div>'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Daily Superintendent Report</div>
        <h1>Capture the job today so BuildCommand can analyze tomorrow.</h1>
        <div class="muted">{project_label}</div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>New Daily Report</h2>

            <form method="post" action="/daily-report">
                <label>Report Date</label>
                <input type="date" name="report_date" value="{date.today().isoformat()}" required>

                <label>Weather</label>
                <input type="text" name="weather" placeholder="Example: Clear, 96°F">

                <label>Total Manpower</label>
                <input type="number" name="manpower" min="0" value="0">

                <label>Work Completed</label>
                <textarea name="work_completed" placeholder="What got completed today?"></textarea>

                <label>Delays / Constraints</label>
                <textarea name="delays" placeholder="Access issues, missing material, RFIs, manpower problems, etc."></textarea>

                <label>Deliveries</label>
                <textarea name="deliveries" placeholder="What arrived or failed to arrive?"></textarea>

                <label>Inspections</label>
                <textarea name="inspections" placeholder="Passed, failed, scheduled, or pending inspections."></textarea>

                <label>Safety Notes</label>
                <textarea name="safety" placeholder="Incidents, observations, toolbox talks, corrective actions."></textarea>

                <label>Tomorrow's Plan</label>
                <textarea name="tomorrow_plan" placeholder="What needs to happen tomorrow?"></textarea>

                <button type="submit">Save Daily Report</button>
            </form>
        </div>

        <div>
            <h2 style="margin-top:0;">Recent Reports</h2>
            {report_cards}
        </div>
    </div>
    """

    return shell("Daily Report", body)


@app.post("/daily-report")
def save_daily_report(
    report_date: str = Form(...),
    weather: str = Form(""),
    manpower: int = Form(0),
    work_completed: str = Form(""),
    delays: str = Form(""),
    deliveries: str = Form(""),
    inspections: str = Form(""),
    safety: str = Form(""),
    tomorrow_plan: str = Form("")
):
    pid = project_id()
    c = db()
    c.execute(
        """
        INSERT INTO daily_reports(
            project_id, report_date, weather, manpower, work_completed,
            delays, deliveries, inspections, safety, tomorrow_plan, created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            report_date,
            weather.strip(),
            manpower,
            work_completed.strip(),
            delays.strip(),
            deliveries.strip(),
            inspections.strip(),
            safety.strip(),
            tomorrow_plan.strip(),
            date.today().isoformat()
        )
    )
    c.commit()
    c.close()
    return RedirectResponse(url="/daily-report", status_code=303)


@app.get("/ai-analysis", response_class=HTMLResponse)
def ai_analysis():
    pid = project_id()
    c = db()

    project = c.execute(
        "SELECT * FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        "SELECT * FROM activities WHERE project_id=? ORDER BY start",
        (pid,)
    ).fetchall()

    risks = c.execute(
        """
        SELECT r.*, a.name activity
        FROM risks r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY r.score DESC
        """,
        (pid,)
    ).fetchall()

    make_ready_items = c.execute(
        """
        SELECT m.*, a.name activity
        FROM make_ready m
        JOIN activities a ON a.id=m.activity_id
        WHERE m.project_id=? AND m.status='OPEN'
        ORDER BY due
        """,
        (pid,)
    ).fetchall()

    report = c.execute(
        """
        SELECT *
        FROM daily_reports
        WHERE project_id=?
        ORDER BY report_date DESC, id DESC
        LIMIT 1
        """,
        (pid,)
    ).fetchone()

    c.close()

    project_name = esc(project["name"]) if project else "Current Project"

    critical = [r for r in risks if r["band"] == "CRITICAL"]
    high = [r for r in risks if r["band"] == "HIGH"]
    in_progress = [a for a in activities if a["status"] == "IN_PROGRESS"]

    top_actions = []

    for r in critical[:3]:
        top_actions.append(
            f'CRITICAL: {esc(r["activity"])} — {esc(r["explanation"])}'
        )

    for item in make_ready_items[:3]:
        top_actions.append(
            f'MAKE READY: {esc(item["title"])} — due {esc(item["due"])}'
        )

    if report:
        delays = (report["delays"] or "").strip()
        inspections = (report["inspections"] or "").strip()
        tomorrow = (report["tomorrow_plan"] or "").strip()

        if delays:
            top_actions.append(f'FIELD DELAY: {esc(delays)}')

        if inspections:
            top_actions.append(f'INSPECTION: {esc(inspections)}')

        if tomorrow:
            top_actions.append(f'TOMORROW: {esc(tomorrow)}')

    if not top_actions:
        top_actions.append(
            "No immediate high-priority issues were found in the current project data."
        )

    action_html = "".join(
        f'<div class="action">{item}</div>'
        for item in top_actions[:7]
    )

    if report:
        report_summary = (
            f'<div class="small">Latest Report: {esc(report["report_date"])}</div>'
            f'<p><b>Manpower:</b> {report["manpower"] or 0}</p>'
            f'<p><b>Work Completed:</b> {esc(report["work_completed"]) or "—"}</p>'
            f'<p><b>Delays:</b> {esc(report["delays"]) or "—"}</p>'
            f'<p><b>Tomorrow:</b> {esc(report["tomorrow_plan"]) or "—"}</p>'
        )
    else:
        report_summary = '<div class="muted">No daily report has been submitted yet.</div>'

    risk_html = "".join(
        (
            f'<div class="action">'
            f'<span class="badge {r["band"]}">{r["band"]}</span> '
            f'<b>{esc(r["activity"])}</b> · {r["score"]:.0f}/100'
            f'<div class="small">{esc(r["explanation"])}</div>'
            f'</div>'
        )
        for r in risks[:6]
    ) or '<div class="muted">No risk records yet.</div>'

    body = f"""
    <div class="hero">
        <div class="eyebrow">BuildCommand Intelligence</div>
        <h1>What needs attention now?</h1>
        <div class="muted">
            Current project analysis for {project_name}.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Critical Risks</div>
            <div class="kpi">{len(critical)}</div>
        </div>
        <div class="card">
            <div class="label">High Risks</div>
            <div class="kpi">{len(high)}</div>
        </div>
        <div class="card">
            <div class="label">Open Make-Ready</div>
            <div class="kpi">{len(make_ready_items)}</div>
        </div>
        <div class="card">
            <div class="label">Active Activities</div>
            <div class="kpi">{len(in_progress)}</div>
        </div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Handle First</h2>
            {action_html}
        </div>

        <div class="card">
            <h2>Latest Field Signal</h2>
            {report_summary}
        </div>
    </div>

    <div class="card">
        <h2>Risk Intelligence</h2>
        {risk_html}
    </div>

    <div class="card">
        <h2>BuildCommand Recommendation</h2>
        <p>
            Focus first on critical risks and open make-ready items, then verify field delays,
            inspections, and tomorrow's plan before committing additional manpower or recovery cost.
        </p>
        <div class="small">
            This is the first intelligence layer. The next version can connect a live AI model
            so BuildCommand can answer natural-language questions about the project.
        </div>
    </div>
    """

    return shell("AI Analysis", body)


def build_project_context(pid):
    c = db()

    project = c.execute(
        "SELECT * FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        "SELECT * FROM activities WHERE project_id=? ORDER BY start",
        (pid,)
    ).fetchall()

    risks = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM risks r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY r.score DESC
        """,
        (pid,)
    ).fetchall()

    make_ready_items = c.execute(
        """
        SELECT m.*, a.external_id, a.name activity
        FROM make_ready m
        JOIN activities a ON a.id=m.activity_id
        WHERE m.project_id=? AND m.status='OPEN'
        ORDER BY due
        """,
        (pid,)
    ).fetchall()

    reports = c.execute(
        """
        SELECT *
        FROM daily_reports
        WHERE project_id=?
        ORDER BY report_date DESC, id DESC
        LIMIT 5
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        "SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",
        (pid,)
    ).fetchall()

    production_rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM production p
        JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=?
        ORDER BY p.work_date DESC, p.id DESC
        LIMIT 12
        """,
        (pid,)
    ).fetchall()

    sub_updates = c.execute(
        """
        SELECT u.*, s.name sub_name, s.trade
        FROM subcontractor_updates u
        JOIN subs s ON s.id=u.sub_id
        WHERE u.project_id=?
        ORDER BY u.update_date DESC, u.id DESC
        LIMIT 15
        """,
        (pid,)
    ).fetchall()

    recovery_rows = c.execute(
        """
        SELECT r.*, a.external_id, a.name activity
        FROM recovery r
        JOIN activities a ON a.id=r.activity_id
        WHERE r.project_id=?
        ORDER BY r.id DESC
        LIMIT 12
        """,
        (pid,)
    ).fetchall()

    action_rows = c.execute(
        """
        SELECT *
        FROM action_items
        WHERE project_id=? AND status='OPEN'
        ORDER BY due, id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    readiness_rows = c.execute(
        """
        SELECT ar.*, a.external_id, a.name activity, a.start
        FROM activity_readiness ar
        JOIN activities a ON a.id=ar.activity_id
        WHERE ar.project_id=?
        ORDER BY a.start
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    procurement_rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM procurement p
        LEFT JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=?
        ORDER BY p.required_on_site, p.id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    issue_rows = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM project_issues i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=? AND i.status!='CLOSED'
        ORDER BY i.due, i.id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    punch_rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM punch_items p
        LEFT JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=? AND p.status!='VERIFIED'
        ORDER BY p.due, p.id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    inspection_rows = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM inspections_tracker i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=? AND i.result!='PASSED'
        ORDER BY i.scheduled_date, i.id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    submittal_rows = c.execute(
        """
        SELECT s.*, a.external_id, a.name activity
        FROM submittals s
        LEFT JOIN activities a ON a.id=s.activity_id
        WHERE s.project_id=? AND s.status NOT IN ('APPROVED','APPROVED_AS_NOTED')
        ORDER BY s.due_date, s.id
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    safety_rows = c.execute(
        """
        SELECT s.*, a.external_id, a.name activity
        FROM safety_items s
        LEFT JOIN activities a ON a.id=s.activity_id
        WHERE s.project_id=? AND s.status!='CLOSED'
        ORDER BY s.event_date DESC, s.id DESC
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    change_rows = c.execute(
        """
        SELECT ce.*, a.external_id, a.name activity
        FROM change_events ce
        LEFT JOIN activities a ON a.id=ce.activity_id
        WHERE ce.project_id=? AND ce.status NOT IN ('APPROVED','REJECTED')
        ORDER BY ce.id DESC
        LIMIT 20
        """,
        (pid,)
    ).fetchall()

    meeting_rows = c.execute(
        """
        SELECT *
        FROM meeting_notes
        WHERE project_id=?
        ORDER BY meeting_date DESC, id DESC
        LIMIT 10
        """,
        (pid,)
    ).fetchall()

    c.close()

    lines = []

    if project:
        lines.append(
            f'PROJECT: {project["number"]} - {project["name"]} | Status: {project["status"]}'
        )

    lines.append("\nSCHEDULE ACTIVITIES:")
    for a in activities:
        lines.append(
            f'- {a["external_id"]}: {a["name"]} | Trade: {a["trade"]} | '
            f'{a["start"]} to {a["finish"]} | {a["pct"]:.0f}% | {a["status"]}'
        )

    lines.append("\nRISKS:")
    for r in risks:
        lines.append(
            f'- {r["band"]} {r["score"]:.0f}/100 | {r["external_id"]} {r["activity"]}: '
            f'{r["explanation"]}'
        )

    lines.append("\nOPEN MAKE-READY ITEMS:")
    for m in make_ready_items:
        lines.append(
            f'- {m["priority"]} | {m["external_id"]} {m["activity"]} | '
            f'{m["title"]} | Reason: {m["reason"]} | Due: {m["due"]}'
        )

    lines.append("\nSUBCONTRACTORS:")
    for s in subs:
        lines.append(f'- {s["name"]} | Trade: {s["trade"]}')

    lines.append("\nRECENT PRODUCTION:")
    for p in production_rows:
        qty = p["qty"] or 0
        plan = p["planned_qty"] or 0
        pct = (qty / plan * 100) if plan > 0 else 0
        lines.append(
            f'- {p["work_date"]} | {p["external_id"]} {p["activity"]} | '
            f'Crew {p["crew"] or 0} | Actual {qty:g} {p["unit"] or ""} | '
            f'Plan {plan:g} | {pct:.0f}% of plan'
        )

    lines.append("\nRECENT SUBCONTRACTOR UPDATES:")
    for u in sub_updates:
        lines.append(
            f'- {u["update_date"]} | {u["sub_name"]} | Trade: {u["trade"]} | '
            f'Manpower: {u["manpower"] or 0} | Status: {u["status"] or "N/A"} | '
            f'Commitment: {u["commitment"] or "N/A"} | Issue: {u["issue"] or "N/A"}'
        )

    lines.append("\nRECOVERY SCENARIOS:")
    for r in recovery_rows:
        days = r["days_recovered"] or 0
        cost = r["est_cost"] or 0
        cpd = (cost / days) if days > 0 else 0
        lines.append(
            f'- {r["external_id"]} {r["activity"]} | '
            f'{r["scenario"]} | Days recovered: {days:.1f} | '
            f'Cost: ${cost:,.0f} | Cost/day: ${cpd:,.0f} | Status: {r["status"]}'
        )

    lines.append("\nOPEN ACTION ITEMS:")
    for a in action_rows:
        lines.append(
            f'- {a["priority"]} | {a["title"]} | Owner: {a["owner"] or "Unassigned"} | '
            f'Due: {a["due"]} | Notes: {a["notes"] or "N/A"}'
        )

    lines.append("\nACTIVITY READINESS:")
    for r in readiness_rows:
        pct, status, _ = readiness_result(r)
        lines.append(
            f'- {r["external_id"]} {r["activity"]} | Starts {r["start"]} | '
            f'Readiness {pct}% | Status: {status} | Notes: {r["notes"] or "N/A"}'
        )

    lines.append("\nSCHEDULE HEALTH:")
    readiness_map = {r["activity_id"]: r for r in readiness_rows}

    for a in activities:
        score, status, _, reasons = schedule_health_status(
            a,
            readiness_map.get(a["id"]),
            production_rows,
            risks
        )
        lines.append(
            f'- {a["external_id"]} {a["name"]} | Health score {score} | '
            f'Status: {status} | Reasons: {"; ".join(reasons)}'
        )

    lines.append("\nPROCUREMENT / LONG LEAD:")
    for p in procurement_rows:
        badge, risk_text = procurement_risk(
            p["required_on_site"],
            p["promised_date"],
            p["status"]
        )
        activity_text = (
            f'{p["external_id"]} {p["activity"]}'
            if p["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {p["item"]} | {activity_text} | Vendor: {p["vendor"] or "N/A"} | '
            f'Required: {p["required_on_site"] or "N/A"} | '
            f'Promised: {p["promised_date"] or "N/A"} | '
            f'Status: {p["status"] or "N/A"} | Risk: {risk_text} | '
            f'Notes: {p["notes"] or "N/A"}'
        )

    lines.append("\nOPEN RFIS / ISSUES:")
    for i in issue_rows:
        activity_text = (
            f'{i["external_id"]} {i["activity"]}'
            if i["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {i["issue_type"]} | {i["priority"]} | {i["title"]} | '
            f'{activity_text} | Owner: {i["owner"] or "Unassigned"} | '
            f'Due: {i["due"] or "N/A"} | Status: {i["status"]} | '
            f'Description: {i["description"] or "N/A"} | '
            f'Response: {i["response"] or "N/A"}'
        )

    lines.append("\nOPEN QUALITY / PUNCH ITEMS:")
    for p in punch_rows:
        activity_text = (
            f'{p["external_id"]} {p["activity"]}'
            if p["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {p["priority"]} | {p["title"]} | Location: {p["location"] or "N/A"} | '
            f'Trade: {p["trade"] or "N/A"} | {activity_text} | '
            f'Owner: {p["owner"] or "Unassigned"} | Due: {p["due"] or "N/A"} | '
            f'Status: {p["status"]} | Description: {p["description"] or "N/A"} | '
            f'Resolution: {p["resolution"] or "N/A"}'
        )

    lines.append("\nOPEN / FAILED INSPECTIONS:")
    for i in inspection_rows:
        activity_text = (
            f'{i["external_id"]} {i["activity"]}'
            if i["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {i["inspection_type"]} | {activity_text} | '
            f'Authority: {i["authority"] or "N/A"} | '
            f'Scheduled: {i["scheduled_date"] or "N/A"} | '
            f'Result: {i["result"]} | '
            f'Reinspection: {i["reinspection_date"] or "N/A"} | '
            f'Notes: {i["notes"] or "N/A"}'
        )

    lines.append("\nOPEN SUBMITTALS:")
    for s in submittal_rows:
        activity_text = (
            f'{s["external_id"]} {s["activity"]}'
            if s["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {s["title"]} | Spec: {s["spec_section"] or "N/A"} | '
            f'{activity_text} | Responsible: {s["responsible_party"] or "Unassigned"} | '
            f'Sent: {s["sent_date"] or "N/A"} | Due: {s["due_date"] or "N/A"} | '
            f'Status: {s["status"]} | Notes: {s["notes"] or "N/A"}'
        )

    lines.append("\nOPEN SAFETY ITEMS:")
    for s in safety_rows:
        activity_text = (
            f'{s["external_id"]} {s["activity"]}'
            if s["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {s["severity"]} | {s["item_type"]} | {s["title"]} | '
            f'Location: {s["location"] or "N/A"} | {activity_text} | '
            f'Responsible: {s["responsible_party"] or "Unassigned"} | '
            f'Status: {s["status"]} | Description: {s["description"] or "N/A"} | '
            f'Corrective action: {s["corrective_action"] or "N/A"}'
        )

    lines.append("\nOPEN CHANGE EVENTS:")
    for ce in change_rows:
        activity_text = (
            f'{ce["external_id"]} {ce["activity"]}'
            if ce["external_id"]
            else "No linked activity"
        )
        lines.append(
            f'- {ce["event_type"]} | {ce["title"]} | {activity_text} | '
            f'Responsible: {ce["responsible_party"] or "Unassigned"} | '
            f'Estimated cost: ${ce["estimated_cost"] or 0:,.0f} | '
            f'Schedule impact: {ce["schedule_days"] or 0:.1f} days | '
            f'Status: {ce["status"]} | Description: {ce["description"] or "N/A"}'
        )

    lines.append("\nRECENT MEETING NOTES:")
    for m in meeting_rows:
        lines.append(
            f'- {m["meeting_date"]} | {m["meeting_type"]} | {m["title"]} | '
            f'Attendees: {m["attendees"] or "N/A"} | '
            f'Decisions: {m["decisions"] or "N/A"} | '
            f'Commitments: {m["commitments"] or "N/A"} | '
            f'Follow-up: {m["follow_up"] or "N/A"}'
        )

    lines.append("\nRECENT DAILY REPORTS:")
    for r in reports:
        lines.append(
            f'- Date: {r["report_date"]} | Weather: {r["weather"] or "N/A"} | '
            f'Manpower: {r["manpower"] or 0}\n'
            f'  Work completed: {r["work_completed"] or "N/A"}\n'
            f'  Delays: {r["delays"] or "N/A"}\n'
            f'  Deliveries: {r["deliveries"] or "N/A"}\n'
            f'  Inspections: {r["inspections"] or "N/A"}\n'
            f'  Safety: {r["safety"] or "N/A"}\n'
            f'  Tomorrow plan: {r["tomorrow_plan"] or "N/A"}'
        )

    return "\n".join(lines)


@app.get("/assistant", response_class=HTMLResponse)
def assistant_page():
    pid = project_id()
    c = db()
    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()
    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    api_ready = bool(os.environ.get("OPENAI_API_KEY"))

    status_html = (
        '<span class="badge READY">AI CONNECTED</span>'
        if api_ready
        else '<span class="badge HIGH">API KEY NEEDED</span>'
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">BuildCommand AI Copilot</div>
        <h1>Ask the project.</h1>
        <div class="muted">{project_label}</div>
        <div style="margin-top:10px;">{status_html}</div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Ask BuildCommand</h2>

            <form method="post" action="/assistant">
                <label>Your Question</label>
                <textarea
                    name="question"
                    placeholder="Example: What should I worry about today?"
                    required
                ></textarea>

                <button type="submit">Analyze Project</button>
            </form>

            <div class="small" style="margin-top:14px;">
                Try: What should I handle first? Which activity could delay us?
                What should I ask the MEP subcontractor? What should tomorrow's plan include?
            </div>
        </div>

        <div class="card">
            <h2>How it works</h2>
            <p>
                BuildCommand sends the selected project's schedule, risks, open make-ready items,
                subcontractors, and recent daily reports to the AI with your question.
            </p>
            <p class="small">
                The AI is instructed to stay grounded in project data and clearly identify when
                information is missing instead of inventing jobsite facts.
            </p>
        </div>
    </div>
    """

    return shell("AI Assistant", body)


@app.post("/assistant", response_class=HTMLResponse)
def assistant_answer(question: str = Form(...)):
    pid = project_id()

    c = db()
    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()
    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    api_key = os.environ.get("OPENAI_API_KEY")

    if not api_key:
        answer = """
        OPENAI_API_KEY is not configured yet.

        Add the key in Render under your service's Environment settings,
        then redeploy the service. Do not paste the API key into full_app.py.
        """
    else:
        context = build_project_context(pid)

        instructions = """
You are BuildCommand AI, a construction superintendent and project-execution copilot.

Use only the project information supplied in the prompt as job-specific facts.
Do not invent schedule status, subcontractor commitments, inspections, deliveries,
manpower, safety conditions, or field progress.

Prioritize:
1. immediate field risk,
2. schedule impact,
3. make-ready constraints,
4. inspections and deliveries,
5. subcontractor follow-up,
6. practical next actions.

When useful, structure the answer as:
- Handle first
- Why it matters
- Who to follow up with
- Next action

Keep answers concise, practical, and written for a working superintendent.
If the project data is insufficient, clearly say what information is missing.
"""

        user_input = f"""
PROJECT DATA
------------
{context}

SUPERINTENDENT QUESTION
-----------------------
{question}
"""

        try:
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model="gpt-5.6",
                instructions=instructions,
                input=user_input
            )
            answer = response.output_text
        except Exception as exc:
            answer = (
                "BuildCommand could not reach the AI service. "
                f"Error: {str(exc)}"
            )

    answer_html = esc(answer).replace("\n", "<br>")

    body = f"""
    <div class="hero">
        <div class="eyebrow">BuildCommand AI Copilot</div>
        <h1>Project Answer</h1>
        <div class="muted">{project_label}</div>
    </div>

    <div class="grid2">
        <div class="card">
            <div class="small">YOUR QUESTION</div>
            <h3>{esc(question)}</h3>

            <a href="/assistant"
               style="color:#f0b44d;text-decoration:none;font-weight:700;">
                ← Ask another question
            </a>
        </div>

        <div class="card">
            <div class="small">BUILDCOMMAND AI</div>
            <div style="margin-top:12px;line-height:1.65;">
                {answer_html}
            </div>
        </div>
    </div>
    """

    return shell("AI Assistant", body)


@app.get("/make-ready/new", response_class=HTMLResponse)
def new_make_ready_form():
    pid = project_id()
    c = db()

    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    options = "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    if not options:
        body = """
        <div class="hero">
            <div class="eyebrow">Make Ready</div>
            <h1>Add Make-Ready Item</h1>
        </div>
        <div class="card">
            <p>This project has no activities yet. Add a schedule activity first.</p>
            <a href="/activities/new" style="color:#f0b44d;font-weight:700;text-decoration:none;">
                + Add Activity
            </a>
        </div>
        """
        return shell("Add Make-Ready", body)

    body = f"""
    <div class="hero">
        <div class="eyebrow">Make Ready</div>
        <h1>Add Make-Ready Item</h1>
        <div class="muted">{project_label}</div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/make-ready/new">

            <label>Activity</label>
            <select name="activity_id" required>
                {options}
            </select>

            <label>Blocker / Action Title</label>
            <input
                type="text"
                name="title"
                placeholder="Example: Confirm electrical gear delivery"
                required
            >

            <label>Why It Matters</label>
            <textarea
                name="reason"
                placeholder="Describe the constraint, dependency, or field impact."
                required
            ></textarea>

            <div class="grid2">
                <div>
                    <label>Clear By</label>
                    <input type="date" name="due" required>
                </div>

                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="WATCH">Watch</option>
                        <option value="LOW">Low</option>
                    </select>
                </div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Make-Ready Item</button>

                <a href="/make-ready"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Add Make-Ready", body)


@app.post("/make-ready/new")
def create_make_ready(
    activity_id: int = Form(...),
    title: str = Form(...),
    reason: str = Form(...),
    due: str = Form(...),
    priority: str = Form("HIGH")
):
    pid = project_id()

    c = db()

    activity = c.execute(
        "SELECT id FROM activities WHERE id=? AND project_id=?",
        (activity_id, pid)
    ).fetchone()

    if activity:
        c.execute(
            """
            INSERT INTO make_ready(
                project_id,
                activity_id,
                title,
                reason,
                due,
                priority,
                status
            )
            VALUES(?,?,?,?,?,?,?)
            """,
            (
                pid,
                activity_id,
                title.strip(),
                reason.strip(),
                due,
                priority,
                "OPEN"
            )
        )
        c.commit()

    c.close()

    return RedirectResponse(url="/make-ready", status_code=303)


@app.post("/make-ready/{item_id}/close")
def close_make_ready(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE make_ready
        SET status='COMPLETE'
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/make-ready", status_code=303)


@app.post("/daily-report/{report_id}/analyze")
def analyze_daily_report(report_id: int):
    pid = project_id()
    c = db()

    report = c.execute(
        """
        SELECT *
        FROM daily_reports
        WHERE id=? AND project_id=?
        """,
        (report_id, pid)
    ).fetchone()

    project = c.execute(
        "SELECT * FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    activities = c.execute(
        "SELECT * FROM activities WHERE project_id=? ORDER BY start",
        (pid,)
    ).fetchall()

    c.close()

    if not report:
        return RedirectResponse(url="/daily-report", status_code=303)

    api_key = os.environ.get("OPENAI_API_KEY")

    if not api_key:
        analysis_text = (
            "OPENAI_API_KEY is not configured. Add the key in Render Environment settings "
            "to enable automatic report analysis."
        )
    else:
        schedule_lines = []
        for a in activities:
            schedule_lines.append(
                f'{a["external_id"]} | {a["name"]} | {a["trade"]} | '
                f'{a["start"]} to {a["finish"]} | {a["pct"]:.0f}% | {a["status"]}'
            )

        schedule_text = "\n".join(schedule_lines) or "No schedule activities entered."

        prompt = f"""
PROJECT
{project["number"] if project else ""} - {project["name"] if project else ""}

SCHEDULE
{schedule_text}

DAILY REPORT
Date: {report["report_date"]}
Weather: {report["weather"] or "N/A"}
Manpower: {report["manpower"] or 0}
Work completed: {report["work_completed"] or "N/A"}
Delays / constraints: {report["delays"] or "N/A"}
Deliveries: {report["deliveries"] or "N/A"}
Inspections: {report["inspections"] or "N/A"}
Safety: {report["safety"] or "N/A"}
Tomorrow plan: {report["tomorrow_plan"] or "N/A"}
"""

        instructions = """
You are BuildCommand AI, a construction superintendent field-intelligence copilot.

Analyze the daily report against the schedule information provided.
Do not invent facts that are not present.

Return a concise superintendent review with these headings:
HANDLE FIRST
SCHEDULE IMPACT
SUBCONTRACTOR / FOLLOW-UP
TOMORROW READINESS
MISSING INFORMATION

Call out specific delays, inspection issues, delivery risks, manpower concerns,
or tomorrow-plan gaps when supported by the report.
"""

        try:
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model="gpt-5.6",
                instructions=instructions,
                input=prompt
            )
            analysis_text = response.output_text
        except Exception as exc:
            analysis_text = f"AI analysis failed: {str(exc)}"

    c = db()
    c.execute(
        "DELETE FROM daily_report_analysis WHERE project_id=? AND report_id=?",
        (pid, report_id)
    )
    c.execute(
        """
        INSERT INTO daily_report_analysis(
            project_id,
            report_id,
            analysis_text,
            created
        )
        VALUES(?,?,?,?)
        """,
        (
            pid,
            report_id,
            analysis_text,
            date.today().isoformat()
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/daily-report", status_code=303)


@app.get("/actions", response_class=HTMLResponse)
def actions_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT *
        FROM action_items
        WHERE project_id=?
        ORDER BY
            CASE status
                WHEN 'OPEN' THEN 1
                WHEN 'COMPLETE' THEN 2
                ELSE 3
            END,
            CASE priority
                WHEN 'CRITICAL' THEN 1
                WHEN 'HIGH' THEN 2
                WHEN 'WATCH' THEN 3
                WHEN 'LOW' THEN 4
                ELSE 5
            END,
            due
        """,
        (pid,)
    ).fetchall()

    c.close()

    today = date.today().isoformat()

    open_items = [r for r in rows if r["status"] == "OPEN"]
    complete_items = [r for r in rows if r["status"] == "COMPLETE"]
    overdue_items = [
        r for r in open_items
        if r["due"] and r["due"] < today
    ]

    open_html = ""

    for r in open_items:
        overdue = bool(r["due"] and r["due"] < today)
        due_text = f'Due {esc(r["due"])}'

        if overdue:
            due_text += " · OVERDUE"

        badge = r["priority"] if r["priority"] in ["CRITICAL","HIGH","WATCH","LOW"] else "OPEN"

        open_html += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["priority"])}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">Owner: {esc(r["owner"]) or "Unassigned"}</div>
                </div>

                <form method="post" action="/actions/{r["id"]}/complete">
                    <button type="submit">Mark Complete</button>
                </form>
            </div>

            <p>{esc(r["notes"]) or "No notes entered."}</p>
            <div class="small">{due_text}</div>
        </div>
        """

    if not open_html:
        open_html = '<div class="card"><div class="muted">No open action items.</div></div>'

    complete_html = "".join(
        f"""
        <div class="action">
            <span class="badge COMPLETE">COMPLETE</span>
            <b>{esc(r["title"])}</b>
            <div class="small">
                Owner: {esc(r["owner"]) or "Unassigned"} · Due {esc(r["due"]) or "—"}
            </div>
        </div>
        """
        for r in complete_items[:12]
    ) or '<div class="muted">No completed actions yet.</div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Action Center</div>
                <h1>Turn project intelligence into accountable action.</h1>
                <div class="muted">
                    Assign ownership, due dates, and priority to the work that cannot fall through the cracks.
                </div>
            </div>

            <a href="/actions/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Action
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Open Actions</div>
            <div class="kpi">{len(open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue</div>
            <div class="kpi">{len(overdue_items)}</div>
        </div>

        <div class="card">
            <div class="label">Critical</div>
            <div class="kpi">{sum(r["priority"] == "CRITICAL" for r in open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Completed</div>
            <div class="kpi">{len(complete_items)}</div>
        </div>
    </div>

    <div class="grid2">
        <div>
            <h2>Open Actions</h2>
            {open_html}
        </div>

        <div class="card">
            <h2>Recently Completed</h2>
            {complete_html}
        </div>
    </div>
    """

    return shell("Action Center", body)


@app.get("/actions/new", response_class=HTMLResponse)
def new_action_form():
    pid = project_id()
    c = db()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    project = c.execute(
        "SELECT name,number FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    c.close()

    owner_options = '<option value="">Unassigned</option>'
    owner_options += '<option value="Superintendent">Superintendent</option>'
    owner_options += '<option value="Project Manager">Project Manager</option>'

    for s in subs:
        owner_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    project_label = "Current Project"
    if project:
        project_label = f'{esc(project["number"])} - {esc(project["name"])}'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Action Center</div>
        <h1>Add Action Item</h1>
        <div class="muted">{project_label}</div>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/actions/new">

            <label>Action</label>
            <input
                type="text"
                name="title"
                placeholder="Example: Confirm switchgear delivery date"
                required
            >

            <label>Owner</label>
            <select name="owner">
                {owner_options}
            </select>

            <div class="grid2">
                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="WATCH">Watch</option>
                        <option value="LOW">Low</option>
                    </select>
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due" required>
                </div>
            </div>

            <label>Notes</label>
            <textarea
                name="notes"
                placeholder="What specifically needs to happen?"
            ></textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Action</button>

                <a href="/actions"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Add Action", body)


@app.post("/actions/new")
def create_action(
    title: str = Form(...),
    owner: str = Form(""),
    priority: str = Form("HIGH"),
    due: str = Form(...),
    notes: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        INSERT INTO action_items(
            project_id,
            title,
            owner,
            priority,
            due,
            status,
            notes,
            created
        )
        VALUES(?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            title.strip(),
            owner.strip(),
            priority,
            due,
            "OPEN",
            notes.strip(),
            date.today().isoformat()
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/actions", status_code=303)


@app.post("/actions/{action_id}/complete")
def complete_action(action_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE action_items
        SET status='COMPLETE'
        WHERE id=? AND project_id=?
        """,
        (action_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/actions", status_code=303)


def readiness_result(row):
    checks = [
        row["drawings"],
        row["material"],
        row["manpower"],
        row["predecessor"],
        row["access_ready"],
        row["inspection"],
        row["equipment"],
    ]

    complete = sum(1 for x in checks if x)
    pct = round((complete / len(checks)) * 100)

    critical_ready = bool(
        row["drawings"]
        and row["material"]
        and row["manpower"]
        and row["predecessor"]
        and row["access_ready"]
    )

    if complete == len(checks):
        status = "READY"
        badge = "READY"
    elif critical_ready and complete >= 5:
        status = "AT RISK"
        badge = "WATCH"
    else:
        status = "NOT READY"
        badge = "CRITICAL"

    return pct, status, badge


@app.get("/readiness", response_class=HTMLResponse)
def readiness_page():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT *
        FROM activities
        WHERE project_id=? AND status!='COMPLETE'
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    readiness_rows = c.execute(
        """
        SELECT *
        FROM activity_readiness
        WHERE project_id=?
        """,
        (pid,)
    ).fetchall()

    c.close()

    readiness_by_activity = {
        r["activity_id"]: r
        for r in readiness_rows
    }

    cards = ""
    ready_count = 0
    risk_count = 0
    not_ready_count = 0

    for a in activities:
        r = readiness_by_activity.get(a["id"])

        if r:
            pct, status, badge = readiness_result(r)
            notes = esc(r["notes"]) or "No readiness notes."
        else:
            pct, status, badge = 0, "NOT READY", "CRITICAL"
            notes = "Readiness has not been reviewed."

        if status == "READY":
            ready_count += 1
        elif status == "AT RISK":
            risk_count += 1
        else:
            not_ready_count += 1

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <div class="eyebrow">{esc(a["external_id"])}</div>
                    <h3 style="margin:6px 0;">{esc(a["name"])}</h3>
                    <div class="muted">{esc(a["trade"])} · Starts {esc(a["start"])}</div>
                </div>

                <span class="badge {badge}">{status}</span>
            </div>

            <div style="margin-top:14px;">
                <div class="label">Readiness</div>
                <div class="kpi">{pct}%</div>
            </div>

            <p>{notes}</p>

            <a href="/readiness/{a["id"]}"
               style="color:#f0b44d;text-decoration:none;font-weight:700;">
                Review Readiness →
            </a>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No incomplete activities found.</div></div>'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Lookahead Readiness</div>
        <h1>Is upcoming work actually ready to start?</h1>
        <div class="muted">
            Verify the conditions that must be true before crews hit the field.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Activities Reviewed</div>
            <div class="kpi">{len(activities)}</div>
        </div>

        <div class="card">
            <div class="label">Ready</div>
            <div class="kpi">{ready_count}</div>
        </div>

        <div class="card">
            <div class="label">At Risk</div>
            <div class="kpi">{risk_count}</div>
        </div>

        <div class="card">
            <div class="label">Not Ready</div>
            <div class="kpi">{not_ready_count}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Readiness", body)


@app.get("/readiness/{activity_id}", response_class=HTMLResponse)
def readiness_form(activity_id: int):
    pid = project_id()
    c = db()

    activity = c.execute(
        """
        SELECT *
        FROM activities
        WHERE id=? AND project_id=?
        """,
        (activity_id, pid)
    ).fetchone()

    row = c.execute(
        """
        SELECT *
        FROM activity_readiness
        WHERE activity_id=? AND project_id=?
        """,
        (activity_id, pid)
    ).fetchone()

    c.close()

    if not activity:
        return RedirectResponse(url="/readiness", status_code=303)

    def checked(field):
        return "checked" if row and row[field] else ""

    notes = esc(row["notes"]) if row else ""

    body = f"""
    <div class="hero">
        <div class="eyebrow">Lookahead Readiness</div>
        <h1>{esc(activity["external_id"])} - {esc(activity["name"])}</h1>
        <div class="muted">
            {esc(activity["trade"])} · {esc(activity["start"])} to {esc(activity["finish"])}
        </div>
    </div>

    <div class="card" style="max-width:820px;">
        <h2>Start Readiness Checklist</h2>

        <form method="post" action="/readiness/{activity_id}">
            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="drawings" value="1" {checked("drawings")}>
                <span class="form-check-label">Drawings / approved information are available</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="material" value="1" {checked("material")}>
                <span class="form-check-label">Required material is on site or confirmed</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="manpower" value="1" {checked("manpower")}>
                <span class="form-check-label">Manpower is committed</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="predecessor" value="1" {checked("predecessor")}>
                <span class="form-check-label">Predecessor work is complete</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="access_ready" value="1" {checked("access_ready")}>
                <span class="form-check-label">Work area and access are ready</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="inspection" value="1" {checked("inspection")}>
                <span class="form-check-label">Required inspections / prerequisites are cleared</span>
            </label>

            <label class="form-check">
                <input class="form-check-input" type="checkbox" name="equipment" value="1" {checked("equipment")}>
                <span class="form-check-label">Required equipment / tools are available</span>
            </label>

            <label style="display:block;margin-top:18px;">Readiness Notes</label>
            <textarea
                name="notes"
                placeholder="What is missing, who owns it, or what needs to happen before start?"
            >{notes}</textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Readiness</button>

                <a href="/readiness"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Back
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Readiness Review", body)


@app.post("/readiness/{activity_id}")
def save_readiness(
    activity_id: int,
    drawings: int = Form(0),
    material: int = Form(0),
    manpower: int = Form(0),
    predecessor: int = Form(0),
    access_ready: int = Form(0),
    inspection: int = Form(0),
    equipment: int = Form(0),
    notes: str = Form("")
):
    pid = project_id()
    c = db()

    activity = c.execute(
        "SELECT id FROM activities WHERE id=? AND project_id=?",
        (activity_id, pid)
    ).fetchone()

    if activity:
        c.execute(
            """
            INSERT INTO activity_readiness(
                project_id,
                activity_id,
                drawings,
                material,
                manpower,
                predecessor,
                access_ready,
                inspection,
                equipment,
                notes,
                updated
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(project_id, activity_id)
            DO UPDATE SET
                drawings=excluded.drawings,
                material=excluded.material,
                manpower=excluded.manpower,
                predecessor=excluded.predecessor,
                access_ready=excluded.access_ready,
                inspection=excluded.inspection,
                equipment=excluded.equipment,
                notes=excluded.notes,
                updated=excluded.updated
            """,
            (
                pid,
                activity_id,
                1 if drawings else 0,
                1 if material else 0,
                1 if manpower else 0,
                1 if predecessor else 0,
                1 if access_ready else 0,
                1 if inspection else 0,
                1 if equipment else 0,
                notes.strip(),
                date.today().isoformat()
            )
        )
        c.commit()

    c.close()

    return RedirectResponse(url="/readiness", status_code=303)


def schedule_health_status(activity, readiness_row, production_rows, risk_rows):
    today = date.today().isoformat()

    pct = activity["pct"] or 0
    start = activity["start"] or ""
    finish = activity["finish"] or ""

    reasons = []
    score = 0

    if finish and finish < today and pct < 100:
        score += 40
        reasons.append("Finish date has passed and activity is incomplete.")

    if start and start <= today and pct == 0 and activity["status"] != "COMPLETE":
        score += 20
        reasons.append("Activity has started by date but shows 0% complete.")

    if readiness_row:
        readiness_pct, readiness_status, _ = readiness_result(readiness_row)

        if readiness_status == "NOT READY":
            score += 25
            reasons.append(f"Readiness is only {readiness_pct}% and activity is NOT READY.")
        elif readiness_status == "AT RISK":
            score += 12
            reasons.append(f"Readiness is {readiness_pct}% and activity is AT RISK.")

    related_risks = [
        r for r in risk_rows
        if r["activity_id"] == activity["id"]
    ]

    for r in related_risks:
        if r["band"] == "CRITICAL":
            score += 25
            reasons.append("Critical risk is open.")
        elif r["band"] == "HIGH":
            score += 15
            reasons.append("High risk is open.")

    related_prod = [
        p for p in production_rows
        if p["activity_id"] == activity["id"]
    ]

    if related_prod:
        latest = related_prod[0]
        qty = latest["qty"] or 0
        plan = latest["planned_qty"] or 0

        if plan > 0:
            prod_pct = (qty / plan) * 100

            if prod_pct < 90:
                score += 20
                reasons.append(f"Latest production is {prod_pct:.0f}% of plan.")
            elif prod_pct < 100:
                score += 8
                reasons.append(f"Latest production is {prod_pct:.0f}% of plan.")

    score = min(100, score)

    if score >= 60:
        status = "CRITICAL"
        badge = "CRITICAL"
    elif score >= 35:
        status = "HIGH"
        badge = "HIGH"
    elif score >= 15:
        status = "WATCH"
        badge = "WATCH"
    else:
        status = "STABLE"
        badge = "READY"

    if not reasons:
        reasons.append("No significant schedule-health warning signals found.")

    return score, status, badge, reasons


@app.get("/schedule-health", response_class=HTMLResponse)
def schedule_health_page():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT *
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    readiness_rows = c.execute(
        """
        SELECT *
        FROM activity_readiness
        WHERE project_id=?
        """,
        (pid,)
    ).fetchall()

    production_rows = c.execute(
        """
        SELECT *
        FROM production
        WHERE project_id=?
        ORDER BY work_date DESC,id DESC
        """,
        (pid,)
    ).fetchall()

    risk_rows = c.execute(
        """
        SELECT *
        FROM risks
        WHERE project_id=?
        """,
        (pid,)
    ).fetchall()

    c.close()

    readiness_by_activity = {
        r["activity_id"]: r
        for r in readiness_rows
    }

    health_rows = []

    for a in activities:
        score, status, badge, reasons = schedule_health_status(
            a,
            readiness_by_activity.get(a["id"]),
            production_rows,
            risk_rows
        )

        health_rows.append(
            (score, a, status, badge, reasons)
        )

    health_rows.sort(key=lambda x: x[0], reverse=True)

    critical_count = sum(1 for x in health_rows if x[2] == "CRITICAL")
    high_count = sum(1 for x in health_rows if x[2] == "HIGH")
    watch_count = sum(1 for x in health_rows if x[2] == "WATCH")
    stable_count = sum(1 for x in health_rows if x[2] == "STABLE")

    cards = ""

    for score, a, status, badge, reasons in health_rows:
        reason_html = "".join(
            f'<div class="small">• {esc(reason)}</div>'
            for reason in reasons
        )

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <div class="eyebrow">{esc(a["external_id"])}</div>
                    <h3 style="margin:6px 0;">{esc(a["name"])}</h3>
                    <div class="muted">
                        {esc(a["trade"])} · {esc(a["start"])} to {esc(a["finish"])}
                    </div>
                </div>

                <span class="badge {badge}">{status}</span>
            </div>

            <div class="grid3" style="margin-top:16px;">
                <div>
                    <div class="label">Health Score</div>
                    <div class="kpi">{score}</div>
                </div>

                <div>
                    <div class="label">Complete</div>
                    <div class="kpi">{(a["pct"] or 0):.0f}%</div>
                </div>

                <div>
                    <div class="label">Status</div>
                    <div style="font-size:18px;font-weight:800;">
                        {esc(a["status"]).replace("_"," ").title()}
                    </div>
                </div>
            </div>

            <div style="margin-top:14px;">
                {reason_html}
            </div>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No schedule activities found.</div></div>'

    body = f"""
    <div class="hero">
        <div class="eyebrow">Schedule Health</div>
        <h1>Which activities are drifting before the schedule update catches it?</h1>
        <div class="muted">
            Combines schedule dates, progress, readiness, production, and risk signals.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Critical</div>
            <div class="kpi">{critical_count}</div>
        </div>

        <div class="card">
            <div class="label">High</div>
            <div class="kpi">{high_count}</div>
        </div>

        <div class="card">
            <div class="label">Watch</div>
            <div class="kpi">{watch_count}</div>
        </div>

        <div class="card">
            <div class="label">Stable</div>
            <div class="kpi">{stable_count}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Schedule Health", body)


@app.get("/project-settings", response_class=HTMLResponse)
def project_settings_page():
    pid = project_id()
    c = db()

    project = c.execute(
        "SELECT * FROM projects WHERE id=?",
        (pid,)
    ).fetchone()

    counts = {
        "activities": c.execute(
            "SELECT COUNT(*) n FROM activities WHERE project_id=?",
            (pid,)
        ).fetchone()["n"],
        "risks": c.execute(
            "SELECT COUNT(*) n FROM risks WHERE project_id=?",
            (pid,)
        ).fetchone()["n"],
        "make_ready": c.execute(
            "SELECT COUNT(*) n FROM make_ready WHERE project_id=?",
            (pid,)
        ).fetchone()["n"],
        "daily_reports": c.execute(
            "SELECT COUNT(*) n FROM daily_reports WHERE project_id=?",
            (pid,)
        ).fetchone()["n"],
    }

    c.close()

    if not project:
        return RedirectResponse(url="/", status_code=303)

    statuses = ["ACTIVE", "PLANNING", "ON_HOLD", "COMPLETE"]
    status_options = "".join(
        f'<option value="{s}" {"selected" if project["status"] == s else ""}>{s.replace("_"," ").title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Project Settings</div>
        <h1>{esc(project["number"])} - {esc(project["name"])}</h1>
        <div class="muted">
            Manage the selected project's identity and lifecycle.
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Activities</div>
            <div class="kpi">{counts["activities"]}</div>
        </div>

        <div class="card">
            <div class="label">Risks</div>
            <div class="kpi">{counts["risks"]}</div>
        </div>

        <div class="card">
            <div class="label">Make Ready</div>
            <div class="kpi">{counts["make_ready"]}</div>
        </div>

        <div class="card">
            <div class="label">Daily Reports</div>
            <div class="kpi">{counts["daily_reports"]}</div>
        </div>
    </div>

    <div class="grid2">
        <div class="card">
            <h2>Edit Project</h2>

            <form method="post" action="/project-settings/edit">
                <label>Project Name</label>
                <input
                    type="text"
                    name="name"
                    value="{esc(project["name"])}"
                    required
                >

                <label>Project Number</label>
                <input
                    type="text"
                    name="number"
                    value="{esc(project["number"])}"
                    required
                >

                <label>Status</label>
                <select name="status">
                    {status_options}
                </select>

                <button type="submit">Save Project Changes</button>
            </form>
        </div>

        <div class="card">
            <h2>Delete Project</h2>

            <p>
                Deleting a project removes its schedule activities, risks, make-ready items,
                field updates, production records, daily reports, subcontractor updates,
                actions, readiness records, recovery scenarios, and saved analyses.
            </p>

            <div class="small">
                This cannot be undone.
            </div>

            <form method="post"
                  action="/project-settings/delete"
                  style="margin-top:18px;">
                <label>Type DELETE to confirm</label>
                <input
                    type="text"
                    name="confirm_text"
                    placeholder="DELETE"
                    required
                >

                <button type="submit"
                        style="background:#492324;color:#ffb0b0;">
                    Delete Project
                </button>
            </form>
        </div>
    </div>
    """

    return shell("Project Settings", body)


@app.post("/project-settings/edit")
def edit_project_settings(
    name: str = Form(...),
    number: str = Form(...),
    status: str = Form(...)
):
    pid = project_id()

    allowed_statuses = {"ACTIVE", "PLANNING", "ON_HOLD", "COMPLETE"}
    if status not in allowed_statuses:
        status = "ACTIVE"

    c = db()
    c.execute(
        """
        UPDATE projects
        SET name=?, number=?, status=?
        WHERE id=?
        """,
        (
            name.strip(),
            number.strip(),
            status,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/project-settings", status_code=303)


@app.post("/project-settings/delete")
def delete_project_settings(confirm_text: str = Form(...)):
    pid = project_id()

    if confirm_text.strip().upper() != "DELETE":
        return RedirectResponse(url="/project-settings", status_code=303)

    c = db()

    activity_ids = [
        r["id"]
        for r in c.execute(
            "SELECT id FROM activities WHERE project_id=?",
            (pid,)
        ).fetchall()
    ]

    # Delete project-scoped tables first.
    tables = [
        "daily_report_analysis",
        "daily_reports",
        "subcontractor_updates",
        "action_items",
        "activity_readiness",
        "procurement",
        "project_issues",
        "punch_items",
        "inspections_tracker",
        "submittals",
        "safety_items",
        "change_events",
        "meeting_notes",
        "field_updates",
        "production",
        "make_ready",
        "risks",
        "recovery",
        "memory",
        "subs",
    ]

    for table in tables:
        c.execute(
            f"DELETE FROM {table} WHERE project_id=?",
            (pid,)
        )

    c.execute(
        "DELETE FROM activities WHERE project_id=?",
        (pid,)
    )

    c.execute(
        "DELETE FROM projects WHERE id=?",
        (pid,)
    )

    next_project = c.execute(
        "SELECT id FROM projects ORDER BY id LIMIT 1"
    ).fetchone()

    if next_project:
        c.execute(
            """
            INSERT INTO app_state(id, selected_project_id)
            VALUES(1, ?)
            ON CONFLICT(id)
            DO UPDATE SET selected_project_id=excluded.selected_project_id
            """,
            (next_project["id"],)
        )
    else:
        c.execute(
            "DELETE FROM app_state WHERE id=1"
        )

    c.commit()
    c.close()

    if next_project:
        return RedirectResponse(url="/", status_code=303)

    return RedirectResponse(url="/projects/new", status_code=303)


def procurement_risk(required_on_site, promised_date, status):
    if status == "DELIVERED":
        return "READY", "DELIVERED"

    if not required_on_site:
        return "WATCH", "NO REQUIRED DATE"

    if not promised_date:
        return "CRITICAL", "NO PROMISED DATE"

    if promised_date > required_on_site:
        return "CRITICAL", "LATE"

    if status in ["RELEASED", "FABRICATION", "SHIPPED"]:
        return "WATCH", status

    return "HIGH", status or "OPEN"


@app.get("/procurement", response_class=HTMLResponse)
def procurement_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM procurement p
        LEFT JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=?
        ORDER BY
            CASE p.status
                WHEN 'DELIVERED' THEN 5
                WHEN 'SHIPPED' THEN 4
                WHEN 'FABRICATION' THEN 3
                WHEN 'RELEASED' THEN 2
                ELSE 1
            END,
            p.required_on_site
        """,
        (pid,)
    ).fetchall()

    c.close()

    critical = 0
    watch = 0
    delivered = 0

    cards = ""

    for r in rows:
        badge, risk_text = procurement_risk(
            r["required_on_site"],
            r["promised_date"],
            r["status"]
        )

        if badge == "CRITICAL":
            critical += 1
        elif badge == "WATCH":
            watch += 1

        if r["status"] == "DELIVERED":
            delivered += 1

        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{risk_text}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["item"])}</h3>
                    <div class="muted">{activity_text}</div>
                </div>

                <a href="/procurement/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <div class="grid3" style="margin-top:16px;">
                <div>
                    <div class="label">Vendor / Sub</div>
                    <div>{esc(r["vendor"]) or "—"}</div>
                </div>

                <div>
                    <div class="label">Required On Site</div>
                    <div>{esc(r["required_on_site"]) or "—"}</div>
                </div>

                <div>
                    <div class="label">Promised</div>
                    <div>{esc(r["promised_date"]) or "—"}</div>
                </div>
            </div>

            <p>{esc(r["notes"]) or "No notes entered."}</p>
            <div class="small">Status: {esc(r["status"]).replace("_"," ").title()}</div>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No procurement items added yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Procurement Intelligence</div>
                <h1>Know what material can hurt the schedule before it arrives late.</h1>
                <div class="muted">
                    Track required-on-site dates, vendor commitments, and long-lead exposure.
                </div>
            </div>

            <a href="/procurement/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Procurement Item
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Items</div>
            <div class="kpi">{len(rows)}</div>
        </div>

        <div class="card">
            <div class="label">Critical</div>
            <div class="kpi">{critical}</div>
        </div>

        <div class="card">
            <div class="label">Watch</div>
            <div class="kpi">{watch}</div>
        </div>

        <div class="card">
            <div class="label">Delivered</div>
            <div class="kpi">{delivered}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Procurement", body)


@app.get("/procurement/new", response_class=HTMLResponse)
def new_procurement_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    options = '<option value="">No linked activity</option>'
    options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Procurement Intelligence</div>
        <h1>Add Procurement Item</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/procurement/new">

            <label>Material / Equipment</label>
            <input
                type="text"
                name="item"
                placeholder="Example: Main electrical switchgear"
                required
            >

            <label>Linked Activity</label>
            <select name="activity_id">
                {options}
            </select>

            <label>Vendor / Subcontractor</label>
            <input
                type="text"
                name="vendor"
                placeholder="Example: Valley Electric / Eaton"
            >

            <div class="grid2">
                <div>
                    <label>Required On Site</label>
                    <input type="date" name="required_on_site" required>
                </div>

                <div>
                    <label>Promised Date</label>
                    <input type="date" name="promised_date">
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                <option value="NOT_RELEASED">Not Released</option>
                <option value="RELEASED">Released</option>
                <option value="FABRICATION">Fabrication</option>
                <option value="SHIPPED">Shipped</option>
                <option value="DELIVERED">Delivered</option>
            </select>

            <label>Notes</label>
            <textarea
                name="notes"
                placeholder="Lead time, submittal status, release issue, delivery commitment, etc."
            ></textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Procurement Item</button>

                <a href="/procurement"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Add Procurement", body)


@app.post("/procurement/new")
def create_procurement(
    item: str = Form(...),
    activity_id: str = Form(""),
    vendor: str = Form(""),
    required_on_site: str = Form(...),
    promised_date: str = Form(""),
    status: str = Form("NOT_RELEASED"),
    notes: str = Form("")
):
    pid = project_id()

    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid_activity = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()

        if not valid_activity:
            linked_activity = None

    c.execute(
        """
        INSERT INTO procurement(
            project_id,
            activity_id,
            item,
            vendor,
            required_on_site,
            promised_date,
            status,
            notes,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            item.strip(),
            vendor.strip(),
            required_on_site,
            promised_date,
            status,
            notes.strip(),
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    _v57_emit(project_id(),"PROCUREMENT_CHANGE","Procurement updated","UI")
    return RedirectResponse(url="/procurement", status_code=303)


@app.get("/procurement/{item_id}/edit", response_class=HTMLResponse)
def edit_procurement_form(item_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        """
        SELECT *
        FROM procurement
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    ).fetchone()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    if not item:
        return RedirectResponse(url="/procurement", status_code=303)

    activity_options = '<option value="">No linked activity</option>'

    for a in activities:
        selected = "selected" if item["activity_id"] == a["id"] else ""
        activity_options += (
            f'<option value="{a["id"]}" {selected}>'
            f'{esc(a["external_id"])} - {esc(a["name"])}</option>'
        )

    statuses = [
        "NOT_RELEASED",
        "RELEASED",
        "FABRICATION",
        "SHIPPED",
        "DELIVERED"
    ]

    status_options = "".join(
        f'<option value="{s}" {"selected" if item["status"] == s else ""}>'
        f'{s.replace("_"," ").title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Procurement Intelligence</div>
        <h1>Edit Procurement Item</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/procurement/{item_id}/edit">

            <label>Material / Equipment</label>
            <input type="text" name="item" value="{esc(item["item"])}" required>

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Vendor / Subcontractor</label>
            <input type="text" name="vendor" value="{esc(item["vendor"])}">

            <div class="grid2">
                <div>
                    <label>Required On Site</label>
                    <input type="date" name="required_on_site" value="{esc(item["required_on_site"])}" required>
                </div>

                <div>
                    <label>Promised Date</label>
                    <input type="date" name="promised_date" value="{esc(item["promised_date"])}">
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                {status_options}
            </select>

            <label>Notes</label>
            <textarea name="notes">{esc(item["notes"])}</textarea>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Changes</button>

                <a href="/procurement"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>

        <form method="post"
              action="/procurement/{item_id}/delete"
              style="margin-top:22px;padding-top:18px;border-top:1px solid #213042;">
            <button type="submit"
                    style="background:#492324;color:#ffb0b0;">
                Delete Procurement Item
            </button>
        </form>
    </div>
    """

    return shell("Edit Procurement", body)


@app.post("/procurement/{item_id}/edit")
def edit_procurement(
    item_id: int,
    item: str = Form(...),
    activity_id: str = Form(""),
    vendor: str = Form(""),
    required_on_site: str = Form(...),
    promised_date: str = Form(""),
    status: str = Form("NOT_RELEASED"),
    notes: str = Form("")
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid_activity = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()

        if not valid_activity:
            linked_activity = None

    c.execute(
        """
        UPDATE procurement
        SET activity_id=?,
            item=?,
            vendor=?,
            required_on_site=?,
            promised_date=?,
            status=?,
            notes=?
        WHERE id=? AND project_id=?
        """,
        (
            linked_activity,
            item.strip(),
            vendor.strip(),
            required_on_site,
            promised_date,
            status,
            notes.strip(),
            item_id,
            pid
        )
    )

    c.commit()
    c.close()

    return RedirectResponse(url="/procurement", status_code=303)


@app.post("/procurement/{item_id}/delete")
def delete_procurement(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        "DELETE FROM procurement WHERE id=? AND project_id=?",
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/procurement", status_code=303)


@app.get("/issues", response_class=HTMLResponse)
def issues_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM project_issues i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=?
        ORDER BY
            CASE i.status
                WHEN 'OPEN' THEN 1
                WHEN 'ANSWERED' THEN 2
                WHEN 'CLOSED' THEN 3
                ELSE 4
            END,
            CASE i.priority
                WHEN 'CRITICAL' THEN 1
                WHEN 'HIGH' THEN 2
                WHEN 'WATCH' THEN 3
                ELSE 4
            END,
            i.due
        """,
        (pid,)
    ).fetchall()

    c.close()

    today = date.today().isoformat()
    open_items = [r for r in rows if r["status"] == "OPEN"]
    overdue = [r for r in open_items if r["due"] and r["due"] < today]
    answered = [r for r in rows if r["status"] == "ANSWERED"]

    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        overdue_text = ""
        if r["status"] == "OPEN" and r["due"] and r["due"] < today:
            overdue_text = " · OVERDUE"

        badge = r["priority"] if r["priority"] in ["CRITICAL","HIGH","WATCH","LOW"] else "OPEN"

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["priority"])}</span>
                    <span class="badge OPEN">{esc(r["issue_type"])}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">{activity_text}</div>
                </div>

                <a href="/issues/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <p>{esc(r["description"]) or "No description entered."}</p>
            <div class="small">
                Owner: {esc(r["owner"]) or "Unassigned"} · Due {esc(r["due"]) or "—"}{overdue_text}
            </div>

            <div class="small" style="margin-top:8px;">
                Status: {esc(r["status"])}
            </div>

            {"<p><b>Response:</b> " + esc(r["response"]) + "</p>" if r["response"] else ""}
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No RFIs or project issues logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">RFIs / Issues</div>
                <h1>Track unanswered questions before they stop the field.</h1>
                <div class="muted">
                    Capture ownership, due dates, responses, and schedule exposure.
                </div>
            </div>

            <a href="/issues/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add RFI / Issue
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Open</div>
            <div class="kpi">{len(open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue</div>
            <div class="kpi">{len(overdue)}</div>
        </div>

        <div class="card">
            <div class="label">Answered</div>
            <div class="kpi">{len(answered)}</div>
        </div>

        <div class="card">
            <div class="label">Total</div>
            <div class="kpi">{len(rows)}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("RFIs / Issues", body)


@app.get("/issues/new", response_class=HTMLResponse)
def new_issue_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    owner_options = '<option value="">Unassigned</option>'
    owner_options += '<option value="Architect / Engineer">Architect / Engineer</option>'
    owner_options += '<option value="Owner">Owner</option>'
    owner_options += '<option value="Project Manager">Project Manager</option>'
    owner_options += '<option value="Superintendent">Superintendent</option>'

    for s in subs:
        owner_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    body = f"""
    <div class="hero">
        <div class="eyebrow">RFIs / Issues</div>
        <h1>Add RFI or Project Issue</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/issues/new">

            <label>Type</label>
            <select name="issue_type">
                <option value="RFI">RFI</option>
                <option value="FIELD_ISSUE">Field Issue</option>
                <option value="DESIGN">Design Issue</option>
                <option value="COORDINATION">Coordination</option>
                <option value="OWNER_DECISION">Owner Decision</option>
            </select>

            <label>Title</label>
            <input
                type="text"
                name="title"
                placeholder="Example: RFI - Beam conflict with duct route"
                required
            >

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Owner / Responsible Party</label>
            <select name="owner">
                {owner_options}
            </select>

            <div class="grid2">
                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="WATCH">Watch</option>
                        <option value="LOW">Low</option>
                    </select>
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due" required>
                </div>
            </div>

            <label>Description</label>
            <textarea
                name="description"
                placeholder="What is the question, conflict, or decision needed?"
                required
            ></textarea>

            <button type="submit">Save RFI / Issue</button>
        </form>
    </div>
    """

    return shell("Add RFI / Issue", body)


@app.post("/issues/new")
def create_issue(
    issue_type: str = Form(...),
    title: str = Form(...),
    activity_id: str = Form(""),
    owner: str = Form(""),
    priority: str = Form("HIGH"),
    due: str = Form(...),
    description: str = Form(...)
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()

        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO project_issues(
            project_id,
            activity_id,
            issue_type,
            title,
            owner,
            due,
            priority,
            status,
            description,
            response,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            issue_type,
            title.strip(),
            owner.strip(),
            due,
            priority,
            "OPEN",
            description.strip(),
            "",
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    _v57_emit(project_id(),"ISSUE_CHANGE","Issue created","UI")
    return RedirectResponse(url="/issues", status_code=303)


@app.get("/issues/{issue_id}/edit", response_class=HTMLResponse)
def edit_issue_form(issue_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        """
        SELECT *
        FROM project_issues
        WHERE id=? AND project_id=?
        """,
        (issue_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/issues", status_code=303)

    statuses = ["OPEN", "ANSWERED", "CLOSED"]
    status_options = "".join(
        f'<option value="{s}" {"selected" if item["status"] == s else ""}>{s.title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">RFIs / Issues</div>
        <h1>Edit {esc(item["issue_type"])}</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/issues/{issue_id}/edit">

            <label>Title</label>
            <input type="text" name="title" value="{esc(item["title"])}" required>

            <label>Owner / Responsible Party</label>
            <input type="text" name="owner" value="{esc(item["owner"])}">

            <div class="grid2">
                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL" {"selected" if item["priority"]=="CRITICAL" else ""}>Critical</option>
                        <option value="HIGH" {"selected" if item["priority"]=="HIGH" else ""}>High</option>
                        <option value="WATCH" {"selected" if item["priority"]=="WATCH" else ""}>Watch</option>
                        <option value="LOW" {"selected" if item["priority"]=="LOW" else ""}>Low</option>
                    </select>
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due" value="{esc(item["due"])}" required>
                </div>
            </div>

            <label>Description</label>
            <textarea name="description" required>{esc(item["description"])}</textarea>

            <label>Response / Resolution</label>
            <textarea name="response">{esc(item["response"])}</textarea>

            <label>Status</label>
            <select name="status">
                {status_options}
            </select>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;">
                <button type="submit">Save Changes</button>
                <a href="/issues"
                   style="display:inline-block;color:#f0b44d;text-decoration:none;padding:10px 4px;font-weight:700;">
                    Cancel
                </a>
            </div>
        </form>
    </div>
    """

    return shell("Edit RFI / Issue", body)


@app.post("/issues/{issue_id}/edit")
def edit_issue(
    issue_id: int,
    title: str = Form(...),
    owner: str = Form(""),
    priority: str = Form("HIGH"),
    due: str = Form(...),
    description: str = Form(...),
    response: str = Form(""),
    status: str = Form("OPEN")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE project_issues
        SET title=?,
            owner=?,
            priority=?,
            due=?,
            description=?,
            response=?,
            status=?
        WHERE id=? AND project_id=?
        """,
        (
            title.strip(),
            owner.strip(),
            priority,
            due,
            description.strip(),
            response.strip(),
            status,
            issue_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/issues", status_code=303)


@app.get("/punch", response_class=HTMLResponse)
def punch_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT p.*, a.external_id, a.name activity
        FROM punch_items p
        LEFT JOIN activities a ON a.id=p.activity_id
        WHERE p.project_id=?
        ORDER BY
            CASE p.status
                WHEN 'OPEN' THEN 1
                WHEN 'CORRECTED' THEN 2
                WHEN 'VERIFIED' THEN 3
                ELSE 4
            END,
            CASE p.priority
                WHEN 'CRITICAL' THEN 1
                WHEN 'HIGH' THEN 2
                WHEN 'WATCH' THEN 3
                ELSE 4
            END,
            p.due
        """,
        (pid,)
    ).fetchall()

    c.close()

    today = date.today().isoformat()

    open_items = [r for r in rows if r["status"] == "OPEN"]
    corrected_items = [r for r in rows if r["status"] == "CORRECTED"]
    verified_items = [r for r in rows if r["status"] == "VERIFIED"]
    overdue_items = [
        r for r in open_items
        if r["due"] and r["due"] < today
    ]

    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        badge = (
            r["priority"]
            if r["priority"] in ["CRITICAL", "HIGH", "WATCH", "LOW"]
            else "OPEN"
        )

        overdue_text = ""
        if r["status"] == "OPEN" and r["due"] and r["due"] < today:
            overdue_text = " · OVERDUE"

        if r["status"] == "OPEN":
            action_buttons = f"""
            <form method="post" action="/punch/{r["id"]}/corrected">
                <button type="submit">Mark Corrected</button>
            </form>
            """
        elif r["status"] == "CORRECTED":
            action_buttons = f"""
            <form method="post" action="/punch/{r["id"]}/verified">
                <button type="submit">Verify Complete</button>
            </form>
            """
        else:
            action_buttons = '<span class="badge COMPLETE">VERIFIED</span>'

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["priority"])}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">
                        {esc(r["location"]) or "No location"} · {esc(r["trade"]) or "No trade"}
                    </div>
                </div>

                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    {action_buttons}
                    <a href="/punch/{r["id"]}/edit"
                       style="color:#f0b44d;text-decoration:none;font-weight:700;padding:10px 2px;">
                        Edit
                    </a>
                </div>
            </div>

            <p>{esc(r["description"]) or "No description entered."}</p>

            <div class="small">
                {activity_text}
            </div>

            <div class="small">
                Owner: {esc(r["owner"]) or "Unassigned"} ·
                Due {esc(r["due"]) or "—"}{overdue_text} ·
                Status: {esc(r["status"])}
            </div>

            {"<p><b>Resolution:</b> " + esc(r["resolution"]) + "</p>" if r["resolution"] else ""}
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No punch or quality items logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Quality / Punch List</div>
                <h1>Track deficiencies until they are corrected and verified.</h1>
                <div class="muted">
                    Assign ownership, due dates, location, trade, and final resolution.
                </div>
            </div>

            <a href="/punch/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Punch Item
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Open</div>
            <div class="kpi">{len(open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue</div>
            <div class="kpi">{len(overdue_items)}</div>
        </div>

        <div class="card">
            <div class="label">Corrected</div>
            <div class="kpi">{len(corrected_items)}</div>
        </div>

        <div class="card">
            <div class="label">Verified</div>
            <div class="kpi">{len(verified_items)}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Punch List", body)


@app.get("/punch/new", response_class=HTMLResponse)
def new_punch_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    owner_options = '<option value="">Unassigned</option>'
    owner_options += '<option value="Superintendent">Superintendent</option>'
    owner_options += '<option value="Project Manager">Project Manager</option>'

    for s in subs:
        owner_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Quality / Punch List</div>
        <h1>Add Punch Item</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/punch/new">

            <label>Item Title</label>
            <input
                type="text"
                name="title"
                placeholder="Example: Repair damaged drywall at Room 214"
                required
            >

            <label>Location</label>
            <input
                type="text"
                name="location"
                placeholder="Example: Level 2 - Room 214"
            >

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Trade</label>
            <input
                type="text"
                name="trade"
                placeholder="Example: Drywall"
            >

            <label>Owner / Responsible Party</label>
            <select name="owner">
                {owner_options}
            </select>

            <div class="grid2">
                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL">Critical</option>
                        <option value="HIGH">High</option>
                        <option value="WATCH">Watch</option>
                        <option value="LOW">Low</option>
                    </select>
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due" required>
                </div>
            </div>

            <label>Description</label>
            <textarea
                name="description"
                placeholder="Describe the deficiency and what acceptable correction looks like."
                required
            ></textarea>

            <button type="submit">Save Punch Item</button>
        </form>
    </div>
    """

    return shell("Add Punch Item", body)


@app.post("/punch/new")
def create_punch(
    title: str = Form(...),
    location: str = Form(""),
    activity_id: str = Form(""),
    trade: str = Form(""),
    owner: str = Form(""),
    priority: str = Form("HIGH"),
    due: str = Form(...),
    description: str = Form(...)
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()

        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO punch_items(
            project_id,
            activity_id,
            title,
            location,
            trade,
            owner,
            priority,
            due,
            status,
            description,
            resolution,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            title.strip(),
            location.strip(),
            trade.strip(),
            owner.strip(),
            priority,
            due,
            "OPEN",
            description.strip(),
            "",
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    return RedirectResponse(url="/punch", status_code=303)


@app.get("/punch/{item_id}/edit", response_class=HTMLResponse)
def edit_punch_form(item_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        """
        SELECT *
        FROM punch_items
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/punch", status_code=303)

    body = f"""
    <div class="hero">
        <div class="eyebrow">Quality / Punch List</div>
        <h1>Edit Punch Item</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/punch/{item_id}/edit">

            <label>Item Title</label>
            <input type="text" name="title" value="{esc(item["title"])}" required>

            <label>Location</label>
            <input type="text" name="location" value="{esc(item["location"])}">

            <label>Trade</label>
            <input type="text" name="trade" value="{esc(item["trade"])}">

            <label>Owner</label>
            <input type="text" name="owner" value="{esc(item["owner"])}">

            <div class="grid2">
                <div>
                    <label>Priority</label>
                    <select name="priority">
                        <option value="CRITICAL" {"selected" if item["priority"]=="CRITICAL" else ""}>Critical</option>
                        <option value="HIGH" {"selected" if item["priority"]=="HIGH" else ""}>High</option>
                        <option value="WATCH" {"selected" if item["priority"]=="WATCH" else ""}>Watch</option>
                        <option value="LOW" {"selected" if item["priority"]=="LOW" else ""}>Low</option>
                    </select>
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due" value="{esc(item["due"])}" required>
                </div>
            </div>

            <label>Description</label>
            <textarea name="description" required>{esc(item["description"])}</textarea>

            <label>Resolution</label>
            <textarea name="resolution">{esc(item["resolution"])}</textarea>

            <button type="submit">Save Changes</button>
        </form>
    </div>
    """

    return shell("Edit Punch Item", body)


@app.post("/punch/{item_id}/edit")
def edit_punch(
    item_id: int,
    title: str = Form(...),
    location: str = Form(""),
    trade: str = Form(""),
    owner: str = Form(""),
    priority: str = Form("HIGH"),
    due: str = Form(...),
    description: str = Form(...),
    resolution: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE punch_items
        SET title=?,
            location=?,
            trade=?,
            owner=?,
            priority=?,
            due=?,
            description=?,
            resolution=?
        WHERE id=? AND project_id=?
        """,
        (
            title.strip(),
            location.strip(),
            trade.strip(),
            owner.strip(),
            priority,
            due,
            description.strip(),
            resolution.strip(),
            item_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/punch", status_code=303)


@app.post("/punch/{item_id}/corrected")
def mark_punch_corrected(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE punch_items
        SET status='CORRECTED'
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/punch", status_code=303)


@app.post("/punch/{item_id}/verified")
def mark_punch_verified(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE punch_items
        SET status='VERIFIED'
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/punch", status_code=303)


@app.get("/inspections", response_class=HTMLResponse)
def inspections_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT i.*, a.external_id, a.name activity
        FROM inspections_tracker i
        LEFT JOIN activities a ON a.id=i.activity_id
        WHERE i.project_id=?
        ORDER BY
            CASE i.result
                WHEN 'FAILED' THEN 1
                WHEN 'PENDING' THEN 2
                WHEN 'SCHEDULED' THEN 3
                WHEN 'PASSED' THEN 4
                ELSE 5
            END,
            i.scheduled_date
        """,
        (pid,)
    ).fetchall()

    c.close()

    today = date.today().isoformat()

    pending = [r for r in rows if r["result"] in ["PENDING", "SCHEDULED"]]
    failed = [r for r in rows if r["result"] == "FAILED"]
    passed = [r for r in rows if r["result"] == "PASSED"]
    overdue = [
        r for r in pending
        if r["scheduled_date"] and r["scheduled_date"] < today
    ]

    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        if r["result"] == "PASSED":
            badge = "READY"
        elif r["result"] == "FAILED":
            badge = "CRITICAL"
        elif r["result"] == "SCHEDULED":
            badge = "WATCH"
        else:
            badge = "OPEN"

        reinspection = (
            f' · Reinspection {esc(r["reinspection_date"])}'
            if r["reinspection_date"]
            else ""
        )

        overdue_text = ""
        if r["result"] in ["PENDING", "SCHEDULED"] and r["scheduled_date"] and r["scheduled_date"] < today:
            overdue_text = " · OVERDUE"

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["result"])}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["inspection_type"])}</h3>
                    <div class="muted">{activity_text}</div>
                </div>

                <a href="/inspections/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <p>{esc(r["notes"]) or "No notes entered."}</p>

            <div class="small">
                Authority: {esc(r["authority"]) or "—"} ·
                Scheduled {esc(r["scheduled_date"]) or "—"}{overdue_text}{reinspection}
            </div>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No inspections logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Inspection Intelligence</div>
                <h1>Know which inspection can stop the next activity.</h1>
                <div class="muted">
                    Track scheduled inspections, pass/fail results, authorities, and reinspections.
                </div>
            </div>

            <a href="/inspections/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Inspection
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Pending</div>
            <div class="kpi">{len(pending)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue</div>
            <div class="kpi">{len(overdue)}</div>
        </div>

        <div class="card">
            <div class="label">Failed</div>
            <div class="kpi">{len(failed)}</div>
        </div>

        <div class="card">
            <div class="label">Passed</div>
            <div class="kpi">{len(passed)}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Inspections", body)


@app.get("/inspections/new", response_class=HTMLResponse)
def new_inspection_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Inspection Intelligence</div>
        <h1>Add Inspection</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/inspections/new">

            <label>Inspection Type</label>
            <input
                type="text"
                name="inspection_type"
                placeholder="Example: Above Ceiling Inspection"
                required
            >

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Authority / Inspector</label>
            <input
                type="text"
                name="authority"
                placeholder="Example: City of Phoenix"
            >

            <label>Scheduled Date</label>
            <input type="date" name="scheduled_date" required>

            <label>Result</label>
            <select name="result">
                <option value="PENDING">Pending</option>
                <option value="SCHEDULED">Scheduled</option>
                <option value="PASSED">Passed</option>
                <option value="FAILED">Failed</option>
            </select>

            <label>Reinspection Date</label>
            <input type="date" name="reinspection_date">

            <label>Notes</label>
            <textarea
                name="notes"
                placeholder="Required corrections, prerequisites, inspector comments, etc."
            ></textarea>

            <button type="submit">Save Inspection</button>
        </form>
    </div>
    """

    return shell("Add Inspection", body)


@app.post("/inspections/new")
def create_inspection(
    inspection_type: str = Form(...),
    activity_id: str = Form(""),
    authority: str = Form(""),
    scheduled_date: str = Form(...),
    result: str = Form("PENDING"),
    reinspection_date: str = Form(""),
    notes: str = Form("")
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()
        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO inspections_tracker(
            project_id,
            activity_id,
            inspection_type,
            authority,
            scheduled_date,
            result,
            reinspection_date,
            notes,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            inspection_type.strip(),
            authority.strip(),
            scheduled_date,
            result,
            reinspection_date,
            notes.strip(),
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    _v57_emit(project_id(),"INSPECTION_CHANGE","Inspection updated","UI")
    return RedirectResponse(url="/inspections", status_code=303)


@app.get("/inspections/{inspection_id}/edit", response_class=HTMLResponse)
def edit_inspection_form(inspection_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        """
        SELECT *
        FROM inspections_tracker
        WHERE id=? AND project_id=?
        """,
        (inspection_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/inspections", status_code=303)

    results = ["PENDING", "SCHEDULED", "PASSED", "FAILED"]
    result_options = "".join(
        f'<option value="{r}" {"selected" if item["result"] == r else ""}>{r.title()}</option>'
        for r in results
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Inspection Intelligence</div>
        <h1>Edit Inspection</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/inspections/{inspection_id}/edit">

            <label>Inspection Type</label>
            <input type="text" name="inspection_type" value="{esc(item["inspection_type"])}" required>

            <label>Authority / Inspector</label>
            <input type="text" name="authority" value="{esc(item["authority"])}">

            <label>Scheduled Date</label>
            <input type="date" name="scheduled_date" value="{esc(item["scheduled_date"])}" required>

            <label>Result</label>
            <select name="result">
                {result_options}
            </select>

            <label>Reinspection Date</label>
            <input type="date" name="reinspection_date" value="{esc(item["reinspection_date"])}">

            <label>Notes</label>
            <textarea name="notes">{esc(item["notes"])}</textarea>

            <button type="submit">Save Changes</button>
        </form>
    </div>
    """

    return shell("Edit Inspection", body)


@app.post("/inspections/{inspection_id}/edit")
def edit_inspection(
    inspection_id: int,
    inspection_type: str = Form(...),
    authority: str = Form(""),
    scheduled_date: str = Form(...),
    result: str = Form("PENDING"),
    reinspection_date: str = Form(""),
    notes: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE inspections_tracker
        SET inspection_type=?,
            authority=?,
            scheduled_date=?,
            result=?,
            reinspection_date=?,
            notes=?
        WHERE id=? AND project_id=?
        """,
        (
            inspection_type.strip(),
            authority.strip(),
            scheduled_date,
            result,
            reinspection_date,
            notes.strip(),
            inspection_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/inspections", status_code=303)


@app.get("/submittals", response_class=HTMLResponse)
def submittals_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT s.*, a.external_id, a.name activity
        FROM submittals s
        LEFT JOIN activities a ON a.id=s.activity_id
        WHERE s.project_id=?
        ORDER BY
            CASE s.status
                WHEN 'REJECTED' THEN 1
                WHEN 'PENDING' THEN 2
                WHEN 'SUBMITTED' THEN 3
                WHEN 'APPROVED_AS_NOTED' THEN 4
                WHEN 'APPROVED' THEN 5
                ELSE 6
            END,
            s.due_date
        """,
        (pid,)
    ).fetchall()

    c.close()

    today = date.today().isoformat()

    pending = [r for r in rows if r["status"] in ["PENDING", "SUBMITTED"]]
    rejected = [r for r in rows if r["status"] == "REJECTED"]
    approved = [r for r in rows if r["status"] in ["APPROVED", "APPROVED_AS_NOTED"]]
    overdue = [
        r for r in pending
        if r["due_date"] and r["due_date"] < today
    ]

    brain_analyzed = 0
    brain_wrong = 0
    brain_review = 0
    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        if r["status"] == "REJECTED":
            badge = "CRITICAL"
        elif r["status"] in ["PENDING", "SUBMITTED"]:
            badge = "WATCH"
        elif r["status"] in ["APPROVED", "APPROVED_AS_NOTED"]:
            badge = "READY"
        else:
            badge = "OPEN"

        overdue_text = ""
        if r["status"] in ["PENDING", "SUBMITTED"] and r["due_date"] and r["due_date"] < today:
            overdue_text = " · OVERDUE"

        # 1.8.1 native Submittal Brain merge.
        brain = _v180_submittal_action_model(r["id"], pid)
        brain_status = brain["status"]

        if brain_status.get("analyzed"):
            brain_analyzed += 1

        identity = str(brain_status.get("identity_status") or "NOT_ANALYZED").upper()
        if identity == "MISMATCH":
            brain_wrong += 1
        elif identity in {"HUMAN_REVIEW", "PARTIAL_MATCH"}:
            brain_review += 1

        identity_label = brain_status.get("identity_label") or "NOT ANALYZED"
        overall = brain_status.get("overall_status") or "NOT_ANALYZED"

        review_link = ""
        if brain.get("review_visible") and brain.get("review_url"):
            review_link = (
                f'<a href="{brain["review_url"]}" '
                'style="color:#d6e6ff;text-decoration:none;font-weight:700;">'
                'Latest Brain Review</a>'
            )

        finding_text = ""
        finding_summary = brain_status.get("finding_summary")
        if finding_summary:
            finding_text = (
                f'<div class="small" style="margin-top:8px;">'
                f'Findings: {finding_summary["total"]} · '
                f'Noncompliant: {finding_summary["noncompliant"]} · '
                f'Needs review: {finding_summary["needs_review"]}'
                '</div>'
            )

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["status"]).replace("_"," ")}</span>
                    {_v180_status_badge(identity_label)}
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">{activity_text}</div>
                </div>

                <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                    <a href="/submittals/{r["id"]}/brain/ux"
                       style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:9px 12px;border-radius:8px;font-weight:800;">
                        Analyze with Submittal Brain
                    </a>
                    <a href="/submittals/{r["id"]}/edit"
                       style="color:#f0b44d;text-decoration:none;font-weight:700;">
                        Edit
                    </a>
                </div>
            </div>

            <div class="grid3" style="margin-top:14px;">
                <div>
                    <div class="label">Spec Section</div>
                    <div>{esc(r["spec_section"]) or "—"}</div>
                </div>

                <div>
                    <div class="label">Responsible</div>
                    <div>{esc(r["responsible_party"]) or "—"}</div>
                </div>

                <div>
                    <div class="label">Due</div>
                    <div>{esc(r["due_date"]) or "—"}{overdue_text}</div>
                </div>
            </div>

            <div style="margin-top:14px;padding:12px;border:1px solid rgba(255,255,255,.10);border-radius:10px;">
                <div class="label">Submittal Brain</div>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:6px;">
                    {_v180_status_badge(identity_label)}
                    {_v180_status_badge(overall)}
                    {review_link}
                </div>
                {finding_text}
                <div class="small" style="margin-top:7px;">
                    Project plans/specifications remain controlling evidence. Human review required.
                </div>
            </div>

            <p>{esc(r["notes"]) or "No notes entered."}</p>
            <div class="small">Sent: {esc(r["sent_date"]) or "—"}</div>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No submittals logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Document Control · Submittal Brain</div>
                <h1>Track and verify submittals before they become schedule blockers.</h1>
                <div class="muted">
                    Every submittal can now be analyzed directly against project plans/specifications
                    and separately verified against manufacturer evidence.
                </div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <a href="/submittals-brain-dashboard"
                   style="display:inline-block;border:1px solid rgba(255,255,255,.18);color:#fff;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                    Brain Dashboard
                </a>
                <a href="/submittals/new"
                   style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                    + Add Submittal
                </a>
            </div>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Pending</div>
            <div class="kpi">{len(pending)}</div>
        </div>

        <div class="card">
            <div class="label">Overdue</div>
            <div class="kpi">{len(overdue)}</div>
        </div>

        <div class="card">
            <div class="label">Brain Analyzed</div>
            <div class="kpi">{brain_analyzed}</div>
        </div>

        <div class="card">
            <div class="label">Wrong / Review</div>
            <div class="kpi">{brain_wrong + brain_review}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Submittals", body)


@app.get("/submittals/new", response_class=HTMLResponse)
def new_submittal_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    responsible_options = '<option value="">Unassigned</option>'
    responsible_options += '<option value="Project Manager">Project Manager</option>'
    responsible_options += '<option value="Architect / Engineer">Architect / Engineer</option>'

    for s in subs:
        responsible_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Document Control</div>
        <h1>Add Submittal</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/submittals/new">

            <label>Submittal Title</label>
            <input type="text" name="title" placeholder="Example: Electrical Switchgear Product Data" required>

            <label>Spec Section</label>
            <input type="text" name="spec_section" placeholder="Example: 26 24 16">

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Subcontractor / Responsible Party</label>
            <input
                type="text"
                name="responsible_party"
                list="responsible_parties"
                placeholder="Type or select a subcontractor"
            >
            <datalist id="responsible_parties">
                <option value="Project Manager">
                <option value="Architect / Engineer">
                {''.join(f'<option value="{esc(s["name"])}">{esc(s["trade"])}</option>' for s in subs)}
            </datalist>

            <div class="grid2">
                <div>
                    <label>Sent Date</label>
                    <input type="date" name="sent_date">
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due_date" required>
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                <option value="PENDING">Pending</option>
                <option value="SUBMITTED">Submitted</option>
                <option value="APPROVED">Approved</option>
                <option value="APPROVED_AS_NOTED">Approved As Noted</option>
                <option value="REJECTED">Rejected / Revise & Resubmit</option>
            </select>

            <label>Notes</label>
            <textarea name="notes" placeholder="Review comments, lead-time impact, release constraints, etc."></textarea>

            <button type="submit">Save Submittal</button>
        </form>
    </div>
    """

    return shell("Add Submittal", body)


@app.post("/submittals/new")
def create_submittal(
    title: str = Form(...),
    spec_section: str = Form(""),
    activity_id: str = Form(""),
    responsible_party: str = Form(""),
    sent_date: str = Form(""),
    due_date: str = Form(...),
    status: str = Form("PENDING"),
    notes: str = Form("")
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()
        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO submittals(
            project_id, activity_id, title, spec_section, responsible_party,
            sent_date, due_date, status, notes, created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            title.strip(),
            spec_section.strip(),
            responsible_party.strip(),
            sent_date,
            due_date,
            status,
            notes.strip(),
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    _v57_emit(project_id(),"SUBMITTAL_CHANGE","Submittal created","UI")
    return RedirectResponse(url="/submittals", status_code=303)


@app.get("/submittals/{submittal_id}/edit", response_class=HTMLResponse)
def edit_submittal_form(submittal_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        "SELECT * FROM submittals WHERE id=? AND project_id=?",
        (submittal_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/submittals", status_code=303)

    statuses = ["PENDING", "SUBMITTED", "APPROVED", "APPROVED_AS_NOTED", "REJECTED"]
    status_options = "".join(
        f'<option value="{s}" {"selected" if item["status"] == s else ""}>{s.replace("_"," ").title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Document Control</div>
        <h1>Edit Submittal</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/submittals/{submittal_id}/edit">

            <label>Submittal Title</label>
            <input type="text" name="title" value="{esc(item["title"])}" required>

            <label>Spec Section</label>
            <input type="text" name="spec_section" value="{esc(item["spec_section"])}">

            <label>Subcontractor / Responsible Party</label>
            <input
                type="text"
                name="responsible_party"
                value="{esc(item["responsible_party"])}"
                placeholder="Type subcontractor or responsible party"
            >

            <div class="grid2">
                <div>
                    <label>Sent Date</label>
                    <input type="date" name="sent_date" value="{esc(item["sent_date"])}">
                </div>

                <div>
                    <label>Due Date</label>
                    <input type="date" name="due_date" value="{esc(item["due_date"])}" required>
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                {status_options}
            </select>

            <label>Notes</label>
            <textarea name="notes">{esc(item["notes"])}</textarea>

            <button type="submit">Save Changes</button>
        </form>
    </div>
    """

    return shell("Edit Submittal", body)


@app.post("/submittals/{submittal_id}/edit")
def edit_submittal(
    submittal_id: int,
    title: str = Form(...),
    spec_section: str = Form(""),
    responsible_party: str = Form(""),
    sent_date: str = Form(""),
    due_date: str = Form(...),
    status: str = Form("PENDING"),
    notes: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE submittals
        SET title=?,
            spec_section=?,
            responsible_party=?,
            sent_date=?,
            due_date=?,
            status=?,
            notes=?
        WHERE id=? AND project_id=?
        """,
        (
            title.strip(),
            spec_section.strip(),
            responsible_party.strip(),
            sent_date,
            due_date,
            status,
            notes.strip(),
            submittal_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/submittals", status_code=303)


@app.get("/safety", response_class=HTMLResponse)
def safety_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT s.*, a.external_id, a.name activity
        FROM safety_items s
        LEFT JOIN activities a ON a.id=s.activity_id
        WHERE s.project_id=?
        ORDER BY
            CASE s.status
                WHEN 'OPEN' THEN 1
                WHEN 'CORRECTED' THEN 2
                WHEN 'CLOSED' THEN 3
                ELSE 4
            END,
            CASE s.severity
                WHEN 'CRITICAL' THEN 1
                WHEN 'HIGH' THEN 2
                WHEN 'WATCH' THEN 3
                ELSE 4
            END,
            s.event_date DESC
        """,
        (pid,)
    ).fetchall()

    c.close()

    open_items = [r for r in rows if r["status"] == "OPEN"]
    corrected = [r for r in rows if r["status"] == "CORRECTED"]
    closed = [r for r in rows if r["status"] == "CLOSED"]
    critical = [r for r in open_items if r["severity"] == "CRITICAL"]

    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        badge = (
            r["severity"]
            if r["severity"] in ["CRITICAL","HIGH","WATCH","LOW"]
            else "OPEN"
        )

        if r["status"] == "OPEN":
            action_button = f"""
            <form method="post" action="/safety/{r["id"]}/corrected">
                <button type="submit">Mark Corrected</button>
            </form>
            """
        elif r["status"] == "CORRECTED":
            action_button = f"""
            <form method="post" action="/safety/{r["id"]}/closed">
                <button type="submit">Close Item</button>
            </form>
            """
        else:
            action_button = '<span class="badge COMPLETE">CLOSED</span>'

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["severity"])}</span>
                    <span class="badge OPEN">{esc(r["item_type"]).replace("_"," ")}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">{esc(r["location"]) or "No location"} · {activity_text}</div>
                </div>

                <div>{action_button}</div>
            </div>

            <p>{esc(r["description"]) or "No description entered."}</p>

            <div class="small">
                Date: {esc(r["event_date"])} ·
                Responsible: {esc(r["responsible_party"]) or "Unassigned"} ·
                Status: {esc(r["status"])}
            </div>

            {"<p><b>Corrective Action:</b> " + esc(r["corrective_action"]) + "</p>" if r["corrective_action"] else ""}
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No safety items logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Safety Intelligence</div>
                <h1>Track observations, near misses, and corrective actions.</h1>
                <div class="muted">
                    Keep safety issues visible until they are corrected and closed.
                </div>
            </div>

            <a href="/safety/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Safety Item
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Open</div>
            <div class="kpi">{len(open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Critical</div>
            <div class="kpi">{len(critical)}</div>
        </div>

        <div class="card">
            <div class="label">Corrected</div>
            <div class="kpi">{len(corrected)}</div>
        </div>

        <div class="card">
            <div class="label">Closed</div>
            <div class="kpi">{len(closed)}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Safety", body)


@app.get("/safety/new", response_class=HTMLResponse)
def new_safety_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    responsible_options = '<option value="">Unassigned</option>'
    responsible_options += '<option value="Superintendent">Superintendent</option>'
    responsible_options += '<option value="Safety Manager">Safety Manager</option>'

    for s in subs:
        responsible_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Safety Intelligence</div>
        <h1>Add Safety Item</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/safety/new">

            <label>Type</label>
            <select name="item_type">
                <option value="OBSERVATION">Observation</option>
                <option value="NEAR_MISS">Near Miss</option>
                <option value="INCIDENT">Incident</option>
                <option value="CORRECTIVE_ACTION">Corrective Action</option>
            </select>

            <label>Title</label>
            <input type="text" name="title" placeholder="Example: Missing guardrail at stair opening" required>

            <label>Event Date</label>
            <input type="date" name="event_date" value="{date.today().isoformat()}" required>

            <label>Location</label>
            <input type="text" name="location" placeholder="Example: Level 3 west stair">

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Responsible Party</label>
            <select name="responsible_party">
                {responsible_options}
            </select>

            <label>Severity</label>
            <select name="severity">
                <option value="CRITICAL">Critical</option>
                <option value="HIGH">High</option>
                <option value="WATCH">Watch</option>
                <option value="LOW">Low</option>
            </select>

            <label>Description</label>
            <textarea name="description" placeholder="Describe the condition or event." required></textarea>

            <label>Corrective Action</label>
            <textarea name="corrective_action" placeholder="What must be done to correct or prevent recurrence?"></textarea>

            <button type="submit">Save Safety Item</button>
        </form>
    </div>
    """

    return shell("Add Safety Item", body)


@app.post("/safety/new")
def create_safety_item(
    item_type: str = Form(...),
    title: str = Form(...),
    event_date: str = Form(...),
    location: str = Form(""),
    activity_id: str = Form(""),
    responsible_party: str = Form(""),
    severity: str = Form("WATCH"),
    description: str = Form(...),
    corrective_action: str = Form("")
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()
        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO safety_items(
            project_id,
            activity_id,
            event_date,
            item_type,
            title,
            location,
            responsible_party,
            severity,
            status,
            description,
            corrective_action,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            event_date,
            item_type,
            title.strip(),
            location.strip(),
            responsible_party.strip(),
            severity,
            "OPEN",
            description.strip(),
            corrective_action.strip(),
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    return RedirectResponse(url="/safety", status_code=303)


@app.post("/safety/{item_id}/corrected")
def mark_safety_corrected(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE safety_items
        SET status='CORRECTED'
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/safety", status_code=303)


@app.post("/safety/{item_id}/closed")
def mark_safety_closed(item_id: int):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE safety_items
        SET status='CLOSED'
        WHERE id=? AND project_id=?
        """,
        (item_id, pid)
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/safety", status_code=303)


@app.get("/changes", response_class=HTMLResponse)
def changes_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT ce.*, a.external_id, a.name activity
        FROM change_events ce
        LEFT JOIN activities a ON a.id=ce.activity_id
        WHERE ce.project_id=?
        ORDER BY
            CASE ce.status
                WHEN 'OPEN' THEN 1
                WHEN 'PRICING' THEN 2
                WHEN 'SUBMITTED' THEN 3
                WHEN 'APPROVED' THEN 4
                WHEN 'REJECTED' THEN 5
                ELSE 6
            END,
            ce.id DESC
        """,
        (pid,)
    ).fetchall()

    c.close()

    open_items = [r for r in rows if r["status"] in ["OPEN", "PRICING", "SUBMITTED"]]
    approved = [r for r in rows if r["status"] == "APPROVED"]
    rejected = [r for r in rows if r["status"] == "REJECTED"]

    open_cost = sum((r["estimated_cost"] or 0) for r in open_items)
    open_days = sum((r["schedule_days"] or 0) for r in open_items)

    cards = ""

    for r in rows:
        activity_text = (
            f'{esc(r["external_id"])} - {esc(r["activity"])}'
            if r["external_id"]
            else "No linked activity"
        )

        if r["status"] == "APPROVED":
            badge = "READY"
        elif r["status"] == "REJECTED":
            badge = "LOW"
        elif r["status"] == "SUBMITTED":
            badge = "WATCH"
        elif r["status"] == "PRICING":
            badge = "HIGH"
        else:
            badge = "OPEN"

        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge {badge}">{esc(r["status"])}</span>
                    <span class="badge OPEN">{esc(r["event_type"]).replace("_"," ")}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">{activity_text}</div>
                </div>

                <a href="/changes/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <div class="grid3" style="margin-top:16px;">
                <div>
                    <div class="label">Estimated Cost</div>
                    <div class="kpi">${(r["estimated_cost"] or 0):,.0f}</div>
                </div>

                <div>
                    <div class="label">Schedule Impact</div>
                    <div class="kpi">{(r["schedule_days"] or 0):.1f}</div>
                    <div class="small">days</div>
                </div>

                <div>
                    <div class="label">Responsible</div>
                    <div>{esc(r["responsible_party"]) or "Unassigned"}</div>
                </div>
            </div>

            <p>{esc(r["description"]) or "No description entered."}</p>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No change events logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Change Intelligence</div>
                <h1>Track field changes before cost and schedule impact get lost.</h1>
                <div class="muted">
                    Capture scope changes, owner decisions, design changes, and potential change orders.
                </div>
            </div>

            <a href="/changes/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Change Event
            </a>
        </div>
    </div>

    <div class="grid4">
        <div class="card">
            <div class="label">Open Events</div>
            <div class="kpi">{len(open_items)}</div>
        </div>

        <div class="card">
            <div class="label">Open Exposure</div>
            <div class="kpi">${open_cost:,.0f}</div>
        </div>

        <div class="card">
            <div class="label">Potential Days</div>
            <div class="kpi">{open_days:.1f}</div>
        </div>

        <div class="card">
            <div class="label">Approved</div>
            <div class="kpi">{len(approved)}</div>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Change Events", body)


@app.get("/changes/new", response_class=HTMLResponse)
def new_change_form():
    pid = project_id()
    c = db()

    activities = c.execute(
        """
        SELECT id,external_id,name
        FROM activities
        WHERE project_id=?
        ORDER BY start,name
        """,
        (pid,)
    ).fetchall()

    subs = c.execute(
        """
        SELECT name,trade
        FROM subs
        WHERE project_id=?
        ORDER BY trade,name
        """,
        (pid,)
    ).fetchall()

    c.close()

    activity_options = '<option value="">No linked activity</option>'
    activity_options += "".join(
        f'<option value="{a["id"]}">{esc(a["external_id"])} - {esc(a["name"])}</option>'
        for a in activities
    )

    responsible_options = '<option value="">Unassigned</option>'
    responsible_options += '<option value="Owner">Owner</option>'
    responsible_options += '<option value="Architect / Engineer">Architect / Engineer</option>'
    responsible_options += '<option value="General Contractor">General Contractor</option>'

    for s in subs:
        responsible_options += (
            f'<option value="{esc(s["name"])}">{esc(s["name"])} - {esc(s["trade"])}</option>'
        )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Change Intelligence</div>
        <h1>Add Change Event</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/changes/new">

            <label>Change Type</label>
            <select name="event_type">
                <option value="OWNER_CHANGE">Owner Change</option>
                <option value="DESIGN_CHANGE">Design Change</option>
                <option value="SCOPE_GAP">Scope Gap</option>
                <option value="FIELD_CONDITION">Field Condition</option>
                <option value="RFI_IMPACT">RFI Impact</option>
                <option value="POTENTIAL_CHANGE_ORDER">Potential Change Order</option>
            </select>

            <label>Title</label>
            <input
                type="text"
                name="title"
                placeholder="Example: Added power for imaging equipment"
                required
            >

            <label>Linked Activity</label>
            <select name="activity_id">
                {activity_options}
            </select>

            <label>Responsible Party</label>
            <select name="responsible_party">
                {responsible_options}
            </select>

            <div class="grid2">
                <div>
                    <label>Estimated Cost Impact</label>
                    <input
                        type="number"
                        name="estimated_cost"
                        min="0"
                        step="100"
                        value="0"
                    >
                </div>

                <div>
                    <label>Schedule Impact (Days)</label>
                    <input
                        type="number"
                        name="schedule_days"
                        min="0"
                        step="0.5"
                        value="0"
                    >
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                <option value="OPEN">Open</option>
                <option value="PRICING">Pricing</option>
                <option value="SUBMITTED">Submitted</option>
                <option value="APPROVED">Approved</option>
                <option value="REJECTED">Rejected</option>
            </select>

            <label>Description</label>
            <textarea
                name="description"
                placeholder="Describe the change, cause, scope, cost exposure, and schedule impact."
                required
            ></textarea>

            <button type="submit">Save Change Event</button>
        </form>
    </div>
    """

    return shell("Add Change Event", body)


@app.post("/changes/new")
def create_change_event(
    event_type: str = Form(...),
    title: str = Form(...),
    activity_id: str = Form(""),
    responsible_party: str = Form(""),
    estimated_cost: float = Form(0),
    schedule_days: float = Form(0),
    status: str = Form("OPEN"),
    description: str = Form(...)
):
    pid = project_id()
    linked_activity = int(activity_id) if activity_id.strip() else None

    estimated_cost = max(0.0, estimated_cost)
    schedule_days = max(0.0, schedule_days)

    c = db()

    if linked_activity is not None:
        valid = c.execute(
            "SELECT id FROM activities WHERE id=? AND project_id=?",
            (linked_activity, pid)
        ).fetchone()
        if not valid:
            linked_activity = None

    c.execute(
        """
        INSERT INTO change_events(
            project_id,
            activity_id,
            event_type,
            title,
            responsible_party,
            estimated_cost,
            schedule_days,
            status,
            description,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            linked_activity,
            event_type,
            title.strip(),
            responsible_party.strip(),
            estimated_cost,
            schedule_days,
            status,
            description.strip(),
            date.today().isoformat()
        )
    )

    c.commit()
    c.close()

    return RedirectResponse(url="/changes", status_code=303)


@app.get("/changes/{change_id}/edit", response_class=HTMLResponse)
def edit_change_form(change_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        "SELECT * FROM change_events WHERE id=? AND project_id=?",
        (change_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/changes", status_code=303)

    statuses = ["OPEN", "PRICING", "SUBMITTED", "APPROVED", "REJECTED"]
    status_options = "".join(
        f'<option value="{s}" {"selected" if item["status"] == s else ""}>{s.title()}</option>'
        for s in statuses
    )

    body = f"""
    <div class="hero">
        <div class="eyebrow">Change Intelligence</div>
        <h1>Edit Change Event</h1>
    </div>

    <div class="card" style="max-width:760px;">
        <form method="post" action="/changes/{change_id}/edit">

            <label>Title</label>
            <input type="text" name="title" value="{esc(item["title"])}" required>

            <label>Responsible Party</label>
            <input type="text" name="responsible_party" value="{esc(item["responsible_party"])}">

            <div class="grid2">
                <div>
                    <label>Estimated Cost</label>
                    <input
                        type="number"
                        name="estimated_cost"
                        min="0"
                        step="100"
                        value="{item["estimated_cost"] or 0}"
                    >
                </div>

                <div>
                    <label>Schedule Impact (Days)</label>
                    <input
                        type="number"
                        name="schedule_days"
                        min="0"
                        step="0.5"
                        value="{item["schedule_days"] or 0}"
                    >
                </div>
            </div>

            <label>Status</label>
            <select name="status">
                {status_options}
            </select>

            <label>Description</label>
            <textarea name="description" required>{esc(item["description"])}</textarea>

            <button type="submit">Save Changes</button>
        </form>
    </div>
    """

    return shell("Edit Change Event", body)


@app.post("/changes/{change_id}/edit")
def edit_change_event(
    change_id: int,
    title: str = Form(...),
    responsible_party: str = Form(""),
    estimated_cost: float = Form(0),
    schedule_days: float = Form(0),
    status: str = Form("OPEN"),
    description: str = Form(...)
):
    pid = project_id()

    estimated_cost = max(0.0, estimated_cost)
    schedule_days = max(0.0, schedule_days)

    c = db()
    c.execute(
        """
        UPDATE change_events
        SET title=?,
            responsible_party=?,
            estimated_cost=?,
            schedule_days=?,
            status=?,
            description=?
        WHERE id=? AND project_id=?
        """,
        (
            title.strip(),
            responsible_party.strip(),
            estimated_cost,
            schedule_days,
            status,
            description.strip(),
            change_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/changes", status_code=303)


@app.get("/meetings", response_class=HTMLResponse)
def meetings_page():
    pid = project_id()
    c = db()

    rows = c.execute(
        """
        SELECT *
        FROM meeting_notes
        WHERE project_id=?
        ORDER BY meeting_date DESC, id DESC
        LIMIT 30
        """,
        (pid,)
    ).fetchall()

    c.close()

    cards = ""

    for r in rows:
        cards += f"""
        <div class="card">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
                <div>
                    <span class="badge OPEN">{esc(r["meeting_type"]).replace("_"," ")}</span>
                    <h3 style="margin:10px 0 4px;">{esc(r["title"])}</h3>
                    <div class="muted">{esc(r["meeting_date"])}</div>
                </div>

                <a href="/meetings/{r["id"]}/edit"
                   style="color:#f0b44d;text-decoration:none;font-weight:700;">
                    Edit
                </a>
            </div>

            <div class="small">Attendees</div>
            <p>{esc(r["attendees"]) or "—"}</p>

            <div class="small">Decisions</div>
            <p>{esc(r["decisions"]) or "—"}</p>

            <div class="small">Commitments</div>
            <p>{esc(r["commitments"]) or "—"}</p>

            <div class="small">Follow-Up</div>
            <p>{esc(r["follow_up"]) or "—"}</p>
        </div>
        """

    if not cards:
        cards = '<div class="card"><div class="muted">No meeting notes logged yet.</div></div>'

    body = f"""
    <div class="hero">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;">
            <div>
                <div class="eyebrow">Meeting Intelligence</div>
                <h1>Capture decisions and commitments before they disappear into notes.</h1>
                <div class="muted">
                    Track OAC meetings, trade coordination, owner decisions, and follow-up.
                </div>
            </div>

            <a href="/meetings/new"
               style="display:inline-block;background:#f0b44d;color:#0a1017;text-decoration:none;padding:12px 18px;border-radius:9px;font-weight:800;">
                + Add Meeting Notes
            </a>
        </div>
    </div>

    <div class="grid2">
        {cards}
    </div>
    """

    return shell("Meetings", body)


@app.get("/meetings/new", response_class=HTMLResponse)
def new_meeting_form():
    body = f"""
    <div class="hero">
        <div class="eyebrow">Meeting Intelligence</div>
        <h1>Add Meeting Notes</h1>
    </div>

    <div class="card" style="max-width:820px;">
        <form method="post" action="/meetings/new">

            <label>Meeting Date</label>
            <input type="date" name="meeting_date" value="{date.today().isoformat()}" required>

            <label>Meeting Type</label>
            <select name="meeting_type">
                <option value="OAC">OAC</option>
                <option value="SUBCONTRACTOR_COORDINATION">Subcontractor Coordination</option>
                <option value="OWNER_MEETING">Owner Meeting</option>
                <option value="INTERNAL">Internal</option>
                <option value="SAFETY">Safety</option>
                <option value="PREINSTALL">Pre-Installation</option>
            </select>

            <label>Title</label>
            <input type="text" name="title" placeholder="Example: Weekly OAC Meeting" required>

            <label>Attendees</label>
            <textarea name="attendees" placeholder="Who attended?"></textarea>

            <label>Decisions Made</label>
            <textarea name="decisions" placeholder="What was decided?"></textarea>

            <label>Commitments</label>
            <textarea name="commitments" placeholder="Who committed to what and by when?"></textarea>

            <label>Follow-Up</label>
            <textarea name="follow_up" placeholder="What needs to happen next?"></textarea>

            <button type="submit">Save Meeting Notes</button>
        </form>
    </div>
    """

    return shell("Add Meeting Notes", body)


@app.post("/meetings/new")
def create_meeting(
    meeting_date: str = Form(...),
    meeting_type: str = Form(...),
    title: str = Form(...),
    attendees: str = Form(""),
    decisions: str = Form(""),
    commitments: str = Form(""),
    follow_up: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        INSERT INTO meeting_notes(
            project_id,
            meeting_date,
            meeting_type,
            title,
            attendees,
            decisions,
            commitments,
            follow_up,
            created
        )
        VALUES(?,?,?,?,?,?,?,?,?)
        """,
        (
            pid,
            meeting_date,
            meeting_type,
            title.strip(),
            attendees.strip(),
            decisions.strip(),
            commitments.strip(),
            follow_up.strip(),
            date.today().isoformat()
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/meetings", status_code=303)


@app.get("/meetings/{meeting_id}/edit", response_class=HTMLResponse)
def edit_meeting_form(meeting_id: int):
    pid = project_id()
    c = db()

    item = c.execute(
        "SELECT * FROM meeting_notes WHERE id=? AND project_id=?",
        (meeting_id, pid)
    ).fetchone()

    c.close()

    if not item:
        return RedirectResponse(url="/meetings", status_code=303)

    body = f"""
    <div class="hero">
        <div class="eyebrow">Meeting Intelligence</div>
        <h1>Edit Meeting Notes</h1>
    </div>

    <div class="card" style="max-width:820px;">
        <form method="post" action="/meetings/{meeting_id}/edit">

            <label>Meeting Date</label>
            <input type="date" name="meeting_date" value="{esc(item["meeting_date"])}" required>

            <label>Title</label>
            <input type="text" name="title" value="{esc(item["title"])}" required>

            <label>Attendees</label>
            <textarea name="attendees">{esc(item["attendees"])}</textarea>

            <label>Decisions Made</label>
            <textarea name="decisions">{esc(item["decisions"])}</textarea>

            <label>Commitments</label>
            <textarea name="commitments">{esc(item["commitments"])}</textarea>

            <label>Follow-Up</label>
            <textarea name="follow_up">{esc(item["follow_up"])}</textarea>

            <button type="submit">Save Changes</button>
        </form>
    </div>
    """

    return shell("Edit Meeting Notes", body)


@app.post("/meetings/{meeting_id}/edit")
def edit_meeting(
    meeting_id: int,
    meeting_date: str = Form(...),
    title: str = Form(...),
    attendees: str = Form(""),
    decisions: str = Form(""),
    commitments: str = Form(""),
    follow_up: str = Form("")
):
    pid = project_id()

    c = db()
    c.execute(
        """
        UPDATE meeting_notes
        SET meeting_date=?,
            title=?,
            attendees=?,
            decisions=?,
            commitments=?,
            follow_up=?
        WHERE id=? AND project_id=?
        """,
        (
            meeting_date,
            title.strip(),
            attendees.strip(),
            decisions.strip(),
            commitments.strip(),
            follow_up.strip(),
            meeting_id,
            pid
        )
    )
    c.commit()
    c.close()

    return RedirectResponse(url="/meetings", status_code=303)


def safe_filename(name):
    base=os.path.basename(name or "upload"); cleaned="".join(ch for ch in base if ch.isalnum() or ch in "._- ")
    return cleaned[:120] or "upload"


def refresh_notifications(pid=None):
    cid=current_company_id()
    if not cid or not pid: return
    c=db(); c.execute("DELETE FROM notifications WHERE company_id=? AND project_id=? AND source='AUTO'",(cid,pid)); today=date.today().isoformat()
    def add(sev,title,detail):
        c.execute("INSERT INTO notifications(company_id,project_id,severity,title,detail,source,status,created) VALUES(?,?,?,?,?,'AUTO','UNREAD',?)",(cid,pid,sev,title,detail,datetime.utcnow().isoformat()))
    for r in c.execute("SELECT * FROM action_items WHERE project_id=? AND status='OPEN' AND due!='' AND due<?",(pid,today)).fetchall(): add(r["priority"] or "HIGH",f'Overdue action: {r["title"]}',f'Owner: {r["owner"] or "Unassigned"} · Due {r["due"]}')
    for r in c.execute("SELECT * FROM procurement WHERE project_id=? AND status!='DELIVERED' AND promised_date!='' AND required_on_site!='' AND promised_date>required_on_site",(pid,)).fetchall(): add("CRITICAL",f'Late procurement: {r["item"]}',f'Promised {r["promised_date"]}; required {r["required_on_site"]}')
    for r in c.execute("SELECT * FROM inspections_tracker WHERE project_id=? AND result='FAILED'",(pid,)).fetchall(): add("CRITICAL",f'Failed inspection: {r["inspection_type"]}',r["notes"] or "Correction/reinspection required.")
    for r in c.execute("SELECT * FROM submittals WHERE project_id=? AND status='REJECTED'",(pid,)).fetchall(): add("HIGH",f'Rejected submittal: {r["title"]}',r["notes"] or "Revise and resubmit.")
    for r in c.execute("SELECT * FROM safety_items WHERE project_id=? AND status!='CLOSED' AND severity='CRITICAL'",(pid,)).fetchall(): add("CRITICAL",f'Safety: {r["title"]}',r["description"] or "Critical safety item is open.")
    c.commit(); c.close()


@app.get("/notifications",response_class=HTMLResponse)
def notifications_page():
    pid=project_id(); refresh_notifications(pid); c=db(); rows=c.execute("SELECT * FROM notifications WHERE company_id=? AND (project_id=? OR project_id IS NULL) ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'WATCH' THEN 3 ELSE 4 END,id DESC LIMIT 100",(current_company_id(),pid)).fetchall(); c.close()
    cards="".join(f'<div class="card"><span class="badge {r["severity"] if r["severity"] in ["CRITICAL","HIGH","WATCH","LOW","READY"] else "OPEN"}">{esc(r["severity"])}</span><h3>{esc(r["title"])}</h3><p>{esc(r["detail"])}</p><div class="small">{esc(r["created"])}</div></div>' for r in rows) or '<div class="card"><div class="muted">No active notifications.</div></div>'
    return shell("Notifications",f'<div class="hero"><div class="eyebrow">Notifications</div><h1>What needs your attention?</h1></div><div class="card"><form method="post" action="/notifications/email-digest"><button type="submit">Email My Alert Digest</button></form><div class="small">Requires SMTP settings in Render.</div></div><div class="grid2">{cards}</div>')


@app.get("/documents",response_class=HTMLResponse)
def documents_page():
    pid=project_id(); c=db(); rows=c.execute("SELECT a.*,u.display_name FROM attachments a LEFT JOIN users u ON u.id=a.created_by WHERE a.company_id=? AND a.project_id=? ORDER BY a.id DESC",(current_company_id(),pid)).fetchall(); c.close()
    files_html="".join(f'<div class="card"><span class="badge OPEN">{esc(r["category"])}</span><h3>{esc(r["title"] or r["original_name"])}</h3><div class="small">{esc(r["original_name"])} · {(r["size_bytes"] or 0)/1024:.0f} KB</div><p><a href="/documents/{r["id"]}/download" style="color:#f0b44d;font-weight:700;">Download</a></p></div>' for r in rows) or '<div class="card"><div class="muted">No project documents uploaded yet.</div></div>'
    body=f'''<div class="hero"><div class="eyebrow">Document & Photo Center</div><h1>Keep field evidence with the project.</h1><div class="muted">Set UPLOAD_DIR to a Render persistent-disk path for durable storage.</div></div><div class="grid2"><div class="card"><h2>Upload</h2><form method="post" action="/documents/upload" enctype="multipart/form-data"><label>Category</label><select name="category"><option>PHOTO</option><option>DAILY_REPORT</option><option>RFI</option><option>PUNCH</option><option>SAFETY</option><option>SUBMITTAL</option><option>OTHER</option></select><label>Title</label><input name="title"><label>File</label><input type="file" name="file" required><button type="submit">Upload File</button></form></div><div class="card"><h2>Upload Rules</h2><p>Maximum 10 MB. PDF, image, Office, CSV, and text files are accepted.</p></div></div><div class="grid2">{files_html}</div>'''
    return shell("Documents",body)


@app.post("/documents/upload")
async def documents_upload(category:str=Form("OTHER"),title:str=Form(""),file:UploadFile=File(...)):
    pid=project_id(); original=safe_filename(file.filename); ext=Path(original).suffix.lower()
    if ext not in ALLOWED_UPLOAD_EXTENSIONS: return HTMLResponse("File type not allowed.",status_code=400)
    data=await file.read()
    if len(data)>MAX_UPLOAD_BYTES: return HTMLResponse("File exceeds the 10 MB limit.",status_code=400)
    stored=f"{secrets.token_hex(12)}{ext}"; path=os.path.join(UPLOAD_DIR,stored)
    with open(path,"wb") as f: f.write(data)
    c=db(); c.execute("INSERT INTO attachments(company_id,project_id,category,title,original_name,stored_name,mime_type,size_bytes,created_by,created) VALUES(?,?,?,?,?,?,?,?,?,?)",(current_company_id(),pid,category,title.strip(),original,stored,file.content_type or mimetypes.guess_type(original)[0] or "application/octet-stream",len(data),current_user_id(),datetime.utcnow().isoformat())); c.commit(); c.close()
    return RedirectResponse("/documents",status_code=303)


@app.get("/documents/{attachment_id}/download")
def document_download(attachment_id:int):
    c=db(); row=c.execute("SELECT * FROM attachments WHERE id=? AND company_id=?",(attachment_id,current_company_id())).fetchone(); c.close()
    if not row: return HTMLResponse("File not found.",status_code=404)
    path=os.path.join(UPLOAD_DIR,row["stored_name"])
    if not os.path.isfile(path): return HTMLResponse("Stored file is unavailable. Configure persistent storage.",status_code=404)
    return FileResponse(path,media_type=row["mime_type"] or "application/octet-stream",filename=row["original_name"])


@app.get("/morning-brief",response_class=HTMLResponse)
def morning_brief_page():
    pid=project_id(); c=db(); row=c.execute("SELECT * FROM morning_briefs WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 1",(current_company_id(),pid)).fetchone(); c.close(); brief=esc(row["brief_text"]).replace("\n","<br>") if row else "No AI morning brief has been generated yet."
    return shell("Morning Brief",f'<div class="hero"><div class="eyebrow">Proactive AI</div><h1>Morning Superintendent Brief</h1></div><div class="card"><form method="post" action="/morning-brief/generate"><button type="submit">Generate Current Brief</button></form></div><div class="card"><div style="line-height:1.65;">{brief}</div></div>')


@app.post("/morning-brief/generate")
def generate_morning_brief():
    pid=project_id(); api_key=os.environ.get("OPENAI_API_KEY"); context=build_project_context(pid)
    if api_key and OpenAI is not None:
        try:
            client=OpenAI(api_key=api_key); response=client.responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions="You are BuildCommand AI, a construction superintendent morning-command copilot. Use only supplied project facts. Return: HANDLE FIRST, SCHEDULE THREATS, WHO OWES WHAT, TODAY'S VERIFICATIONS, COST / CHANGE EXPOSURE, SAFETY / QUALITY. Do not invent facts.",input=context); brief=response.output_text
        except Exception as exc: brief=f"AI brief failed: {exc}"
    else: brief="OPENAI_API_KEY is not configured. The rule-based Daily Command dashboard remains available."
    c=db(); c.execute("INSERT INTO morning_briefs(company_id,project_id,brief_date,brief_text,created) VALUES(?,?,?,?,?)",(current_company_id(),pid,date.today().isoformat(),brief,datetime.utcnow().isoformat())); c.commit(); c.close(); return RedirectResponse("/morning-brief",status_code=303)


@app.get("/team",response_class=HTMLResponse)
def team_page():
    user=current_user(); c=db(); rows=c.execute("SELECT * FROM users WHERE company_id=? ORDER BY display_name,email",(current_company_id(),)).fetchall(); c.close(); members="".join(f'<div class="action"><b>{esc(r["display_name"] or r["email"])}</b><div class="small">{esc(r["email"])} · {esc(r["role"])}</div></div>' for r in rows)
    add=''
    if user and user["role"] in ["OWNER","ADMIN"]: add='''<div class="card"><h2>Add Team Member</h2><form method="post" action="/team/add"><label>Name</label><input name="display_name" required><label>Email</label><input type="email" name="email" required><label>Temporary Password</label><input type="password" name="password" minlength="8" required><label>Role</label><select name="role"><option>MEMBER</option><option>ADMIN</option></select><button type="submit">Create User</button></form></div>'''
    return shell("Team",f'<div class="hero"><div class="eyebrow">Accounts</div><h1>Company Team</h1></div><div class="grid2"><div class="card"><h2>Users</h2>{members}</div>{add}</div>')


@app.post("/team/add")
def add_team_member(display_name:str=Form(...),email:str=Form(...),password:str=Form(...),role:str=Form("MEMBER")):
    user=current_user()
    if not user or user["role"] not in ["OWNER","ADMIN"]: return HTMLResponse("Not authorized.",status_code=403)
    if role not in ["MEMBER","ADMIN"]: role="MEMBER"
    c=db()
    if c.execute("SELECT id FROM users WHERE lower(email)=lower(?)",(email.strip(),)).fetchone(): c.close(); return HTMLResponse("That email is already in use.",status_code=400)
    c.execute("INSERT INTO users(company_id,email,display_name,password_hash,role,created) VALUES(?,?,?,?,?,?)",(current_company_id(),email.strip().lower(),display_name.strip(),hash_password(password),role,date.today().isoformat())); c.commit(); c.close(); return RedirectResponse("/team",status_code=303)


@app.get("/company-settings",response_class=HTMLResponse)
def company_settings():
    u=current_user(); return shell("Company Settings",f'''<div class="hero"><div class="eyebrow">Branding</div><h1>Company Settings</h1></div><div class="card" style="max-width:720px;"><form method="post" action="/company-settings"><label>Company Name</label><input name="name" value="{esc(u["company_name"] if u else "")}" required><label>Logo URL (optional)</label><input name="logo_url" value="{esc(u["logo_url"] if u else "")}"><button type="submit">Save Company Settings</button></form></div>''')


@app.post("/company-settings")
def company_settings_save(name:str=Form(...),logo_url:str=Form("")):
    u=current_user()
    if not u or u["role"] not in ["OWNER","ADMIN"]: return HTMLResponse("Not authorized.",status_code=403)
    c=db(); c.execute("UPDATE companies SET name=?,logo_url=? WHERE id=?",(name.strip(),logo_url.strip(),current_company_id())); c.commit(); c.close(); return RedirectResponse("/company-settings",status_code=303)


@app.get("/exports",response_class=HTMLResponse)
def exports_page():
    return shell("Exports",'''<div class="hero"><div class="eyebrow">Reports & Exports</div><h1>Take BuildCommand data with you.</h1></div><div class="grid2"><div class="card"><h2>Project CSV</h2><a href="/exports/project.csv" style="color:#f0b44d;font-weight:700;">Download CSV</a></div><div class="card"><h2>Project JSON</h2><a href="/exports/project.json" style="color:#f0b44d;font-weight:700;">Download JSON</a></div><div class="card"><h2>Latest Daily Report PDF</h2><a href="/exports/daily-report.pdf" style="color:#f0b44d;font-weight:700;">Download PDF</a></div><div class="card"><h2>Backup</h2><a href="/backup/download" style="color:#f0b44d;font-weight:700;">Download Backup ZIP</a></div></div>''')


@app.get("/exports/project.csv")
def export_project_csv():
    pid=project_id(); c=db(); project=c.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone(); risks=c.execute("SELECT * FROM risks WHERE project_id=? ORDER BY score DESC",(pid,)).fetchall(); actions=c.execute("SELECT * FROM action_items WHERE project_id=? ORDER BY due",(pid,)).fetchall(); c.close(); out=io.StringIO(); w=csv.writer(out); w.writerow(["BuildCommand AI Project Export"]); w.writerow(["Project",project["number"] if project else "",project["name"] if project else ""]); w.writerow([]); w.writerow(["RISKS"]); w.writerow(["Score","Band","Explanation"]); [w.writerow([r["score"],r["band"],r["explanation"]]) for r in risks]; w.writerow([]); w.writerow(["ACTIONS"]); w.writerow(["Title","Owner","Priority","Due","Status","Notes"]); [w.writerow([r["title"],r["owner"],r["priority"],r["due"],r["status"],r["notes"]]) for r in actions]; return Response(out.getvalue(),media_type="text/csv",headers={"Content-Disposition":'attachment; filename="buildcommand_project.csv"'})


@app.get("/exports/project.json")
def export_project_json():
    pid=project_id(); c=db(); project=c.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone(); tables=["activities","risks","make_ready","action_items","project_issues","punch_items","inspections_tracker","submittals","safety_items","change_events","meeting_notes","procurement","production","daily_reports","subs","subcontractor_updates"]; payload={"project":dict(project) if project else None}; [payload.__setitem__(t,[dict(r) for r in c.execute(f"SELECT * FROM {t} WHERE project_id=?",(pid,)).fetchall()]) for t in tables]; c.close(); return Response(json.dumps(payload,indent=2,default=str),media_type="application/json",headers={"Content-Disposition":'attachment; filename="buildcommand_project.json"'})


@app.get("/exports/daily-report.pdf")
def export_daily_report_pdf():
    pid=project_id(); c=db(); project=c.execute("SELECT * FROM projects WHERE id=?",(pid,)).fetchone(); report=c.execute("SELECT * FROM daily_reports WHERE project_id=? ORDER BY report_date DESC,id DESC LIMIT 1",(pid,)).fetchone(); c.close()
    if not report: return HTMLResponse("No daily report is available to export.",status_code=404)
    if canvas is None: return HTMLResponse("PDF support is not installed. Ensure reportlab is in requirements.txt.",status_code=503)
    buffer=io.BytesIO(); pdf=canvas.Canvas(buffer); y=742; pdf.setFont("Helvetica-Bold",16); pdf.drawString(45,y,"BuildCommand AI - Daily Superintendent Report"); y-=24; pdf.setFont("Helvetica",10); pdf.drawString(45,y,f'{project["number"]} - {project["name"]}'); y-=18; pdf.drawString(45,y,f'Date: {report["report_date"]}   Manpower: {report["manpower"] or 0}'); y-=26
    for label,value in [("Weather",report["weather"]),("Work Completed",report["work_completed"]),("Delays / Constraints",report["delays"]),("Deliveries",report["deliveries"]),("Inspections",report["inspections"]),("Safety",report["safety"]),("Tomorrow's Plan",report["tomorrow_plan"])]:
        pdf.setFont("Helvetica-Bold",10); pdf.drawString(45,y,label); y-=14; pdf.setFont("Helvetica",9); words=str(value or "—").split(); line=""
        for word in words:
            test=(line+" "+word).strip()
            if pdf.stringWidth(test,"Helvetica",9)>510: pdf.drawString(55,y,line); y-=12; line=word
            else: line=test
            if y<60: pdf.showPage(); y=742
        if line: pdf.drawString(55,y,line); y-=12
        y-=10
    pdf.setFont("Helvetica",8); pdf.drawString(45,30,"Built by Wilson LaHood · © 2026 Wilson LaHood"); pdf.save(); buffer.seek(0); return Response(buffer.getvalue(),media_type="application/pdf",headers={"Content-Disposition":'attachment; filename="buildcommand_daily_report.pdf"'})


@app.get("/backup/download")
def backup_download():
    stamp=datetime.utcnow().strftime("%Y%m%d_%H%M%S"); tmp=f"/tmp/bc_{secrets.token_hex(5)}"; os.makedirs(tmp,exist_ok=True); dbcopy=os.path.join(tmp,"buildcommand.db"); s=sqlite3.connect(DB); t=sqlite3.connect(dbcopy); s.backup(t); t.close(); s.close(); zpath=f"/tmp/buildcommand_backup_{stamp}.zip"
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        z.write(dbcopy,arcname="buildcommand.db"); c=db(); files=c.execute("SELECT * FROM attachments WHERE company_id=?",(current_company_id(),)).fetchall(); c.close()
        for r in files:
            p=os.path.join(UPLOAD_DIR,r["stored_name"])
            if os.path.isfile(p): z.write(p,arcname=f'uploads/{r["stored_name"]}')
    return FileResponse(zpath,media_type="application/zip",filename=f"buildcommand_backup_{stamp}.zip")


@app.get("/system-check",response_class=HTMLResponse)
def system_check():
    checks=[]
    try:
        c=db(); tables=["projects","activities","subs","subcontractor_updates","daily_reports","risks","make_ready","action_items","project_issues","punch_items","inspections_tracker","submittals","safety_items","change_events","meeting_notes","procurement","attachments","users","companies"]
        for t in tables: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()
        c.close(); checks.append(("READY","Database schema","Core tables respond successfully."))
    except Exception as exc: checks.append(("CRITICAL","Database schema",str(exc)))
    checks.append(("READY" if os.environ.get("OPENAI_API_KEY") else "WATCH","OpenAI connection","OPENAI_API_KEY is configured." if os.environ.get("OPENAI_API_KEY") else "AI key is not configured.")); checks.append(("READY" if os.path.isdir(UPLOAD_DIR) and os.access(UPLOAD_DIR,os.W_OK) else "CRITICAL","Upload storage",f"Upload path: {UPLOAD_DIR}")); checks.append(("READY" if DATABASE_KIND=="postgres" else "WATCH","Database engine",f"Current engine: {DATABASE_KIND}.")); checks.append(("READY" if os.environ.get("UPLOAD_DIR") else "WATCH","Persistent files","UPLOAD_DIR is explicitly configured." if os.environ.get("UPLOAD_DIR") else "Set UPLOAD_DIR to a Render persistent-disk path for durable files.")); html="".join(f'<div class="card"><span class="badge {b}">{b}</span><h3>{esc(t)}</h3><p>{esc(d)}</p></div>' for b,t,d in checks); return shell("System Check",f'<div class="hero"><div class="eyebrow">Stability</div><h1>BuildCommand System Check</h1></div><div class="grid2">{html}</div>')


@app.get("/beta-feedback",response_class=HTMLResponse)
def beta_feedback_page():
    c=db(); rows=c.execute("SELECT b.*,u.display_name FROM beta_feedback b LEFT JOIN users u ON u.id=b.user_id WHERE b.company_id=? ORDER BY b.id DESC LIMIT 20",(current_company_id(),)).fetchall(); c.close(); recent="".join(f'<div class="action"><b>{esc(r["category"])}</b> · {r["rating"]}/5<div>{esc(r["feedback"])}</div><div class="small">{esc(r["display_name"] or "")} · {esc(r["created"])}</div></div>' for r in rows) or '<div class="muted">No beta feedback yet.</div>'; return shell("Beta Feedback",f'''<div class="hero"><div class="eyebrow">Beta Program</div><h1>What should BuildCommand improve next?</h1></div><div class="grid2"><div class="card"><form method="post" action="/beta-feedback"><label>Rating</label><select name="rating"><option value="5">5 - Excellent</option><option value="4">4</option><option value="3">3</option><option value="2">2</option><option value="1">1 - Poor</option></select><label>Category</label><select name="category"><option>FIELD_WORKFLOW</option><option>AI</option><option>SCHEDULE</option><option>MOBILE</option><option>REPORTING</option><option>BUG</option><option>OTHER</option></select><label>Feedback</label><textarea name="feedback" required></textarea><button type="submit">Save Feedback</button></form></div><div class="card"><h2>Recent Feedback</h2>{recent}</div></div>''')


@app.post("/beta-feedback")
def beta_feedback_save(rating:int=Form(...),category:str=Form(...),feedback:str=Form(...)):
    c=db(); c.execute("INSERT INTO beta_feedback(company_id,user_id,project_id,rating,category,feedback,created) VALUES(?,?,?,?,?,?,?)",(current_company_id(),current_user_id(),project_id(),max(1,min(5,rating)),category,feedback.strip(),datetime.utcnow().isoformat())); c.commit(); c.close(); return RedirectResponse("/beta-feedback",status_code=303)


@app.post("/notifications/email-digest")
def notifications_email_digest():
    import smtplib
    from email.message import EmailMessage
    user=current_user(); pid=project_id(); refresh_notifications(pid)
    host=os.environ.get("SMTP_HOST"); sender=os.environ.get("SMTP_FROM"); smtp_user=os.environ.get("SMTP_USER"); smtp_password=os.environ.get("SMTP_PASSWORD"); port=int(os.environ.get("SMTP_PORT","587"))
    if not host or not sender:
        return HTMLResponse(shell("Notifications",'<div class="card"><h2>Email alerts need setup</h2><p>Add SMTP_HOST and SMTP_FROM in Render. If your mail provider requires login, also add SMTP_USER and SMTP_PASSWORD.</p><p><a href="/notifications">Back to Notifications</a></p></div>'),status_code=503)
    c=db(); rows=c.execute("SELECT * FROM notifications WHERE company_id=? AND project_id=? ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'WATCH' THEN 3 ELSE 4 END,id DESC LIMIT 30",(current_company_id(),pid)).fetchall(); c.close()
    lines=[f'{r["severity"]}: {r["title"]} — {r["detail"]}' for r in rows]
    msg=EmailMessage(); msg["Subject"]="BuildCommand AI Alert Digest"; msg["From"]=sender; msg["To"]=user["email"]; msg.set_content("\n".join(lines) or "No active BuildCommand alerts.")
    with smtplib.SMTP(host,port,timeout=15) as smtp:
        smtp.starttls()
        if smtp_user: smtp.login(smtp_user,smtp_password or "")
        smtp.send_message(msg)
    return RedirectResponse("/notifications",status_code=303)


def ensure_today_morning_brief(pid):
    if not pid or not company_setting("auto_ai_brief", 1):
        return
    cid = current_company_id()
    c = db()
    existing = c.execute(
        "SELECT id FROM morning_briefs WHERE company_id=? AND project_id=? AND brief_date=? LIMIT 1",
        (cid, pid, date.today().isoformat()),
    ).fetchone()
    c.close()
    if existing or not os.environ.get("OPENAI_API_KEY") or OpenAI is None:
        return
    try:
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-5.6"),
            instructions=(
                "You are BuildCommand AI. Create a concise superintendent morning brief grounded only in "
                "supplied project data. Use HANDLE FIRST, SCHEDULE THREATS, WHO OWES WHAT, TODAY'S "
                "VERIFICATIONS, COST / CHANGE EXPOSURE, SAFETY / QUALITY."
            ),
            input=build_project_context(pid),
        )
        brief = response.output_text
    except Exception:
        return
    c = db()
    c.execute(
        "INSERT INTO morning_briefs(company_id,project_id,brief_date,brief_text,created) VALUES(?,?,?,?,?)",
        (cid, pid, date.today().isoformat(), brief, datetime.utcnow().isoformat()),
    )
    c.commit()
    c.close()


@app.get("/setup", response_class=HTMLResponse)
def setup_wizard():
    cid = current_company_id()
    ensure_company_settings(cid)
    u = current_user()
    c = db()
    pc = c.execute("SELECT COUNT(*) n FROM projects WHERE company_id=?", (cid,)).fetchone()["n"]
    tc = c.execute("SELECT COUNT(*) n FROM users WHERE company_id=?", (cid,)).fetchone()["n"]
    c.close()
    body = f"""
    <div class="hero"><div class="eyebrow">Customer Setup</div><h1>Finish your BuildCommand workspace.</h1></div>
    <div class="grid2">
      <div class="card"><h2>1. Company</h2><p>{esc(u['company_name'])}</p><a href="/company-settings">Edit Company →</a></div>
      <div class="card"><h2>2. Project</h2><p>{pc} project(s)</p><a href="/projects/new">Add Project →</a></div>
      <div class="card"><h2>3. Team</h2><p>{tc} user(s)</p><a href="/invitations">Invite Team →</a></div>
      <div class="card"><h2>4. Field Setup</h2><a href="/subcontractors">Add Subcontractors →</a><br><a href="/activities/new">Add Schedule Activity →</a></div>
    </div>
    <div class="card"><form method="post" action="/setup/complete"><button type="submit">Finish Setup</button></form></div>
    """
    return shell("Setup", body)


@app.post("/setup/complete")
def setup_complete():
    cid = current_company_id()
    ensure_company_settings(cid)
    c = db()
    c.execute("UPDATE company_settings SET onboarding_complete=1 WHERE company_id=?", (cid,))
    c.commit()
    c.close()
    return RedirectResponse("/", 303)


@app.get("/invitations", response_class=HTMLResponse)
def invitations_page():
    if not require_role("ADMIN"):
        return HTMLResponse("Not authorized.", 403)
    c = db()
    rows = c.execute(
        "SELECT * FROM invitations WHERE company_id=? ORDER BY id DESC LIMIT 30",
        (current_company_id(),),
    ).fetchall()
    c.close()
    hist = "".join(
        f"<div class='action'><b>{esc(r['email'])}</b> · {esc(r['role'])}<div class='small'>{'Accepted' if r['accepted'] else 'Pending'} · Expires {esc(r['expires'])}</div></div>"
        for r in rows
    ) or "<div class='muted'>No invitations yet.</div>"
    form = """
    <div class='card'><h2>Create Invitation</h2><form method='post' action='/invitations'>
    <label>Email</label><input type='email' name='email' required>
    <label>Role</label><select name='role'>
      <option value='READ_ONLY'>Read Only</option><option value='FIELD_USER'>Field User</option>
      <option value='SUPERINTENDENT'>Superintendent</option><option value='PROJECT_MANAGER'>Project Manager</option>
      <option value='ADMIN'>Admin</option>
    </select><button type='submit'>Create Invite</button></form></div>
    """
    return shell(
        "Invitations",
        f"<div class='hero'><div class='eyebrow'>Team Invitations</div><h1>Invite the project team.</h1></div><div class='grid2'>{form}<div class='card'><h2>Recent</h2>{hist}</div></div>",
    )


@app.post("/invitations")
def create_invitation(email: str = Form(...), role: str = Form("FIELD_USER")):
    if not require_role("ADMIN"):
        return HTMLResponse("Not authorized.", 403)
    valid = {"READ_ONLY", "FIELD_USER", "SUPERINTENDENT", "PROJECT_MANAGER", "ADMIN"}
    role = role if role in valid else "FIELD_USER"
    raw = secrets.token_urlsafe(32)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    expires = (datetime.utcnow() + timedelta(days=7)).isoformat()
    c = db()
    c.execute(
        "INSERT INTO invitations(company_id,email,role,token_hash,expires,accepted,created_by,created) VALUES(?,?,?,?,?,?,?,?)",
        (current_company_id(), email.strip().lower(), role, token_hash, expires, 0, current_user_id(), datetime.utcnow().isoformat()),
    )
    c.commit()
    c.close()
    link = f"/accept-invite?token={raw}"
    return HTMLResponse(
        shell(
            "Invitation Created",
            f"<div class='card'><h2>Invitation created</h2><p>Send this link to {esc(email)}. It expires in 7 days.</p><input value='{esc(link)}' readonly><p><a href='/invitations'>Back</a></p></div>",
        )
    )


@app.get("/accept-invite", response_class=HTMLResponse)
def accept_invite_get(token: str):
    th = hashlib.sha256(token.encode()).hexdigest()
    c = db()
    inv = c.execute(
        "SELECT i.*,c.name company_name FROM invitations i JOIN companies c ON c.id=i.company_id WHERE i.token_hash=? AND i.accepted=0 AND i.expires>?",
        (th, datetime.utcnow().isoformat()),
    ).fetchone()
    c.close()
    if not inv:
        return HTMLResponse("Invitation invalid or expired.", 400)
    return f"""
    <!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>{CSS}</style></head>
    <body><main class='main'><div class='card'><h1>Join {esc(inv['company_name'])}</h1>
    <form method='post' action='/accept-invite'><input type='hidden' name='token' value='{esc(token)}'>
    <label>Name</label><input name='display_name' required><label>Password</label><input type='password' name='password' minlength='8' required>
    <button type='submit'>Create Account</button></form></div></main></body></html>
    """


@app.post("/accept-invite")
def accept_invite_post(token: str = Form(...), display_name: str = Form(...), password: str = Form(...)):
    if len(password) < 8:
        return HTMLResponse("Password must be at least 8 characters.", 400)
    th = hashlib.sha256(token.encode()).hexdigest()
    c = db()
    inv = c.execute(
        "SELECT * FROM invitations WHERE token_hash=? AND accepted=0 AND expires>?",
        (th, datetime.utcnow().isoformat()),
    ).fetchone()
    if not inv:
        c.close()
        return HTMLResponse("Invitation invalid or expired.", 400)
    if c.execute("SELECT id FROM users WHERE lower(email)=lower(?)", (inv["email"],)).fetchone():
        c.close()
        return HTMLResponse("Email already registered.", 400)
    c.execute(
        "INSERT INTO users(company_id,email,display_name,password_hash,role,created) VALUES(?,?,?,?,?,?)",
        (inv["company_id"], inv["email"], display_name.strip(), hash_password(password), inv["role"], date.today().isoformat()),
    )
    uid = c.execute("SELECT last_insert_rowid() id").fetchone()["id"]
    c.execute("UPDATE invitations SET accepted=1 WHERE id=?", (inv["id"],))
    fp = c.execute("SELECT id FROM projects WHERE company_id=? ORDER BY id LIMIT 1", (inv["company_id"],)).fetchone()
    if fp:
        c.execute(
            "INSERT INTO user_state(user_id,selected_project_id) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET selected_project_id=excluded.selected_project_id",
            (uid, fp["id"]),
        )
    c.commit()
    c.close()
    raw = create_session(uid)
    resp = RedirectResponse("/", 303)
    resp.set_cookie("bc_session", raw, httponly=True, secure=os.environ.get("COOKIE_SECURE", "1") == "1", samesite="lax", max_age=2592000)
    return resp


@app.get("/production-settings", response_class=HTMLResponse)
def production_settings_page():
    if not require_role("ADMIN"):
        return HTMLResponse("Not authorized.", 403)
    cid = current_company_id()
    ensure_company_settings(cid)
    c = db()
    s = c.execute("SELECT * FROM company_settings WHERE company_id=?", (cid,)).fetchone()
    c.close()
    body = f"""
    <div class='hero'><div class='eyebrow'>Production Controls</div><h1>Automation & beta settings</h1></div>
    <div class='card'><form method='post' action='/production-settings'>
    <label>Automatic AI Morning Brief</label><select name='auto_ai_brief'>
      <option value='1' {'selected' if s['auto_ai_brief'] else ''}>Enabled</option><option value='0' {'selected' if not s['auto_ai_brief'] else ''}>Disabled</option></select>
    <label>Email Alerts</label><select name='email_alerts'>
      <option value='1' {'selected' if s['email_alerts'] else ''}>Enabled</option><option value='0' {'selected' if not s['email_alerts'] else ''}>Disabled</option></select>
    <label>Beta Mode</label><select name='beta_mode'>
      <option value='1' {'selected' if s['beta_mode'] else ''}>Enabled</option><option value='0' {'selected' if not s['beta_mode'] else ''}>Disabled</option></select>
    <button type='submit'>Save Settings</button></form></div>
    """
    return shell("Production Settings", body)


@app.post("/production-settings")
def production_settings_save(auto_ai_brief: int = Form(1), email_alerts: int = Form(0), beta_mode: int = Form(1)):
    if not require_role("ADMIN"):
        return HTMLResponse("Not authorized.", 403)
    cid = current_company_id()
    ensure_company_settings(cid)
    c = db()
    c.execute(
        "UPDATE company_settings SET auto_ai_brief=?,email_alerts=?,beta_mode=? WHERE company_id=?",
        (1 if auto_ai_brief else 0, 1 if email_alerts else 0, 1 if beta_mode else 0, cid),
    )
    c.commit()
    c.close()
    return RedirectResponse("/production-settings", 303)


@app.get("/beta-checklist", response_class=HTMLResponse)
def beta_checklist():
    pid = project_id()
    c = db()
    checks = {
        "Project created": bool(pid),
        "Schedule activity entered": c.execute("SELECT COUNT(*) n FROM activities WHERE project_id=?", (pid,)).fetchone()["n"] > 0 if pid else False,
        "Subcontractor entered": c.execute("SELECT COUNT(*) n FROM subs WHERE project_id=?", (pid,)).fetchone()["n"] > 0 if pid else False,
        "Daily report submitted": c.execute("SELECT COUNT(*) n FROM daily_reports WHERE project_id=?", (pid,)).fetchone()["n"] > 0 if pid else False,
        "Risk entered": c.execute("SELECT COUNT(*) n FROM risks WHERE project_id=?", (pid,)).fetchone()["n"] > 0 if pid else False,
        "AI configured": bool(os.environ.get("OPENAI_API_KEY")),
        "Persistent upload path configured": bool(os.environ.get("UPLOAD_DIR")),
        "PostgreSQL connected": DATABASE_KIND == "postgres",
    }
    c.close()
    complete = sum(1 for v in checks.values() if v)
    html = "".join(
        f"<div class='action'><span class='badge {'READY' if ok else 'WATCH'}'>{'DONE' if ok else 'TODO'}</span> {esc(name)}</div>"
        for name, ok in checks.items()
    )
    return shell(
        "Beta Checklist",
        f"<div class='hero'><div class='eyebrow'>Beta Readiness</div><h1>{complete}/{len(checks)} launch checks complete</h1></div><div class='card'>{html}</div><div class='card'><a href='/beta-feedback'>Record Beta Feedback →</a></div>",
    )


def parse_iso_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except Exception:
        return None


def activity_delay_signal(activity, today=None):
    today = today or date.today()
    start = parse_iso_date(activity["start"])
    finish = parse_iso_date(activity["finish"])
    pct = float(activity["pct"] or 0)
    status = activity["status"] or "NOT_STARTED"
    score, reasons = 0, []
    if finish and finish < today and pct < 100:
        score += 55; reasons.append("finish date has passed")
    if start and start <= today and pct <= 0 and status != "COMPLETE":
        score += 25; reasons.append("scheduled start has passed with 0% complete")
    if start and finish and start <= today <= finish:
        total = max(1, (finish-start).days+1)
        elapsed = max(0, (today-start).days+1)
        expected = min(100, elapsed/total*100)
        if pct + 15 < expected:
            variance = expected-pct
            score += min(35, 10 + variance*.6)
            reasons.append(f"progress trails time-elapsed plan by about {variance:.0f} points")
    score = min(100, int(round(score)))
    band = "CRITICAL" if score >= 70 else "HIGH" if score >= 45 else "WATCH" if score >= 20 else "READY"
    return score, band, reasons


def procurement_warning_signal(row):
    required, promised = parse_iso_date(row["required_on_site"]), parse_iso_date(row["promised_date"])
    status, today = (row["status"] or "NOT_RELEASED").upper(), date.today()
    score, reasons = 0, []
    if status == "DELIVERED": return 0, "READY", ["delivered"]
    if not required: score += 20; reasons.append("required-on-site date missing")
    if not promised: score += 45; reasons.append("promised date missing")
    elif required and promised > required:
        late=(promised-required).days; score += min(80,45+late*4); reasons.append(f"promised date is {late} day(s) after required date")
    if required:
        days=(required-today).days
        if days < 0: score += 30; reasons.append("required-on-site date has passed")
        elif days <= 7 and status not in ["SHIPPED","DELIVERED"]: score += 25; reasons.append("needed within 7 days and not shipped")
        elif days <= 21 and status in ["NOT_RELEASED","RELEASED"]: score += 12; reasons.append("needed within 3 weeks and not yet in fabrication/shipping")
    score=min(100,score)
    band="CRITICAL" if score>=70 else "HIGH" if score>=45 else "WATCH" if score>=20 else "READY"
    return score,band,reasons or ["no procurement warning detected"]


def project_health_snapshot(pid):
    c=db()
    activities=c.execute("SELECT * FROM activities WHERE project_id=?",(pid,)).fetchall()
    risks=c.execute("SELECT * FROM risks WHERE project_id=?",(pid,)).fetchall()
    actions=c.execute("SELECT * FROM action_items WHERE project_id=? AND status='OPEN'",(pid,)).fetchall()
    issues=c.execute("SELECT * FROM project_issues WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchall()
    procurement=c.execute("SELECT * FROM procurement WHERE project_id=? AND status!='DELIVERED'",(pid,)).fetchall()
    readiness=c.execute("SELECT * FROM activity_readiness WHERE project_id=?",(pid,)).fetchall()
    safety=c.execute("SELECT * FROM safety_items WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchall()
    inspections=c.execute("SELECT * FROM inspections_tracker WHERE project_id=? AND result!='PASSED'",(pid,)).fetchall(); c.close()
    today=date.today()
    overdue_actions=sum(1 for x in actions if parse_iso_date(x["due"]) and parse_iso_date(x["due"])<today)
    overdue_issues=sum(1 for x in issues if parse_iso_date(x["due"]) and parse_iso_date(x["due"])<today)
    delay_risk=sum(activity_delay_signal(a)[0] for a in activities)/len(activities) if activities else 0
    risk_exp=sum(float(r["score"] or 0) for r in risks)/len(risks) if risks else 0
    proc_exp=sum(procurement_warning_signal(p)[0] for p in procurement)/len(procurement) if procurement else 0
    ready_pct=sum(readiness_result(r)[0] for r in readiness)/len(readiness) if readiness else (50 if activities else 100)
    safety_penalty=sum(25 if s["severity"]=="CRITICAL" else 15 if s["severity"]=="HIGH" else 7 for s in safety)
    inspection_penalty=sum(18 if i["result"]=="FAILED" else 7 for i in inspections)
    scores={"schedule":max(0,100-delay_risk),"readiness":max(0,min(100,ready_pct)),"procurement":max(0,100-proc_exp),"risk":max(0,100-risk_exp),"field":max(0,100-min(45,overdue_actions*6+overdue_issues*7)-min(35,safety_penalty+inspection_penalty))}
    overall=round(scores["schedule"]*.28+scores["readiness"]*.22+scores["procurement"]*.18+scores["risk"]*.17+scores["field"]*.15)
    return {"overall":overall,**{k:round(v) for k,v in scores.items()},"overdue_actions":overdue_actions,"overdue_issues":overdue_issues}


@app.get("/project-health", response_class=HTMLResponse)
def project_health_page():
    h=project_health_snapshot(project_id())
    badge,label=("READY","Healthy") if h["overall"]>=85 else ("WATCH","Watch") if h["overall"]>=70 else ("HIGH","At Risk") if h["overall"]>=50 else ("CRITICAL","Critical")
    return shell("Project Health",f'<div class="hero"><div class="eyebrow">Executive Project Health</div><h1>{h["overall"]}/100 <span class="badge {badge}">{label}</span></h1></div><div class="grid4"><div class="card"><div class="label">Schedule</div><div class="kpi">{h["schedule"]}</div></div><div class="card"><div class="label">Readiness</div><div class="kpi">{h["readiness"]}</div></div><div class="card"><div class="label">Procurement</div><div class="kpi">{h["procurement"]}</div></div><div class="card"><div class="label">Risk</div><div class="kpi">{h["risk"]}</div></div></div><div class="card"><h2>Field Execution {h["field"]}</h2><p>Overdue actions: {h["overdue_actions"]} · Overdue RFIs/issues: {h["overdue_issues"]}</p></div>')


@app.get("/lookahead-intelligence", response_class=HTMLResponse)
def lookahead_intelligence_page():
    pid=project_id(); today=date.today(); horizon=today+timedelta(days=21); c=db()
    activities=c.execute("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,)).fetchall(); readiness_rows=c.execute("SELECT * FROM activity_readiness WHERE project_id=?",(pid,)).fetchall(); procurement=c.execute("SELECT * FROM procurement WHERE project_id=? AND status!='DELIVERED'",(pid,)).fetchall(); inspections=c.execute("SELECT * FROM inspections_tracker WHERE project_id=? AND result!='PASSED'",(pid,)).fetchall(); issues=c.execute("SELECT * FROM project_issues WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchall(); c.close()
    rm={r["activity_id"]:r for r in readiness_rows}; pm={}; im={}; qm={}
    for p in procurement: pm.setdefault(p["activity_id"],[]).append(p)
    for i in inspections: im.setdefault(i["activity_id"],[]).append(i)
    for q in issues: qm.setdefault(q["activity_id"],[]).append(q)
    cards=''
    for a in activities:
        start,finish=parse_iso_date(a["start"]),parse_iso_date(a["finish"])
        if not start or (finish and finish<today) or start>horizon: continue
        rp,rs=(0,"NOT REVIEWED")
        if a["id"] in rm: rp,rs,_=readiness_result(rm[a["id"]])
        blockers=[]
        if rs in ["NOT READY","AT RISK","NOT REVIEWED"]: blockers.append(f"Readiness {rp}%")
        for p in pm.get(a["id"],[]):
            _,b,_=procurement_warning_signal(p)
            if b!="READY": blockers.append(f"Procurement: {p['item']} ({b})")
        for i in im.get(a["id"],[]): blockers.append(f"Inspection: {i['inspection_type']} ({i['result']})")
        for q in qm.get(a["id"],[]): blockers.append(f"{q['issue_type']}: {q['title']}")
        _,dband,_=activity_delay_signal(a)
        if dband!="READY": blockers.append(f"Schedule: {dband}")
        days=(start-today).days; timing="STARTED / DUE NOW" if days<=0 else f"Starts in {days} day(s)"; badge="READY" if not blockers else "CRITICAL" if any("CRITICAL" in b for b in blockers) else "WATCH"
        bh=''.join(f'<div class="small">• {esc(b)}</div>' for b in blockers) or '<div class="small">No major blocker detected.</div>'
        cards+=f'<div class="card"><span class="badge {badge}">{timing}</span><h3>{esc(a["external_id"])} - {esc(a["name"])}</h3><p>Readiness: {rp}%</p>{bh}</div>'
    return shell("3-Week Lookahead",f'<div class="hero"><div class="eyebrow">3-Week Lookahead Intelligence</div><h1>Upcoming work + blockers</h1><div class="muted">{today} through {horizon}</div></div><div class="grid2">{cards or "<div class=card>No activities in the next 21 days.</div>"}</div>')


@app.get("/sub-scorecards", response_class=HTMLResponse)
def subcontractor_scorecards_page():
    pid=project_id(); c=db(); subs=c.execute("SELECT * FROM subs WHERE project_id=? ORDER BY trade,name",(pid,)).fetchall(); updates=c.execute("SELECT * FROM subcontractor_updates WHERE project_id=? ORDER BY update_date DESC,id DESC",(pid,)).fetchall(); punch=c.execute("SELECT * FROM punch_items WHERE project_id=? AND status!='VERIFIED'",(pid,)).fetchall(); safety=c.execute("SELECT * FROM safety_items WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchall(); actions=c.execute("SELECT * FROM action_items WHERE project_id=? AND status='OPEN'",(pid,)).fetchall(); c.close(); today=date.today(); cards=''
    for s in subs:
        su=[u for u in updates if u["sub_id"]==s["id"]]; latest=su[0] if su else None; score=100; reasons=[]
        if not latest: score-=20; reasons.append("no recent subcontractor update")
        else:
            st=(latest["status"] or "").upper(); score-=35 if st=="CRITICAL" else 22 if st=="HIGH" else 10 if st=="WATCH" else 0
            if st in ["CRITICAL","HIGH","WATCH"]: reasons.append(f"latest status: {st}")
            if (latest["manpower"] or 0)<=0: score-=12; reasons.append("latest manpower is zero")
        name=(s["name"] or "").lower(); trade=(s["trade"] or "").lower(); op=sum(1 for p in punch if (name and name in (p["owner"] or "").lower()) or (trade and trade in (p["trade"] or "").lower())); osf=sum(1 for x in safety if name and name in (x["responsible_party"] or "").lower()); oa=sum(1 for a in actions if name and name in (a["owner"] or "").lower() and parse_iso_date(a["due"]) and parse_iso_date(a["due"])<today)
        if op: score-=min(20,op*4); reasons.append(f"{op} open punch item(s)")
        if osf: score-=min(25,osf*8); reasons.append(f"{osf} open safety item(s)")
        if oa: score-=min(20,oa*6); reasons.append(f"{oa} overdue action(s)")
        score=max(0,score); grade="A" if score>=90 else "B" if score>=80 else "C" if score>=65 else "D" if score>=50 else "F"; badge="READY" if score>=80 else "WATCH" if score>=65 else "HIGH" if score>=50 else "CRITICAL"; rh=''.join(f'<div class="small">• {esc(r)}</div>' for r in reasons) or '<div class="small">No major negative signal detected.</div>'; cards+=f'<div class="card"><span class="badge {badge}">Grade {grade}</span><h3>{esc(s["name"])}</h3><div class="muted">{esc(s["trade"])}</div><div class="kpi">{score}</div>{rh}</div>'
    return shell("Subcontractor Scorecards",f'<div class="hero"><div class="eyebrow">Trade Partner Intelligence</div><h1>Subcontractor Scorecards</h1></div><div class="grid3">{cards or "<div class=card>Add subcontractors to generate scorecards.</div>"}</div>')


@app.get("/rfi-impact", response_class=HTMLResponse)
def rfi_impact_page():
    pid=project_id(); c=db(); issues=c.execute("""SELECT i.*,a.external_id,a.name activity,a.start activity_start FROM project_issues i LEFT JOIN activities a ON a.id=i.activity_id WHERE i.project_id=? AND i.status!='CLOSED' ORDER BY i.due,i.id""",(pid,)).fetchall(); activities=c.execute("SELECT * FROM activities WHERE project_id=? ORDER BY start",(pid,)).fetchall(); c.close(); cards=''; today=date.today()
    for i in issues:
        ls=parse_iso_date(i["activity_start"]) if i["activity_start"] else None; impacted=[a for a in activities if ls and parse_iso_date(a["start"]) and parse_iso_date(a["start"])>=ls and a["id"]!=i["activity_id"]]; due=parse_iso_date(i["due"]); score=20+(40 if i["priority"]=="CRITICAL" else 25 if i["priority"]=="HIGH" else 0)+(25 if due and due<today else 0)+(20 if ls and (ls-today).days<=14 else 0); score=min(100,score); badge="CRITICAL" if score>=70 else "HIGH" if score>=45 else "WATCH"; impact=', '.join(f'{a["external_id"]} {a["name"]}' for a in impacted[:4]) or 'No downstream activity inferred from date order.'; cards+=f'<div class="card"><span class="badge {badge}">Impact {score}</span><h3>{esc(i["title"])}</h3><p>Linked: {esc(i["external_id"] or "None")} {esc(i["activity"] or "")}</p><p>Possible downstream exposure: {esc(impact)}</p></div>'
    return shell("RFI Impact",f'<div class="hero"><div class="eyebrow">RFI Impact Intelligence</div><h1>Which questions can move the schedule?</h1></div><div class="grid2">{cards or "<div class=card>No open RFIs/issues.</div>"}</div>')


@app.get("/procurement-warning", response_class=HTMLResponse)
def procurement_warning_page():
    pid=project_id(); c=db(); rows=c.execute("""SELECT p.*,a.external_id,a.name activity FROM procurement p LEFT JOIN activities a ON a.id=p.activity_id WHERE p.project_id=? AND p.status!='DELIVERED' ORDER BY p.required_on_site,p.id""",(pid,)).fetchall(); c.close(); scored=sorted([(procurement_warning_signal(r)[0],procurement_warning_signal(r)[1],r,procurement_warning_signal(r)[2]) for r in rows],key=lambda x:x[0],reverse=True); cards=''
    for score,band,r,reasons in scored: cards+=f'<div class="card"><span class="badge {band}">{band} · {score}</span><h3>{esc(r["item"])}</h3><p>Required: {esc(r["required_on_site"] or "—")} · Promised: {esc(r["promised_date"] or "—")}</p>'+''.join(f'<div class="small">• {esc(x)}</div>' for x in reasons)+'</div>'
    return shell("Procurement Warning",f'<div class="hero"><div class="eyebrow">Procurement Early Warning</div><h1>Material threats ranked before installation.</h1></div><div class="grid2">{cards or "<div class=card>No open procurement items.</div>"}</div>')


def recovery_options_for_activity(activity,delay_score):
    if delay_score<20: return [("Protect Plan",0,0,"No major delay signal. Protect access, material, and inspection readiness.")]
    return [("Add targeted manpower",min(3.0,max(1.0,delay_score/30)),2500+delay_score*35,"Increase manpower only after constraints are cleared."),("Second shift / extended hours",min(5.0,max(1.5,delay_score/22)),4500+delay_score*55,"Use where supervision and site rules allow."),("Resequence downstream work",min(4.0,max(1.0,delay_score/25)),1500+delay_score*20,"Advance unaffected work while the constraint is removed.")]


@app.get("/ai-recovery", response_class=HTMLResponse)
def ai_recovery_page():
    pid=project_id(); c=db(); acts=c.execute("SELECT * FROM activities WHERE project_id=? AND status!='COMPLETE' ORDER BY start",(pid,)).fetchall(); c.close(); scored=sorted([(activity_delay_signal(a)[0],activity_delay_signal(a)[1],a) for a in acts],key=lambda x:x[0],reverse=True); cards=''
    for score,band,a in scored[:6]:
        opts=recovery_options_for_activity(a,score); oh=''.join(f'<div class="action"><b>{esc(n)}</b><div class="small">Estimated recovery: {d:.1f} day(s) · ROM cost: ${cst:,.0f}</div><div class="small">{esc(note)}</div></div>' for n,d,cst,note in opts); n,d,cst,_=opts[0]; cards+=f'<div class="card"><span class="badge {band}">Delay Signal {score}</span><h3>{esc(a["external_id"])} - {esc(a["name"])}</h3>{oh}<form method="post" action="/ai-recovery/save"><input type="hidden" name="activity_id" value="{a["id"]}"><input type="hidden" name="scenario" value="{esc(n)}"><input type="hidden" name="days_recovered" value="{d}"><input type="hidden" name="est_cost" value="{cst}"><button type="submit">Save Top Recovery Option</button></form></div>'
    return shell("AI Recovery Planner",f'<div class="hero"><div class="eyebrow">Recovery Intelligence</div><h1>What can we do when work drifts?</h1><div class="muted">ROM planning aid—field validation required.</div></div><div class="grid2">{cards}</div>')


@app.post("/ai-recovery/save")
def save_ai_recovery(activity_id:int=Form(...),scenario:str=Form(...),days_recovered:float=Form(0),est_cost:float=Form(0)):
    pid=project_id(); c=db(); c.execute("INSERT INTO recovery(project_id,activity_id,scenario,days_recovered,est_cost,status) VALUES(?,?,?,?,?,'PROPOSED')",(pid,activity_id,scenario,days_recovered,est_cost)); c.commit(); c.close(); return RedirectResponse('/ai-recovery',status_code=303)


@app.get("/quick-entry", response_class=HTMLResponse)
def quick_entry_page():
    pid=project_id(); c=db(); rows=c.execute("SELECT * FROM quick_entries WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 15",(current_company_id(),pid)).fetchall(); c.close(); recent=''.join(f'<div class="action"><b>{esc(r["entry_type"])}</b> → {esc(r["routed_to"])}<div>{esc(r["text"])}</div></div>' for r in rows) or '<div class="muted">No quick entries yet.</div>'; body=f'''<div class="hero"><div class="eyebrow">Superintendent Quick Entry</div><h1>Say it once. Route it where it belongs.</h1></div><div class="grid2"><div class="card"><form method="post" action="/quick-entry"><label>Route As</label><select name="entry_type"><option value="AUTO">Auto Detect</option><option value="ACTION">Action</option><option value="FIELD_UPDATE">Field Update</option><option value="RFI">RFI / Issue</option><option value="SAFETY">Safety Observation</option></select><label>Field Note</label><textarea id="quickText" name="text" required></textarea><button type="button" onclick="startBuildCommandVoice()">Speak</button><button type="submit">Route Entry</button></form></div><div class="card"><h2>Recent Quick Entries</h2>{recent}</div></div><script>function startBuildCommandVoice(){{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){{alert('Voice recognition is not supported by this browser.');return;}}const rec=new SR();rec.lang='en-US';rec.onresult=function(e){{document.getElementById('quickText').value=e.results[0][0].transcript;}};rec.start();}}</script>'''; return shell("Quick Entry",body)


@app.post("/quick-entry")
def save_quick_entry(entry_type:str=Form("AUTO"),text:str=Form(...)):
    pid=project_id(); raw=text.strip(); low=raw.lower(); detected=entry_type
    if detected=="AUTO": detected="SAFETY" if any(k in low for k in ["unsafe","safety","guardrail","near miss","incident"]) else "RFI" if any(k in low for k in ["rfi","question","clarify","design","drawing conflict"]) else "ACTION" if any(k in low for k in ["need to","follow up","confirm","call","send","by friday","by tomorrow"]) else "FIELD_UPDATE"
    c=db(); routed=detected
    if detected=="ACTION": c.execute("INSERT INTO action_items(project_id,title,owner,priority,due,status,notes,created) VALUES(?,?,?,?,?,'OPEN',?,?)",(pid,raw[:140],"Superintendent","WATCH",date.today().isoformat(),raw,date.today().isoformat())); routed="Action Center"
    elif detected=="RFI": c.execute("INSERT INTO project_issues(project_id,activity_id,issue_type,title,owner,due,priority,status,description,response,created) VALUES(?,NULL,'FIELD_ISSUE',?,'',?,'WATCH','OPEN',?,'',?)",(pid,raw[:140],date.today().isoformat(),raw,date.today().isoformat())); routed="RFIs / Issues"
    elif detected=="SAFETY": c.execute("INSERT INTO safety_items(project_id,activity_id,event_date,item_type,title,location,responsible_party,severity,status,description,corrective_action,created) VALUES(?,NULL,?,'OBSERVATION',?,'','','WATCH','OPEN',?,'',?)",(pid,date.today().isoformat(),raw[:140],raw,date.today().isoformat())); routed="Safety"
    else: c.execute("INSERT INTO field_updates(project_id,activity_id,update_type,text,created) VALUES(?,NULL,'QUICK_ENTRY',?,?)",(pid,raw,date.today().isoformat())); routed="Field Updates"
    c.execute("INSERT INTO quick_entries(company_id,project_id,user_id,entry_type,text,routed_to,created) VALUES(?,?,?,?,?,?,?)",(current_company_id(),pid,current_user_id(),detected,raw,routed,datetime.utcnow().isoformat())); c.commit(); c.close(); return RedirectResponse('/quick-entry',status_code=303)


@app.get("/weekly-report", response_class=HTMLResponse)
def weekly_report_page():
    pid=project_id(); c=db(); row=c.execute("SELECT * FROM weekly_ai_reports WHERE company_id=? AND project_id=? ORDER BY id DESC LIMIT 1",(current_company_id(),pid)).fetchone(); c.close(); report=esc(row["report_text"]).replace("\n","<br>") if row else "No weekly AI report generated yet."; return shell("Weekly AI Report",f'<div class="hero"><div class="eyebrow">Owner / PM Reporting</div><h1>AI Weekly Project Report</h1></div><div class="card"><form method="post" action="/weekly-report/generate"><button type="submit">Generate Weekly Report</button></form></div><div class="card">{report}</div>')


@app.post("/weekly-report/generate")
def generate_weekly_report():
    pid=project_id(); context=build_project_context(pid); health=project_health_snapshot(pid); key=os.environ.get("OPENAI_API_KEY")
    if key:
        instructions=f'''You are BuildCommand AI producing a professional weekly construction project report for an owner/project manager. Use only supplied project facts. Project health score: {health["overall"]}/100. Use sections: EXECUTIVE SUMMARY, SCHEDULE, FIELD PROGRESS, RFIs / DECISIONS, PROCUREMENT, SAFETY / QUALITY, CHANGE EXPOSURE, TOP PRIORITIES NEXT WEEK. Do not invent facts, commitments, costs, or dates.'''
        try: report=OpenAI(api_key=key).responses.create(model=os.environ.get("OPENAI_MODEL","gpt-5.6"),instructions=instructions,input=context).output_text
        except Exception as exc: report=f"AI weekly report failed: {exc}"
    else: report=f"Project Health: {health['overall']}/100\nOPENAI_API_KEY is not configured."
    c=db(); c.execute("INSERT INTO weekly_ai_reports(company_id,project_id,week_ending,report_text,created) VALUES(?,?,?,?,?)",(current_company_id(),pid,date.today().isoformat(),report,datetime.utcnow().isoformat())); c.commit(); c.close(); return RedirectResponse('/weekly-report',status_code=303)


@app.get("/ai-command", response_class=HTMLResponse)
def ai_command_page():
    pid=project_id(); h=project_health_snapshot(pid); c=db(); acts=c.execute("SELECT * FROM activities WHERE project_id=? AND status!='COMPLETE'",(pid,)).fetchall(); actions=c.execute("SELECT * FROM action_items WHERE project_id=? AND status='OPEN'",(pid,)).fetchall(); procs=c.execute("SELECT * FROM procurement WHERE project_id=? AND status!='DELIVERED'",(pid,)).fetchall(); issues=c.execute("SELECT * FROM project_issues WHERE project_id=? AND status!='CLOSED'",(pid,)).fetchall(); c.close(); sig=[]; today=date.today()
    for a in acts:
        s,b,r=activity_delay_signal(a)
        if b!="READY": sig.append((s,b,"Schedule",f'{a["external_id"]} {a["name"]}',"; ".join(r)))
    for p in procs:
        s,b,r=procurement_warning_signal(p)
        if b!="READY": sig.append((s,b,"Procurement",p["item"],"; ".join(r)))
    for a in actions:
        d=parse_iso_date(a["due"])
        if d and d<today: sig.append((65,a["priority"] or "HIGH","Action",a["title"],f'Overdue · Owner {a["owner"] or "Unassigned"}'))
    for i in issues:
        d=parse_iso_date(i["due"])
        if d and d<today: sig.append((70,i["priority"] or "HIGH",i["issue_type"],i["title"],"Response/decision overdue"))
    sig.sort(key=lambda x:x[0],reverse=True); sh=''.join(f'<div class="action"><span class="badge {b if b in ["CRITICAL","HIGH","WATCH","READY","LOW"] else "HIGH"}">{esc(cat)}</span> <b>{esc(t)}</b><div class="small">{esc(d)}</div></div>' for _,b,cat,t,d in sig[:12]) or '<div class="muted">No major automated warning signals detected.</div>'; return shell("AI Command",f'<div class="hero"><div class="eyebrow">AI Daily Command Center</div><h1>Project Health {h["overall"]}/100</h1></div><div class="grid2"><div class="card"><h2>Handle First</h2>{sh}</div><div class="card"><h2>Command Tools</h2><p><a href="/lookahead-intelligence">3-Week Lookahead</a></p><p><a href="/ai-recovery">Recovery Planner</a></p><p><a href="/quick-entry">Quick / Voice Entry</a></p><p><a href="/weekly-report">Weekly AI Report</a></p></div></div>')


def _attachment_text(row):
    if not row:
        return ""
    path=os.path.join(UPLOAD_DIR,row["stored_name"])
    ext=Path(row["original_name"] or "").suffix.lower()
    if not os.path.isfile(path):
        return ""
    try:
        if ext in {".txt",".csv",".md"}:
            return Path(path).read_text(errors="ignore")[:250000]
        if ext==".pdf" and PdfReader is not None:
            return "\n".join((p.extract_text() or "") for p in PdfReader(path).pages[:250])[:350000]
        if ext in {".xlsx",".xlsm"} and openpyxl is not None:
            wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
            lines=[]
            for ws in wb.worksheets[:30]:
                lines.append("SHEET: "+ws.title)
                for vals in ws.iter_rows(values_only=True):
                    lines.append(" | ".join("" if v is None else str(v) for v in vals))
                    if len(lines)>25000:
                        break
            return "\n".join(lines)[:350000]
    except Exception:
        return ""
    return ""


def _blueprint_json(text_value):
    raw=(text_value or "").strip()
    if raw.startswith("```"):
        raw=re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw=re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except Exception:
        m=re.search(r"\{.*\}",raw,re.S)
        if m:
            return json.loads(m.group(0))
        raise ValueError("Blueprint Brain returned a response that was not valid JSON.")


def _blueprint_scope_text(trade_data):
    lines=[]
    summary=(trade_data.get("summary") or "").strip()
    if summary:
        lines.append(summary)
        lines.append("")
    for i,item in enumerate(trade_data.get("items") or [],1):
        req=(item.get("requirement") or "").strip()
        if not req:
            continue
        src=[]
        if item.get("source_sheet"): src.append("Sheet "+str(item.get("source_sheet")))
        if item.get("source_detail"): src.append("Detail "+str(item.get("source_detail")))
        if item.get("source_spec"): src.append("Spec "+str(item.get("source_spec")))
        conf=(item.get("confidence") or "MEDIUM").upper()
        line=f"{i}. {req}"
        if src: line += " ["+" · ".join(src)+"]"
        line += f" — Confidence: {conf}"
        lines.append(line)
    return "\n".join(lines).strip()


def _blueprint_prompt(source_names):
    return f"""
You are the BuildCommand AI Blueprint Brain, a construction-document scope intelligence engine.

SOURCE FILES:
{source_names}

MISSION:
Read the supplied project plans/specifications as one coordinated construction package. Build a trade-by-trade scope of work by finding requirements wherever they appear, including requirements that belong to one trade but are written on another discipline's sheets.

NON-NEGOTIABLE RULES:
1. Use only information supported by the supplied files. Never invent drawing numbers, details, spec sections, quantities, equipment, code requirements, or responsibilities.
2. A requirement may be assigned to a trade even when it is found on another discipline's sheet. Mark those as CROSS_DISCIPLINE.
3. Every scope item must preserve the best available source: sheet number, detail, spec section, note, or filename. If a source cannot be identified, use an empty string and lower the confidence.
4. Distinguish explicit requirements from coordination inferences. Use item_type values SCOPE, CROSS_DISCIPLINE, COORDINATION, EXCLUSION_REVIEW, or RFI_CANDIDATE.
5. Flag contradictions, missing information, equipment with unclear power/plumbing/HVAC connections, unclear trade responsibility, and likely scope gaps as RFI candidates. Do not resolve ambiguity by guessing.
6. Include all detected trades, not only MEP. Typical trades can include demolition, earthwork, concrete, masonry, structural steel, rough carpentry, millwork, waterproofing, roofing, doors/frames/hardware, glazing, framing/drywall, ceilings, flooring, tile, painting, specialties, equipment, furnishings, fire sprinkler, plumbing, HVAC, controls, electrical, fire alarm, low voltage, security, site utilities, paving, landscaping, and others actually supported by the documents.
7. Phrase each requirement as an actionable subcontractor scope item suitable for GC review. Do not claim the generated scope replaces the signed subcontract, specifications, addenda, RFIs, or professional design review.
8. Confidence must be HIGH, MEDIUM, or LOW based on source clarity.
9. Trade ownership rules: resilient/rubber/vinyl base and resilient flooring belong to Flooring, not Framing/Drywall.
10. Demolition is system-owned: electrical demolition belongs to Electrical, plumbing demolition to Plumbing, HVAC/mechanical demolition to HVAC/Mechanical, fire sprinkler demolition to Fire Sprinkler, fire alarm demolition to Fire Alarm, and low-voltage/security demolition to the applicable systems trade. Only non-system/general demolition belongs to Demolition.

Return ONLY valid JSON using exactly this top-level structure:
{{
  "project_summary": "short summary grounded in the documents",
  "detected_disciplines": ["Architectural", "Electrical"],
  "trade_scopes": [
    {{
      "trade": "Electrical",
      "division": "26",
      "summary": "short trade scope overview",
      "items": [
        {{
          "requirement": "actionable scope requirement",
          "source_sheet": "E2.1",
          "source_detail": "3/E5.2",
          "source_spec": "26 05 00",
          "source_note": "General Note 7",
          "related_trade": "Mechanical",
          "confidence": "HIGH",
          "item_type": "CROSS_DISCIPLINE"
        }}
      ]
    }}
  ],
  "cross_discipline_flags": ["plain-language flag with source"],
  "rfi_candidates": ["plain-language ambiguity/gap with source"],
  "review_notes": ["items the GC should verify before issuing scopes"]
}}

IMPORTANT TRADE OWNERSHIP:
Classify by the actual work/material/system, not by which drawing sheet contains the note.
If one note contains work for multiple trades, split it into separate scope items and keep the same source sheet/detail/spec reference on each.
Wall/gypsum/drywall patching = Framing / Drywall. Paint/refinish after patch = Painting.
Doors, door frames, hollow-metal/wood doors and hardware = Doors / Frames / Hardware.
Door rough openings, jamb studs and header framing = Framing / Drywall.
Tile materials/installation = Tile. Metal studs/framing = Framing / Drywall even when shown in a tile detail.
MEP demolition stays with the responsible MEP trade. General non-MEP demolition = Demolition.
""".strip()


V33_TRADES = [
    "Demolition","Earthwork","Concrete","Masonry","Structural Steel","Rough Carpentry",
    "Millwork","Waterproofing","Roofing","Doors / Frames / Hardware","Storefront / Glazing",
    "Framing / Drywall","Ceilings","Flooring / Tile","Painting","Toilet / Bath Accessories",
    "Specialties","Equipment","Furnishings","Fire Sprinkler","Plumbing","HVAC / Mechanical",
    "Controls","Electrical","Fire Alarm","Low Voltage","Security","Site Utilities",
    "Paving","Landscaping","Unassigned"
]


def _v33_normalize_trade(name):
    n=(name or "").strip().lower()
    aliases={
        "mechanical":"HVAC / Mechanical","hvac":"HVAC / Mechanical",
        "hvac/mechanical":"HVAC / Mechanical","mechanical / hvac":"HVAC / Mechanical",
        "drywall":"Framing / Drywall","framing":"Framing / Drywall","framing/drywall":"Framing / Drywall",
        "doors/frames/hardware":"Doors / Frames / Hardware","door hardware":"Doors / Frames / Hardware",
        "storefront":"Storefront / Glazing","glazing":"Storefront / Glazing",
        "glazing/storefront":"Storefront / Glazing","glazing / storefront":"Storefront / Glazing",
        "storefront/glazing":"Storefront / Glazing","storefront / glazing":"Storefront / Glazing",
        "tile":"Flooring / Tile","flooring":"Flooring / Tile","flooring/tile":"Flooring / Tile",
        "tile/flooring":"Flooring / Tile","flooring / tile":"Flooring / Tile","tile / flooring":"Flooring / Tile",
        "bath accessories":"Toilet / Bath Accessories","bathroom accessories":"Toilet / Bath Accessories",
        "toilet accessories":"Toilet / Bath Accessories","toilet room accessories":"Toilet / Bath Accessories",
        "toilet / bath accessories":"Toilet / Bath Accessories",
        "fire sprinkler":"Fire Sprinkler","sprinkler":"Fire Sprinkler","fire alarm":"Fire Alarm",
        "low voltage":"Low Voltage","low-voltage":"Low Voltage","electrical":"Electrical",
        "plumbing":"Plumbing","demolition":"Demolition","demo":"Demolition"
    }
    return aliases.get(n, (name or "Unassigned").strip() or "Unassigned")

